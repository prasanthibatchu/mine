﻿using DevExpress.Diagram.Core;
using DevExpress.Diagram.Core.Native;
using DevExpress.Spreadsheet;
using DevExpress.Utils;
using DevExpress.Utils.DragDrop;
using DevExpress.XtraDiagram;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Tile;
using DevExpress.XtraGrid.Views.Tile.ViewInfo;
using DevExpress.XtraSplashScreen;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using YSECIT.HRMS.APIHandler;
using YSECIT.HRMS.CommonClasses;
using YSECIT.HRMS.MessageForm;
using YSECIT.HRMS.Model;
using YSECIT.HRMS.Utility;

using static YSECIT.HRMS.MessageForm.DropRelation;
using Label = System.Windows.Forms.Label;

namespace YSECIT.HRMS.Forms.Home
{
    public partial class Frm_Teams : DevExpress.XtraEditors.XtraForm
    {
        private int iTeamId;
        private bool bLoading;
        private readonly TeamAPI teamAPI;
        private readonly Panel _emptyDropPanel;
        private List<TempTeamMember> TeamList = new();
        private List<TeamEmployeeModel> objEmp = new();
        private List<TeamListModel> TList = new();
        private DiagramContainer SelectedContainer;
        private bool AddView = false;
        private bool IsOrgChart = false;

        private class TempTeamMember
        {
            public string? TeamName { get; set; }
            public int TeamNumber { get; set; }
            public int ContactId { get; set; }
            public int ParentId { get; set; }
            public string? FullName { get; set; }
            public int LevelId { get; set; }
            public int MergedContactId { get; set; }
            public string? Position { get; set; }
            public int TypeId { get; set; }
            public int RefTeamId { get; set; }
            public bool IsOrgChart { get; set; }
            public byte[]? EmployeeImage { get; set; }
        }


        public Frm_Teams()
        {
            InitializeComponent();

            SelectedContainer = new DiagramContainer();
            teamAPI = new TeamAPI();
            iTeamId = 0;
            bLoading = true;

            _emptyDropPanel = new Panel
            {
                BackColor = System.Drawing.Color.Transparent,
                AllowDrop = true,
                Visible = false,
                Dock = DockStyle.Fill,
                Parent = GrpTeams,
            };

            InitalSettings();

            //DiagTeam.ItemBoundsChanged += DiagTeam_ItemBoundsChanged;

        }

        private void InitalSettings()
        {
            _emptyDropPanel.BringToFront();
            _emptyDropPanel.DragEnter += EmptyDropPanel_DragEnter;
            _emptyDropPanel.DragDrop += EmptyDropPanel_DragDrop;

            Label lblDropHint = new()
            {
                Text = "Drag employees here to start building the team.",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = System.Drawing.Color.Gray,
                Font = new Font("Tahoma", 11, FontStyle.Italic)
            };
            _emptyDropPanel.Controls.Add(lblDropHint);

            DiagTeam.AllowDrop = true;

            DiagTeam.OptionsView.ShowGrid = false;
            DiagTeam.OptionsView.ShowPageBreaks = false;
            DiagTeam.BackColor = Color.White;
            DiagTeam.OptionsView.ShowRulers = false;
        }
        private void Frm_Teams_Load(object sender, EventArgs e)
        {
            if (SplashScreenManager.Default != null && SplashScreenManager.Default.IsSplashFormVisible)
                SplashScreenManager.CloseForm();

            BtnSave.Enabled = BtnAdd.Enabled = CommonMethods.ObjectAuthentication("Frm_Teams_Insert");
            BtnExport.Enabled = CommonMethods.ObjectAuthentication("Frm_Teams_Print");

            LoadTeamHistory();
            LoadTeams();
            ClearForm();
            bLoading = false;
        }


        private async void LoadTeamHistory()
        {
            try
            {
                DataSet objds = await teamAPI.GetAllTeams();
                if (objds.Tables.Count > 0 && objds.Tables[0].Rows.Count > 0)
                {
                    var parentColumn = objds.Tables[0].Columns["TeamId"];
                    var childColumn = objds.Tables[1].Columns["TeamId"];

                    if (parentColumn != null && childColumn != null)
                    {
                        objds.Relations.Add("Details", parentColumn, childColumn, false);
                    }

                    GrdHistory.DataSource = objds.Tables[0];
                    GrvHistory.OptionsDetail.EnableMasterViewMode = true;
                    GrvHistory.OptionsDetail.SmartDetailExpand = true;
                    GrvHistory.OptionsDetail.ShowDetailTabs = false;

                    GrvHistory.Columns["TeamId"].Visible = GrvHistory.Columns["HierachyId"].Visible = GrvHistory.Columns["IsOrgChart"].Visible = false;

                    foreach (GridColumn col in GrvHistory.Columns)
                    {
                        col.OptionsColumn.AllowEdit = false;
                    }

                    AddOrRefreshEditColumn();

                    GrdHistory.LevelTree.Nodes.Add("Details", GrvDetailView);
                }


            }
            catch { }
        }

        private void AddOrRefreshEditColumn()
        {
            // Remove existing Edit column if it exists
            if (GrvHistory.Columns["Edit"] != null)
            {
                GrvHistory.Columns.Remove(GrvHistory.Columns["Edit"]);
            }

            // Create and add Edit column
            GridColumn editColumn = new GridColumn
            {
                FieldName = "Edit",
                UnboundType = DevExpress.Data.UnboundColumnType.String,
                Caption = "",
                VisibleIndex = GrvHistory.Columns.Count,
                Width = 40,
                OptionsColumn = {
                AllowEdit = true,
                AllowSort = DevExpress.Utils.DefaultBoolean.False,
                AllowGroup = DevExpress.Utils.DefaultBoolean.False
                }
            };

            // Create button editor
            RepositoryItemButtonEdit editButton = new RepositoryItemButtonEdit
            {
                TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor
            };

            // Add built-in DevExpress Edit icon
            editButton.Buttons.Clear();
            editButton.Buttons.Add(new DevExpress.XtraEditors.Controls.EditorButton(
                DevExpress.XtraEditors.Controls.ButtonPredefines.Undo));
            editButton.Buttons[0].ToolTip = "Edit";

            // Handle button click
            editButton.ButtonClick += EditButton_ButtonClick;

            // Add editor to grid and bind to column
            GrdHistory.RepositoryItems.Add(editButton);
            editColumn.ColumnEdit = editButton;

            // Add column to grid view
            GrvHistory.Columns.Add(editColumn);
        }


        private async void EditButton_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            try
            {
                int rowHandle = GrvHistory.FocusedRowHandle;
                if (rowHandle >= 0)
                {
                    BtnAdd_Click(sender, e);

                    var teamId = GrvHistory.GetRowCellValue(rowHandle, "TeamId");
                    iTeamId = Convert.ToInt32(teamId);
                    SelectedContainer = new DiagramContainer();
                    var empSeleted = objEmp.Where(x => x.Brand == "1'").ToList();
                    empSeleted.ForEach(e => e.Brand = "0");

                    TeamModel teamModels = await teamAPI.GetTeamDetails(iTeamId);
                    if (teamModels != null)
                    {
                        TxtName.Text = teamModels.TeamName;
                        IsOrgChart = teamModels.IsOrgChart;
                        TeamList = teamModels.Details?.Select(t => new TempTeamMember
                        {
                            TeamNumber = t.TeamNumber,
                            TeamName = t.TeamName,
                            ContactId = t.ContactId,
                            ParentId = t.ParentId,
                            FullName = t.FullName,
                            LevelId = t.LevelId,
                            MergedContactId = t.MergedContactId,
                            Position = t.Position,
                            TypeId = t.TypeId,
                            RefTeamId = t.RefTeamId,
                            IsOrgChart = IsOrgChart,
                            EmployeeImage = t.EmployeeImage
                        }).ToList() ?? new List<TempTeamMember>();

                        BuildDiagramFromTeamList();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private async void LoadEmployees()
        {
            objEmp = await teamAPI.GetEmployeeDetails();

            GrdEmployee.DataSource = objEmp.Where(T => T.TeamCount > 0).ToList();

            GrdNEmployee.DataSource = objEmp.Where(T => T.TeamCount == 0).ToList();

        }


        private async void LoadTeams()
        {
            TList = await teamAPI.GetTeamList();

            GrdTeam.DataSource = TList;

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            SplashScreenManager.ShowForm(typeof(WaitForm1));
            AddView = true;
            ClearForm();
            PanelAdd.BringToFront();
            SplashScreenManager.CloseForm();
        }

        private void BtnHistory_Click(object sender, EventArgs e)
        {
            SplashScreenManager.ShowForm(typeof(WaitForm1));
            AddView = false;
            LoadTeamHistory();
            PanelAdd.SendToBack();
            SplashScreenManager.CloseForm();
        }


        //private void GrvTeam_ItemDoubleClick(object sender, TileViewItemClickEventArgs e)
        //{
        //    //try
        //    //{
        //    //    SplashScreenManager.ShowForm(typeof(WaitForm1));

        //    //    if (GrdTeam.FocusedView is TileView tileView)
        //    //    {
        //    //        var dataRow = tileView.GetRow(e.Item.RowHandle);
        //    //        if (dataRow is TeamListModel row)
        //    //        {
        //    //            SelectedContainer = new DiagramContainer();
        //    //            var empSeleted = objEmp.Where(x => x.Brand == "1'").ToList();
        //    //            empSeleted.ForEach(e => e.Brand = "0");

        //    //            TxtName.Text = row.TeamName;
        //    //            iTeamId = row.TeamId;
        //    //            TeamModel teamModels =await  teamAPI.GetTeamDetails(iTeamId);
        //    //            if (teamModels != null)
        //    //            {
        //    //                IsOrgChart = teamModels.IsOrgChart;
        //    //                TeamList = teamModels.Details?.Select(t => new TempTeamMember
        //    //                {
        //    //                    TeamNumber = t.TeamNumber,
        //    //                    TeamName = t.TeamName,
        //    //                    ContactId = t.ContactId,
        //    //                    ParentId = t.ParentId,
        //    //                    FullName = t.FullName,
        //    //                    LevelId = t.LevelId,
        //    //                    Position = t.Position,
        //    //                    TypeId = t.TypeId,
        //    //                    RefTeamId = t.RefTeamId,
        //    //                    IsOrgChart = IsOrgChart,
        //    //                    EmployeeImage = t.EmployeeImage
        //    //                }).ToList() ?? new List<TempTeamMember>();

        //    //                BuildDiagramFromTeamList();
        //    //            }
        //    //        }
        //    //    }
        //    //}
        //    //catch (Exception ex)
        //    //{
        //    //    InfoForm.Show(ex.Message, "Teams");
        //    //}
        //    //finally
        //    //{
        //    //    SplashScreenManager.CloseForm();
        //    //}
        //}



        private async void GrdTeam_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //if (e.Button != MouseButtons.Left)
            //    return;  // Ignore right-clicks and others

            TileView view = GrvTeam;
            TileViewHitInfo hitInfo = view.CalcHitInfo(e.Location);
            if (hitInfo.InItem)
            {
                var dataRow = view.GetRow(hitInfo.RowHandle);
                if (dataRow is TeamListModel row)
                {
                    SelectedContainer = new DiagramContainer();
                    var empSeleted = objEmp.Where(x => x.Brand == "1'").ToList();
                    empSeleted.ForEach(e => e.Brand = "0");

                    TxtName.Text = row.TeamName;
                    iTeamId = row.TeamId;
                    TeamModel teamModels = await teamAPI.GetTeamDetails(iTeamId);
                    if (teamModels != null)
                    {
                        IsOrgChart = teamModels.IsOrgChart;
                        TeamList = teamModels.Details?.Select(t => new TempTeamMember
                        {
                            TeamNumber = t.TeamNumber,
                            TeamName = t.TeamName,
                            ContactId = t.ContactId,
                            ParentId = t.ParentId,
                            FullName = t.FullName,
                            LevelId = t.LevelId,
                            MergedContactId = t.MergedContactId,
                            Position = t.Position,
                            TypeId = t.TypeId,
                            RefTeamId = t.RefTeamId,
                            IsOrgChart = IsOrgChart,
                            EmployeeImage = t.EmployeeImage
                        }).ToList() ?? new List<TempTeamMember>();

                        BuildDiagramFromTeamList();
                    }
                }
            }
        }



        private void BuildDiagramFromTeamList()
        {
            bLoading = true;
            DiagTeam.Items.Clear();

            var idToItem = new Dictionary<int, DiagramItem>();
            var TmList = TeamList.Where(x => x.MergedContactId == 0).ToList();
            var MerList = TeamList.Where(x => x.MergedContactId > 0).ToList();

            foreach (var member in TmList)
            {
                var container = CreateEmployeeContainer(member, Point.Empty);
                DiagTeam.Items.Add(container);
                idToItem[member.ContactId] = container;
            }

            foreach (var member in TmList.Where(m => m.ParentId != 0))
            {
                if (idToItem.ContainsKey(member.ParentId) && idToItem.ContainsKey(member.ContactId))
                {
                    var connector = new DiagramConnector
                    {
                        BeginItem = idToItem[member.ParentId],
                        EndItem = idToItem[member.ContactId]
                    };
                    DiagTeam.Items.Add(connector);
                }
            }

            foreach (var mergedId in MerList.Select(m => m.MergedContactId).Distinct())
            {
                var targetContainer = DiagTeam.Items
                    .OfType<DiagramContainer>()
                    .FirstOrDefault(c => (int?)c.Tag == mergedId);

                var membersInGroup = TeamList
                    .Where(m => m.MergedContactId == mergedId || m.ContactId == mergedId)
                    .ToList();

                if (targetContainer != null)
                {
                    UpdateMergedContainer(targetContainer, membersInGroup);
                }
            }

            DiagTeam.ApplyTreeLayout();
            DiagTeam.FitToItems(DiagTeam.Items);
            DiagTeam.FitToDrawing();

            AssignOrderAndLevel();
            UpdateEmptyDropPanelVisibility();
            bLoading = false;
        }


        private DiagramContainer CreateEmployeeContainer(TempTeamMember member, Point clientPoint)
        {
            PointF diagramPoint = DiagTeam.PointToDocument(new DevExpress.Utils.PointFloat(clientPoint.X, clientPoint.Y));
            DiagramContainer container;

            Image? img = null;
            if (member.EmployeeImage != null && member.EmployeeImage.Length > 0)
            {
                using var ms = new System.IO.MemoryStream(member.EmployeeImage);
                img = System.Drawing.Image.FromStream(ms);
            }

            DiagramShape textHead = new DiagramShape();
            bool tHead = false;

            if (member.IsOrgChart && member.TypeId == 3)
            {
                textHead = new DiagramShape()
                {
                    Size = new SizeF(150, 20),
                    Position = new DevExpress.Utils.PointFloat(0, 0),
                    Content = $"{member.TeamName}",
                    Shape = DevExpress.Diagram.Core.BasicShapes.Rectangle,
                    Appearance = {
                        BackColor = System.Drawing.Color.LightSteelBlue,
                        Font = new Font("Tahoma", 9F),
                        ForeColor = System.Drawing.Color.Black
                        },
                    CanSelect = false,
                    CanMove = false,
                    CanDelete = false
                };
                tHead = true;
            }

            var imageItem = new DiagramImage()
            {
                Size = tHead ? new SizeF(150, 90) : new SizeF(150, 100),
                Image = img,
                StretchMode = StretchMode.Uniform,
                Position = tHead ? new DevExpress.Utils.PointFloat(0, 20) : new DevExpress.Utils.PointFloat(0, 0),
                CanSelect = false,
                CanMove = false,
                CanDelete = false
            };

            var textShape = new DiagramShape()
            {
                Size = new SizeF(150, 40),
                Position = tHead ? new DevExpress.Utils.PointFloat(0, 110) : new DevExpress.Utils.PointFloat(0, 100),
                Content = $"{member.FullName}\n{member.Position}",
                Shape = DevExpress.Diagram.Core.BasicShapes.Rectangle,
                Appearance = {
                    BackColor = System.Drawing.Color.LightSteelBlue,
                    Font = new Font("Tahoma", 9F),
                    ForeColor = System.Drawing.Color.Black
                },
                CanSelect = false,
                CanMove = false,
                CanDelete = false
            };

            container = new DiagramContainer()
            {
                Position = new DevExpress.Utils.PointFloat(diagramPoint.X, diagramPoint.Y),
                Size = tHead ? new SizeF(150, 150) : new SizeF(150, 140),
                CanResize = false,
                Tag = member.ContactId,
                Appearance = {
                    BackColor = System.Drawing.Color.White,
                    BorderColor = System.Drawing.Color.Gray
                    }
            };

            if (tHead)
                container.Items.Add(textHead);

            container.Items.Add(imageItem);
            container.Items.Add(textShape);

            UpdateEmpSource(member.ContactId, "1");
            return container;
        }

        private void UpdateEmptyDropPanelVisibility()
        {
            int containerCount = DiagTeam.Items.OfType<DiagramContainer>().Count();
            _emptyDropPanel.Visible = containerCount == 0;
        }
        private void EmptyDropPanel_DragEnter(object? sender, DragEventArgs e)
        {
            if (e.Data != null && e.Data.GetDataPresent(typeof(TempTeamMember)))
            {
                if (e.Data.GetData(typeof(TempTeamMember)) is not TempTeamMember draggedEmp) return;

                if (draggedEmp.IsOrgChart && draggedEmp.TypeId != 1)
                {
                    InfoForm.Show("Please drag Company to start Organization hierarchy");
                    e.Effect = DragDropEffects.None;
                    return;
                }

                e.Effect = DragDropEffects.Move;
            }
            else
                e.Effect = DragDropEffects.None;
        }



        private void EmptyDropPanel_DragDrop(object? sender, DragEventArgs e)
        {
            if (e.Data != null && e.Data.GetDataPresent(typeof(TempTeamMember)))
            {
                if (e.Data.GetData(typeof(TempTeamMember)) is not TempTeamMember draggedEmp) return;

                if (draggedEmp.IsOrgChart && draggedEmp.TypeId != 1) return;

                // Mark as root node
                draggedEmp.ParentId = 0;

                // Ensure it's not already in diagram
                bool alreadyExists = DiagTeam.Items
                    .OfType<DiagramContainer>()
                    .Any(c => (int?)c.Tag == draggedEmp.ContactId);

                if (!alreadyExists)
                {
                    TeamList.Add(draggedEmp);
                    Point clientPoint = DiagTeam.PointToClient(new Point(e.X, e.Y));
                    var container = CreateEmployeeContainer(draggedEmp, clientPoint);
                    DiagTeam.Items.Add(container);
                }

                DiagTeam.ApplyTreeLayout();
                DiagTeam.FitToItems(DiagTeam.Items);
                AssignOrderAndLevel();
                UpdateEmptyDropPanelVisibility();

            }
        }

        private int GetContainerKey(TempTeamMember member)
        {
            return member.MergedContactId > 0 ? member.MergedContactId : member.ContactId;
        }

        // 4️⃣ Assign LevelId + optional Order
        private void AssignOrderAndLevel()
        {
            // Use containers (not shapes)
            var containers = DiagTeam.Items.OfType<DiagramContainer>().ToList();
            var connectors = DiagTeam.Items.OfType<DiagramConnector>().ToList();

            var parentToChildren = new Dictionary<int, List<int>>();

            foreach (var connector in connectors)
            {
                if (connector.BeginItem is DiagramContainer parentContainer &&
                    connector.EndItem is DiagramContainer childContainer)
                {
                    if (parentContainer.Tag == null || childContainer.Tag == null)
                        continue;  // Skip if no ContactId

                    int parentId = (int)parentContainer.Tag;
                    int childId = (int)childContainer.Tag;

                    if (!parentToChildren.ContainsKey(parentId))
                        parentToChildren[parentId] = new List<int>();

                    parentToChildren[parentId].Add(childId);
                }
            }

            var idToMember = TeamList.ToDictionary(x => x.ContactId);

            int orderCounter = 1;

            var allChildIds = parentToChildren.Values.SelectMany(l => l).ToHashSet();

            var rootContainers = containers
                .Where(c => c.Tag != null && !allChildIds.Contains((int)c.Tag))
                .ToList();

            foreach (var rootContainer in rootContainers)
            {
                int rootId = (int)rootContainer.Tag;
                AssignRecursive(rootId, 0, ref orderCounter, parentToChildren, idToMember);
            }

            if (!IsOrgChart)
            {
                GrdEmployee.DataSource = objEmp.Where(T => T.TeamCount > 0).ToList();
                GrvEmployee.RefreshData();
            }

        }

        private void AssignRecursive(int contactId, int level, ref int orderCounter, Dictionary<int, List<int>> parentToChildren, Dictionary<int, TempTeamMember> idToMember)
        {
            if (!idToMember.ContainsKey(contactId)) return;

            var member = idToMember[contactId];
            member.LevelId = level;
            member.TeamNumber = orderCounter++;

            if (IsOrgChart)
            {
                //var tmpSel = TList.FirstOrDefault(x => x.ContactId == member.ContactId);
                //if (tmpSel != null)
                //    tmpSel.Levels = "Level - " + member.LevelId.ToString();
            }
            else
            {
                var empSel = objEmp.FirstOrDefault(x => x.ContactId == member.ContactId);
                if (empSel != null)
                    empSel.Levels = "Level - " + member.LevelId.ToString();
            }

            if (parentToChildren.ContainsKey(contactId))
            {
                foreach (var childId in parentToChildren[contactId])
                {
                    AssignRecursive(childId, level + 1, ref orderCounter, parentToChildren, idToMember);
                }
            }
        }



        private void GrdEmployee_MouseDown(object sender, MouseEventArgs e)
        {
            var hitInfo = GrvEmployee.CalcHitInfo(e.Location);
            if (hitInfo.ItemInfo != null && e.Button == MouseButtons.Left && !IsOrgChart)
            {
                if (GrvEmployee.GetRow(hitInfo.RowHandle) is TeamEmployeeModel emp)
                {
                    // Use TempTeamMember instead of anonymous type
                    var tempEmp = new TempTeamMember
                    {
                        TeamName = string.Empty,
                        TeamNumber = 0,
                        ContactId = emp.ContactId,
                        FullName = emp.FullName,
                        ParentId = 0, // Assuming drag-drop to root unless specified later
                        LevelId = 0,
                        MergedContactId = 0,
                        Position = emp.Position,
                        TypeId = 0,
                        RefTeamId = 0,
                        IsOrgChart = false,
                        EmployeeImage = emp.EmployeeImage
                    };

                    GrdEmployee.DoDragDrop(tempEmp, DragDropEffects.Move);
                }
            }
        }

        private void GrdNEmployee_MouseDown(object sender, MouseEventArgs e)
        {
            var hitInfo = GrvNEmployee.CalcHitInfo(e.Location);
            if (hitInfo.ItemInfo != null && e.Button == MouseButtons.Left && !IsOrgChart)
            {
                if (GrvNEmployee.GetRow(hitInfo.RowHandle) is TeamEmployeeModel emp)
                {
                    // Use TempTeamMember instead of anonymous type
                    var tempEmp = new TempTeamMember
                    {
                        TeamName = string.Empty,
                        TeamNumber = 0,
                        ContactId = emp.ContactId,
                        FullName = emp.FullName,
                        ParentId = 0, // Assuming drag-drop to root unless specified later
                        LevelId = 0,
                        MergedContactId = 0,
                        Position = emp.Position,
                        TypeId = 0,
                        RefTeamId = 0,
                        IsOrgChart = false,
                        EmployeeImage = emp.EmployeeImage
                    };

                    GrdNEmployee.DoDragDrop(tempEmp, DragDropEffects.Move);
                }
            }
        }

        private void GrdTeam_MouseDown(object sender, MouseEventArgs e)
        {
            var hitInfo = GrvTeam.CalcHitInfo(e.Location);
            if (hitInfo.ItemInfo != null && e.Button == MouseButtons.Left)
            {
                if (GrvTeam.GetRow(hitInfo.RowHandle) is TeamListModel emp)
                {
                    // Use TempTeamMember instead of anonymous type
                    IsOrgChart = true;
                    var tempEmp = new TempTeamMember
                    {
                        TeamName = emp.TeamName,
                        TeamNumber = 0,
                        ContactId = emp.ContactId,
                        FullName = emp.FullName,
                        ParentId = 0, // Assuming drag-drop to root unless specified later
                        LevelId = 0,
                        MergedContactId = 0,
                        Position = emp.Position,
                        TypeId = emp.TypeId,
                        RefTeamId = emp.TeamId,
                        IsOrgChart = true,
                        EmployeeImage = emp.EmployeeImage
                    };

                    GrdTeam.DoDragDrop(tempEmp, DragDropEffects.Move);
                }
            }
        }


        private PointF ClientToDiagram(Point clientPoint)
        {
            float zoomFactor = (float)(DiagTeam.OptionsView.ZoomFactor / 100.0);
            //var viewportTopLeft = DiagTeam.GetViewportBounds(); // This acts like our "ScrollPosition"
            //float diagramX = (clientPoint.X / zoomFactor) + viewportTopLeft.X;
            //float diagramY = (clientPoint.Y / zoomFactor) + viewportTopLeft.Y;

            //return new PointF(diagramX, diagramY);
            // Get scroll position
            return new PointF(
                        clientPoint.X / zoomFactor,
                        clientPoint.Y / zoomFactor
                    );

        }


        private DiagramContainer GetDiagramContainerPoint(Point clientPoint)
        {
            var diagramPoint = DiagTeam.PointToDocument(new DevExpress.Utils.PointFloat(clientPoint.X, clientPoint.Y));

            float scaleFactor = (float)(DiagTeam.OptionsView.ZoomFactor);
            Point scaledPoint = new Point((int)(diagramPoint.X / scaleFactor), (int)(diagramPoint.Y / scaleFactor));

            foreach (DiagramContainer container in DiagTeam.Items.OfType<DiagramContainer>())
            {
                Console.WriteLine($"Client Point: {scaledPoint}");
                var ss = container.Tag;
                Console.WriteLine($"Container Bounds: {container.Bounds}");

                if (container.Bounds.Contains(scaledPoint))
                {
                    return container;
                }

                if (container.Bounds.X < scaledPoint.X && scaledPoint.Y < container.Bounds.Y)
                    return container;

            }
            return new DiagramContainer();
        }


        private void GetDiagramContainer(Point clientPoint)
        {
            var diagramPoint = DiagTeam.PointToDocument(new DevExpress.Utils.PointFloat(clientPoint.X, clientPoint.Y));
            DiagramHitInfo[] hitInfos = DiagTeam.CalcHitInfo(diagramPoint);
            foreach (DiagramHitInfo hitInfo in hitInfos)
            {
                DiagramItem? item = null;
                hitInfo.MatchHitInfo(callbacks =>
                {
                    item = callbacks.ParentItem;

                });
            }
        }

        private void DiagTeam_MouseClick(object sender, MouseEventArgs e)
        {
            var selectedContainers = DiagTeam.SelectedItems
               .OfType<DiagramContainer>()
               .ToList();

            if (selectedContainers.Count == 0)
                return;

            foreach (var container in selectedContainers)
            {
                if (container.Tag == null)
                    continue;

                int contactId = (int)container.Tag;

                var member = TeamList.FirstOrDefault(m => m.ContactId == contactId);
                if (member == null)
                    continue;

                if (SelectedContainer != null && SelectedContainer.Tag != null)
                {
                    SelectedContainer.Appearance.BorderColor = Color.Black; // Default color
                    SelectedContainer.Appearance.BackColor = Color.White; // Default background

                    if (IsOrgChart)
                    {
                        var tmpSel = TList.FirstOrDefault(x => x.ContactId == Convert.ToInt32(SelectedContainer.Tag));
                        if (tmpSel != null)
                        {
                            tmpSel.Brand = "1";
                        }
                    }
                    else
                    {
                        var empSel = objEmp.FirstOrDefault(x => x.ContactId == Convert.ToInt32(SelectedContainer.Tag));
                        if (empSel != null)
                        {
                            empSel.Brand = "1";
                        }
                    }
                }
                SelectedContainer = container;

                container.Appearance.BorderColor = Color.Red;
                container.Appearance.BackColor = Color.LightGreen;
                DiagTeam.Refresh();

                UpdateEmpSource(Convert.ToInt32(SelectedContainer.Tag), "2");

            }
        }

        private void DiagTeam_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data != null && e.Data.GetDataPresent(typeof(TempTeamMember)))
            {
                if (e.Data.GetData(typeof(TempTeamMember)) is not TempTeamMember draggedEmp) return;

                if (IsOrgChart && draggedEmp.TypeId != 3)   //Teams
                {
                    InfoForm.Show("Please drag team to build Organization hierarchy");
                    e.Effect = DragDropEffects.None;
                    return;
                }
                else if (!IsOrgChart && draggedEmp.TypeId != 0)
                {
                    InfoForm.Show("Please drag employee to build a Team");
                    e.Effect = DragDropEffects.None;
                    return;
                }

                e.Effect = DragDropEffects.Move;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void DiagTeam_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data != null && e.Data.GetDataPresent(typeof(TempTeamMember)))
            {
                if (e.Data.GetData(typeof(TempTeamMember)) is not TempTeamMember draggedEmp) return;

                if (IsOrgChart && draggedEmp.TypeId != 3)   //Teams
                {
                    InfoForm.Show("Please drag team to build Organization hierarchy");
                    e.Effect = DragDropEffects.None;
                    return;
                }
                else if (!IsOrgChart && draggedEmp.TypeId != 0)
                {
                    InfoForm.Show("Please drag employee to build a Team");
                    e.Effect = DragDropEffects.None;
                    return;
                }

                e.Effect = DragDropEffects.Move;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void DiagTeam_DragDrop(object sender, DragEventArgs e)
        {
            if (e.Data != null && !e.Data.GetDataPresent(typeof(TempTeamMember))) return;

            var draggedEmp = e.Data?.GetData(typeof(TempTeamMember)) as TempTeamMember;
            if (draggedEmp == null) return;

            // Get drop point in diagram coordinates
            Point clientPoint = DiagTeam.PointToClient(new Point(e.X, e.Y));

            DiagramContainer? targetContainer = SelectedContainer;

            if (targetContainer == null || targetContainer.Tag == null)
            {
                InfoForm.Show("Click on a member to drop the employee/team.");
                return;
            }

            int targetId = (int)targetContainer.Tag;
            int targetTypeId = (int)TeamList.FirstOrDefault(x => x.ContactId == targetId)?.TypeId;

            if (targetTypeId == 1 && draggedEmp.TypeId != 3)
            {
                InfoForm.Show("Invalid drop");
                return;
            }
            else if (targetTypeId == 0 && draggedEmp.TypeId != 0)
            {
                IsOrgChart = false;
                InfoForm.Show("Invalid drop");
                return;
            }
            // Prevent self-parenting or cyclic assignment
            if (draggedEmp.ContactId == targetId || IsDescendant(draggedEmp.ContactId, targetId))
            {
                InfoForm.Show("Invalid drop: cannot assign as child of self or descendant.");
                return;
            }

            bool LREnable = TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ParentId > 0 ? true : false;

            var existingImage = targetContainer.Items
                                 .OfType<DiagramImage>()
                                 .FirstOrDefault();

            Image? image = null;
            if (existingImage != null)
            {
                image = (Image)existingImage.Image;
            }

            bool Topenble = TeamList.FirstOrDefault(x => x.ContactId == targetId)?.TypeId != 1;

            int result = DropRelation.Show("Choose how to assign the dragged employee:", image, LREnable, Topenble);

            if (result == (int)Positions.Cancel)
                return;

            // Check if employee already exists in diagram
            var container = DiagTeam.Items
                .OfType<DiagramContainer>()
                .FirstOrDefault(c => (int?)c.Tag == draggedEmp.ContactId);

            if (container == null)
            {
                if (result != (int)Positions.Replace && result != (int)Positions.Merge)
                {
                    TeamList.Add(draggedEmp);
                    container = CreateEmployeeContainer(draggedEmp, clientPoint);
                    DiagTeam.Items.Add(container);
                }
            }
            else
            {
                InfoForm.Show("Employee already exists in the diagram.");
                return;
            }

            if (result == (int)Positions.Merge)
            {
                var existsc = TeamList.FirstOrDefault(x => x.ContactId == draggedEmp.ContactId)?.ContactId > 0;
                if (!existsc)
                {
                    draggedEmp.ParentId = TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ParentId ?? 0;
                    draggedEmp.MergedContactId = (int)TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ContactId;
                    draggedEmp.LevelId = (int)TeamList.FirstOrDefault(x => x.ContactId == targetId)?.LevelId;

                    TeamList.Add(draggedEmp);

                    var membersInGroup = TeamList
                    .Where(m => m.MergedContactId == targetId || m.ContactId == targetId)
                    .ToList();

                    if (targetContainer != null)
                    {
                        UpdateMergedContainer(targetContainer, membersInGroup);
                    }
                }
                else
                {
                    InfoForm.Show("Employee already exists in the diagram.");
                    return;
                }
            }
            else
            {

                // Remove existing connectors to this employee
                var oldConnectors = DiagTeam.Items
                    .OfType<DiagramConnector>()
                    .Where(conn => conn.EndItem == container)
                    .ToList();

                foreach (var conn in oldConnectors)
                    DiagTeam.Items.Remove(conn);
            }

            // Now assign based on user choice
            if (result == (int)Positions.Left)
            {
                draggedEmp.ParentId = TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ParentId ?? 0;
                var parentConnector = DiagTeam.Items
                        .OfType<DiagramConnector>()
                        .FirstOrDefault(c => c.EndItem == targetContainer);

                // Get the parent container (if any)
                DiagramContainer? parentContainer = parentConnector?.BeginItem as DiagramContainer;

                if (parentContainer != null)
                {
                    var connector = new DiagramConnector
                    {
                        BeginItem = parentContainer,
                        EndItem = container
                    };
                    DiagTeam.Items.Add(connector);
                }

                SwapContainers(targetContainer, container);

            }
            else if (result == (int)Positions.Right)
            {
                draggedEmp.ParentId = TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ParentId ?? 0;
                var parentConnector = DiagTeam.Items
                        .OfType<DiagramConnector>()
                        .FirstOrDefault(c => c.EndItem == targetContainer);

                // Get the parent container (if any)
                DiagramContainer? parentContainer = parentConnector?.BeginItem as DiagramContainer;

                if (parentContainer != null)
                {
                    var connector = new DiagramConnector
                    {
                        BeginItem = parentContainer,
                        EndItem = container
                    };
                    DiagTeam.Items.Add(connector);
                }
            }
            else if (result == (int)Positions.Bottom)
            {
                // Drop as CHILD of selected
                draggedEmp.ParentId = targetId;

                var parentContainer = targetContainer;
                if (parentContainer != null)
                {
                    var connector = new DiagramConnector
                    {
                        BeginItem = parentContainer,
                        EndItem = container
                    };
                    DiagTeam.Items.Add(connector);
                }
            }
            else if (result == (int)Positions.Top)
            {
                var targetEmp = TeamList.FirstOrDefault(x => x.ContactId == targetId);
                if (targetEmp == null) return;

                if (targetEmp.TypeId == 1) return;

                // Prevent cyclic relationship
                if (IsDescendant(targetId, draggedEmp.ContactId))
                {
                    InfoForm.Show("Cannot create cyclic relationship.");
                    return;
                }

                // Step 1: Save selected's current parent (if any)
                int? oldParentId = targetEmp.ParentId;

                // Step 2: Make selected a child of dragged employee
                targetEmp.ParentId = draggedEmp.ContactId;

                // Step 3: Make dragged a child of selected’s old parent
                draggedEmp.ParentId = oldParentId ?? 0;

                // Step 4: Remove old connector(s) pointing to selected (target)
                var oldTargetConnectors = DiagTeam.Items
                    .OfType<DiagramConnector>()
                    .Where(conn => conn.EndItem == targetContainer)
                    .ToList();
                foreach (var conn in oldTargetConnectors)
                    DiagTeam.Items.Remove(conn);

                // Step 5: Remove old connector(s) pointing to dragged (if any)
                var oldDraggedConnectors = DiagTeam.Items
                    .OfType<DiagramConnector>()
                    .Where(conn => conn.EndItem == container)
                    .ToList();
                foreach (var conn in oldDraggedConnectors)
                    DiagTeam.Items.Remove(conn);

                // Step 6: Add connector from dragged → selected
                DiagTeam.Items.Add(new DiagramConnector
                {
                    BeginItem = container,
                    EndItem = targetContainer
                });

                // Step 7: If old parent existed, connect it to dragged
                if (oldParentId != null && oldParentId != 0)
                {
                    var oldParentContainer = DiagTeam.Items
                        .OfType<DiagramContainer>()
                        .FirstOrDefault(c => (int?)c.Tag == oldParentId);

                    if (oldParentContainer != null)
                    {
                        DiagTeam.Items.Add(new DiagramConnector
                        {
                            BeginItem = oldParentContainer,
                            EndItem = container
                        });
                    }
                }
            }
            else if (result == (int)Positions.Replace)  // Replace with dragged container
            {
                var targetEmp = TeamList.FirstOrDefault(x => x.ContactId == targetId);
                if (targetEmp == null) return;

                int? oldParentId = targetEmp.ParentId;

                var ChildEmps = TeamList.FirstOrDefault(x => x.ParentId == targetEmp.ContactId);

                if (ChildEmps != null)
                {
                    foreach (var emp in TeamList)
                    {
                        if (emp.ParentId == targetEmp.ContactId)
                        {
                            emp.ParentId = draggedEmp.ContactId;
                        }
                    }
                }

                // Step 1: Update targetEmp's data to become draggedEmp
                draggedEmp.ParentId = oldParentId ?? 0;
                draggedEmp.TeamNumber = targetEmp.TeamNumber;
                draggedEmp.LevelId = targetEmp.LevelId;

                TeamList.Remove(targetEmp);

                TeamList.Add(draggedEmp);

                targetContainer.Items.Clear();

                Image? img = null;
                if (draggedEmp.EmployeeImage != null && draggedEmp.EmployeeImage.Length > 0)
                {
                    using var ms = new System.IO.MemoryStream(draggedEmp.EmployeeImage);
                    img = System.Drawing.Image.FromStream(ms);
                }

                DiagramImage imageItem = new DiagramImage()
                {
                    Size = new SizeF(150, 100),
                    Image = img,
                    StretchMode = StretchMode.Uniform,
                    Position = new DevExpress.Utils.PointFloat(0, 0),

                    CanSelect = false,
                    CanMove = false,
                    CanDelete = false
                };

                DiagramShape textShape = new DiagramShape()
                {
                    Size = new SizeF(150, 40),
                    Position = new DevExpress.Utils.PointFloat(0, 100),
                    Content = $"{draggedEmp.FullName}\n{draggedEmp.Position}",
                    Shape = DevExpress.Diagram.Core.BasicShapes.Rectangle,
                    Appearance = {
                        BackColor = System.Drawing.Color.LightSteelBlue,
                        Font = new Font("Tahoma", 9F),
                        ForeColor = System.Drawing.Color.Black
                    },


                    CanSelect = false,
                    CanMove = false,
                    CanDelete = false
                };

                targetContainer.Items.Add(imageItem);
                targetContainer.Items.Add(textShape);

                targetContainer.Tag = draggedEmp.ContactId;

                UpdateEmpSource(targetEmp.ContactId, "0");

            }


            // Refresh diagram

            DiagTeam.ApplyTreeLayout();

            DiagTeam.FitToItems(DiagTeam.Items);

            AssignOrderAndLevel();
            UpdateEmptyDropPanelVisibility();


        }

        void UpdateMergedContainer(DiagramContainer container, List<TempTeamMember> mergedMembers)
        {
            container.Items.Clear();

            float memberBlockWidth = 120f;
            float imageHeight = 80f;
            float textHeight = 40f;
            float blockSpacing = 10f;
            float padding = 10f;

            float currentX = padding;

            foreach (var member in mergedMembers)
            {
                Image img = null;
                if (member.EmployeeImage != null && member.EmployeeImage.Length > 0)
                {
                    using var ms = new MemoryStream(member.EmployeeImage);
                    img = Image.FromStream(ms);
                }

                // Centered image
                var imageItem = new DiagramImage()
                {
                    Size = new SizeF(memberBlockWidth, imageHeight),
                    Position = new PointFloat(currentX, padding),
                    Image = img,
                    StretchMode = StretchMode.Uniform, // Keep aspect ratio
                    Tag = mergedMembers.Count > 1 ? member.ContactId : null,
                    CanSelect = mergedMembers.Count > 1,
                    CanRotate =false,
                    CanMove = false,
                    CanDelete = false
                };


                var textShape = new DiagramShape()
                {
                    Size = new SizeF(memberBlockWidth, textHeight),
                    Position = new PointFloat(currentX, padding + imageHeight),
                    Content = $"{member.FullName}\n{member.Position}",
                    Shape = DevExpress.Diagram.Core.BasicShapes.Rectangle,
                    Appearance = {
                    BackColor = Color.LightSteelBlue,
                    BorderSize = 0,
                    Font = new Font("Tahoma", 8F, FontStyle.Regular),
                    ForeColor = Color.Black,
                    TextOptions = { WordWrap = DevExpress.Utils.WordWrap.Wrap }
                    },
                    CanSelect = false,
                    CanMove = false,
                    CanDelete = false
                };

                container.Items.Add(imageItem);
                container.Items.Add(textShape);

                currentX += memberBlockWidth + blockSpacing;
            }

            // Update container size
            float totalWidth = currentX + padding - blockSpacing;
            float totalHeight = padding + imageHeight + textHeight + padding;

            container.Size = new SizeF(totalWidth, totalHeight);
        }




        private void UpdateEmpSource(int cId, string sVal)
        {
            try
            {
                var empSel = IsOrgChart ? null : objEmp.FirstOrDefault(x => x.ContactId == cId);
                if (empSel != null)
                {
                    empSel.Brand = sVal;

                    if (empSel.TeamCount > 0)
                    {
                        GrdEmployee.DataSource = objEmp.Where(T => T.TeamCount > 0).ToList();
                        GrvEmployee.RefreshData();

                        FocusFirstLightGreenTile(GrvEmployee);
                    }
                    else
                    {
                        GrdNEmployee.DataSource = objEmp.Where(T => T.TeamCount == 0).ToList();
                        GrvNEmployee.RefreshData();

                        FocusFirstLightGreenTile(GrvNEmployee);
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }


        private void SwapContainers(DiagramContainer containerA, DiagramContainer? containerB)
        {
            if (containerA == null || containerB == null) return;

            // 1. Swap Visual Position
            var tempPos = containerA.Position;
            containerA.Position = containerB.Position;
            containerB.Position = tempPos;

            // 2. Swap TeamNumber in data model (to affect layout order)
            if (containerA.Tag is int idA && containerB.Tag is int idB)
            {
                var empA = TeamList.FirstOrDefault(x => x.ContactId == idA);
                var empB = TeamList.FirstOrDefault(x => x.ContactId == idB);

                if (empA != null && empB != null)
                {
                    int tempTeam = empA.TeamNumber;
                    empA.TeamNumber = empB.TeamNumber;
                    empB.TeamNumber = tempTeam;
                }
            }

            // 3. Fix connectors only from parent → containerA or containerB
            var connectors = DiagTeam.Items.OfType<DiagramConnector>().ToList();
            foreach (var conn in connectors)
            {
                // Only touch parent connectors (not child ones)
                if (conn.EndItem == containerA)
                {
                    conn.EndItem = containerB;
                }
                else if (conn.EndItem == containerB)
                {
                    conn.EndItem = containerA;
                }
            }

        }



        private void DiagTeam_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode != Keys.Delete)
                return;

            bool isDeleted = false;
            int contactId = 0;
            var container = SelectedContainer;

            if (container.Tag == null)
            {
                var selected = DiagTeam.SelectedItems
                  .OfType<DiagramImage>()
                  .FirstOrDefault();

                if (selected != null)
                {
                    contactId = (int)selected.Tag;
                    var confirm = MessageDialog.Show($"Are you sure you want to delete the selected member?", "Confirm Delete", "Yes", "No");
                    if (confirm == DialogResult.Yes)
                    {
                        var MainCotactId = TeamList.FirstOrDefault(x => x.ContactId == contactId)?.MergedContactId;
                        if (MainCotactId != null)
                        {
                            int newMainId =(int)MainCotactId;
                            if (MainCotactId==0)  // tagged contactid
                            {
                                var empA = TeamList
                                    .FirstOrDefault(x => x.MergedContactId == contactId && x.ContactId != contactId);

                                if (empA != null)
                                {
                                    newMainId = empA.ContactId;

                                    // Update all others to now point to empA.ContactId
                                    foreach (var member in TeamList.Where(x => x.MergedContactId == contactId && x.ContactId != empA.ContactId))
                                    {
                                        member.MergedContactId = newMainId;
                                    }

                                    // Set empA itself as not merged
                                    empA.MergedContactId = 0;
                                    MainCotactId = contactId;
                                }
                            }

                            TeamList.RemoveAll(m => m.ContactId == contactId);

                            var targetContainer = DiagTeam.Items
                            .OfType<DiagramContainer>()
                            .FirstOrDefault(c => (int?)c.Tag == MainCotactId);

                            var membersInGroup = TeamList
                                .Where(m => m.MergedContactId == newMainId || m.ContactId == newMainId)
                                .ToList();

                            if (targetContainer != null)
                            {
                                UpdateMergedContainer(targetContainer, membersInGroup);
                            }

                            isDeleted = true;
                        }
                    }
                }
            }
            else
            {
                contactId = (int)container.Tag;

                var member = TeamList.FirstOrDefault(m => m.ContactId == contactId);
                if (member == null)
                    return;

                string fullName = IsOrgChart ? member.TeamName ?? " this team" : member.FullName ?? " this person";

                var result = MessageDialog.Show(
                    $"Are you sure you want to delete {fullName} and all their subordinates?",
                    "Confirm Delete", "Yes", "No"
                );

                if (result == DialogResult.Yes)
                {

                    isDeleted = true;

                    // Collect all ContactIds to delete (self + descendants)
                    var contactIdsToDelete = GetAllDescendants(contactId);
                    contactIdsToDelete.Add(contactId);

                    // Gather both containers + connectors to delete in one list
                    var itemsToRemove = DiagTeam.Items
                        .Where(item =>
                            (item is DiagramContainer c && c.Tag != null && contactIdsToDelete.Contains((int)c.Tag)) ||
                            (item is DiagramConnector conn &&
                                ((conn.BeginItem is DiagramContainer begin && begin.Tag != null && contactIdsToDelete.Contains((int)begin.Tag)) ||
                                 (conn.EndItem is DiagramContainer end && end.Tag != null && contactIdsToDelete.Contains((int)end.Tag)))
                            )
                        )
                        .ToList();

                    // Remove everything in one shot
                    foreach (var item in itemsToRemove)
                    {
                        DiagTeam.Items.Remove(item);
                    }

                    // Remove from TeamList
                    TeamList.RemoveAll(m => contactIdsToDelete.Contains(m.ContactId));

                }
            }

            if (isDeleted)
            {
                AssignOrderAndLevel();
                UpdateEmptyDropPanelVisibility();

                // Re-layout and fit view after deletion
                DiagTeam.ApplyTreeLayout();
                DiagTeam.FitToItems(DiagTeam.Items);

                DiagTeam.ClearSelection();
                SelectedContainer = new DiagramContainer();

                UpdateEmpSource(contactId, "0");
            }

            e.Handled = true;
        }



        private List<int> GetAllDescendants(int parentId)
        {
            List<int> descendants = new List<int>();

            // Build parent → children map from TeamList
            var parentToChildren = TeamList
                .GroupBy(m => m.ParentId)
                .ToDictionary(g => g.Key, g => g.Select(m => m.ContactId).ToList());

            // Recursive traversal
            void CollectDescendants(int id)
            {
                if (parentToChildren.ContainsKey(id))
                {
                    foreach (var childId in parentToChildren[id])
                    {
                        descendants.Add(childId);
                        CollectDescendants(childId);
                    }
                }
            }

            CollectDescendants(parentId);
            return descendants;
        }

        private void RemoveItemsFromDiagram(List<int> contactIds)
        {
            // Remove shapes
            var shapesToRemove = DiagTeam.Items
                .OfType<DevExpress.XtraDiagram.DiagramShape>()
                .Where(s => contactIds.Contains((int)s.Tag))
                .ToList();

            foreach (var shape in shapesToRemove)
            {
                DiagTeam.Items.Remove(shape);
            }

            // Remove connectors where either end is in contactIds
            var connectorsToRemove = DiagTeam.Items
                .OfType<DevExpress.XtraDiagram.DiagramConnector>()
                .Where(c =>
                {
                    var beginShape = c.BeginItem as DevExpress.XtraDiagram.DiagramShape;
                    var endShape = c.EndItem as DevExpress.XtraDiagram.DiagramShape;
                    return (beginShape != null && contactIds.Contains((int)beginShape.Tag)) ||
                           (endShape != null && contactIds.Contains((int)endShape.Tag));
                })
                .ToList();

            foreach (var connector in connectorsToRemove)
            {
                DiagTeam.Items.Remove(connector);
            }
        }


        private bool IsDescendant(int sourceId, int targetId)
        {
            var parentMap = TeamList.ToDictionary(x => x.ContactId, x => x.ParentId);
            int current = targetId;

            while (current != 0)
            {
                if (current == sourceId)
                    return true;

                if (!parentMap.ContainsKey(current))
                    break;

                current = parentMap[current];
            }
            return false;
        }

        private async void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SplashScreenManager.ShowForm(typeof(WaitForm1));

                if (TxtName.Text.Trim() == string.Empty)
                {
                    InfoForm.Show("Please Enter Team Name");
                    return;
                }

                List<TeamDetails>? tmList = new();

                if (TeamList is not null && TeamList.Count > 0)
                {
                    tmList = TeamList?.Select(t => new TeamDetails
                    {
                        TeamId = iTeamId,
                        TeamNumber = t.TeamNumber,
                        ContactId = t.ContactId,
                        ParentId = t.ParentId,
                        LevelId = t.LevelId,
                        RefTeamId = t.RefTeamId,
                        MergedContactId = t.MergedContactId
                    }).ToList();

                    TeamModel objTeam = new()
                    {
                        TeamId = iTeamId,
                        TeamName = TxtName.Text.Trim(),
                        Tags = string.Empty,
                        HierachyId = AppParameters.CompanyId,
                        Remarks = string.Empty,
                        IsOrgChart = IsOrgChart,
                        IsActive = true,
                        UserId = AppParameters.UserId,
                        Details = tmList
                    };

                    ResponseModel response = await teamAPI.TeamTrans(objTeam);
                    InfoForm.Show(response.Message ?? string.Empty);
                    ClearForm();
                    LoadTeams();
                }
                else
                {
                    InfoForm.Show("Please Drag employees and build team before saving");
                }
            }
            catch (Exception ex)
            {
                InfoForm.Show(ex.Message);
            }
            finally
            {
                SplashScreenManager.CloseForm();
            }

        }

        private void ClearForm()
        {
            bLoading = true;
            iTeamId = 0;
            TxtName.Text = string.Empty;
            TeamList.Clear();
            SelectedContainer = new DiagramContainer();
            ResetDiagram();
            UpdateEmptyDropPanelVisibility();
            LoadEmployees();
            IsOrgChart = false;
            bLoading = false;

        }

        private void ResetDiagram()
        {
            DiagTeam.Items.BeginUpdate();

            var items = DiagTeam.Items.Cast<DiagramItem>().ToList();
            foreach (var item in items)
            {
                DiagTeam.Items.Remove(item);
            }

            DiagTeam.Items.EndUpdate();

            DiagTeam.OptionsView.ZoomFactor = 100;
            DiagTeam.ScrollToPoint(new DevExpress.Utils.PointFloat(0, 0));

            // Optional — call FitToPage() if your version supports it
            DiagTeam.FitToPage();
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            SplashScreenManager.ShowForm(typeof(WaitForm1));
            ClearForm();
            SplashScreenManager.CloseForm();
        }


        private void RemoveConnectorsTo(DiagramItem item)
        {
            var toRemove = DiagTeam.Items
                .OfType<DiagramConnector>()
                .Where(conn => conn.EndItem == item)
                .ToList();

            foreach (var conn in toRemove)
                DiagTeam.Items.Remove(conn);
        }

        private void DiagTeam_ItemBoundsChanged(object sender, DiagramItemBoundsChangedEventArgs e)
        {
            if (!bLoading)
            {
                // var newParent = SelectedContainer;

                if (e.Item is DiagramContainer movedContainer)
                {
                    // Get moved item ID from Tag
                    int movedId = (int?)movedContainer.Tag ?? 0;

                    // Lookup the data model for the moved item
                    var emp = TeamList.FirstOrDefault(x => x.ContactId == movedId);
                    if (emp == null)
                        return;

                    // Find the new parent container based on position
                    var newParent = SelectedContainer;

                    if (newParent == null)
                        return;

                    int newParentId = (int?)newParent.Tag ?? 0;

                    // Prevent cycles or self-parenting
                    if (movedId == newParentId || IsDescendant(movedId, newParentId))
                    {
                        InfoForm.Show("Cannot move under a descendant or self.");
                        return;
                    }

                    // Get old parent container by data
                    var oldParent = DiagTeam.Items
                        .OfType<DiagramContainer>()
                        .FirstOrDefault(c => (int?)c.Tag == emp.ParentId);

                    // Visually remove from old parent
                    if (oldParent != null)
                    {
                        oldParent.Items.Remove(movedContainer);
                    }
                    else
                    {
                        DiagTeam.Items.Remove(movedContainer);
                    }

                    // Add to new parent
                    newParent.Items.Add(movedContainer);

                    // Remove old connectors
                    var oldConnectors = DiagTeam.Items
                        .OfType<DiagramConnector>()
                        .Where(conn => conn.EndItem == movedContainer)
                        .ToList();

                    foreach (var conn in oldConnectors)
                        DiagTeam.Items.Remove(conn);

                    // Add new connector
                    var newConnector = new DiagramConnector
                    {
                        BeginItem = newParent,
                        EndItem = movedContainer
                    };
                    DiagTeam.Items.Add(newConnector);

                    // Update model
                    emp.ParentId = newParentId;

                    // Re-layout
                    DiagTeam.ApplyTreeLayout();
                    DiagTeam.FitToItems(DiagTeam.Items);
                    AssignOrderAndLevel();
                    UpdateEmptyDropPanelVisibility();
                }

            }
        }

        private void GrvEmployee_ItemCustomize(object sender, DevExpress.XtraGrid.Views.Tile.TileViewItemCustomizeEventArgs e)
        {
            if (GrvEmployee.GetRow(e.RowHandle) is TeamEmployeeModel model && (model.Brand == "1" || model.Brand == "2"))
            {
                e.Item.AppearanceItem.Normal.BackColor = model.Brand == "1" ? Color.FromArgb(251, 172, 116) : Color.LightGreen;
            }
            else
            {
                e.Item.AppearanceItem.Normal.BackColor = Color.White;
            }
        }

        private void GrvNEmployee_ItemCustomize(object sender, DevExpress.XtraGrid.Views.Tile.TileViewItemCustomizeEventArgs e)
        {
            if (GrvNEmployee.GetRow(e.RowHandle) is TeamEmployeeModel model && (model.Brand == "1" || model.Brand == "2"))
            {
                e.Item.AppearanceItem.Normal.BackColor = model.Brand == "1" ? Color.FromArgb(251, 172, 116) : Color.LightGreen;
            }
            else
            {
                e.Item.AppearanceItem.Normal.BackColor = Color.White;
            }
        }


        private void FocusFirstLightGreenTile(TileView tileView)
        {
            for (int i = 0; i < tileView.RowCount; i++)
            {
                var model = tileView.GetRow(i) as TeamEmployeeModel;
                if (model != null && model.Brand == "2")
                {
                    tileView.FocusedRowHandle = i;
                    tileView.MakeRowVisible(i);
                    break;
                }
            }
        }



        private void BtnExport_Click(object sender, EventArgs e)
        {
            if (AddView)
            {
                DiagramShape headerShape = new()
                {
                    Size = new SizeF(200, 40),
                    Position = new DevExpress.Utils.PointFloat(20, 20),
                    Content = TxtName.Text,
                    Shape = DevExpress.Diagram.Core.BasicShapes.RoundCornerRectangle,
                    Appearance = {
                        BackColor = System.Drawing.Color.Transparent,
                        Font = new Font("Tahoma", 10F,FontStyle.Bold),
                        ForeColor = System.Drawing.Color.Black,
                        BorderColor =System.Drawing.Color.DarkBlue,
                    },
                };

                DiagTeam.Items.Add(headerShape);

                //DiagTeam.Print();

                using (var saveDialog = new SaveFileDialog())
                {
                    saveDialog.Filter = "PDF Files (.pdf)|*.pdf";
                    if (saveDialog.ShowDialog() != DialogResult.Cancel)
                    {
                        var exportFilePath = saveDialog.FileName;
                        DiagTeam.ExportToPdf(exportFilePath);
                    }
                }

                DiagTeam.Items.Remove(headerShape);

            }
            else
            {
                if (GrvHistory.RowCount > 0)
                {
                    DevExpress.Export.ExportSettings.DefaultExportType = DevExpress.Export.ExportType.WYSIWYG;
                    using (var saveDialog = new SaveFileDialog())
                    {
                        saveDialog.Filter = "Excel Files (.xlsx)|*.xlsx";
                        if (saveDialog.ShowDialog() != DialogResult.Cancel)
                        {
                            var exportFilePath = saveDialog.FileName;
                            GrvHistory.OptionsPrint.PrintDetails = true;
                            GrvHistory.OptionsPrint.ExpandAllDetails = true;
                            GrvHistory.OptionsPrint.ExpandAllGroups = true;
                            GrvHistory.OptionsPrint.AllowMultilineHeaders = true;
                            GrvHistory.OptionsPrint.IgnoreGroupDrawMode.Equals(true);
                            GrvHistory.OptionsPrint.AutoWidth = false;
                            GrvHistory.ExportToXlsx(exportFilePath);
                        }
                    }
                }
                else
                {
                    InfoForm.Show("No Details Found", "Teams");
                }
            }
        }

        private void GrdHistory_ViewRegistered(object sender, DevExpress.XtraGrid.ViewOperationEventArgs e)
        {
            if (e.View.IsDetailView)
            {
                ((GridView)(e.View)).Columns["TeamId"].Visible = false;

                for (var i = 0; i < ((GridView)(e.View)).Columns.Count; i++)
                {
                    ((GridView)(e.View)).Columns[i].OptionsFilter.FilterPopupMode = DevExpress.XtraGrid.Columns.FilterPopupMode.CheckedList;
                    ((GridView)(e.View)).Columns[i].OptionsColumn.AllowEdit = false;
                }
            }
        }

        private void GrvDetailView_RowStyle(object sender, RowStyleEventArgs e)
        {
            GridView? view = sender as GridView;
            if (view == null || e.RowHandle < 0)
                return;

            string? status = view.GetRowCellValue(e.RowHandle, "Status")?.ToString();
            if (status == "InActive")
            {
                e.Appearance.Font = new Font(e.Appearance.Font, FontStyle.Strikeout);
                e.Appearance.BackColor = Color.LavenderBlush;
            }

        }

        private void GrvDetailView_RowCellStyle(object sender, RowCellStyleEventArgs e)
        {
            GridView? view = sender as GridView;
            if (view == null || e.RowHandle < 0)
                return;

            if (e.Column.FieldName == "Status")
            {
                string? status = view.GetRowCellValue(e.RowHandle, "Status")?.ToString();
                if (status == "Active")
                {
                    e.Appearance.BackColor = Color.DarkSeaGreen;
                }
                else if (status == "InActive")
                {
                    e.Appearance.BackColor = Color.LightCoral;
                }
                else
                {
                    e.Appearance.BackColor = Color.LightYellow;
                }
            }
        }


        private void GrvTeam_ItemPress(object sender, TileViewItemClickEventArgs e)
        {
            if (e.Item != null)
            {

            }

        }


    }
}
if (result == (int)Positions.Merge)
{
    var existsc = TeamList.FirstOrDefault(x => x.ContactId == draggedEmp.ContactId)?.ContactId > 0;
    if (!existsc)
    {
        draggedEmp.ParentId = TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ParentId ?? 0;
        draggedEmp.MergedContactId = (int)TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ContactId;
        draggedEmp.LevelId = (int)TeamList.FirstOrDefault(x => x.ContactId == targetId)?.LevelId;

        TeamList.Add(draggedEmp);

        var membersInGroup = TeamList
            .Where(m => m.MergedContactId == targetId || m.ContactId == targetId)
            .ToList();

        if (targetContainer != null)
        {
            UpdateMergedContainer(targetContainer, membersInGroup);
        }
    }
    else
    {
        InfoForm.Show("Employee already exists in the diagram.");
        return;
    }
}if (result == (int)Positions.Merge)
{
    var existsc = TeamList.FirstOrDefault(x => x.ContactId == draggedEmp.ContactId)?.ContactId > 0;
    if (!existsc)
    {
        draggedEmp.ParentId = TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ParentId ?? 0;
        draggedEmp.MergedContactId = (int)TeamList.FirstOrDefault(x => x.ContactId == targetId)?.ContactId;
        draggedEmp.LevelId = (int)TeamList.FirstOrDefault(x => x.ContactId == targetId)?.LevelId;

        TeamList.Add(draggedEmp);

        var membersInGroup = TeamList
            .Where(m => m.MergedContactId == targetId || m.ContactId == targetId)
            .ToList();

        if (targetContainer != null)
        {
            UpdateMergedContainer(targetContainer, membersInGroup);
        }
    }
    else
    {
        InfoForm.Show("Employee already exists in the diagram.");
        return;
    }
}