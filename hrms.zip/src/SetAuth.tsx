import { BrowserRouter } from 'react-router-dom';
import { useDispatch } from "react-redux";
import React, { useEffect } from "react";
 
import RequireAuth from "./RequireAuth";
import LayoutHRMS from "./layout/LayoutHRMS";
import RouterConfiguration from "./RouterConfiguration"; // <-- Add this import
const getUser = () => {
  let _user = localStorage.getItem("_user");
  if (_user) _user = JSON.parse(_user);
  else _user = null;
  return _user;
};
const SetAuth = () => {
  const dispatch = useDispatch();
  let userDispatch = async () => { 
    let _user = getUser();
    const updateUserDetails = await import("Layout/UserDetailsSlice").then(
      (module:any) => module?.updateUserDetails
    );
    if (_user) {
      dispatch(updateUserDetails(_user));
    }
  };
  useEffect(() => {
    userDispatch();
    return;
  }, []);
  return (
    <BrowserRouter>
   <RouterConfiguration RequireAuth={RequireAuth} Layout={LayoutHRMS} LayoutType="HRMS"/>
    </BrowserRouter>
  );
};

export default SetAuth;
