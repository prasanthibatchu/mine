 
declare module 'Layout/Layout' {
  import React from 'react';
  export interface LayoutProps {}
  const Layout: React.FC<LayoutProps>;
  export default Layout;
}
declare module 'Layout/Login2' {
  import React from 'react';
  export interface LoginProps {}
  const Login: React.FC<LoginProps>;
  export default Login;
}

declare module 'Layout/UserDetailsSlice' {
  import React from 'react';
  export interface Props {}
  const UserDetailsSlice: React.FC<Props>;
  export default UserDetailsSlice;
}

 declare module 'Layout/MenuLayoutVisibilitySlice' {
  import React from 'react';
  export interface Props {}
  const MenuLayoutVisibilitySlice: React.FC<Props>;
  export default MenuLayoutVisibilitySlice;
}

declare module 'Layout/YsecInput2' {
  import React from 'react';
  export interface Props {
    label?: string;
    mandatory?: any;
    icon?: React.ReactNode;
    name?: string;
    value?: any;
    placeholder?: string;
    disabled?:any;
     onChange?: React.ChangeEventHandler<HTMLInputElement>;
     className?: string;
     defaultValue?:any;
     type?:any;
     onFocus?:any;
     onBlur?:any;
  }
  const YsecInput2: React.FC<Props>;
  export default YsecInput2;
}
 declare module 'Layout/YsecTextarea2' {
  import React from 'react';
  export interface Props {
    placeholder?:string;
    type?:any;
        label?: string;
    mandatory?: boolean;
    name?: string;
    value?: string;
    onChange?: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
    [key: string]: any;
    icon?:string;

  }
  const YsecTextarea2: React.FC<Props>;
  export default YsecTextarea2;
}


 declare module 'Layout/YsecSelect2' {
  import React from 'react';
  export interface Props {
    label?: string;
    mandatory?: boolean;
    name?: string;
    className?: string;
    objectNameKey?: string;
    objectValueKey?: string;
    value?:any,
    data?: Array<Record<string, any>>;
    onChange?: (e: any) => void;
    disabled?:any
    defaultValue?:any;
  }
  const YsecSelect2: React.FC<Props>;
  export default YsecSelect2;
}



 declare module 'Layout/YsecCheckbox2' {
  import React from 'react';
  export interface Props {
     label?: string;
    mandatory?: boolean;
    name?: string;
    className?: string;
    value?:any;
    onChange?: (e: any) => void;
    checked?:any;
    disabled?:boolean;
    key?:any;
  }
  const YsecCheckbox2: React.FC<Props>;
  export default YsecCheckbox2;
}



 declare module 'Layout/YsecRadio2' {
  import React from 'react';
  export interface Props {
     label?: string;
    mandatory?: boolean;
    name?: string;
    className?: string;
    value?:any;
    onChange?: (e: any) => void;
    checked?:any;
    id?:any;
    disabled?:boolean;
  }
  const YsecRadio2: React.FC<Props>;
  export default YsecRadio2;
}


 declare module 'Layout/YsecDatePicker2' {
  import React from 'react';
  export interface Props {
    name?: string;
    value?: any;
    className?: string;
    placeholderText?: string;
    label?: string;
    mandatory?: boolean;
    error?: string;
    onChange?: (e: any) => void;
    placeholder?: string;
    ysecType?: string;
    ysecFormat?: string;
    ysecMinDate?: string;
    ysecMaxDate?: string;
    wrapperClass?:any;
    multipleSelect?: boolean;
    defaultValue?:string;
  }
  const YsecDatePicker2: React.FC<Props>;
  export default YsecDatePicker2;
}



 declare module 'Layout/YsecCountrySelect2' {
  import React from 'react';
  export interface Props {
    name?: string;
    value?: any;
    className?: string;
    placeholderText?: string;
    label?: string;
    mandatory?: boolean;
    error?: string;
    onChange?: (e: any) => void;
    placeholder?: string;
    selection?: string;
    id?:any;
    activePhoneCode?:any;
  }
  const YsecCountrySelect2: React.FC<Props>;
  export default YsecCountrySelect2;
}

 declare module 'Layout/YsecTimePicker2' {
  import React from 'react';
  export interface Props {
    name?:string;
    label?:string;
    value?:any;
    onChange?:(e:any)=>void;
    placeholder?:string;
    mandatory?:boolean;
    ysecFormat?:any;
  }
  const YsecTimePicker2: React.FC<Props>;
  export default YsecTimePicker2;
}

 declare module 'Layout/YsecDropdown2' {
  import React from 'react';
  export interface Props {
     label?: string;
    mandatory?: boolean;
    name?: string;
    className?: string;
    objectNameKey?: string;
    objectValueKey?: string;
    value?:any,
    data?: Array<Record<string, any>>;
    onChange?: (e: any) => void;
    disabled?:any;
    defaultSelectedValue?:any;
  }
  const YsecDropdown2: React.FC<Props>;
  export default YsecDropdown2;
}


declare module 'Layout/YsecFont' {
  import React from 'react';
  export interface Props {
     className?: string;
    disabled?:boolean
     onClick?: React.MouseEventHandler<HTMLSpanElement>;
  }
  const YsecFont: React.FC<Props>;
  export default YsecFont;
}


declare module 'Layout/YsecButton2' {
  import React from 'react';
  export interface Props extends React.ButtonHTMLAttributes<HTMLButtonElement> {}
  const YsecButton2: React.FC<Props>;
  export default YsecButton2;
}

 declare module 'Layout/YsecMultipleCheck2' {
  import React from 'react';
  export interface Props {
     label?: string;
    mandatory?: boolean;
    name?: string;
    className?: string;
    objectNameKey?: string;
    objectValueKey?: string;
    value?:any,
    data?: Array<Record<string, any>>;
    onChange?: (e: any) => void;
    disabled?:any
    multiple?:boolean
  }
  const YsecMultipleCheck2: React.FC<Props>;
  export default YsecMultipleCheck2;
}


declare module 'YsecitUtilityWeb/YsecTable' {
  import React, { Ref } from 'react';

  export interface ColumnDef {
    id: string;
    header?: string | ((props: any) => React.ReactNode);
    size?: number;
    dragColumnDisable?: boolean;
    sortDisable?: boolean;
    pinDisable?: boolean;
    menuDisable?: boolean;
    classNameTh?: string;
    classNameTd?: string;
    filter?: boolean;
    search?: boolean;
    columnType?: 'display' | 'group';
    pin?: 'left' | 'right';
    cell?: (props: any) => React.ReactNode;
    exportFileSetting?: any;
    columns?: ColumnDef[]; // for group columns
    accessorKey?: string;
    subRows?: boolean;
    footer?: (props: any) => React.ReactNode;
    aggregatedCell?: (props: any) => React.ReactNode;
    aggregationFn?: 'sum' | 'min' | 'max' | 'extent' | 'mean' | 'median' | 'unique' | 'uniqueCount' | 'count';
  }

  export interface Props {
    rowData: any[];
    columnDefs: ColumnDef[];
    reRender?: boolean;
    filter?: boolean;
    columnSettingDisable?: boolean;
    exportFileDisable?: boolean;
    propsSettings?: {
      filter?: { displayElementID?: string };
      exportFile?: { displayElementID?: string };
      columnSetting?: { displayElementID?: string };
    };
    pagination?: boolean;
    pageSize?: number;
    tableRef?: Ref<any>;
    ExpandRowData?: React.ComponentType<any>;
    group?: any[];
    editCell?: boolean;
    densityStyle?: 'sm' | 'md';
    virtualizedRows?: boolean;
    visibleItems?: number;
    tableContainerHeight?: number;
    subRows?: boolean;
    copyCell?: boolean;
    dragColumnDisable?:boolean;
    // Additional props as required
  }

  const YsecTable: React.FC<Props>;
  export default YsecTable;
}




// declare module 'remoteApp/RemoteCard' {
//   import React from 'react';

//   export interface RemoteCardProps {
//     title: string;
//     content: string;
//   }

//   const RemoteCard: React.FC<RemoteCardProps>;
//   export default RemoteCard;
// }

// declare module 'remoteApp/RemoteHeader' {
//   import React from 'react';

//   export interface RemoteHeaderProps {
//     title: string;
//     subtitle?: string;
//   }

//   const RemoteHeader: React.FC<RemoteHeaderProps>;
//   export default RemoteHeader;
// }
