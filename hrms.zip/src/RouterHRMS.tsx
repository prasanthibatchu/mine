import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Navigate, Route, Routes, useParams } from "react-router-dom";
import AxiosLayout from "./apis/axios";
const SamplePage = React.lazy(() => import("./pages/samplePage/SamplePage"));
const NotFound = React.lazy(() => import("./pages/NotFound"));
const Teams = React.lazy(() => import("./pages/Teams/Teams"))
const Dashboard = React.lazy(() => import("./pages/Dashboard/Dashboard"))
const Registration = React.lazy(() => import("./pages/ManageEmployee/Registration/Registration"));
const Contracts = React.lazy(() => import("./pages/ManageEmployee/Contracts/Contract"));
const InsuranceAndFamilyDetails = React.lazy(() => import("./pages/ManageEmployee/InsuranceAndFamilyDet/InsuranceAndFamilyDet"))
const PerformanceEvolution = React.lazy(() => import("./pages/ManageEmployee/PerformanceEvalutions/PerformanceEvalutions"))
const EmployeeAnnouncements = React.lazy(() => import('./pages/ManageEmployee/Announcements/Announcements'))
const FoodHandlers = React.lazy(() => import("./pages/ManageEmployee/FoodHandlers/FoodHandlers"))
const LeaveSlot = React.lazy(() => import("./pages/ManageEmployee/LeaveSlot/LeaveSlot"))
const EmployeeRequests = React.lazy(() => import("./pages/ManageEmployee/EmployeeRequests/EmployeeRequests"))
const LeaveBalance = React.lazy(() => import("./pages/EmployeeReport/LeaveBalance/LeaveBalance"))
const StaffList = React.lazy(() => import("./pages/EmployeeReport/StaffList/StaffList"))
const EmployeeDetails = React.lazy(() => import("./pages/EmployeeReport/EmployeeDetails/EmployeeDetails"))
const StaffHistory = React.lazy(() => import("./pages/EmployeeReport/StaffHistory/StaffHistory"))
const EmployeeCards = React.lazy(() => import("./pages/EmployeeReport/EmployeeCards/EmployeeCards"))
const EmployeeDetailsReport = React.lazy(() => import("./pages/EmployeeReport/EmployeeDetailsReport/EmployeeDetailsReport"))
const PoliceClearance = React.lazy(() => import("./pages/EmployeeReport/PoliceClearance/PoliceClearance"))
const EmployeeData = React.lazy(() => import("./pages/EmployeeReport/EmployeeData/EmployeeData"))
const InsuranceAndPensionDetailsReport = React.lazy(() => import("./pages/EmployeeReport/InsuranceDetails/InsuranceAndPensionDet"))
const InsuranceAndFamilyDetailsReport = React.lazy(() => import("./pages/EmployeeReport/InsuranceDetails/InsuranceAndFamilyDet"))
const PensionReport = React.lazy(() => import("./pages/EmployeeReport/PensionReport/PensionReport"))
const LateAndWork = React.lazy(() => import("./pages/EmployeeReport/LateAndWork/LateAndWork"))
const AdditionalRequirements = React.lazy(() => import("./pages/EmployeeReport/AdditionalRequirements/AdditionalRequirements"))
const Covid19Certificate = React.lazy(() => import("./pages/EmployeeReport/CovidCertificate/CovidCertificate"))
const PensionHistory=React.lazy(() => import("./pages/EmployeeReport/PensionHistory/PensionHistory"))
const PendingContracts=React.lazy(() => import("./pages/EmployeeReport/PendingContracts/PendingContracts"))
const ClosingContracts=React.lazy(() => import("./pages/EmployeeReport/PendingContracts/ClosingContracts"))
const DownloadEmployeeDetails=React.lazy(()=>import("./pages/EmployeeReport/DownloadEmployeeDetails/DownloadEmployeeDetails"))
const LogReport=React.lazy(()=>import("./pages/EmployeeReport/LogReport/LogReport"))
const BlackListEmployees=React.lazy(()=>import("./pages/EmployeeReport/BlackListEmps/BlackListEmps"))
const TakenLeaves=React.lazy(()=>import("./pages/ManagePayroll/TakenLeaves/TakenLeaves"))
const AddLeaves=React.lazy(()=>import("./pages/ManagePayroll/AddLeaves/AddLeaves"))
const Advance=React.lazy(()=>import("./pages/ManagePayroll/Advance/Advance"))
const Loan=React.lazy(()=>import("./pages/ManagePayroll/Loan/Loan"))
const Rota=React.lazy(()=>import("./pages/ManagePayroll/Rota/Rota"))
const Exception=React.lazy(()=>import("./pages/ManagePayroll/Exception/Exception"))
const WarningLetter=React.lazy(()=>import("./pages/ManagePayroll/WarningLetter/WarningLetter"))
const OtherDeductions=React.lazy(()=>import("./pages/ManagePayroll/OtherDeductions/OtherDeductions"))

interface UserType {
  user: string;
  userName: string;
  companyId: number;
  company?: string;
}

const RouterHRMS = () => {
  const EncryptFun = (ID: any) => {
    return ID ? btoa(ID) : null;
  };
  const { user } = useSelector((state: any) => state.user);
  // setting baseURL ---------------------------------------- base url coming from Layout project api
  AxiosLayout.defaults.baseURL = user?.apiUrls?.apiURL;
  const [flagHRMAuthorization, setIflagHRMAuthorization] = useState<boolean>(false);
  let { productID } = useParams();
  const userString = localStorage.getItem('_user');
  const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
  useEffect(() => {
    const fetchToken = async () => {
      if (user?.apiUrls?.apiURL) {
        try {
          // const res = await AxiosLayout.get(user?.apiUrls?.apiURL + `Login/GenerateToken?UserId=${user.user}`);
          const res: any = await AxiosLayout.get(`Login/GenerateToken?UserId=${user.user}`);

          if (res.status === 200) {
            AxiosLayout.defaults.headers.common['HRMAuthorization'] = res.data;
            setIflagHRMAuthorization(true)
          }
        } catch (error) {
          console.error("Error generating token:", error);
        }
      }
    };

    fetchToken();
  }, [user]);
  return (
    EncryptFun(user?.apiUrls?.productId) === productID && flagHRMAuthorization && <Routes>

      <Route
        index
        element={userId?.companyId === 78 ? <Navigate to="teams" replace /> : <React.Suspense fallback={<>Loading...</>}>
          <SamplePage />
        </React.Suspense>}
      />
      <Route
        path="not-found"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <NotFound />
          </React.Suspense>
        }
      />
      <Route
        path="teams"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Teams />
          </React.Suspense>
        }
      />
      <Route
        path="dashboard"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Dashboard />
          </React.Suspense>
        }
      />
      <Route
        path="registration"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Registration />
          </React.Suspense>
        }
      />
      <Route
        path="contracts"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Contracts />
          </React.Suspense>
        }
      />
      <Route
        path="insurance-family-details"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <InsuranceAndFamilyDetails />
          </React.Suspense>
        }
      />
      <Route
        path="performance-evaluations"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <PerformanceEvolution />
          </React.Suspense>
        }
      />
      <Route
        path="employee-announcements"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <EmployeeAnnouncements />
          </React.Suspense>
        }
      />
      <Route
        path="food-handlers"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <FoodHandlers />
          </React.Suspense>
        }
      />
      <Route
        path="leave-slot"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <LeaveSlot />
          </React.Suspense>
        }
      />
      <Route
        path="employee-requests"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <EmployeeRequests />
          </React.Suspense>
        }
      />
      <Route
        path="leave-balance"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <LeaveBalance />
          </React.Suspense>
        }
      />
      <Route
        path="staff-list"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <StaffList />
          </React.Suspense>
        }
      />
      <Route
        path="employee-details"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <EmployeeDetails />
          </React.Suspense>
        }
      />
      <Route
        path="staff-history"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <StaffHistory />
          </React.Suspense>
        }
      />
      <Route
        path="employee-cards"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <EmployeeCards />
          </React.Suspense>
        }
      />
      <Route
        path="employee-details-report"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <EmployeeDetailsReport />
          </React.Suspense>
        }
      />
      <Route
        path="police-clearence"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <PoliceClearance />
          </React.Suspense>
        }
      />
      <Route
        path="employee-data"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <EmployeeData />
          </React.Suspense>
        }
      />
      <Route
        path="insurance-and-pension-details"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <InsuranceAndPensionDetailsReport />
          </React.Suspense>
        }
      />
      <Route
        path="insurance-and-family-report"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <InsuranceAndFamilyDetailsReport />
          </React.Suspense>
        }
      />
      <Route
        path="pension-report"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <PensionReport />
          </React.Suspense>
        }
      />
      <Route
        path="late-and-work-longer-than-shift-details"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <LateAndWork />
          </React.Suspense>
        }
      />
      <Route
        path="additional-requirements"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <AdditionalRequirements />
          </React.Suspense>
        }
      />
      <Route
        path="covid19-certificate"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Covid19Certificate />
          </React.Suspense>
        }
      />
       <Route
        path="pension-history"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <PensionHistory />
          </React.Suspense>
        }
      />
      <Route
        path="pending-contracts"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <PendingContracts />
          </React.Suspense>
        }
      />
      <Route
        path="closing-contracts"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <ClosingContracts />
          </React.Suspense>
        }
      />
      <Route
        path="download-employee-details"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <DownloadEmployeeDetails />
          </React.Suspense>
        }
      />
      <Route
        path="log-report"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <LogReport />
          </React.Suspense>
        }
      />
      <Route
        path="blacklist-employees"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <BlackListEmployees />
          </React.Suspense>
        }
      />
      <Route
        path="taken-leaves"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <TakenLeaves />
          </React.Suspense>
        }
      />
       <Route
        path="add-leaves"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <AddLeaves />
          </React.Suspense>
        }
      />
      <Route
        path="advance"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Advance />
          </React.Suspense>
        }
      />
      <Route
        path="loan"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Loan />
          </React.Suspense>
        }
      />
      <Route
        path="rota"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Rota />
          </React.Suspense>
        }
      />
      <Route
        path="exception"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Exception />
          </React.Suspense>
        }
      />
      <Route
        path="warning-letter"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <WarningLetter />
          </React.Suspense>
        }
      />
      <Route
        path="other-deduction"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <OtherDeductions />
          </React.Suspense>
        }
      />
    </Routes>
  );
};

export default RouterHRMS;
