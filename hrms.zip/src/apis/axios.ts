 
export const BASE_URL_IMAGE = '';
// AxiosLayout getting from Layout project
const axios_ = {
    AxiosLayout: await import("Layout/AxiosLayout").then(
      (module) => module?.default
    ),
  };
export default axios_.AxiosLayout;


