import React, { useEffect } from "react";
import "./LayoutHRMS.scss";
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate, useParams } from "react-router-dom";
import { useSelector } from "react-redux";

const EncryptFun = (ID:any) => {
  return ID ? btoa(ID) : null;
};


const LayoutHRMS = () => {
  const Layout:any = React.lazy(() => import("Layout/Layout"));
  let { companyID, productID } = useParams();
  const navigate = useNavigate();
  const { user } = useSelector((state:any) => state.user);

  useEffect(() => {
    const intervalId = setInterval(() => {
      //assign interval to a variable to clear it.
      if (companyID) {
        clearInterval(intervalId);
      } else loader();
    }, 1000);
    return () => clearInterval(intervalId); //This is important
  }, [user]);
  const loader = () => {
    if (!companyID) {
      navigate(`/hrms/${EncryptFun(user.companyId + "-erp-" + "444")}/NjA=`);
    }
  };

  return (
    <React.Suspense fallback={<div>Loading...</div>}>
      <Layout
        productId_={productID}
        companyId_={companyID}
        LayoutType="layoutHRMS"
      />
    </React.Suspense>
  );
};
export default LayoutHRMS;
