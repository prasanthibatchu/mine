import React from "react";
import { Route, Routes } from "react-router-dom";
  const RouterHRMS= React.lazy(() => import("./RouterHRMS"));

 interface RouterConfigurationProps {
  RequireAuth: React.ComponentType;
  Layout: any;
 LayoutType:string
}

const RouterConfiguration: React.FC<RouterConfigurationProps> = ({ RequireAuth, Layout, LayoutType }) => {

  return (
    <Routes>
      <Route element={<RequireAuth />}>
        <Route path="/" element={<Layout LayoutType={LayoutType} />}> 
        //don't add routing component in this js--  add in RouterHRMS.js
        <Route
            path="/hrms/:companyID/:productID/*"
            element={
              <React.Suspense fallback={<>Loading...</>}>
                <RouterHRMS/>
              </React.Suspense>
            }
          />      
        </Route>
      </Route>
    </Routes>
  );
};

export default RouterConfiguration;
