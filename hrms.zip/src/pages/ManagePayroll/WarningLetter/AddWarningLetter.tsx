import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

export const AddWarningLetter: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [openModal, setOpenModal] = useState<boolean>(false)
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [err, setErr] = useState<number>(0)
    const [isActive, setIsActive] = useState<boolean>(false)
    const [pay, setPay] = useState<boolean>(false)
    const [selectedDate, setSeletedDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [reasonDate, setReasondDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [remarks, setRemarks] = useState<string>("")
    const [selectedId, setSelectedId] = useState<number>(0)
    const [showDocs, setShowDocs] = useState<boolean>(false)
    const [docData, setDocData] = useState<any[]>([])
    const fileref = useRef<HTMLInputElement | any>(null)
    const [files, setFiles] = useState<any[]>([]);
    const [changeRadio, setChangeRadio] = useState<string | number>("empNote")

    const [empData, setEmpData] = useState<any>({
        selectedCompany: 0, selectLanguage: 0, emp_position: "", salary: "", selectedCurrency: 0, reason: "", reason_dutch: "", warning_text: "", text_dutch: "", manager_name: "", position: "", manager_remark: "", manger_dutch: "", signed: false, recived: false, delete: false, currency_name: ""
    })
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    console.log(props?.singleUserData, "props?.singleUserData")
    useEffect(() => {
        if (props?.singleUserData?.EmployeeNote === true) {
            setChangeRadio("empNote")
        }
        else if (props?.singleUserData?.NCNSwarning === true) {
            setChangeRadio("ncns")
        }
        else if (props?.singleUserData?.WarningLetter === true) {
            setChangeRadio("warn_letter")
        } else if (props?.singleUserData?.VerbalWarning === true) {
            setChangeRadio("verbal_letter")
        } else if (props?.singleUserData?.Suspension === true) {
            setChangeRadio("suspension")
        } else if (props?.singleUserData?.Termination === true) {
            setChangeRadio("termination")
        } else if (props?.singleUserData?.LeaveLetter === true) {
            setChangeRadio("leave")
        }
        else {
            return;
        }

        setEmpData({
            selectedCompany: props?.singleUserData?.CompanyId,
            selectLanguage: 0,
            emp_position: "",
            salary: props?.singleUserData?.Salary,
            selectedCurrency: props?.singleUserData?.CurrencyId,
            reason: props?.singleUserData?.Reason,
            reason_dutch: props?.singleUserData?.ReasonDutch,
            warning_text: props?.singleUserData?.LetterText,
            text_dutch: props?.singleUserData?.LetterTextDutch,
            manager_name: props?.singleUserData?.SignatoryName,
            position: props?.singleUserData?.SignatoryPossition,
            manager_remark: props?.singleUserData?.Comments,
            manger_dutch: props?.singleUserData?.ManagementCommentsDutch,
            signed: props?.singleUserData?.Signed,
            recived: props?.singleUserData?.Received,
            delete: props?.singleUserData?.Isactive === true ? false : true,
            currency_name: props?.singleUserData?.Currency
        })
        setSelectedId(props?.singleUserData?.LetterId)
        setSeletedDate(props?.singleUserData?.Date?.split("T")[0])
        setReasondDate(props?.singleUserData?.NCNSdate?.split("T")[0])

    }, [])
    useEffect(() => {
        if (empData.selectedCurrency !== 0) {
            const cdata = props?.currencyData?.filter((i: any) => i.CurrencyId === empData?.selectedCurrency)
            setEmpData({ ...empData, currency_name: cdata[0]?.Currency })
        }
    }, [empData.selectedCurrency])
    const onChange = async (e: any) => {
        setEmpData({ ...empData, [e.target.name]: e.target.value })
    }
    const handleCheckboxChange = (e: any) => {
        const { name, checked } = e.target;


        setEmpData((prev: any) => ({ ...prev, [name]: checked }));

    };
    const handleValidation = async (e: any) => {
        e.preventDefault()
        setErr(0)
        if (empData?.selectedCompany === 0) {
            setErr(1)
        }

        else {
            const payload = {
                letterId: selectedId,
                employeeId: props?.selectEmp,
                companyId: userId?.companyId,
                date: selectedDate,
                to: empData?.emp_position,
                letterText: empData?.warning_text,
                signatoryName: empData?.manager_name,
                signatoryPossition: empData?.position,
                isactive: empData?.delete === false ? true : false,
                ncnSdate: reasonDate,
                employeeNote: changeRadio === "empNote" ? true : false,
                ncnSwarning: changeRadio === "ncns" ? true : false,
                suspension: changeRadio === "suspension" ? true : false,
                verbalWarning: changeRadio === "verbal_letter" ? true : false,
                warningLetter: changeRadio === "warn_letter" ? true : false,
                reason: empData?.reason,
                comments: empData?.manager_remark,
                letterTextDutch: empData?.text_dutch,
                managementCommentsDutch: empData?.manger_dutch,
                reasonDutch: empData?.reason_dutch,
                termination: changeRadio === "termination" ? true : false,
                signed: empData?.signed,
                received: empData?.recived,
                employeeComments: props?.singleUserData?.EmployeeComments ?? "",
                casinoManager: props?.singleUserData?.CasinoManager ?? "",
                managingDirector: props?.singleUserData?.ManagingDirector ?? "",
                salary: empData?.salary=="" ?0:empData?.salary,
                currencyId: empData?.selectedCurrency,
                currency: empData?.currency_name,
                finalSettlementLetter: false,
                referenceLetter: false,
                leaveLetter: changeRadio === "leave" ? true : false,
                resignationWithNotice: false,
                resignationWithoutNotice: false,
                userId: userId?.user,
                documentTypeId: 0,
                documentPath: "",
                uploadDocPath: ""
            }
            console.log(payload, "payyy")
            AxiosLayout.post("/LeaveDetails/SaveorUpdateWarningLetterDetails", payload).then((res: any) => {
                if (res.data.Status === 1) {
                    props?.setData([])
                    props?.setCurrencyData([])
                    props?.setSingleUseData({})
                    handleClear()
                    props?.setAlertMessage(res?.data?.Message)
                    props?.getMasterData()
                    props?.getData()
                    props?.setOpen(false)

                }
                else {
                    setErrorMessage(res?.data?.Message)
                }
            })
        }
    }
    const handleClear = () => {
        setErr(0)
        setIsActive(false)
        setPay(false)
        setRemarks("")
        setSelectedId(0)
        setSeletedDate(new Date().toISOString()?.split("T")[0])
        setReasondDate(new Date().toISOString()?.split("T")[0])
        setEmpData({
            selectedCompany: 0, selectLanguage: 0, emp_position: "", salary: "", selectedCurrency: 0, reason: "", reason_dutch: "", warning_text: "", text_dutch: "", manager_name: "", position: "", manager_remark: "", manger_dutch: "", signed: false, recived: false, delete: false, currency_name: ""
        })
        setSeletedDate(new Date().toISOString()?.split("T")[0])
        setReasondDate(new Date().toISOString()?.split("T")[0])
    }



    const handleUploadFileButtonClick = () => {
        fileref.current?.click();
    };
    const handleFileChange = (e: any) => {
        const selectedFiles = Array.from(e.target.files);
        setFiles([...files, ...selectedFiles]);
    };

    const isFieldDisabled = (field: string) => {
        switch (field) {
            case "reason":
                return changeRadio === "empNote" || changeRadio === "ncns";
            case "reason_dutch":
                return changeRadio === "empNote" || changeRadio === "ncns";
            case "manager_remark":
                return changeRadio === "empNote" || changeRadio == "termination";
            case "manger_dutch":
                return changeRadio === "empNote" || changeRadio == "termination";
            case "emp_position":
                return changeRadio === "ncns" || changeRadio === "warn_letter" || changeRadio === "verbal_letter";
            case "salary":
                return changeRadio === "ncns" || changeRadio === "warn_letter" || changeRadio === "verbal_letter" || changeRadio == "termination";

            case "warning_text":
                return changeRadio == "termination";
            case "text_dutch":
                return changeRadio == "termination";
            default:
                return false;
        }
    };
    return (
        <div className='p-2 formsheight'>
            {alertMessage && (
                <div className="alert alert-success" role="alert">
                    {alertMessage}
                </div>
            )}
            {errorMessage && (
                <div className="alert alert-danger" role="alert">
                    {errorMessage}
                </div>
            )}

            <div>

                <Row>

                    <Col xs={12} md={4} lg={3} xl={2} className='mt-2'>
                        <YsecRadio
                            label="Employee Note"
                            name="changeRadio"
                            className="test"
                            id="leaveValue1"
                            value={"empNote"}
                            onChange={(e: any) => {
                                setChangeRadio(e.target.value)
                            }}
                            checked={changeRadio == "empNote"}
                        /></Col>
                    <Col xs={12} md={4} lg={3} xl={2} className='mt-2'>
                        <YsecRadio
                            label="NCNS Warning"
                            name="changeRadio"
                            className="test"
                            id="leaveValue2"
                            value={"ncns"}
                            onChange={(e: any) => {
                                setChangeRadio(e.target.value)
                            }}
                            checked={changeRadio == "ncns"}
                        />
                    </Col>
                    <Col xs={12} md={4} lg={3} xl={2} className='mt-2'>
                        <YsecRadio
                            label="Warning Letter"
                            name="changeRadio"
                            className="test"
                            id="leaveValue3"
                            value={"warn_letter"}
                            onChange={(e: any) => {
                                setChangeRadio(e.target.value)
                            }}
                            checked={changeRadio == "warn_letter"}
                        />
                    </Col>
                    <Col xs={12} md={4} lg={3} xl={2} className='mt-2'>
                        <YsecRadio
                            label="Verbal Letter"
                            name="changeRadio"
                            className="test"
                            id="leaveValue4"
                            value={"verbal_letter"}
                            onChange={(e: any) => {
                                setChangeRadio(e.target.value)
                            }}
                            checked={changeRadio == "verbal_letter"}
                        />
                    </Col>
                    <Col xs={12} md={4} lg={3} xl={2} className='mt-2'>
                        <YsecRadio
                            label="Suspension Letter"
                            name="changeRadio"
                            className="test"
                            id="leaveValue5"
                            value={"suspension"}
                            onChange={(e: any) => {
                                setChangeRadio(e.target.value)
                            }}
                            checked={changeRadio == "suspension"}
                        />
                    </Col>

                    <Col xs={12} md={4} lg={3} xl={2} className='mt-2'>
                        <YsecRadio
                            label="Termination Letter"
                            name="changeRadio"
                            className="test"
                            id="leaveValue6"
                            value={"termination"}
                            onChange={(e: any) => {
                                setChangeRadio(e.target.value)
                            }}
                            checked={changeRadio == "termination"}
                        />
                    </Col>
                    <Col xs={12} md={4} lg={3} xl={2} className='mt-2' >
                        <YsecRadio
                            label="Leave Letter"
                            name="changeRadio"
                            className="test"
                            id="leaveValue7"
                            value={"leave"}
                            onChange={(e: any) => {
                                setChangeRadio(e.target.value)
                            }}
                            checked={changeRadio == "leave"}
                        />
                    </Col>
                </Row>
                <Row>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput label="Employee Id" value={props?.selectEmp} disabled className='disableField' />
                    </Col>
                    <Col xs={12} md={6} lg={3} >
                        <YsecSelect className={`md`} name='selectedCompany'
                            objectNameKey="name"
                            objectValueKey="id"
                            data={[
                                { id: 0, name: "Select" },
                                { id: userId?.companyId, name: userId?.company }
                            ]}
                            value={empData?.selectedCompany}
                            label="Company" mandatory
                            onChange={onChange}

                        />
                        {err === 1 && <label className='error'>Please Select Company..</label>}

                    </Col>
                    <Col xs={12} md={6} lg={3} >
                        <YsecDatePicker
                            key={selectedDate}
                            name="selectedDate"
                            value={selectedDate}
                            className="md"
                            label="Date/Explanation"
                            error="test message"
                            onChange={(e: any) => setSeletedDate(e.target.value)}
                            ysecType="tab"
                            ysecFormat="YYYY-MM-D"
                            ysecMinDate="1000_Y"
                            ysecMaxDate="1000_Y"
                            placeholder="YYYY-MM-DD"
                            wrapperClass
                            multipleSelect={false}
                        />

                    </Col>
                    <Col xs={12} md={6} lg={3} >
                        <YsecDatePicker
                            key={reasonDate}
                            name="reasonDate"
                            value={reasonDate}
                            className="md"
                            label="Reason Date"
                            error="test message"
                            onChange={(e: any) => setReasondDate(e.target.value)}
                            ysecType="tab"
                            ysecFormat="YYYY-MM-D"
                            ysecMinDate="1000_Y"
                            ysecMaxDate="1000_Y"
                            placeholder="YYYY-MM-DD"
                            wrapperClass
                            multipleSelect={false}
                        />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput label="To/Employee Position" name="emp_position" value={empData?.emp_position} onChange={onChange} disabled={isFieldDisabled("emp_position")} className={`${isFieldDisabled("emp_position") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput label="Salary" key={empData?.salary} name="salary" value={empData?.salary} onChange={onChange} disabled={isFieldDisabled("salary")} className={`${isFieldDisabled("salary") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecSelect name='selectedCurrency'
                            objectNameKey="name"
                            objectValueKey="id"
                            data={[
                                { id: 0, name: "Select" },
                                ...props?.currencyData?.map((i: any) => ({
                                    id: i?.CurrencyId,
                                    name: i?.Currency
                                }))
                            ]}
                            value={empData?.selectedCurrency}
                            label="Currency Type" 
                            onChange={onChange}
                            disabled={isFieldDisabled("selectedCurrency")} className={`md ${isFieldDisabled("selectedCurrency") && "disableField"} `}
                        />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecSelect className={`md`} name='selectLanguage'
                            objectNameKey="name"
                            objectValueKey="id"
                            data={props?.languages?.map((i: any) => ({
                                id: i?.LanguageId,
                                name: i?.LanguageName
                            }))
                            }
                            value={empData?.selectLanguage}
                            label="Select Language" 
                            onChange={onChange}

                        />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput label="Text/Warning Type" name="warning_text" value={empData?.warning_text} onChange={onChange} disabled={isFieldDisabled("warning_text")} className={`${isFieldDisabled("warning_text") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput label="In Dutch" name="text_dutch" value={empData?.text_dutch} onChange={onChange} disabled={isFieldDisabled("text_dutch")} className={`${isFieldDisabled("text_dutch") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput label="Name/Manager" name="manager_name" value={empData?.manager_name} onChange={onChange} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput label="Position" name="position" value={empData?.position} onChange={onChange} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecTextarea label="Reason" name="reason" value={empData?.reason} onChange={onChange} disabled={isFieldDisabled("reason")} className={`${isFieldDisabled("reason") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecTextarea label="In Dutch" name="reason_dutch" value={empData?.reason_dutch} onChange={onChange} disabled={isFieldDisabled("reason_dutch")} className={`${isFieldDisabled("reason_dutch") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecTextarea label="Manager Remark" name="manager_remark" value={empData?.manager_remark} onChange={onChange} disabled={isFieldDisabled("manager_remark")} className={`${isFieldDisabled("manager_remark") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecTextarea label="In Dutch" name="manger_dutch" value={empData?.manger_dutch} onChange={onChange} disabled={isFieldDisabled("manger_dutch")} className={`${isFieldDisabled("manger_dutch") && "disableField"} `} />
                    </Col>
                    <Col xs={12} md={3} lg={1} className={"d-flex align-items-center mt-3"}>
                        <YsecCheckbox key={empData?.delete}
                            label="Delete"
                            className="sm"
                            name="delete"
                            value={empData?.delete}
                            checked={empData?.delete}
                            onChange={handleCheckboxChange}
                        />
                    </Col>
                    <Col xs={12} md={5} lg={7}>
                        <Row className='mt-3'>

                            <Col xs={12} md={6} lg={3}><YsecButton className='mt-1 mb-1 w-100 cancel' >Scan</YsecButton></Col>
                            <Col xs={12} md={6} lg={3}>
                                <YsecButton className='mt-1 mb-1 w-100 cancel' type='button' onClick={handleUploadFileButtonClick}>
                                    Upload File
                                </YsecButton>
                                <input
                                    ref={fileref}
                                    type="file"
                                    // multiple
                                    accept=".pdf,.doc,.docx"
                                    style={{ display: 'none' }}
                                    onChange={handleFileChange}
                                />
                            </Col>
                            <Col xs={12} md={6} lg={3}><YsecButton className='mt-1 mb-1 w-100 cancel' type='button' onClick={() => { setShowDocs(true) }}>View Doc</YsecButton></Col>
                            <Col xs={12} md={6} lg={3}><YsecButton className='mt-1 mb-1 w-100 cancel' type='button'>Delete Doc</YsecButton></Col>
                        </Row>

                    </Col>
                    <Col xs={12} md={2} lg={2} className={"d-flex align-items-end mt-3"}>
                        <YsecCheckbox key={empData?.signed}
                            label="Signed"
                            className="sm"
                            name="signed"
                            value={empData?.signed}
                            checked={empData?.signed}
                            onChange={handleCheckboxChange}
                        />
                    </Col>
                    <Col xs={12} md={2} lg={2} className={"d-flex align-items-end mt-3"}>
                        <YsecCheckbox key={empData?.recived}
                            label="Received"
                            className="sm"
                            name="recived"
                            value={empData?.recived}
                            checked={empData?.recived}
                            onChange={handleCheckboxChange}
                        />
                    </Col>



                </Row>
                <Row className='mt-5 customButns'>
                    <Col xs={12} className='d-flex justify-content-end'>
                        <YsecButton className="me-1 ms-1" type="button" onClick={handleValidation}>Save</YsecButton>
                        <YsecButton className="me-1 ms-1" type="button" >Preview</YsecButton>
                        <YsecButton className="me-1 ms-1 " type="button" onClick={handleClear}>Clear</YsecButton>

                    </Col>
                </Row>



            </div>

        </div>
    )
}