import { Form, Modal } from "react-bootstrap"
import React, { useState } from 'react'
import AxiosLayout from "../../apis/axios";


type Job = {
    Id: number;
    Description: string;
    IsActive?: any;
    Hours?: any;
    Paid?: boolean;
};
interface UserType {
    user: string;
    userName: string;
    companyId: Number;
    // Add more fields if you expect them
}
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

export const CustomModalPayroll: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [header, setHeader] = useState<string>("")
    const [leaveType, setLeaveType] = useState<string>("")
    const [hours, setHours] = useState<string>("")
    const [selectedJob, setSelectedJob] = useState<number>(0)
    const [chcekSelected, setCheckSelected] = useState<boolean>(true)
    const [err, setErr] = useState<number>(0)
    const [expandedRows, setExpandedRows] = useState<string | null>(null);

    const toggleRow = (headDescription: string) => {
        setExpandedRows(prevExpanded =>
            prevExpanded === headDescription ? null : headDescription
        );
    };

    // Create a Set to store unique HeadDescriptions
    const uniqueHeadDescriptions = new Set(props?.data?.map((item: any) => item.HeadDescription));

    const handlesubmit = async (e: any) => {
        e.preventDefault()
        if (header === "") {
            setErr(1)
        }
        else if (leaveType === "") {
            setErr(2)
        }
        else if (hours === "") {
            setErr(3)
        }
        else {
            const payload = {

                tableId: props?.LeaveType,
                id: 0,
                headDescription: leaveType,
                description: header,
                hours: Number(hours),
                paid: chcekSelected,
                isActive: true,
                companyId: userId?.companyId,
                locationId: props?.locationId,
                userId: userId?.user

            }

            AxiosLayout.post("/LeaveDetails/SaveUpdatePopupLeaveExceptionType", payload).then((res: any) => {

                if (res.status === 200) {
                    props?.setAlertMessage(res.data.Message)
                    handleClear()
                    props?.getJobCommonData()
                    props?.getLeaveData()
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                    handleClear()
                    props?.getJobCommonData()
                    props?.getLeaveData()
                }


            })
        }
    }
    const handleClear = () => {
        setHeader("")
        setSelectedJob(0)
        setCheckSelected(true)
        setHeader("")
        setLeaveType("")
        setHours("")
        setCheckSelected(true)
        // props?.setAddName("")
        // props?.setAddType(0)
        // props.setOpen(false)
    }
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">Leave Type</p>
                <button type="button" className="btn-close" onClick={() => {


                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <YsecSelect className={`md`}
                    objectNameKey="name"
                    objectValueKey="id"
                    data={[
                        { id: 0, name: "Select" },
                        ...props?.leaveTypeData?.map((i: any) => ({
                            id: i?.LeaveTypeId,
                            name: i?.Description
                        }))
                    ]}
                    value={header}
                    label="Header" mandatory
                onChange={(e) => setHeader(e.target.value)}

                />
                {err === 1 && <label className='error'>Please Select Heder Name...</label>}

                <YsecInput label="Leave Type" name="leaveType" value={leaveType} onChange={(e) => setLeaveType(e.target.value)} mandatory />
                {err === 2 && <label className='error'>Please Enter Leave Type...</label>}
                <YsecInput label="Hours" name="hours" value={hours} onChange={(e) => setHours(e.target.value)} mandatory type="number"/>
                {err === 3 && <label className='error'>Please Enter Hours...</label>}
                
                <Form.Check className="mt-2 opening"
                    type="checkbox"
                    id="isActive"
                    label="Paid"
                    checked={chcekSelected}
                    onChange={(e) => setCheckSelected(e.target.checked)}
                />

                <div className="d-flex slign-itemd-center justify-content-end mt-3">
                    <YsecButton className="ms-1 me-1" type="button" onClick={handlesubmit} >Save</YsecButton>
                    <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
                </div>
            </Modal.Body>
            <Modal.Body className="modaltable">

                <div className="katableee">

                    <table className="leavetypetable">
                        <tr>
                            <th>Hours</th>
                            <th>Leave Type</th>
                            <th>Paid</th>
                        </tr>
                        <tbody>
                            {[...uniqueHeadDescriptions].map((headDescription: any) => (
                                <React.Fragment key={headDescription}>
                                    <tr onClick={() => toggleRow(headDescription)} style={{ cursor: 'pointer' }}>
                                        <td colSpan={3}>
                                            {expandedRows === headDescription ? <YsecFont className="yf-chevron-down" /> : <YsecFont className="yf-chevron-right" />}{headDescription}
                                        </td>
                                    </tr>

                                    {expandedRows === headDescription && (
                                        // Filter the original data to show only items matching the expanded HeadDescription
                                        props?.data
                                            ?.filter((item: any) => item.HeadDescription === headDescription)
                                            .map((item: any) => (
                                                <tr key={item.Id} onClick={() => {
                                                    setSelectedJob(item?.Id)
                                                    setHeader(item?.Id)
                                                    setLeaveType(item?.HeadDescription)
                                                    setHours(item?.Hours)
                                                    setCheckSelected(item?.Paid)
                                                }}> {/* Use item.Id as key for sub-rows */}
                                                    <td>{item?.Hours}</td>
                                                    <td>{item?.Description}</td>
                                                    <td>
                                                        <Form.Check className="mt-2 opening"
                                                            type="checkbox"
                                                            checked={item?.Paid === true}
                                                        />
                                                    </td>
                                                </tr>
                                            ))
                                    )}
                                </React.Fragment>
                            ))}
                        </tbody>




                    </table>

                </div>
            </Modal.Body>
        </Modal>
    )
}

