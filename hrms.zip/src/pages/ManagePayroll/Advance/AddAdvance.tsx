import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

export const AddAdvance: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;

    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [err, setErr] = useState<number>(0)
    const [isActive, setIsActive] = useState<boolean>(true)
    const [selectedCurrency, setSelectedCurrency] = useState<number>(0)
    const [advanceType, setAdvanceType] = useState<number>(0)
    const [selectSalPeriod, setSelectSalPeriod] = useState<number>(0)
    const [selectedDate, setSeletedDate] = useState<string>("")
    const [amount, setAmount] = useState<number>(0)
    const [paidAmount, setPaidAmount] = useState<number>(0)
    const [balance, setBalance] = useState<number | null>(null)
    const [remarks,setRemarks]=useState<string>("")
    const [selectedId,setSelectedId]=useState<number>(0)
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    console.log(props?.singleUserData)
    useEffect(() => {
 setAdvanceType(props?.singleUserData?.AdvanceTypeId)
 setSelectedCurrency(props?.singleUserData?.CurrencyId)
 setSelectedId(props?.singleUserData?.AdvancePaymentId)
 setSelectSalPeriod(props?.singleUserData?.SalaryPeriod)
 setSeletedDate(props?.singleUserData?.AdvDate?.split("T")[0])
 setAmount(props?.singleUserData?.Amount)
 setPaidAmount(props?.singleUserData?.PaidAmount)
 setBalance(props?.singleUserData?.Balance)
 setRemarks(props?.singleUserData?.Remark)
 setIsActive(props?.singleUserData?.IsActive)

    }, [])

    useEffect(() => {
        const calculated = Number(amount) - Number(paidAmount);
        if (!isNaN(calculated)) {
            setBalance(calculated);
        }
    }, [amount, paidAmount]);
    const handleValidation = async (e: any) => {
        e.preventDefault()
        setErr(0)
        if (selectedCurrency === 0) {
            setErr(1)
        }
        else if (advanceType === 0) {
            setErr(2)
        }
        else if (selectSalPeriod === 0) {
            setErr(3)
        }
        else if (selectedDate === "") {
            setErr(4)
        }
        else if (amount === 0) {
            setErr(5)
        }
        else {
            const payload = {
                employeeId: props?.selectEmp,
                advanceTypeId: advanceType,
                currencyTypeId: selectedCurrency,
                advDate: selectedDate,
                amount: amount,
                salaryPeriodId: selectSalPeriod,
                paidAmount: paidAmount,
                balance: balance,
                remark: remarks,
                isActive: isActive,
                userId: userId?.user,
                companyId: userId?.companyId,
                advancePaymentId: selectedId
            }
            AxiosLayout.post("/Advance/SaveAdvanceDetails", payload).then((res: any) => {
                if (res.data.Status === 1) {              
                    props?.setData([])     
                   props?.setAlertMessage(res?.data?.Message)
                   props?.getData()
               props?.setOpen(false)
              
                }
                else{
                setErrorMessage(res?.data?.Message)
                }
            })
        }
    }
    const handleClear = () => {
        setErr(0)
        setSelectSalPeriod(0)
        setAdvanceType(0)
        setAmount(0)
        setBalance(0)
        setPaidAmount(0)
        setIsActive(true)
        setRemarks("")
        setSelectedId(0)
        setSelectedCurrency(0)
        setAdvanceType(0)
        setSeletedDate("")
    }



    return (
        <div className='p-2 formsheight'>
            {alertMessage && (
                <div className="alert alert-success" role="alert">
                    {alertMessage}
                </div>
            )}
            {errorMessage && (
                <div className="alert alert-danger" role="alert">
                    {errorMessage}
                </div>
            )}

            <Row>
                <Col md={2} className='md-none'></Col>
                <Col xs={12} md={8}>
                    <div className='bg-white p-5'>
                        <Row>
                            <Col xs={12}>
                                <YsecInput label="Employee Id" value={props?.selectEmp} disabled className='disableField' />
                            </Col>
                            <Col xs={12} >

                                <YsecSelect className={`md`} name='selectedCurrency'
                                    key={selectedCurrency}
                                    objectNameKey="name"
                                    objectValueKey="id"
                                    data={[
                                        { id: 0, name: "Select" },
                                        ...props?.currencyData?.map((i: any) => ({
                                            id: i?.CurrencyId,
                                            name: i?.Currency
                                        }))
                                    ]}
                                    value={selectedCurrency}
                                    label="Currency Type" mandatory
                                    onChange={(e: any) => {
                                        setSelectedCurrency(e.target.value)
                                    }}

                                />
                                {err === 1 && <label className='error'>Please Select Currency Type..</label>}

                            </Col>
                            <Col xs={12} >

                                <YsecSelect className={`md`} name='advanceType'
                                    key={advanceType}
                                    objectNameKey="name"
                                    objectValueKey="id"
                                    data={props?.advTypes?.map((i: any) => ({
                                            id: i?.AdvancePaymentTypeId,
                                            name: i?.Description
                                        }))}
                                    value={advanceType}
                                    label="Advance Type" mandatory
                                    onChange={(e: any) => {
                                        setAdvanceType(e.target.value)
                                    }}

                                />
                                {err === 2 && <label className='error'>Please Select Advance Type..</label>}

                            </Col>
                            <Col xs={12} >

                                <YsecSelect className={`md`} name='selectSalPeriod'
                                    key={selectSalPeriod}
                                    objectNameKey="name"
                                    objectValueKey="id"
                                    data={[
                                        { id: 0, name: "Select" },
                                        ...props?.salaryPeriodData?.map((i: any) => ({
                                            id: i?.SalaryPeriod,
                                            name: i?.PeriodStart?.split("T")[0]+" - "+i?.PeriodEnd?.split("T")[0]
                                        }))
                                    ]}
                                    value={selectSalPeriod}
                                    label="Salary Period" mandatory
                                    onChange={(e: any) => {
                                        setSelectSalPeriod(e.target.value)
                                    }}

                                />
                                {err === 3 && <label className='error'>Please Select Salary Period..</label>}

                            </Col>
                            <Col xs={12} >
                                <YsecDatePicker
                                    key={selectedDate}
                                    name="selectedDate"
                                    value={selectedDate}
                                    className="md"
                                    label="Date"
                                    error="test message"
                                    onChange={(e: any) => setSeletedDate(e.target.value)}
                                    ysecType="tab"
                                    ysecFormat="YYYY-MM-D"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y"
                                    placeholder="YYYY-MM-DD"
                                    wrapperClass
                                    multipleSelect={false}
                                    mandatory
                                />
                                {err === 4 && <label className='error'>Please Selcet Date..</label>}
                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Amount" type={"number"} name="amount" mandatory value={amount} onChange={(e: any) => {
                                    setAmount(e.target.value)
                                }} />
                                {err === 5 && <label className='error'>Please Enter Amount..</label>}

                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Paid Amount" type={"number"} name="paidAmount" value={paidAmount} onChange={(e: any) => {
                                    setPaidAmount(e.target.value)
                                }} />

                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Balance" value={balance} disabled className='disableField' />
                            </Col>
                             <Col xs={12}>
                                <YsecTextarea label="Remarks" value={remarks} name="remarks" onChange={(e:any)=>setRemarks(e.target.value)} />
                            </Col>
                            <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                                <YsecCheckbox
                                    label="IsActive"
                                    className="sm"
                                    name="isActive"
                                    value={isActive}
                                    checked={isActive}
                                    onChange={(e: any) => setIsActive(!isActive)}
                                />
                            </Col>
                        </Row>
                        <Row className='mt-5 customButns'>
                            <Col xs={12} className='d-flex justify-content-end'>
                                <YsecButton className="me-1 ms-1 cancel" type="button" onClick={handleClear}>Cancel</YsecButton>
                                <YsecButton className="me-1 ms-1" type="button" onClick={handleValidation}>Save</YsecButton>
                            </Col>
                        </Row></div>
                </Col>

                <Col md={2} className='md-none'></Col>

            </Row>


        </div>
    )
}