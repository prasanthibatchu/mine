import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { AddAdvance } from './AddAdvance';
// import { ApplyLeaves } from './ApplyLeave';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
enum LeaveTypeEnum {
    LeaveType = 1,

}
const Advance: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [open, setOpen] = useState<boolean>(false)
    const [empData, setEmpData] = useState<any[]>([])
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [locationId, setLocationId] = useState<number>(0)
    const [loading, setLoading] = useState<boolean>(false);
    const tableRef = useRef<any>(null);
    const [data, setData] = useState<any[]>([])
    const [leaveTypeTableData, setLeaveTypeTableData] = useState<any[]>([])
    const [singleUserData, setSingleUseData] = useState<any>({})
const [currencyData,setCurrencyData]=useState<any[]>([])
const [salaryPeriodData,setSalaryPeriodData]=useState<any[]>([])
const [advTypes,setAdvTypes]=useState<any[]>([])
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => {
        getMasterData()
        getEmployeeData()
    

    }, []);
    useEffect(() => {
        if (selectEmp !== 0) {
            if (selectedBrand == 0) {
                setErrorMessage("Please Select Brand...");
            }
            else if (selectEmp === 0) {
                setErrorMessage("Please Select Employee...");
            }
            else {
                getData();
                getLeaveTypes()
                    getAdvTypes()
            }
        }
    }, [selectEmp, selectedBrand]);

    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if(res?.data?.CurrencyList !==null){
                    setCurrencyData(res.data?.CurrencyList)
                }
                if(res?.data?.SalaryPeriodList !==null){
                    setSalaryPeriodData(res?.data?.SalaryPeriodList)
                }
                setLoading(false)
            }
        })
    }

    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }
const getAdvTypes=()=>{
    AxiosLayout.get(`/Common/GetCurrAdvanceTypes?CompanyId=${locationId}&UserId=${userId?.user}`).then((res:any)=>{
        if(res.status===200){
            setAdvTypes(res.data?.AdvancePaymentTypes)
        }
    })
}

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }
    const getLeaveTypes = () => {
        AxiosLayout.get(`/LeaveDetails/GetEmployeeLeaveExceptionType?LocationId=${locationId}&tableid=${LeaveTypeEnum?.LeaveType}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setLeaveTypeTableData(res?.data)
            }
        })
    }
    const getData = () => {
        // setOpen(false)
        setLoading(true)
        AxiosLayout.get(`/Advance/GetAdvanceView?EmployeeId=${selectEmp}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setData(res?.data)
                setLoading(false)
            }
        })
    }
    const hanadleUpdateData = () => {
        if (selectEmp === 0) {
            setErrorMessage("Please Select Employee...");
        }
        else {
            setOpen(true)
        }
    }

    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 100 },
        { id: 'FullName', header: 'Full Name', filter: true, size: 100 },
        {
            id: 'AdvDate', header: 'Adv date', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { AdvDate } = row.original;
                return (
                    <>{AdvDate?.split("T")[0]}</>
                );
            },
        },
        { id: 'Amount', header: 'Amount', filter: true, size: 100 },
        { id: 'PaidAmount', header: 'Paid Amount', filter: true, size: 100 },
        { id: 'Balance', header: 'Balance', filter: true, size: 100 },
        { id: 'Description', header: 'Advance Payment', filter: true, size: 100 },
        {
            id: 'PeriodStart', header: 'Period Start', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { PeriodStart } = row.original;
                return (
                    <>{PeriodStart?.split("T")[0]}</>
                );
            },
        },
        {
            id: 'PeriodEnd', header: 'Period End', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { PeriodEnd } = row.original;
                return (
                    <>{PeriodEnd?.split("T")[0]}</>
                );
            },
        },
        { id: 'Currency', header: 'Currency Code', filter: true, size: 100 },
        { id: 'Remark', header: 'Remarks', filter: true, size: 100 },
        {
            id: 'IsActive', header: 'Is Active', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { IsActive } = row.original;
                return (
                    <div className='text-center'>
                        <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} /></div>
                );
            },
        },
        {
            id: 'IsVerified', header: 'Is Verified', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { IsVerified } = row.original;
                return (
                    <div className='text-center'>
                        <input type='checkbox' value={IsVerified} name='IsVerified' checked={IsVerified === true} /></div>
                );
            },
        },


        {
            id: 'edit', header: 'Edit', filter: false, size: 50, cell: ({ row }: { row: any }) => {
                const { EmployeeId } = row.original;

                return (
                    <div className='text-center'>
                        <EditData rowKeyValue={EmployeeId} rowdata={row?.original} />
                    </div>
                );
            },
        },


    ]
    const EditData = ({ rowKeyValue, rowdata }: { rowKeyValue: any, rowdata: any }) => {
        const handleData = () => {
            setSingleUseData(rowdata)
            // console.log(rowdata)

            setOpen(true)
        }
        return (
            <YsecFont className={`yf-document-edit action-icon`}
                onClick={handleData}
            />
        )
    }
    return (
        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Payroll</Breadcrumb.Item>
                            <Breadcrumb.Item active>Advance</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm p-0 ${open !== true && 'cancel'} ${(open === true) && "disbutn"}`}
                            onClick={hanadleUpdateData}
                            disabled={(open === true)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 history  ${open === true && 'cancel'}`} onClick={() => {
                            getData()
                            setOpen(false)
                        }}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>

                    </div>
                </div>
                <div className='manager-container'>

                    <Row className='p-2 m-1'>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >
                            <YsecSelect className={`md ${open === true && "disableField"}`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                label="Brand" mandatory
                                onChange={(e) => handleSelectBrand(e.target.value)}
                                disabled={open === true}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >

                            <YsecDropdown className={`md ${open === true && "disableField"}`}
                                label="Employee" mandatory value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                data={[
                                    { empId: 0, empName: "Select" },
                                    ...empData?.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))
                                ]}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                defaultSelectedValue="0"
                                disabled={open === true}
                            />
                        </Col>

                    </Row>
                    {open === true ? <AddAdvance selectedBrand={selectedBrand} selectBrand={selectedBrand} selectEmp={selectEmp} locationId={locationId} brandData={brandData} setLocationId={setLocationId} data={data} getData={getData}  leaveTypeTableData={leaveTypeTableData} LeaveType={LeaveTypeEnum?.LeaveType} getLeaveTypes={getLeaveTypes}  singleUserData={singleUserData} setSingleUseData={setSingleUseData} currencyData={currencyData} salaryPeriodData={salaryPeriodData} setOpen={setOpen} setAlertMessage={setAlertMessage} setErrorMessage={setErrorMessage} advTypes={advTypes} setData={setData}/> :
                    <>
                    <div className='katable contractstable m-1 bg-white pt-2 pb-2'>
                        {data?.length > 0 ? (

                            <YsecTable
                                rowData={data}
                                columnDefs={staticColumns}
                                filter={true}
                                pagination={true}
                                tableRef={tableRef}
                                pageSize={20}
                                dragColumnDisable={true}

                            />
                        ) : <p className='mb-0 p-3 text-center'>No data Found Here...</p>}

                    </div>
                   </>} 
                </div>

            </React.Suspense>
        </div>
    );
};
export default Advance;