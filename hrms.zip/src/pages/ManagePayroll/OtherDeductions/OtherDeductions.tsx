import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { AddOtherDeduction } from './AddOtherDeductions';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
enum LeaveTypeEnum {
    LeaveType = 1,

}
const OtherDeductions: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [open, setOpen] = useState<boolean>(false)
    const [empData, setEmpData] = useState<any[]>([])
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [locationId, setLocationId] = useState<number>(0)
    const [loading, setLoading] = useState<boolean>(false);
    const tableRef = useRef<any>(null);
    const [data, setData] = useState<any[]>([])
    const [singleUserData, setSingleUseData] = useState<any>({})
const [currencyData,setCurrencyData]=useState<any[]>([])
const [paybackDetails,setPaybackDetails]=useState<any[]>([])
const [loanTypes,setLoanTypes]=useState<any[]>([])
const [salaryPeriodData,setSalaryPeriodData]=useState<any[]>([])

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => {
        getMasterData()
        getEmployeeData()
        getCommeonData()
    }, []);
    useEffect(() => {
        if (selectEmp !== 0) {
            if (selectedBrand == 0) {
                setErrorMessage("Please Select Brand...");
            }
            else if (selectEmp === 0) {
                setErrorMessage("Please Select Employee...");
            }
            else {
                getData();
            }
        }
    }, [selectEmp, selectedBrand]);

    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if(res?.data?.CurrencyList !==null){
                    setCurrencyData(res.data?.CurrencyList)
                }
                if(res?.data?.SalaryPeriodList !==null){
                    setSalaryPeriodData(res?.data?.SalaryPeriodList)
                }
                setLoading(false)
            }
        })
    }

    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }
    const getCommeonData=()=>{
        AxiosLayout.get(`/PayRoll/GetPayRollCommonData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res:any)=>{
setLoanTypes(res?.data)
        })
    }


    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }

    const getData = () => {
        // setOpen(false)
        setLoading(true)
        setData([])
        AxiosLayout.get(`/PayRoll/GetEmployeePenalty?EmployeeID=${selectEmp}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setData(res?.data?.PenaltyDetails)
                setPaybackDetails(res?.data?.PaybackSchedules)
                setLoading(false)
            }
        })
    }
    const hanadleUpdateData = () => {
        if (selectEmp === 0) {
            setErrorMessage("Please Select Employee...");
        }
        else {
            setOpen(true)
        }
    }

    const staticColumns = [
        { id: 'Description', header: 'Description', filter: true, size: 100 },
        { id: 'Currency', header: 'Currency', filter: true, size: 100 },
        {
            id: 'Date', header: 'Date', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { Date } = row.original;
                return (
                    <>{Date?.split("T")[0]}</>
                );
            },
        },
        { id: 'Amount', header: 'Amount', filter: true, size: 100 },
      
        { id: 'Remarks', header: 'Remarks', filter: true, size: 100 },
          { id: 'PaybackCount', header: 'Payback Count', filter: true, size: 100 },
        {
            id: 'IsActive', header: 'Is Active', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { IsActive } = row.original;
                return (
                    <div className='text-center'>
                        <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} /></div>
                );
            },
        },
       


        {
            id: 'edit', header: 'Edit', filter: false, size: 50, cell: ({ row }: { row: any }) => {
                const { EmployeeId } = row.original;

                return (
                    <div className='text-center'>
                        <EditData rowKeyValue={EmployeeId} rowdata={row?.original} />
                    </div>
                );
            },
        },


    ]
    const EditData = ({ rowKeyValue, rowdata }: { rowKeyValue: any, rowdata: any }) => {
        const handleData = () => {
            setSingleUseData(rowdata)
            // console.log(rowdata)

            setOpen(true)
        }
        return (
            <YsecFont className={`yf-document-edit action-icon`}
                onClick={handleData}
            />
        )
    }
    return (
        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Payroll</Breadcrumb.Item>
                            <Breadcrumb.Item active>Other Deduction</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm p-0 ${open !== true && 'cancel'} ${(open === true) && "disbutn"}`}
                            onClick={hanadleUpdateData}
                            disabled={(open === true)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 history  ${open === true && 'cancel'}`} onClick={() => {
                            getData()
                            setOpen(false)
                        }}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>

                    </div>
                </div>
                <div className='manager-container'>

                    <Row className='p-2 m-1'>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >
                            <YsecSelect className={`md ${open === true && "disableField"}`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                label="Brand" mandatory
                                onChange={(e) => handleSelectBrand(e.target.value)}
                                disabled={open === true}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >

                            <YsecDropdown className={`md ${open === true && "disableField"}`}
                                label="Employee" mandatory value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                data={[
                                    { empId: 0, empName: "Select" },
                                    ...empData?.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))
                                ]}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                defaultSelectedValue="0"
                                disabled={open === true}
                            />
                        </Col>

                    </Row>
                    {open === true ? <AddOtherDeduction selectedBrand={selectedBrand} selectBrand={selectedBrand} selectEmp={selectEmp} locationId={locationId} brandData={brandData} setLocationId={setLocationId} data={data} getData={getData}   singleUserData={singleUserData} setSingleUseData={setSingleUseData} currencyData={currencyData}  setOpen={setOpen} setAlertMessage={setAlertMessage} setErrorMessage={setErrorMessage} setData={setData} paybackDetails={paybackDetails} loanTypes={loanTypes} setPaybackDetails={setPaybackDetails} salaryPeriodData={salaryPeriodData} getCommeonData={getCommeonData}/> :
                    <>
                    <div className='katable contractstable m-1 bg-white pt-2 pb-2'>
                        {data?.length > 0 ? (

                            <YsecTable
                                rowData={data}
                                columnDefs={staticColumns}
                                filter={true}
                                pagination={true}
                                tableRef={tableRef}
                                pageSize={20}
                                dragColumnDisable={true}

                            />
                        ) : <p className='mb-0 p-3 text-center'>No data Found Here...</p>}

                    </div>
                   </>} 
                </div>

            </React.Suspense>
        </div>
    );
};
export default OtherDeductions;