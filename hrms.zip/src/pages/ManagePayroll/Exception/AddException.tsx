import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { CustomModalException } from './CustomModal';
import { CustomViewDocModal } from '../../ManageEmployee/CustomDocViewModal';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
export enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}
export const AddException: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [openModal, setOpenModal] = useState<boolean>(false)
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [err, setErr] = useState<number>(0)
    const [isActive, setIsActive] = useState<boolean>(false)
    const [pay, setPay] = useState<boolean>(false)
    const [isVerify, setIsVerify] = useState<boolean>(false)
    const [selectedDate, setSeletedDate] = useState<string>("")
    const [remarks, setRemarks] = useState<string>("")
    const [selectedId, setSelectedId] = useState<number>(0)
    const [selectedExcType, setSelectedExcType] = useState<number>(0)
    const [excHours, setExcHours] = useState<number | null>(null)
    const [showDocs, setShowDocs] = useState<boolean>(false)
    const [docData, setDocData] = useState<any[]>([])
    const fileref = useRef<HTMLInputElement | any>(null)
    const [files, setFiles] = useState<any[]>([]);
    const [excName, setExcName] = useState<string>("")
    
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
       useEffect(() => {
            getDocData()
        }, [])
    useEffect(() => {
        setSelectedId(props?.singleUserData?.ExceptionID)
        setSelectedExcType(props?.singleUserData?.ExceptionTypeId)
        setSeletedDate(props?.singleUserData?.ExcDate?.split("T")[0])
        setExcHours(props?.singleUserData?.ExcHours)
        setRemarks(props?.singleUserData?.Remarks)
        setIsActive(props?.singleUserData?.IsActive)
        setPay(props?.singleUserData?.Pay)
        //  setIsVerify(props?.singleUserData?.IsActive)

    }, [])

    const getDocData = () => {
        AxiosLayout.get(`/Common/GetDocumentDetails?EmployeeId=${props?.selectEmp}&DocTypeId=${DocumentType?.EmpException}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setDocData(res?.data)
            }
        })
    }
    // useEffect(() => {
    //     const calculated = Number(amount) - Number(paidAmount);
    //     if (!isNaN(calculated)) {
    //         setBalance(calculated);
    //     }
    // }, [amount, paidAmount]);

    const handleValidation = async (e: any) => {
        e.preventDefault()
        setErr(0)
        if (selectedExcType === 0) {
            setErr(1)
        }
        else if (selectedDate === "") {
            setErr(2)
        }
        else if (excHours == null) {
            setErr(3)
        }

        else {
            const payload = {
                exceptionID: selectedId,
                employeeID: props?.selectEmp,
                exceptionTypeId: selectedExcType,
                excDate: selectedDate,
                excHours: excHours,
                remarks: remarks,
                pay: pay,
                contractId: props?.singleUserData?.ContractId ?? 0,
                isActive: isActive,
                asSeen: props?.singleUserData?.AsSeen ?? false,
                days: props?.singleUserData?.Days ?? 0,
                refLeaveId: props?.singleUserData?.RefLeaveId ?? 0,
                statusid: props?.singleUserData?.Statusid ?? false,
                verifiedBy: userId?.user,
                verifiedDate: new Date().toISOString()?.split("T")[0],
                approvedBy: props?.singleUserData?.ApprovedBy ?? 0,
                approvedDate: props?.singleUserData?.ApprovedDate ?? "",
                fullName: props?.selectEmpName,
                exceptionname: excName,
                documentTypeId: props?.singleUserData?.DocumentTypeId ?? 0,
                documentPath: "",
                userId: userId?.user
            }
            AxiosLayout.post("/LeaveDetails/SaveorUpdateExceptionDetails", payload).then((res: any) => {
                if (res.data.Status === 1) {
                    props?.setData([])
                    props?.setAlertMessage(res?.data?.Message)
                    props?.getData()
                    props?.setOpen(false)

                }
                else {
                    setErrorMessage(res?.data?.Message)
                }
            })
        }
    }
    const handleClear = () => {
        setErr(0)
        setIsActive(false)
        setPay(false)
        setIsVerify(false)
        setRemarks("")
        setSelectedId(0)
        setSeletedDate("")
    }

    const handleSelectExc = async (val: any) => {
        const dataa = props?.excTypes?.filter((i: any) => i.Id === Number(val))
        console.log(dataa)
        setExcHours(dataa[0]?.Hours)
        setSelectedExcType(val)
        setExcName(dataa[0]?.Description)
    }


    const handleUploadFileButtonClick = () => {
        fileref.current?.click();
    };
    const handleFileChange = (e: any) => {
        const selectedFiles = Array.from(e.target.files);
        setFiles([...files, ...selectedFiles]);
    };
    return (
        <div className='p-2 formsheight'>
            {alertMessage && (
                <div className="alert alert-success" role="alert">
                    {alertMessage}
                </div>
            )}
            {errorMessage && (
                <div className="alert alert-danger" role="alert">
                    {errorMessage}
                </div>
            )}

            <Row>
                <Col md={2} className='md-none'></Col>
                <Col xs={12} md={8}>
                    <div className='bg-white p-5'>
                        <Row>
                            <Col xs={12}>
                                <YsecInput label="Employee Id" value={props?.selectEmp} disabled className='disableField' />
                            </Col>
                            <Col xs={12} className='d-flex'>
                                <div className='w-100 me-1'>
                                    <YsecSelect className={`md`} name='selectedExcType'
                                        key={selectedExcType}
                                        objectNameKey="name"
                                        objectValueKey="id"
                                        data={[
                                            { id: 0, name: "Select" },
                                            ...props?.excTypes?.map((i: any) => ({
                                                id: i?.Id,
                                                name: i?.Description
                                            }))
                                        ]}
                                        value={selectedExcType}
                                        label="Exception Type" mandatory
                                        onChange={(e: any) => {
                                            handleSelectExc(e.target.value)
                                        }}

                                    />
                                    {err === 1 && <label className='error'>Please Select Exception Type..</label>}
                                </div>
                                <div className='mt-4'>
                                    <YsecButton type='button' onClick={() => {
                                        setOpenModal(true)

                                    }} className='cancel' >
                                        <YsecFont className='yf-plus-add' />
                                    </YsecButton></div>
                            </Col>


                            <Col xs={12} >
                                <YsecDatePicker
                                    key={selectedDate}
                                    name="selectedDate"
                                    value={selectedDate}
                                    className="md"
                                    label="Date"
                                    error="test message"
                                    onChange={(e: any) => setSeletedDate(e.target.value)}
                                    ysecType="tab"
                                    ysecFormat="YYYY-MM-D"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y"
                                    placeholder="YYYY-MM-DD"
                                    wrapperClass
                                    multipleSelect={false}
                                    mandatory
                                />
                                {err === 4 && <label className='error'>Please Selcet Date..</label>}
                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Hours" value={excHours} name="excHours" disabled className='disableField' />
                            </Col>
                            <Col xs={12}>
                                <YsecTextarea label="Remarks" value={remarks} name="remarks" onChange={(e: any) => setRemarks(e.target.value)} />
                            </Col>
                            <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                                <YsecCheckbox
                                    label="Pay"
                                    className="sm"
                                    name="pay"
                                    value={pay}
                                    checked={pay}
                                    onChange={(e: any) => setPay(!pay)}
                                />
                            </Col>
                            <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                                <YsecCheckbox
                                    label="IsActive"
                                    className="sm"
                                    name="isActive"
                                    value={isActive}
                                    checked={isActive}
                                    onChange={(e: any) => setIsActive(!isActive)}
                                />
                            </Col> <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                                <YsecCheckbox
                                    label="IsVerified"
                                    className="sm"
                                    name="isVerify"
                                    value={isVerify}
                                    checked={isVerify}
                                    onChange={(e: any) => setIsVerify(!isVerify)}
                                />
                            </Col>
                            <Col xs={12} className='mt-3'>Documents</Col>

                            <Col xs={12} md={6} lg={3}><YsecButton className='mt-1 mb-1 w-100 cancel' >Scan</YsecButton></Col>
                            <Col xs={12} md={6} lg={3}>
                                <YsecButton className='mt-1 mb-1 w-100 cancel' type='button' onClick={handleUploadFileButtonClick}>
                                    Upload File
                                </YsecButton>
                                <input
                                    ref={fileref}
                                    type="file"
                                    // multiple
                                    accept=".pdf,.doc,.docx"
                                    style={{ display: 'none' }}
                                    onChange={handleFileChange}
                                />
                            </Col>
                            <Col xs={12} md={6} lg={3}><YsecButton className='mt-1 mb-1 w-100 cancel' type='button' onClick={() => { setShowDocs(true) }}>View Doc</YsecButton></Col>
                            <Col xs={12} md={6} lg={3}><YsecButton className='mt-1 mb-1 w-100 cancel' type='button'>Delete Doc</YsecButton></Col>

                        </Row>
                        <Row className='mt-5 customButns'>
                            <Col xs={12} className='d-flex justify-content-end'>
                                <YsecButton className="me-1 ms-1 cancel" type="button" onClick={handleClear}>Cancel</YsecButton>
                                <YsecButton className="me-1 ms-1" type="button" onClick={handleValidation}>Save</YsecButton>
                            </Col>
                        </Row></div>
                </Col>

                <Col md={2} className='md-none'></Col>

            </Row>
            {openModal === true && (
                <CustomModalException open={openModal} setOpen={setOpenModal} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} selectBrand={props?.selectedBrand} locationId={props?.locationId} data={props?.excTypes} getExceptionTypes={props?.getExceptionTypes} getData={props?.getData} setExcTypes={props?.setExcTypes} setData={props?.setData} />

            )}
           {showDocs === true && <CustomViewDocModal open={showDocs} setOpen={setShowDocs} data={docData} />}
        </div>
    )
}