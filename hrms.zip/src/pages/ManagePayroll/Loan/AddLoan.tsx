import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import CustomTableDropdown from '../CustomDropdown';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

export const AddLoan: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;

    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [err, setErr] = useState<number>(0)
    const [isActive, setIsActive] = useState<boolean>(true)
    const [selectedCurrency, setSelectedCurrency] = useState<number>(0)
    const [loanType, setLoanType] = useState<number>(0)
    const [selectedDate, setSeletedDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [amount, setAmount] = useState<number>(0)
    const [remarks, setRemarks] = useState<string>("")
    const [selectedId, setSelectedId] = useState<number>(0)
    const [paybackCount, setPaybackCount] = useState<number | null>(null)
    const [loanId, setLoanId] = useState<number>(0)
    const [loanDesc, setLoanDesc] = useState<string>("")
    const [curencyName, setCurrencyName] = useState<string>("")


    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => {
        setLoanId(props?.singleUserData?.LoanId || 0)
        setLoanType(props?.singleUserData?.AdvanceTypeId)
        setSelectedCurrency(props?.singleUserData?.CurrencytypeId)
        setSelectedId(props?.singleUserData?.LoanId)
        setSeletedDate(props?.singleUserData?.Date?.split("T")[0] || new Date().toISOString()?.split("T")[0])
        setAmount(props?.singleUserData?.Amount)
        setRemarks(props?.singleUserData?.Remarks)
        setIsActive(props?.singleUserData?.IsActive)
        setPaybackCount(props?.singleUserData?.PaybackCount)
        const formattedEdData = props?.paybackDetails?.filter((item: any) => item?.AdvanceId === props?.singleUserData?.LoanId)?.map((item: any) => ({
            Amount: item.Amount || "",
            PaidAmount: item.PaidAmount || "",
            Balance: item.Balance || "",
        }));
        props?.setPaybackDetails([...props?.paybackDetails, formattedEdData])
    }, [])


    const handleValidation = async (e: any) => {
        e.preventDefault()
        setErr(0)
        if (selectedCurrency == 0 || selectedCurrency==undefined) {
            setErr(1)
        }
        else if (loanType == 0 || loanType==undefined) {
            setErr(2)
        }

        else if (selectedDate === "") {
            setErr(3)
        }
        else if (amount == 0) {
            setErr(4)
        }
        else if (paybackCount == null) {
            setErr(5)
        }
        else {
            const paybackdata = props?.paybackDetails?.filter((item: any) => item?.AdvanceId === props?.singleUserData?.LoanId)


            const modifiedPaybackdata = paybackdata.map((item: any) => ({
                ...item,
                AdvanceId: item?.AdvanceId ?? 0
            }));

            console.log("Modified paybackdata2:", modifiedPaybackdata);

            const pData = modifiedPaybackdata?.map((i: any, index: number) => ({
                paybackScheduleId: i?.PaybackScheduleId,
                advanceId: i?.AdvanceId,
                penaltyId: 0,
                salaryId: i?.SalaryPeriodId,
                salaryPeriodId: i?.SalaryPeriodId,
                salaryPeriod: i?.SalaryPeriod,
                amount: Number(i?.Amount),
                paidAmount: Number(i?.PaidAmount),
                balance: Number(i?.Balance),
                isActive: i?.isActive,
            }))
            const payload = {
                loanId: loanId,
                employeeID: props?.selectEmp,
                companyId: userId?.companyId,
                advanceTypeId: loanType || 0,
                date: selectedDate,
                currencytypeId: selectedCurrency,
                amount: amount,
                remarks: remarks,
                isActive: isActive,
                paybackCount: Number(paybackCount),
                isFromWebsite: false,
                isVerified: false,
                createdBy: userId?.user,
                paybackSchedules: pData,

                contactId: props?.singleUserData?.ContactId || 0,
                fullName: props?.singleUserData?.FullName,
                description: loanDesc,
                currency: curencyName
            }
            AxiosLayout.post("/LoanDetails/InsertEmpLoanDetails", payload).then((res: any) => {
                if (res.data.Status === 1) {
                     handleClear()
                    props?.setData([])
                    props?.setPaybackDetails([])
                   props?.setSingleUseData({})
                    props?.setAlertMessage(res?.data?.Message)
                    props?.getData()
                    props?.setOpen(false)
                }
                else {
                    setErrorMessage(res.data.Message)
                }
            })
        }
    }
    const handleClear = () => {
        setErr(0)
        setSelectedCurrency(0)
        setPaybackCount(null)
        setLoanType(0)
        setAmount(0)
        setIsActive(true)
        setRemarks("")
        setSelectedId(0)
        setSelectedCurrency(0)
        setSeletedDate(new Date().toISOString()?.split("T")[0])
    }
    // const updateEntry = (paybackScheduleId: number, field: string, value: any) => {
    //     const updatedData = props.paybackDetails.map((item: any) =>
    //         item.PaybackScheduleId === paybackScheduleId
    //             ? { ...item, [field]: value }
    //             : item
    //     );
    //     props.setPaybackDetails(updatedData);
    // };


    const updateEntry = (paybackScheduleId: number, field: string, value: any) => {
        const updatedData = props.paybackDetails.map((item: any) => {
            if (item.PaybackScheduleId === paybackScheduleId) {
                const updatedItem = {
                    ...item,
                    [field]: value,
                };

                if (field === "Amount" || field === "PaidAmount") {
                    const amt = Number(updatedItem.Amount || 0);
                    const paid = Number(updatedItem.PaidAmount || 0);
                    updatedItem.Balance = amt - paid;
                }

                return updatedItem;
            }
            return item;
        });

        props.setPaybackDetails(updatedData);
    };
    const [matchingPeriods, setMatchingPeriods] = useState<any[]>([]);

    const handleCheckPaybackSChedules = () => {
        setMatchingPeriods([]);

        if (paybackCount === null || paybackCount <= 0) {
            setErr(5);
            return;
        }

        setErr(0);
        const selectedDateTime = new Date(`${new Date().toISOString()?.split("T")[0]}T00:00:00Z`);

        const sortedSalaryPeriodData = [...props.salaryPeriodData].sort((a, b) =>
            new Date(a.PeriodStart).getTime() - new Date(b.PeriodStart).getTime()
        );

        let currentPeriodIndex = -1;

        for (let i = 0; i < sortedSalaryPeriodData.length; i++) {
            const period = sortedSalaryPeriodData[i];
            const start = new Date(period.PeriodStart);
            const end = new Date(period.PeriodEnd);
            start.setUTCHours(0, 0, 0, 0);
            end.setUTCHours(0, 0, 0, 0);

            if (selectedDateTime >= start && selectedDateTime <= end) {
                currentPeriodIndex = i;
                break;
            }
        }

        if (currentPeriodIndex === -1) {
            console.log("Selected date doesn't fall within any period.");
            return;
        }

        const uniquePeriodsToShow: any[] = [];
        const seen = new Set<string>();


        for (let i = currentPeriodIndex; i < sortedSalaryPeriodData.length; i++) {
            const period = sortedSalaryPeriodData[i];
            if (!seen.has(period.PeriodDescription)) {
                uniquePeriodsToShow.push(period);
                seen.add(period.PeriodDescription);
            }
            if (uniquePeriodsToShow.length >= paybackCount) break;
        }

        if (uniquePeriodsToShow.length < paybackCount) {

            setErrorMessage("Upcoming Salary Periods are missing.");
        }
        setMatchingPeriods(uniquePeriodsToShow);

        const newPaybacks = uniquePeriodsToShow.map((period: any, idx: number) => {
            const perInstallmentAmount = Number(amount) / paybackCount!;
            const roundedAmount = Math.round(perInstallmentAmount * 100) / 100; // Optional rounding to 2 decimals

            return {
                PaybackScheduleId: idx + 1, // temporary ID
                AdvanceId: selectedId,
                SalaryPeriodId: period.Period || 0,
                SalaryPeriod: `${period.PeriodStart?.split("T")[0]} - ${period.PeriodEnd?.split("T")[0]}`,
                Amount: roundedAmount || 0,
                PaidAmount: 0,
                Balance: roundedAmount || 0,
                isActive: true
            };
        });

        // Filter out old schedules for this loan ID and add new ones
        const filteredOld = props?.paybackDetails?.filter((item: any) => item?.AdvanceId !== props?.singleUserData?.LoanId) || [];

        props.setPaybackDetails([...filteredOld, ...newPaybacks]);
    };

    return (
        <div className='p-2 formsheight'>
            {alertMessage && (
                <div className="alert alert-success" role="alert">
                    {alertMessage}
                </div>
            )}
            {errorMessage && (
                <div className="alert alert-danger" role="alert">
                    {errorMessage}
                </div>
            )}

            <Row>
                {/* <Col md={2} className='md-none'></Col> */}
                <Col xs={12} md={4} lg={3}>
                    <div className='bg-white p-5'>
                        <Row>
                            <Col xs={12}>
                                <YsecInput label="Employee Id" value={props?.selectEmp} disabled className='disableField' />
                            </Col>
                            <Col xs={12} >

                                <YsecSelect className={`md`} name='selectedCurrency'
                                    key={selectedCurrency}
                                    objectNameKey="name"
                                    objectValueKey="id"
                                    data={[
                                        { id: 0, name: "Select" },
                                        ...props?.currencyData?.map((i: any) => ({
                                            id: i?.CurrencyId,
                                            name: i?.Currency
                                        }))
                                    ]}
                                    value={selectedCurrency}
                                    label="Currency Type" mandatory
                                    onChange={(e: any) => {
                                        setSelectedCurrency(e.target.value)
                                        const data = props.currencyData?.filter((i: any) => i.CurrencyId === e.target.value);

                                        setCurrencyName(data[0]?.Currency)
                                    }}

                                />
                                {err === 1 && <label className='error'>Please Select Currency Type..</label>}

                            </Col>
                            <Col xs={12} >

                                <YsecSelect className={`md`} name='advanceType'
                                    key={loanType}
                                    objectNameKey="name"
                                    objectValueKey="id"
                                    data={[
                                        { id: 0, name: "Select" },
                                        ...props?.loanTypes?.filter((i: any) => i?.Description.toLowerCase().includes("loan".toLowerCase()))?.map((i: any) => ({
                                            id: i?.AdvanceTypeId,
                                            name: i?.Description
                                        }))]}
                                    value={loanType}
                                    label="Loan Type" mandatory
                                    onChange={(e: any) => {
                                        setLoanType(e.target.value)
                                        const data = props.loanTypes?.filter((i: any) => i.AdvanceTypeId === e.target.value);

                                        setLoanDesc(data[0]?.Description)
                                    }}

                                />

                                {err === 2 && <label className='error'>Please Select Loan Type..</label>}

                            </Col>



                            <Col xs={12} >
                                <YsecDatePicker
                                    key={selectedDate}
                                    name="selectedDate"
                                    value={selectedDate}
                                    className="md"
                                    label="Date"
                                    error="test message"
                                    onChange={(e: any) => setSeletedDate(e.target.value)}
                                    ysecType="tab"
                                    ysecFormat="YYYY-MM-D"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y"
                                    placeholder="YYYY-MM-DD"
                                    wrapperClass
                                    multipleSelect={false}
                                    defaultValue={new Date().toISOString()?.split("T")[0]}
                                    mandatory
                                />
                                {err === 3 && <label className='error'>Please Selcet Date..</label>}
                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Amount" type={"number"} name="amount" mandatory value={amount} onChange={(e: any) => {
                                    setAmount(e.target.value)
                                }} />
                                {err === 4 && <label className='error'>Please Enter Amount..</label>}

                            </Col>

                            <Col xs={12}>
                                <YsecTextarea label="Remarks" value={remarks} name="remarks" onChange={(e: any) => setRemarks(e.target.value)} />
                            </Col>
                            <Col xs={12} className='d-flex'>
                                <div className=' me-1 w-100'>
                                    <YsecInput label="PayBack Count" key={paybackCount} type={"number"} name="paybackCount" mandatory value={paybackCount} onChange={(e: any) => {
                                        setPaybackCount(e.target.value)
                                    }} />
                                    {err === 5 && <label className='error'>Please Enter Payback Count..</label>}
                                </div>
                                <div className={`mt-4 d-flex  ${err === 5 ? 'align-items-start' : 'align-items-end'}`}>
                                    <YsecButton type='button' onClick={() => {
                                        handleCheckPaybackSChedules()
                                    }} className='cancel' >
                                        <YsecFont className="yf-validation-check" />
                                    </YsecButton></div>
                            </Col>
                            <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                                <YsecCheckbox
                                    label="IsActive"
                                    className="sm"
                                    name="isActive"
                                    value={isActive}
                                    checked={isActive}
                                    onChange={(e: any) => setIsActive(!isActive)}
                                />
                            </Col>
                        </Row>
                        <Row className='mt-5 customButns'>
                            <Col xs={12} className='d-flex justify-content-end'>
                                <YsecButton className="me-1 ms-1 cancel" type="button" onClick={handleClear}>Cancel</YsecButton>
                                <YsecButton className={`me-1 ms-1 ${props?.paybackDetails?.filter((item: any) => item?.AdvanceId === props?.singleUserData?.LoanId)[0]?.PaybackScheduleId == undefined && "disablebtn"}`} type="button" onClick={handleValidation} disabled={props?.paybackDetails?.filter((item: any) => item?.AdvanceId === props?.singleUserData?.LoanId)[0]?.PaybackScheduleId ==undefined}>Save</YsecButton>
                            </Col>
                        </Row></div>
                </Col>

                <Col xs={12} md={10} lg={9}>
                    <Card>
                        <Card.Header>PayBack Schedules</Card.Header>
                        <Card.Body className='paybackcard'>
                            <div className='katableee'>
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Salary Period</th>
                                            <th>Amount</th>
                                            <th>Paid Amount</th>
                                            <th>Balance</th>
                                        </tr>
                                    </thead>
                                    {(props?.paybackDetails?.filter((item: any) => item?.AdvanceId === props?.singleUserData?.LoanId)?.length !== 0 && props?.paybackDetails?.filter((item: any) => item?.AdvanceId === props?.singleUserData?.LoanId)[0]?.PaybackScheduleId) &&

                                        <tbody>
                                            {props?.paybackDetails
                                                ?.filter((item: any) => item?.AdvanceId === props?.singleUserData?.LoanId)
                                                ?.map((entry: any) => {
                                                    const matchedPeriod = props.salaryPeriodData.find(
                                                        (p: any) => p.SalaryPeriodId === entry.SalaryPeriodId
                                                    );

                                                    return (
                                                        <tr key={entry.PaybackScheduleId}>
                                                            <td>

                                                                <CustomTableDropdown
                                                                    options={props.salaryPeriodData}
                                                                    value={props.salaryPeriodData.find((p: any) => p.SalaryPeriodId === entry.SalaryPeriodId)}
                                                                    onSelect={(option: any) => {
                                                                        updateEntry(entry.PaybackScheduleId, "SalaryPeriodId", option.SalaryPeriodId);
                                                                        updateEntry(entry.PaybackScheduleId, "SalaryPeriod", `${option.PeriodStart?.split("T")[0]} - ${option.PeriodEnd?.split("T")[0]}`);
                                                                    }}
                                                                    defaultValue={entry?.SalaryPeriod}
                                                                />
                                                            </td>
                                                            <td>
                                                                <YsecInput
                                                                    className="sm"
                                                                    name="Amount"
                                                                    value={entry.Amount}
                                                                    onChange={(e) =>
                                                                        updateEntry(entry.PaybackScheduleId, "Amount", e.target.value)
                                                                    }
                                                                />
                                                            </td>
                                                            <td>
                                                                <YsecInput
                                                                    className="sm"
                                                                    name="PaidAmount"
                                                                    value={entry.PaidAmount}
                                                                    onChange={(e) =>
                                                                        updateEntry(entry.PaybackScheduleId, "PaidAmount", e.target.value)
                                                                    }
                                                                />
                                                            </td>
                                                            <td>
                                                                <YsecInput className="sm" name="Balance" value={entry.Balance} disabled />
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                        </tbody>
                                    }

                                </table></div>
                        </Card.Body>
                    </Card>
                </Col>

            </Row>

        </div>
    )
}