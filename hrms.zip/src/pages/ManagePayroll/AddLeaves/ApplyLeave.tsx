import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { CustomModalPayroll } from '../CustomModalPayroll';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

export const ApplyLeaves: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [openModal, setOpenModal] = useState<boolean>(false)
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [err, setErr] = useState<number>(0)
    const [selectedLeaveType, setSelectedLeaveype] = useState<number>(0)
    const [from, setFrom] = useState<string>("")
    const [no_days, setNoDays] = useState<number | null>(null)
    const [isActive, setIsActive] = useState<boolean>(false)
    const [toDate,setToDate]=useState<string>("")
const [hours,setHours]=useState<number>(0)
const [leaveDesc,setLeaveDesc]=useState<string>("")
const [leaveId,setLeaveId]=useState<number>(0)
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    console.log(props?.singleUserData)
useEffect(()=>{
    // if(props?.singleUserData?.length !==0){
        setLeaveId(props?.singleUserData?.LeaveId)
        setSelectedLeaveype(props?.singleUserData?.LeavetypeId)
        setFrom(props?.singleUserData?.ApplyDate?.split("T")[0])
        setToDate(props?.singleUserData?.ToDate?.split("T")[0])
        setNoDays(props?.singleUserData?.Days)
        setHours(props?.singleUserData?.Hours)
        setIsActive(props?.singleUserData?.IsActive)
        setLeaveDesc(props?.singleUserData?.Leavedes)
    // }
},[])

  useEffect(() => {
    if (from && no_days !== null && !isNaN(Number(no_days)) && no_days > 0) {
      const fromDate = new Date(from); 
  const calculatedToDate = new Date(fromDate);

      const daysToAdd = Number(no_days); 
      const currentDayOfMonth = fromDate.getDate();
      calculatedToDate.setDate(currentDayOfMonth + daysToAdd - 1); 
      const year = calculatedToDate.getFullYear();
      const month = (calculatedToDate.getMonth() + 1).toString().padStart(2, '0'); 
      const day = calculatedToDate.getDate().toString().padStart(2, '0');      
      const formattedToDate = `${year}-${month}-${day}`;
      setToDate(formattedToDate);
    } else {
      setToDate("");
    }
  }, [from, no_days]);
  useEffect(()=>{
    if(selectedLeaveType===0){
        setHours(0)
    }
    else{
const dataa=props?.leaveTypeTableData?.filter((i:any)=>i.Id===Number(selectedLeaveType))
setLeaveDesc(dataa[0]?.Description)
setHours(dataa[0]?.Hours)
    }
  },[selectedLeaveType])
    const handleValidation = async (e: any) => {
        e.preventDefault()
        setErr(0)
        if (selectedLeaveType === 0) {
            setErr(1)
        }
        else if (from === "") {
            setErr(2)
        }
        else if (no_days === null) {
            setErr(3)
        }
        else {
            const payload = {
                leaveId: leaveId,
                employeeID: props?.selectEmp,
                leavetypeId: Number(selectedLeaveType),
                applyDate: new Date().toISOString()?.split("T")[0],
                fromDate: from,
                toDate: toDate,
                days: Number(no_days),
                hours: hours,
                isActive: isActive,
                isApproved: props?.singleUserData?.IsApproved ||false,
                companyId: userId?.companyId,
                leavedes: leaveDesc,
                userId: userId?.user,
                isSoldHolidayLeave: props?.singleUserData?.IsSoldHolidayLeave ||false,
                isSoldNormalLeave: props?.singleUserData?.IsSoldNormalLeave ||false,
                paid: props?.singleUserData?.Paid ||false
            }
            AxiosLayout.post("/LeaveDetails/LeaveDetails/SaveorUpdateEmpAddLeaveDetails",payload).then((res:any)=>{
                if(res.data.Status===1){
                    console.log(res.data)
                }
            })
        }
    }
    const handleClear = () => {
        setErr(0)
        setSelectedLeaveype(0)
        setFrom("")
        setIsActive(false)
        setNoDays(null)
    }



    return (
        <div className='p-2 formsheight'>
            {alertMessage && (
                <div className="alert alert-success" role="alert">
                    {alertMessage}
                </div>
            )}
            {errorMessage && (
                <div className="alert alert-danger" role="alert">
                    {errorMessage}
                </div>
            )}

            <Row>
                <Col md={2} className='md-none'></Col>
                <Col xs={12} md={8}>
                    <div className='bg-white p-5'>
                        <Row>
                            <Col xs={12}>
                                <YsecInput label="Employee Id" value={props?.selectEmp} disabled className='disableField' />
                            </Col>
                            <Col xs={12} className='d-flex'>
                                <div className=' me-1 w-100'>
                                    <YsecSelect className={`md`} name='leave_type'
                                        key={selectedLeaveType}
                                        objectNameKey="name"
                                        objectValueKey="id"
                                        data={[
                                            { id: 0, name: "Select" },
                                            ...props?.leaveTypeTableData?.map((i: any) => ({
                                                id: i?.Id,
                                                name: i?.Description
                                            }))
                                        ]}
                                        value={selectedLeaveType}
                                        label="Leave Type" mandatory
                                        onChange={(e: any) => {
                                            setSelectedLeaveype(e.target.value)
                                        }}

                                    />
                                    {err === 1 && <label className='error'>Please Selcet Leave Type..</label>}
                                </div>
                                <div className='mt-4'>
                                    <YsecButton type='button' onClick={() => {
                                        setOpenModal(true)
                                    }} className='cancel' >
                                        <YsecFont className='yf-plus-add' />
                                    </YsecButton></div>
                            </Col>
                            <Col xs={12} >
                                <YsecDatePicker
                                    key={from}
                                    name="from"
                                    value={from}
                                    className="md"
                                    label="From Date"
                                    error="test message"
                                    onChange={(e: any) => setFrom(e.target.value)}
                                    ysecType="tab"
                                    ysecFormat="YYYY-MM-D"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y"
                                    placeholder="YYYY-MM-DD"
                                    wrapperClass
                                    multipleSelect={false}
                                    mandatory
                                />
                                {err === 2 && <label className='error'>Please Selcet From Date..</label>}
                            </Col>
                            <Col xs={12}>
                                <YsecInput label="No.of days" type={"number"} name="no_days" mandatory value={no_days} key={no_days} onChange={(e: any) => setNoDays(e.target.value)} />
                                {err === 3 && <label className='error'>Please Enter No.of Days..</label>}

                            </Col>
                            <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                                <YsecCheckbox
                                    label="IsActive"
                                    className="sm"
                                    name="isActive"
                                    value={isActive}
                                    checked={isActive}
                                    onChange={(e: any) => setIsActive(e.target.value)}
                                />
                            </Col>
                        </Row>
                        <Row className='mt-5 customButns'>
                            <Col xs={12} className='d-flex justify-content-end'>
                                <YsecButton className="me-1 ms-1 cancel" type="button" onClick={handleClear}>Cancel</YsecButton>
                                <YsecButton className="me-1 ms-1" type="button" onClick={handleValidation}>Save</YsecButton>
                            </Col>
                        </Row></div>
                </Col>

                <Col md={2} className='md-none'></Col>

            </Row>

            {openModal === true && (
                <CustomModalPayroll open={openModal} setOpen={setOpenModal} data={props?.leaveTypeTableData} getJobCommonData={props?.getLeaveTypes} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} leaveTypeData={props?.leaveTypeData} LeaveType={props?.LeaveType} selectBrand={props?.selectedBrand} locationId={props?.locationId} getLeaveData={props?.getLeaveData} />

            )}
        </div>
    )
}