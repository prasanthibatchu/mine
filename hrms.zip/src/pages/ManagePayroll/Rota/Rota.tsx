import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Modal, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { RotaDetails } from './RotaDetails';


const YsecTimePicker = React.lazy(() => import("Layout/YsecTimePicker2"))
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
const Rota: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [open, setOpen] = useState<boolean>(false)
    const [empData, setEmpData] = useState<any[]>([])
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [locationId, setLocationId] = useState<number>(0)
    const [loading, setLoading] = useState<boolean>(false);
    const [currencyData, setCurrencyData] = useState<any[]>([])
    const [salaryPeriodData, setSalaryPeriodData] = useState<any[]>([])
    const [selectSalPeriod, setSelectSalPeriod] = useState<number>(0)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const [isActive, setIsActive] = useState<boolean>(true)
    const [rotaTypeData, setRotaTypeData] = useState<any[]>([])
    const [selectedRota, setSelectedRota] = useState<number>(0)
    const [deptName, setDeptName] = useState<string>("")
    const [perioDates, setPeriodDates] = useState<any[]>([])
    const [defaultStartDate, setDefaultStartDate] = useState<string>("")
    const [defaultEndDate, setDefaultEndDate] = useState<string>("")
    const [salatyTypeId, setSalaryTypeId] = useState<number>(0)
    const [rotaData, setRotaData] = useState<any[]>([])
    const [dropData, setDropData] = useState<any[]>([])
    const [selectedPerioDates, setSelectedPerioDates] = useState<any>([]);
    const [selectedEmployees, setSelectedEmployees] = useState<any[]>([]);
    const [beginTime, setBeginTime] = useState<string>("")
    const [endTime, setEndTime] = useState<string>("")
    const [isActive2, setIsActive2] = useState<boolean>(true)
    const [total_hrs, setTotalHrs] = useState<number | null>(null)
    const [sDesc, setSDec] = useState<string>("")
    const [lDesc, setLDec] = useState<string>("")
    const [err, setErr] = useState<number>(0)
    const [salPeriodStatus,setSalPeriodStatus]=useState<boolean>(false)
    const [salStatuOpen,setSalStatusOpen]=useState<boolean>(false)
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => {
        getMasterData()
        getEmployeeData()
        getRotaTypeData()
    }, []);
    useEffect(() => {
        if (selectSalPeriod !== 0) {
            getRotaData()
        }
    }, [selectSalPeriod])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res?.data?.CurrencyList !== null) {
                    setCurrencyData(res.data?.CurrencyList)
                }
                if (res?.data?.SalaryPeriodList !== null) {
                    setSalaryPeriodData(res?.data?.SalaryPeriodList)
                }
                setLoading(false)
            }
        })
    }

    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }
    const getRotaTypeData = () => {
        AxiosLayout.get(`/Rota/GetRotaTypes?CompanyId=${userId?.companyId}&UserId=${userId?.user}&isStatus=true`).then((res: any) => {
            if (res.status === 200) {
                setRotaTypeData(res?.data)
            }
        })
    }
    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }

    const handleClear = () => {
setSelectSalPeriod(0)
setSelectedDept(0)
setSelectedRota(0)
setSelectedEmployees([])
setSelectedPerioDates([])
setRotaData([])
setDropData([])
setDeptName("")
    }
    const handleDepartment = (value: any) => {
        const desc = departmentData.filter(i => i.DepartmentId === Number(value))
        setSelectedDept(desc[0]?.DepartmentId)
        setDeptName(desc[0]?.Department)
    }
    const handleSelectSalaryPeriod = (value: any) => {
    const periodData = salaryPeriodData?.filter((i: any) => i.Period === Number(value));
    if (!periodData.length) return;

    const selectedPeriod = periodData[0];

    if (selectedPeriod.Closed) {
        setSalStatusOpen(true)
        // alert("Rota cannot be modified since the salary period is already closed.");
        
    }

 
    setSelectSalPeriod(selectedPeriod.Period);
    setDefaultStartDate(selectedPeriod.PeriodStart?.split("T")[0]);
    setDefaultEndDate(selectedPeriod.PeriodEnd?.split("T")[0]);
    setSalaryTypeId(selectedPeriod.SalaryType);
setSalPeriodStatus(selectedPeriod.Closed)
    const startDate = new Date(selectedPeriod.PeriodStart);
    const endDate = new Date(selectedPeriod.PeriodEnd);
    const formattedDatesInRange = [];

    let currentDate = new Date(startDate);

    while (currentDate <= endDate) {
        const year = currentDate.getFullYear();
        const month = String(currentDate.getMonth() + 1).padStart(2, '0');
        const day = String(currentDate.getDate()).padStart(2, '0');
        formattedDatesInRange.push(`${year}-${month}-${day}`);

        currentDate.setDate(currentDate.getDate() + 1);
    }

    setPeriodDates(formattedDatesInRange);
};

  const getRotaData = () => {
        const payload = {
            rotaWeekNo: false,
            rotaMonth: true,
            startDate: defaultStartDate,
            endDate: defaultEndDate,
            salaryTypeId: salatyTypeId,
            hierachyId: selectedBrand,
            companyId: selectedBrand,
            locationId: locationId,
            userId: userId?.user
        }
        AxiosLayout.post("/Rota/GetRotaDetails", payload).then((res: any) => {
            if (res.status === 200) {
                if (res?.data?.Table !== null) {
                    setRotaData(res?.data?.Table)
                }
                if (res.data?.Table1 !== null) {
                    setDropData(res?.data?.Table1)
                }
            }
        })
    }
    const handleDateClick = (date: any) => {
        if (selectedPerioDates.includes(date)) {
            // Deselect if already selected
            setSelectedPerioDates(selectedPerioDates.filter((d: any) => d !== date));
        } else {
            // Select if not selected
            setSelectedPerioDates([...selectedPerioDates, date]);
        }
    };
    const handleEmployeeClick = (employeeId: string) => {
        if (selectedEmployees.includes(employeeId)) {
            // Deselect if already selected
            setSelectedEmployees(selectedEmployees.filter((id) => id !== employeeId));
        } else {
            // Select if not selected
            setSelectedEmployees([...selectedEmployees, employeeId]);
        }
    };

    const parseTimeToMinutes = (timeString: string): number | null => {
        if (!timeString) return null;
        const parts = timeString.split(':');
        if (parts.length === 2) {
            const hours = parseInt(parts[0], 10);
            const minutes = parseInt(parts[1], 10);
            if (!isNaN(hours) && !isNaN(minutes)) {
                return hours * 60 + minutes;
            }
        }
        return null;
    };

    // Effect to recalculate total_hrs whenever beginTime or endTime changes
    useEffect(() => {
        const beginMinutes = parseTimeToMinutes(beginTime);
        const endMinutes = parseTimeToMinutes(endTime);

        if (beginMinutes !== null && endMinutes !== null) {
            let differenceMinutes = endMinutes - beginMinutes;

            // Handle cases where the end time might be on the next day (e.g., 23:00 to 01:00)
            if (differenceMinutes < 0) {
                differenceMinutes += 24 * 60; // Add 24 hours in minutes
            }

            const hours = differenceMinutes / 60;
            setTotalHrs(hours);
        } else {
            setTotalHrs(null); // Clear total_hrs if times are incomplete or invalid
        }
    }, [beginTime, endTime]);
    const handleSaveRotaType = (e: any) => {
        e.preventDefault()

        setErr(0)
        if (beginTime === "") {
            setErr(10)
        }
        else if (endTime === "") {
            setErr(11)
        }
        else if (sDesc === "") {
            setErr(12)
        }
        //  else if(lDesc===""){
        //     setErr(13)
        // }
        else {

            const payload = {
                description: sDesc,
                short_Desc: lDesc,
                beginTime: beginTime,
                endTime: endTime,
                workingHours: total_hrs,
                isActive: isActive2,
                companyId: userId?.companyId,
                userId: userId?.user
            }
            AxiosLayout.post("/Rota/RotaTypeTrans", payload).then((res: any) => {
                if (res.data?.Status === 1) {
                    setBeginTime("")
                    setEndTime("")
                    setTotalHrs(null)
                    setSDec("")
                    setLDec("")
                    getRotaTypeData()
                    setAlertMessage(res.data?.Message)
                    setOpen(false)
                }
                else {
                    setErrorMessage(res?.data?.Message)
                }
            })
        }
    }


    const handleSave=async(e:any)=>{
        e.preventDefault()
        setErr(0)
        if(selectedBrand===0){
            setErr(1)
        }
        else if(selectSalPeriod===0){
            setErr(2)
        }
         else if(selectedDept===0){
            setErr(3)
        }
         else if(selectedRota===0){
            setErr(4)
        }
        else if(selectedEmployees?.length ===0){
            setErr(5)
        }
        else if(selectedPerioDates?.length ===0){
            setErr(6)
        }
        else{

        }

    }
    return (
        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Payroll</Breadcrumb.Item>
                            <Breadcrumb.Item active>Rota</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='manager-container'>
                    <Row>
                        <Col xs={12} md={4}>
                            <Row>
                                <Col xs={12}>
                                    <YsecSelect className={`md `}
                                        objectNameKey="BrandName"
                                        objectValueKey="BrandId"
                                        data={[
                                            { BrandId: 0, BrandName: "Select Brand" },
                                            ...brandData?.map((i: any) => ({
                                                BrandId: i?.BrandId,
                                                BrandName: i?.Brand
                                            }))
                                        ]}
                                        value={selectedBrand}
                                        label="Brand" mandatory
                                        onChange={(e) => handleSelectBrand(e.target.value)}

                                    />
                                    {err === 1 && <label className='error'>Please Select Brand..</label>}
                                </Col>
                                <Col xs={12}>
                                    <YsecSelect className={`md`} name='selectSalPeriod'
                                        key={selectSalPeriod}
                                        objectNameKey="name"
                                        objectValueKey="id"
                                        data={[
                                            { id: 0, name: "Select" },
                                            ...salaryPeriodData?.map((i: any) => ({
                                                id: i?.Period,
                                                name: i?.Period
                                            }))
                                        ]}
                                        value={selectSalPeriod}
                                        label="Salary Period" mandatory
                                        onChange={(e: any) => {
                                            handleSelectSalaryPeriod(e.target.value)
                                        }}

                                    />
                                    {err === 2 && <label className='error'>Please Select Salary Period..</label>}
                                </Col>
                                <Col xs={12}>
                                    <YsecSelect className={`md`} label="Sub Department" mandatory
                                        objectNameKey="Name"
                                        objectValueKey="id"
                                        data={[
                                            { id: 0, Name: "Select" },
                                            ...departmentData?.map((i: any) => ({
                                                id: i?.DepartmentId,
                                                Name: i?.Department
                                            }))
                                        ]}
                                        value={selectedDept}
                                        onChange={(e) => handleDepartment(e.target.value)}
                                    />
                                    {err === 3 && <label className='error'>Please Select Sub Department..</label>}
                                </Col>
                                <Col xs={12} className='d-flex'>
                                    <div className=' me-1 w-100'>
                                        <YsecSelect className={`md`} label="Rota Type" mandatory
                                            objectNameKey="Name"
                                            objectValueKey="id"
                                            data={[
                                                { id: 0, Name: "Select" },
                                                ...rotaTypeData?.map((i: any) => ({
                                                    id: i?.RotaTypeId,
                                                    Name: i?.RotaType
                                                }))
                                            ]}
                                            value={selectedRota}
                                            onChange={(e) => setSelectedRota(e.target.value)}
                                        />
                                        {err === 4 && <label className='error'>Please Select Rota Type..</label>}
                                    </div>
                                    <div className='mt-4'>
                                        <YsecButton type='button' onClick={() => {
                                            setOpen(true)
                                        }} className='cancel' >
                                            <YsecFont className='yf-plus-add' />
                                        </YsecButton></div>
                                </Col>
                                <Col xs={12} lg={6}>
                                    <label className='rotalabel'>Employee <span>*</span></label>
                                    <div className='rotacardheight'>

                                        {deptName !== "" &&
                                            empData
                                                ?.filter((employee) => employee?.Department === deptName)
                                                ?.map((employee) => (
                                                    <div
                                                        key={employee.EmployeeId}
                                                        onClick={() => handleEmployeeClick(employee.EmployeeId)}
                                                        className={selectedEmployees.includes(employee.EmployeeId) ? 'selected-perio-date' : 'unselected'}

                                                    >
                                                        {employee.FullName} ({employee.EmployeeId})
                                                    </div>
                                                ))}
                                    </div>
                                        {err === 5 && <label className='error'>Please Select Atleast One Employee..</label>}

                                </Col>
                                <Col xs={12} lg={6}>
                                    <label className='rotalabel'>Rota Date <span>*</span></label>
                                    <div className='rotacardheight'>
                                        {selectSalPeriod !== 0 &&
                                            perioDates?.map((i: any) => (
                                                <div
                                                    key={i}
                                                    onClick={() => handleDateClick(i)}
                                                    className={selectedPerioDates?.includes(i) ? 'selected-perio-date' : 'unselected'}
                                                >
                                                    {i}
                                                </div>
                                            ))}
                                    </div>
                                        {err === 6 && <label className='error'>Please Select atleast One Rota Date..</label>}                                    
                                    </Col>
                                <Col xs={12} className={"d-flex align-items-end mt-3"}>
                                    <YsecCheckbox
                                        label="IsActive"
                                        className="sm"
                                        name="isActive"
                                        value={isActive}
                                        checked={isActive}
                                        onChange={(e: any) => setIsActive(!isActive)}
                                    /></Col>

                            </Row>
                            <Row className='mt-5 customButns'>
                                <Col xs={12} lg={4}><YsecButton className={`m-1 w-100 `} type='button' onClick={handleSave}>Save</YsecButton></Col>
                                <Col xs={12} lg={4}><YsecButton className="m-1  w-100 " type="button" onClick={handleClear}>Clear</YsecButton></Col>
                                <Col xs={12} lg={4}><YsecButton className={`m-1 w-100  text-nowrap`}>Import Excel</YsecButton></Col>


                            </Row>
                        </Col>
                        <Col xs={12} md={8}>
                            <Card>
                                <Card.Header>Rota Details</Card.Header>
                                <Card.Body className='cardrota'>
                                    <RotaDetails dropData={dropData} setDropData={setDropData} setRotaData={setRotaData} rotaData={rotaData} perioDates={perioDates} defaultEndDate={defaultEndDate} defaultStartDate={defaultStartDate} setAlertMessage={setAlertMessage} setErrorMessage={setErrorMessage} getRotaData={getRotaData} salPeriodStatus={salPeriodStatus}/>
                                </Card.Body>
                            </Card>
                        </Col>
                    </Row>
                </div>
                <Modal
                    size="lg"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    show={open} onHide={() => {
                        setOpen(false)
                    }}
                >
                    <Modal.Header><p className="modal-title opening" id="exampleModalLabel">Add Rota Type</p>
                        <button type="button" className="btn-close" onClick={() => {
                            setOpen(false)
                        }} aria-label="Close"></button></Modal.Header>
                    <Modal.Body>
                        <Row>
                            <Col xs={12} md={6}>
                                <YsecTimePicker label="Begin Time" mandatory name="beginTime" value={beginTime} onChange={(e: any) => setBeginTime(e)} ysecFormat="24" />
                                {err === 10 && <label className='error'>Please Select Begin Time..</label>}

                            </Col>
                            <Col xs={12} md={6}>
                                <YsecTimePicker label="End Time" mandatory name="endTime" value={endTime} onChange={(e: any) => setEndTime(e)} ysecFormat="24" />
                                {err === 11 && <label className='error'>Please Select End Time..</label>}

                            </Col>
                            <Col xs={12} md={6}>
                                <YsecInput label="Total Hours" name="total_hrs" value={total_hrs?.toFixed(2)} disabled />
                            </Col>
                            <Col xs={12} md={6}>
                                <YsecTextarea label="Short Description" mandatory name="sDesc" value={sDesc} onChange={(e: any) => setSDec(e.target.value)} />
                                {err === 12 && <label className='error'>Please Enter Short Description..</label>}

                            </Col>
                            <Col xs={12} md={6}>
                                <YsecTextarea label="Long Description" name="lDesc" value={lDesc} onChange={(e: any) => setLDec(e.target.value)} />
                            </Col>
                            <Col xs={12} md={6} className='d-flex align-items-end'>
                                <YsecCheckbox
                                    label="IsActive"
                                    className="sm"
                                    name="isActive2"
                                    value={isActive2}
                                    checked={isActive2}
                                    onChange={(e: any) => setIsActive2(!isActive2)}
                                />
                                {/* {err === 13 && <label className='error'>Please Enter Long Description..</label>} */}
                            </Col>


                        </Row>
                        <Row className='mt-5 customButns'>
                            <Col xs={12} className='d-flex justify-content-end'>
                                <YsecButton className="me-1 ms-1 cancel" type="button" onClick={() => setOpen(false)}>Close</YsecButton>
                                <YsecButton className="me-1 ms-1" type="button" onClick={handleSaveRotaType}>Save</YsecButton>
                            </Col>
                        </Row>
                    </Modal.Body>
                </Modal>
                <Modal
                    size="lg"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    show={salStatuOpen} onHide={() => {
                        setSalStatusOpen(false)
                    }}
                >
                    <Modal.Header><p className="modal-title opening textcolor" id="exampleModalLabel">Alert</p>
                        <button type="button" className="btn-close" onClick={() => {
                            setSalStatusOpen(false)
                        }} aria-label="Close"></button></Modal.Header>
                    <Modal.Body>
                        <p className='textcolor'>Rota cannot be modified since the salary period is already closed.</p>
                    </Modal.Body>
                    <Modal.Footer>
                        <YsecButton className='cancel' onClick={() => {
                            setSalStatusOpen(false)
                        }}>OK</YsecButton>
                    </Modal.Footer>
                    </Modal>
            </React.Suspense>
        </div>
    );
};
export default Rota;