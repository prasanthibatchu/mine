import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { Form, Modal } from "react-bootstrap"


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

export const RotaDetails: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [expandedRows, setExpandedRows] = useState<string | null>(null);
    const toggleRow = (headDescription: string) => {
        setExpandedRows(prevExpanded =>
            prevExpanded === headDescription ? null : headDescription
        );
    };
    const uniqueHeadDescriptions = new Set(props?.rotaData?.map((item: any) => item.Department));
    const sortedHeadDescriptions = [...uniqueHeadDescriptions].sort((a: any, b: any) => a.localeCompare(b));
    const [localRotaData, setLocalRotaData] = useState<any[]>([]);

    useEffect(() => {
        setLocalRotaData(props.rotaData || []);
    }, [props.rotaData]);
    const handleRotaChange = (employeeIndex: number, day: number, newValue: any) => {
        const updatedData = [...localRotaData];
        updatedData[employeeIndex][day.toString()] = newValue;
        setLocalRotaData(updatedData);
    };
    // console.log(sortedHeadDescriptions); 
    const rotaDays = props.perioDates.map((dateString: string) => {
        const date = new Date(dateString);
        return date.getDate().toString(); // Ensure keys are strings
    });



    return (
        <div className="katableee">
            {props?.rotaData?.length !== 0 &&
                <table>
                    <tr>
                        <th>Name</th>
                        <th>IsActive</th>


                        {props?.perioDates?.map((dateString: string, index: number) => {
                            const date = new Date(dateString);
                            const dayOfWeek = date.getDay();
                            const textColor = (dayOfWeek === 0 || dayOfWeek === 6) ? "red" : "";

                            // Format to yyyy-mm-dd
                            const formattedDate = date.toISOString().split('T')[0];

                            return (
                                <th
                                    style={{ whiteSpace: "nowrap", color: textColor }}
                                    key={`date-${index}`}
                                >
                                    {formattedDate}
                                </th>
                            );
                        })}




                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                    <tbody>
                        {[...sortedHeadDescriptions].map((headDescription: any) => (
                            <React.Fragment key={headDescription}>
                                <tr onClick={() => toggleRow(headDescription)} style={{ cursor: 'pointer' }}>
                                    <td colSpan={35}>
                                        {expandedRows === headDescription ? <YsecFont className="yf-chevron-down" /> : <YsecFont className="yf-chevron-right" />}
                                        {headDescription}
                                    </td>
                                </tr>
                                {expandedRows === headDescription && (
                                    localRotaData
                                        ?.filter((item: any) => item.Department === headDescription)
                                        // .map((item: any, index: number) => (
                                        .map((item: any) => {
                                            const originalIndex = localRotaData.findIndex(i => i.EmployeeId === item.EmployeeId);
                                            return (
                                                <tr key={item.EmployeeId}>
                                                    <td className='text-nowrap'>{item?.Name}</td>
                                                    <td>
                                                        {/* <Form.Check className="mt-2 opening"
                                                        type="checkbox"
                                                        checked={item?.IsActive === true}
                                                    /> */}
                                                        <Form.Check
                                                            className="opening"
                                                            type="checkbox"
                                                            checked={item?.IsActive === true}
                                                            onChange={(e) => {
                                                                const updatedData = [...localRotaData];
                                                                updatedData[originalIndex].IsActive = e.target.checked;
                                                                setLocalRotaData(updatedData);
                                                            }}
                                                            disabled={props?.salPeriodStatus === true}
                                                        />
                                                    </td>

                                                    {rotaDays.map((day: any) => {
                                                        const value = item?.[day]; // day is already string like "1", "2", ..., "31"
                                                        return (
                                                            <td key={`${item.EmployeeId}-${day}`}>
                                                                <YsecSelect
                                                                    className="md"
                                                                    objectNameKey="Name"
                                                                    objectValueKey="id"
                                                                    data={[
                                                                        { id: 0, Name: "" },
                                                                        ...props?.dropData?.map((i: any) => ({
                                                                            id: i?.RotaTypeId,
                                                                            Name: i?.Short_Desc
                                                                        }))]}
                                                                    value={value}

                                                                    onChange={(e: any) => {
                                                                        const originalIndex = localRotaData.findIndex(i => i.EmployeeId === item.EmployeeId);
                                                                        handleRotaChange(originalIndex, Number(day), Number(e.target.value));
                                                                    }}
                                                                    disabled={props?.salPeriodStatus === true}
                                                                />
                                                            </td>
                                                        );
                                                    })}
                                                    <td>
                                                        <YsecFont
                                                            className="yf-document-edit action-icon"
                                                            disabled={props?.salPeriodStatus === true}
                                                            onClick={async () => {
                                                                if (props?.salPeriodStatus === true) return;

                                                                const editedRow = localRotaData[originalIndex];

                                                                try {
                                                                    // 1. Get rota type ID
                                                                    const rotaTypeId = editedRow?.RotaTypeId || editedRow[1];

                                                                    // 2. Get working hours from API
                                                                    const workingHourRes = await AxiosLayout.get(
                                                                        `/Rota/GetRotaWorkingHours?RotaTypeId=${rotaTypeId}&UserId=${userId?.user}`
                                                                    );
                                                                    const workingHours = workingHourRes?.data?.[0]?.WorkingHours || 0;

                                                                    // 3. Generate rota entries
                                                                    const generateCheckRotas = () => {
                                                                        const startDate = new Date(props?.defaultStartDate);
                                                                        return Object.keys(editedRow)
                                                                            .filter((key) => /^\d+$/.test(key) && editedRow[key] !== null)
                                                                            .map((dayStr, index) => {
                                                                                const day = parseInt(dayStr);
                                                                                const date = new Date(startDate);
                                                                                date.setDate(day);

                                                                                return {
                                                                                    id: index + 1,
                                                                                    empId: editedRow.EmployeeId,
                                                                                    date: date.toISOString(),
                                                                                    rotaTypeId: editedRow[dayStr],
                                                                                    rotaWeekNo: day,
                                                                                    workingHours: workingHours,
                                                                                    isActive: editedRow.IsActive,
                                                                                };
                                                                            });
                                                                    };

                                                                    const checkRotas = generateCheckRotas();

                                                                    // 4. Fetch holidays from backend
                                                                    const holidayRes = await AxiosLayout.get(
                                                                        `/Rota/GetAllHoliday?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
                                                                    );
                                                                    const holidays = holidayRes?.data || [];

                                                                    // 5. Check for holidays in checkRotas
                                                                    let halfDayMsg = "";
                                                                    let fullHolidayMsg = "";

                                                                    checkRotas.forEach((rota) => {
                                                                        const rotaDate = new Date(rota.date).toISOString().split("T")[0];
                                                                        holidays.forEach((holiday:any) => {
                                                                            const holidayDate = new Date(holiday.Date).toISOString().split("T")[0];
                                                                            if (holidayDate === rotaDate) {
                                                                                if (holiday.LeaveType === "HalfDayLeave") {
                                                                                    halfDayMsg += `${rotaDate}, `;
                                                                                } else {
                                                                                    fullHolidayMsg += `${rotaDate}, `;
                                                                                }
                                                                            }
                                                                        });
                                                                    });

                                                                    // 6. Show alert if holidays found
                                                                    if (halfDayMsg || fullHolidayMsg) {
                                                                        let message = "";
                                                                        if (halfDayMsg) {
                                                                            message += ` Half-day holidays:\n${halfDayMsg.slice(0, -2)}\n`;
                                                                        }
                                                                        if (fullHolidayMsg) {
                                                                            message += ` Full holidays:\n${fullHolidayMsg.slice(0, -2)}\n`;
                                                                        }

                                                                        const confirmed = window.confirm(
                                                                            `${message}\nDo you want to continue saving the rota?`
                                                                        );
                                                                        if (!confirmed) return;
                                                                    }

                                                                    // 7. Prepare payload
                                                                    const payloadd = {
                                                                        employeeID: editedRow.EmployeeId,
                                                                        startDate: props?.defaultStartDate,
                                                                        endDate: props?.defaultEndDate,
                                                                        userId: userId?.user,
                                                                        companyId: userId?.companyId,
                                                                        checkRotas: checkRotas,
                                                                    };

                                                                    console.log("Final Payload:", payloadd);

                                                                    // 8. Submit rota
                                                                    const res = await AxiosLayout.post("/Rota/UpdateRotaDetails", payloadd);
                                                                    if (res.data?.Status === 1) {
                                                                        props?.setDropData([]);
                                                                        props?.setRotaData([]);
                                                                        props?.getRotaData();
                                                                        props?.setAlertMessage(res?.data?.Message);
                                                                    } else {
                                                                        props?.setErrorMessage(res?.data?.Message);
                                                                    }
                                                                } catch (error) {
                                                                    console.error("Update Rota Error:", error);
                                                                    props?.setErrorMessage("Error updating rota. Please try again.");
                                                                }
                                                            }}
                                                        />
                                                        {/* <YsecFont
                                                            className="yf-document-edit action-icon"
                                                            disabled={props?.salPeriodStatus === true}
                                                            onClick={async () => {
                                                                if (props?.salPeriodStatus === true) return;

                                                                const editedRow = localRotaData[originalIndex];

                                                                try {
                                                                    // 1. Get Working Hours from API
                                                                    const rotaTypeId = editedRow?.RotaTypeId || editedRow[1]; // fallback if it's in date keys
                                                                    const workingHourRes = await AxiosLayout.get(`/Rota/GetRotaWorkingHours?RotaTypeId=${rotaTypeId}&UserId=${userId?.user}`);
                                                                    const workingHours = workingHourRes?.data?.[0]?.WorkingHours || 0;
                                                                    console.log(workingHours, "work")
                                                                    // 2. Generate checkRotas with workingHours
                                                                    const generateCheckRotas = () => {
                                                                        const startDate = new Date(props?.defaultStartDate);
                                                                        return Object.keys(editedRow)
                                                                            .filter((key) => /^\d+$/.test(key) && editedRow[key] !== null)
                                                                            .map((dayStr, index) => {
                                                                                const day = parseInt(dayStr);
                                                                                const date = new Date(startDate);
                                                                                date.setDate(day);

                                                                                return {
                                                                                    id: index + 1,
                                                                                    empId: editedRow.EmployeeId,
                                                                                    date: date.toISOString(),
                                                                                    rotaTypeId: editedRow[dayStr],
                                                                                    rotaWeekNo: day,
                                                                                    workingHours: workingHours, // ✅ assign from API
                                                                                    isActive: editedRow.IsActive,
                                                                                };
                                                                            });
                                                                    };

                                                                    // 3. Prepare final payload
                                                                    const payloadd = {
                                                                        employeeID: editedRow.EmployeeId,
                                                                        startDate: props?.defaultStartDate,
                                                                        endDate: props?.defaultEndDate,
                                                                        userId: userId?.user,
                                                                        companyId: userId?.companyId,
                                                                        checkRotas: generateCheckRotas()
                                                                    };

                                                                    console.log(payloadd, "payyy");

                                                                    // 4. Post to API
                                                                    const res = await AxiosLayout.post("/Rota/UpdateRotaDetails", payloadd);
                                                                    if (res.data?.Status === 1) {
                                                                        props?.setDropData([]);
                                                                        props?.setRotaData([]);
                                                                        props?.getRotaData();
                                                                        props?.setAlertMessage(res?.data?.Message);
                                                                    } else {
                                                                        props?.setErrorMessage(res?.data?.Message);
                                                                    }

                                                                } catch (error) {
                                                                    console.error("Update Rota Error:", error);
                                                                    props?.setErrorMessage("Error updating rota. Please try again.");
                                                                }
                                                            }}
                                                        /> */}
                                                        {/* <YsecFont className="yf-document-edit action-icon"  disabled={props?.salPeriodStatus===true}
                                                            onClick={() => {
                                                                if(props?.salPeriodStatus===true){
                                                                    return
                                                                }
                                                                const editedRow = localRotaData[originalIndex];

                                                                const generateCheckRotas = () => {
                                                                    const startDate = new Date(props?.defaultStartDate);

                                                                    const checkRotas = Object.keys(editedRow)
                                                                        .filter((key) => /^\d+$/.test(key) && editedRow[key] !== null)
                                                                        .map((dayStr, index) => {
                                                                            const day = parseInt(dayStr);
                                                                            const date = new Date(startDate);
                                                                            date.setDate(day);
                                                                            return {
                                                                                id: index + 1,
                                                                                empId: editedRow.EmployeeId,
                                                                                date: date.toISOString(),
                                                                                rotaTypeId: editedRow[dayStr],
                                                                                rotaWeekNo: day,
                                                                                workingHours: 0,
                                                                                isActive: editedRow.IsActive,
                                                                            };
                                                                        });

                                                                    return checkRotas;
                                                                };
                                                                const payloadd = {
                                                                    employeeID: editedRow.EmployeeId,
                                                                    startDate: props?.defaultStartDate,
                                                                    endDate: props?.defaultEndDate,
                                                                    userId: userId?.user,
                                                                    companyId: userId?.companyId,
                                                                    checkRotas: generateCheckRotas()
                                                                };
                                                                console.log(payloadd, "payyy")
                                                                AxiosLayout.post("/Rota/UpdateRotaDetails", payloadd).then((res: any) => {
                                                                    if (res.data?.Status === 1) {

                                                                        props?.setDropData([])
                                                                        props?.setRotaData([])
                                                                        props?.getRotaData()
                                                                        props?.setAlertMessage(res?.data?.Message)
                                                                    }
                                                                    else {
                                                                        props?.setErrorMessage(res?.data?.Message)
                                                                    }
                                                                })
                                                            }}
                                                        /> */}
                                                    </td>
                                                    <td>
                                                        <YsecFont className="yf-delete-bin-2" disabled={props?.salPeriodStatus === true} onClick={() => {
                                                            if (props?.salPeriodStatus === true) {
                                                                return
                                                            }
                                                            const startDate = props?.defaultStartDate;
                                                            const endDate = props?.defaultEndDate;

                                                            const empRotaDatas = props?.perioDates.map((dateString: string) => {
                                                                const date = new Date(dateString);
                                                                const day = date.getDate().toString();
                                                                return {
                                                                    employeeID: item.EmployeeId,
                                                                    rotaDate: date.toISOString(),
                                                                    rotaType: item?.[day] ?? 0
                                                                };
                                                            });

                                                            const deletePayload = {
                                                                employeeId: item.EmployeeId,
                                                                startDate: startDate,
                                                                endDate: endDate,
                                                                userId: userId?.user,
                                                                empRotaDatas: empRotaDatas
                                                            };

                                                            AxiosLayout.post("/Rota/DeleteRota", deletePayload).then((res: any) => {
                                                                if (res.data?.Status === 1) {
                                                                    props?.setDropData([]);
                                                                    props?.setRotaData([]);
                                                                    props?.getRotaData();
                                                                    props?.setAlertMessage(res?.data?.Message);
                                                                } else {
                                                                    props?.setErrorMessage(res?.data?.Message);
                                                                }
                                                            });
                                                        }} />
                                                    </td>
                                                </tr>)
                                        }
                                        ))}
                                {/* //         ))
                                // )} */}


                            </React.Fragment>
                        ))}
                    </tbody>

                </table>}
        </div>
    )
}