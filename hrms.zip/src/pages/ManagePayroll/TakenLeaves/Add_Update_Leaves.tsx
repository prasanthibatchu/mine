import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManagePayroll.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { CustomModalPayroll } from '../CustomModalPayroll';
import { CustomViewDocModal } from '../../ManageEmployee/CustomDocViewModal';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
export enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}
export const AddUpdateLeaves: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [openModal, setOpenModal] = useState<boolean>(false)
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [fieldData, setFieldData] = useState<any>({ hours: "", leave_type: 0, remarks: "", no_days: 0, holiday_leave: false, isActive: false, isVerified: false, half_day: false, quarter_day: false })
    const [from, setFrom] = useState<string>("")
    const [to, setTo] = useState<string>("")
    const [err, setErr] = useState<number>(0)
    const [showLeaveBlnceData, setShowLeaveBlnceData] = useState<any[]>([])
    const [docData, setDocData] = useState<any[]>([])
    const [showDocs, setShowDocs] = useState<boolean>(false)
    const fileref = useRef<HTMLInputElement | any>(null)
    const [files, setFiles] = useState<any[]>([]);

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getDocData()
    }, [])
    useEffect(() => {
        setFieldData({
            hours: props?.singleUserData?.Hours,
            leave_type: props?.singleUserData?.LeavetypeId,
            remarks: props?.singleUserData?.Remarks,
            no_days: props?.singleUserData?.Days,
            holiday_leave: props?.singleUserData?.IsTakenHolidayLeave,
            isActive: props?.singleUserData?.IsActive,
            isVerified: props?.singleUserData?.Isverified,
            half_day: props?.singleUserData?.Days === 1 && props?.singleUserData?.Hours === 4,
            quarter_day: props?.singleUserData?.Days === 1 && props?.singleUserData?.Hours < 4
        })
        setFrom(props?.singleUserData?.FromDate?.split("T")[0])
        setTo(props?.singleUserData?.ToDate?.split("T")[0])
    }, [])
    useEffect(() => {
        if (fieldData?.leave_type !== undefined && fieldData?.leave_type !== 0) {
            getleaveHoursByLeaveType()
        }
        else {
            return;
        }
    }, [fieldData?.leave_type])

    useEffect(() => {
        if (from !== "" && to !== "") {
            const start = new Date(from);
            const end = new Date(to);
            let totalWorkingDays = 0;
            if (start > end) return;
            for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
                const dayOfWeek = date.getDay();
                if (dayOfWeek === 0 || dayOfWeek === 6) continue;
                totalWorkingDays++;
            }

            setFieldData((prev: any) => ({ ...prev, no_days: totalWorkingDays }));
            if (totalWorkingDays == 1) {
                if (fieldData?.hours == 4) {
                    setFieldData((prev: any) => ({ ...prev, quarter_day: false, half_day: true }));
                } else if (fieldData?.hours < 4) {
                    console.log("hiii--3");
                    setFieldData((prev: any) => ({ ...prev, quarter_day: true, half_day: false }));
                }

            } else {
                setFieldData((prev: any) => ({ ...prev, quarter_day: false, half_day: false }));
            }
        }

    }, [from, to, fieldData.leave_type, fieldData.hours,])
    const getDocData = () => {
        AxiosLayout.get(`/Common/GetDocumentDetails?EmployeeId=${props?.selectEmp}&DocTypeId=${DocumentType?.EmpLeave}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setDocData(res?.data)
            }
        })
    }
    const getleaveHoursByLeaveType = () => {
        AxiosLayout.get(`/LeaveDetails/GetLeaveHoursByLeaveTypeId?LeaveTypeId=${fieldData?.leave_type}&UserId=${userId?.user}`).then((res: any) => {
            if (res?.status === 200) {
                setFieldData((prev: any) => ({ ...prev, hours: res?.data?.Hours, }));

            }
        })
    }

    const onChangeFields = (e: any) => {
        const { name, value } = e.target
        setFieldData({ ...fieldData, [name]: value })
    }

    const handleCheckboxChange = (e: any) => {
        const { name, checked } = e.target;

        if (name === 'half_day' && checked) {
            setFieldData((prev: any) => ({ ...prev, half_day: true, quarter_day: false }));
        } else if (name === 'quarter_day' && checked) {
            setFieldData((prev: any) => ({ ...prev, quarter_day: true, half_day: false }));
        } else {
            setFieldData((prev: any) => ({ ...prev, [name]: checked }));
        }
    };

    const ShowLeaveBalance = () => {
        const payload = {
            hierarchyId: props?.selectedBrand,
            checkDate: new Date().toISOString()?.split("T")[0],
            locationId: props?.locationId,
            employeeid: props?.selectEmp,
            departmentid: 0,
            positionid: 0,
            companyid: userId?.companyId,
            userid: userId?.user
        }
        if (props?.locationId === 4) {
            AxiosLayout.post("/LeaveDetails/GetAnnualLeaveBalanceCalclation_Casino", payload).then((res: any) => {
                if (res.status === 200) {
                    setShowLeaveBlnceData(res?.data?.Table)
                }
            })
        }
        else {
            AxiosLayout.post("/LeaveDetails/GetCurrentLeaveBalanceWithFromDate", payload).then((res: any) => {
                if (res.status === 200) {
                    setShowLeaveBlnceData(res?.data?.Table)
                }
            })
        }
    }
    const handleValidation = async (e: any) => {
        e.preventDefault()
        setErr(0)
        if (fieldData.leave_type == undefined || fieldData.leave_type == 0) {
            setErr(1)
        }
        else if (from === "" || from == undefined) {
            setErr(2)
        }
        else if (to === "" || to == undefined) {
            setErr(3)
        }
        else {
            const payload = {
                leaveId: props?.singleUserData?.LeaveId || 0,
                employeeID: props.selectEmp,
                leavetypeId: fieldData?.leave_type,
                applyDate: new Date().toISOString()?.split("T")[0],
                fromDate: from,
                toDate: to,
                days: fieldData?.no_days,
                hours: fieldData?.hours,
                remarks: fieldData?.remarks,
                companyId: userId?.companyId,
                userId: userId?.user,
                isActive: fieldData?.isActive,
                isverified: fieldData?.isVerified,
                halfDayType: 0,
                isTakenHolidayLeave: fieldData?.holiday_leave,
                isLeaveaddlocation: false,
                isSoldHolidayLeave: false,
                isSoldNormalLeave: false,
                paid: false,
                asSeen: false,
                refLeaveID: 0,
                statusid: false,
                verifiedBy: userId?.user,
                verifiedDate: new Date().toISOString()?.split("T")[0],
                approvedby: userId?.user,
                approvedDate: new Date().toISOString()?.split("T")[0],
                fullName: "",
                leaveDes: "",
                documentTypeId: 0,
                documentPath: "",
                isApproved: false
            }
            AxiosLayout.post("/LeaveDetails/SaveOrUpdateLeaveDetails", payload).then((res: any) => {
                if (res.data.Status === 1) {

                    props?.getData()
                    setAlertMessage(res.data.Message)
                    handleClear()
                }
                else {
                    setErrorMessage(res.data.Message)
                }
            })
        }
        // LeaveDetails/SaveOrUpdateLeaveDetails
    }
    const handleClear = () => {
        setFieldData({ hours: "", leave_type: 0, remarks: "", no_days: 0, holiday_leave: false, isActive: false, isVerified: false, half_day: false, quarter_day: false });
        setFrom("")
        setTo("")
        setErr(0)
    }
    const handleUploadFileButtonClick = () => {
        fileref.current?.click();
    };
    const handleFileChange = (e: any) => {
        const selectedFiles = Array.from(e.target.files);
        setFiles([...files, ...selectedFiles]);
    };
    return (
        <div className='p-2 formsheight'>
            {alertMessage && (
                <div className="alert alert-success" role="alert">
                    {alertMessage}
                </div>
            )}
            {errorMessage && (
                <div className="alert alert-danger" role="alert">
                    {errorMessage}
                </div>
            )}
            <Row className="p-1 pb-3 part-1">
                <Col xs={12} lg={6}>
                    <Row>
                        <Col xs={12} md={6}>
                            <YsecInput label="Employee Id" value={props?.selectEmp} disabled className='disableField' />
                        </Col>
                        <Col xs={12} md={6} className='d-flex'>
                            <div className='jobselect me-1'>
                                <YsecSelect className={`md`} name='leave_type' key={fieldData?.leave_type}
                                    objectNameKey="name"
                                    objectValueKey="id"
                                    data={[
                                        { id: 0, name: "Select" },
                                        ...props?.leaveTypeTableData?.map((i: any) => ({
                                            id: i?.Id,
                                            name: i?.Description
                                        }))
                                    ]}
                                    value={fieldData?.leave_type}
                                    label="Leave Type" mandatory
                                    onChange={(e) => {
                                        onChangeFields(e)
                                    }}

                                />
                                {err === 1 && <label className='error'>Please Selcet Leave Type..</label>}
                            </div>
                            <div className='mt-4'>
                                <YsecButton type='button' onClick={() => {
                                    setOpenModal(true)
                                }} className='cancel' >
                                    <YsecFont className='yf-plus-add' />
                                </YsecButton></div>
                        </Col>
                        <Col xs={12} md={6}>
                            <YsecInput label="Hours" value={fieldData?.hours} disabled className='disableField' />
                        </Col>
                        <Col xs={12} md={6}>
                            <YsecDatePicker key={from}
                                name="from"
                                value={from}
                                className="md"
                                label="From Date"
                                error="test message"
                                onChange={(e: any) => setFrom(e.target.value)}
                                ysecType="tab"
                                ysecFormat="YYYY-MM-D"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                                placeholder="YYYY-MM-DD"
                                wrapperClass
                                multipleSelect={false}
                                mandatory
                            />
                            {err === 2 && <label className='error'>Please Selcet From Date..</label>}
                        </Col>
                        <Col xs={12} md={6}>
                            <YsecDatePicker key={to}
                                name="to"
                                value={to}
                                className="md"
                                label="To Date"
                                error="test message"
                                onChange={(e: any) => setTo(e.target.value)}
                                ysecType="tab"
                                ysecFormat="YYYY-MM-D"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                                placeholder="YYYY-MM-DD"
                                wrapperClass
                                multipleSelect={false}
                                mandatory
                            />
                            {err === 3 && <label className='error'>Please Selcet To Date..</label>}
                        </Col>

                        <Col xs={12} md={3} className={"d-flex align-items-end"}>
                            <YsecCheckbox key={fieldData?.half_day}
                                label="Half Day"
                                className={`sm`}
                                name="half_day"
                                value={fieldData?.half_day}
                                checked={fieldData?.half_day}
                                // onChange={handleCheckboxChange}
                                disabled={fieldData?.no_days > 1}

                            />
                        </Col>
                        <Col xs={12} md={3} className={"d-flex align-items-end"}>
                            <YsecCheckbox key={fieldData?.quarter_day}
                                label="1/4 Day"
                                className={`sm`}
                                name="quarter_day"
                                value={fieldData?.quarter_day}
                                checked={fieldData?.quarter_day}
                                // onChange={handleCheckboxChange}
                                disabled={fieldData?.no_days > 1}
                            />
                        </Col>


                        <Col xs={12} md={6}>
                            <YsecInput label="No.of days" name="no_days" value={fieldData?.no_days} disabled className='disableField' />
                        </Col>
                        <Col xs={12} md={6}>
                            <YsecTextarea label="Remarks" name="remarks" value={fieldData?.remarks} onChange={onChangeFields} />
                        </Col>
                        <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                            <YsecCheckbox key={fieldData?.holiday_leave}
                                label="Holiday Leave"
                                className="sm"
                                name="holiday_leave"
                                value={fieldData?.holiday_leave}
                                checked={fieldData?.holiday_leave}
                                onChange={handleCheckboxChange}
                            />
                        </Col>
                        <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                            <YsecCheckbox key={fieldData?.isActive}
                                label="IsActive"
                                className="sm"
                                name="isActive"
                                value={fieldData?.isActive}
                                checked={fieldData?.isActive}
                                onChange={handleCheckboxChange}
                            />
                        </Col>
                        <Col xs={12} md={4} className={"d-flex align-items-end mt-3"}>
                            <YsecCheckbox key={fieldData?.isVerified}
                                label="Isverified"
                                className="sm"
                                name="isVerified"
                                value={fieldData?.isVerified}
                                checked={fieldData?.isVerified}
                                onChange={handleCheckboxChange}
                            />
                        </Col>
                        <Col xs={12} className='mt-2 w-100'>
                            <h6>Documents</h6>
                        </Col>
                        <Col xs={12} md={6} lg={3}><YsecButton className='m-2 w-100'>Scan Doc</YsecButton></Col>
                        <Col xs={12} md={6} lg={3}><YsecButton className='m-2 w-100' type='button' onClick={handleUploadFileButtonClick}>
                            Upload Doc
                        </YsecButton>
                            <input
                                ref={fileref}
                                type="file"
                                // multiple
                                accept=".pdf,.doc,.docx"
                                style={{ display: 'none' }}
                                onChange={handleFileChange}
                            /></Col>
                        <Col xs={12} md={6} lg={3}><YsecButton className='m-2 w-100' type='button' onClick={() => { setShowDocs(true) }}>View Doc</YsecButton></Col>
                        <Col xs={12} md={6} lg={3}><YsecButton className='m-2 w-100'>Delete Doc</YsecButton></Col>


                    </Row>
                </Col>
                <Col xs={12} lg={6}>
                    <Row>
                        <Col xs={12}><YsecButton className='m-2 w-100' type='button' onClick={ShowLeaveBalance}>Show Leave Balance</YsecButton></Col>
                        <Col Xs={12}>
                            <div className="katableee m-2 w-100">
                                <table width="100%" >
                                    <tr>
                                        <th className='p-3'>{props?.locationId == 4 ? "Annual" : ""}</th>
                                        <th className='p-3'>{props?.locationId == 4 ? "Holiday DIL" : ""}</th>
                                        <th className='p-3'>Curr.Leave.Bal</th>
                                    </tr>

                                    <tr>
                                        <td className='p-3'>{props?.locationId == 4 ? showLeaveBlnceData[0]?.UpdatedAnnualLeave : ""}</td>
                                        <td className='p-3'>{props?.locationId == 4 ? showLeaveBlnceData[0]?.UpdatedDIL : ""}</td>
                                        <td className='p-3'>{props?.locationId == 4 ? showLeaveBlnceData[0]?.FinalUpdatedLeaveBalance : showLeaveBlnceData[0]?.CurrentLeaveBalance}</td>
                                    </tr>
                                </table>
                            </div>
                        </Col>

                    </Row>
                </Col>
            </Row>
            <Row className='mt-5 customButns'>
                <Col xs={12} className='d-flex justify-content-end'>
                    <YsecButton className="me-1 ms-1 cancel" type="button" onClick={handleClear}>Cancel</YsecButton>
                    <YsecButton className="me-1 ms-1" type="button" onClick={handleValidation}>Save</YsecButton>
                </Col>
            </Row>
            {openModal === true && (
                <CustomModalPayroll open={openModal} setOpen={setOpenModal} data={props?.leaveTypeTableData} getJobCommonData={props?.getLeaveTypes} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} leaveTypeData={props?.leaveTypeData} LeaveType={props?.LeaveType} selectBrand={props?.selectedBrand} locationId={props?.locationId} getLeaveData={props?.getLeaveData} />

            )}
            {showDocs === true && <CustomViewDocModal open={showDocs} setOpen={setShowDocs} data={docData} />}
        </div>
    )
}