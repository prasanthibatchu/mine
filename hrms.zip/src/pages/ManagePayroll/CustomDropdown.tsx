import React, { useState, useRef, useEffect } from 'react';

const CustomTableDropdown = ({
  options,
  onSelect,
  value,
  defaultValue
}: {
  options: any;
  onSelect: any;
  value: any;
  defaultValue:any
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleOptionClick = (option: any) => {
    onSelect(option);
    setIsOpen(false);
  };


  const displayValue = value
    ? `${value.PeriodStart?.split("T")[0]} - ${value.PeriodEnd?.split("T")[0]}`
    : defaultValue;

  useEffect(() => {
    const handleClickOutside = (event: any) => {
      if (dropdownRef.current && !dropdownRef.current?.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="custom-dropdown-container" ref={dropdownRef}>
      <div className="dropdown-header" onClick={handleToggle}>
        {displayValue}
        <span className={`dropdown-arrow ${isOpen ? 'open' : ''}`}>&#9660;</span>
      </div>

      {isOpen && (
        <div className="dropdown-options customdropdownlist">
          <table className="options-table">
            <thead>
              <tr>
                <th>Salary Period Id</th>
                <th>Period</th>
                <th>Description</th>
                <th>Closed/Open</th>
                <th>Start Month</th>
              </tr>
            </thead>
            <tbody>
              {options.map((option: any) => (
                <tr
                  key={option.Period}
                  className={`option-row ${value?.Period === option.Period ? 'selected' : ''}`}
                  onClick={() => handleOptionClick(option)}
                >
                  <td>{option.Period}</td>
                  <td>{option.PeriodStart?.split("T")[0] + " - " + option.PeriodEnd?.split("T")[0]}</td>
                  <td>Monthly</td>
                  <td>{option.Closed === true ? "Closed" : "Open"}</td>
                  <td>{option.PeriodStart?.split("T")[0]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default CustomTableDropdown;
// const CustomTableDropdown = ({ options, onSelect, defaultValue }:{ options:any, onSelect:any, defaultValue:any }) => {

//   const [isOpen, setIsOpen] = useState(false);
//   const [selectedValue, setSelectedValue] = useState(defaultValue || null);
//   const dropdownRef = useRef(null);

//   const handleToggle = () => {
//     setIsOpen(!isOpen);
//   };

//   const handleOptionClick = (option:any) => {
//     setSelectedValue(option);
//     onSelect(option);
//     setIsOpen(false);
//   };

//   useEffect(() => {
//     const handleClickOutside = (event:any) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setIsOpen(false);
//       }
//     };
//     document.addEventListener('mousedown', handleClickOutside);
//     return () => {
//       document.removeEventListener('mousedown', handleClickOutside);
//     };
//   }, []);

//   const displayValue = selectedValue
//     ? `${selectedValue.period} - ${selectedValue.description}`
//     : 'Select Salary Period';
// console.log(options,"optionsss")
//   return (
//     <div className="custom-dropdown-container" ref={dropdownRef}>
//       <div className="dropdown-header" onClick={handleToggle}>
//         {displayValue}
//         <span className={`dropdown-arrow ${isOpen ? 'open' : ''}`}>&#9660;</span>
//       </div>

//       {isOpen && (
//         <div className="dropdown-options customdropdownlist">
//           <table className="options-table">
//             <thead>
//               <tr>
//                 <th>Salary Period Id</th>
//                 <th>Period</th>
//                 <th>Description</th>
//                 <th>Closed/Open</th>
//                 <th>Start Month</th>
//               </tr>
//             </thead>
//             <tbody>
//               {options.map((option:any) => (
//                 <tr
//                   key={option.Period}
//                   className={`option-row ${selectedValue && selectedValue.Period === option.Period ? 'selected' : ''}`}
//                   onClick={() => handleOptionClick(option)}
//                 >
//                   <td>{option.Period}</td>
//                   <td>{option.PeriodStart?.split("T")[0]+"-"+option.PeriodEnd?.split("T")[0]}</td>
//                   <td>Monthly</td>
//                   <td>{option.Closed===true?"Closed":"Open"}</td>
//                   <td>{option.PeriodStart?.split("T")[0]}</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>
//         </div>
//       )}
//     </div>
//   );
// };

// export default CustomTableDropdown;