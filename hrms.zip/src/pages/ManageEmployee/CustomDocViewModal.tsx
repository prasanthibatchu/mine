import { Col, Form, Modal, Row } from "react-bootstrap"
import React, { useState } from 'react'
import AxiosLayout from "../../apis/axios";
import YsecFont from "Layout/YsecFont";


type Job = {
    Id: number;
    Description: string;
    IsActive?: any;
};
interface UserType {
    user: string;
    userName: string;
    companyId: Number;
    // Add more fields if you expect them
}
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
export const CustomViewDocModal: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [searchTerm, setSearchTerm] = useState<string>("");

    return (
        <Modal
            {...props}
            size="xl"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">{props?.title}</p>
                <button type="button" className="btn-close" onClick={() => {
                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>

            <Modal.Body>

                <Row>
                    <Col xs={12} md={5}>
                     <div className=" p-2">
                            <YsecInput
                                className="sm "
                                icon='yf-search'
                                value={searchTerm}
                                placeholder="Search"
                                onChange={(e) => {
                                    setSearchTerm(e.target.value);
                                }}
                            />
                        </div>
                        <div className="katableee">
                            <table>
                                <tr >
                                    <th>Employee Id</th>
                                    <th>File</th>
                                    <th>Delete</th>
                                </tr>
                                {(() => {
                                  const filtered = props?.data?.filter((i: any) => {
                                    const term = searchTerm.toLowerCase();
                                    return (
                                      i.File?.toLowerCase().includes(term) ||
                                      String(i.EmployeeId).toLowerCase().includes(term)
                                    );
                                  });
                                  if (!filtered || filtered.length === 0) {
                                    return (
                                      <tr>
                                        <td colSpan={3} style={{ textAlign: 'center' }}>No Data Found</td>
                                      </tr>
                                    );
                                  }
                                  return filtered.map((i: any) => (
                                    <tr key={i.DocumentId}>
                                      <td>{i.EmployeeId}</td>
                                      <td>{i.File}</td>
                                      <td><YsecFont className="yf-delete-bin-2" /></td>
                                    </tr>
                                  ));
                                })()}
                            </table>
                        </div>
                    </Col>
                    <Col xs={12} md={7}>
                        No Image Data
                    </Col>
                </Row>
            </Modal.Body>
        </Modal>
    )
}