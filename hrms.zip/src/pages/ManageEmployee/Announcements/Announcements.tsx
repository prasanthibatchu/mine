import React, { useEffect, useRef, useState } from 'react'
import dayjs from 'dayjs';
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { DatePicker, DatePickerProps } from 'antd';
import { AddContract } from '../Contracts/AddContract';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const EmployeeAnnouncements: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const [anndata, setAnnData] = useState<any[]>([])
    const [fromDate, setFromDate] = useState<string>("");
    const [toDate, setToDate] = useState<string>("")
    const [subject, setSubject] = useState<string>("")
    const [isActive, setIsActive] = useState<any>(true)
    const [open, setOpen] = useState<boolean>(false)
    const [err, setErr] = useState<number>(0)
    const [selectedRow, setSelectedRow] = useState<number>(0)
    const tableRef = useRef<any>(null)

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                    setLoading(false)
                }

            }
        })
    }
    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
    }
    useEffect(() => {
        if (selectedBrand !== 0) {
            getData()
        }
    }, [selectedBrand])
    const getData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand!!!")
        }
        else {
            setLoading(true)
            AxiosLayout.get(`/Employee/GetAnnouncementDetails?BrandId=${selectedBrand}&UserId=${userId?.user}`).then((res: any) => {
                if (res.status === 200) {
                    setAnnData(res.data)
                    setLoading(false)
                }
            })
        }
    }
    const staticColumns = [
        { id: 'StartDate', header: 'Start Date', filter: true, size: 150 },
        { id: 'EndDate', header: 'End Date', filter: true, size: 150 },
        { id: 'Subject', header: 'Subject', filter: true, size: 150 },
        { id: 'FullName', header: 'Created By', filter: true, size: 150 },
        { id: 'StartDate', header: 'Created Date', filter: true, size: 150 },
        { id: 'IsActive', header: 'IsActive', filter: true, size: 150 },
        {
            id: "edit",
            header: "Edit",
            filter: false,
            cell: ({ row }: { row: any }) => {
                const { AnnouncementID } = row.original;

                return (
                      <div className='text-center'>
                    <EditData rowKeyValue={AnnouncementID} rowdata={row?.original} />
                    </div>
                );
            },
        },

    ]

    const EditData = ({ rowKeyValue, rowdata }: { rowKeyValue: any, rowdata: any }) => {
        const handleData = async () => {
            // const dataa = anndata?.filter((i: any) => i.AnnouncementID === Number(rowKeyValue))
            // if (dataa?.length !== 0) {
            setFromDate(rowdata?.StartDate)
            setToDate(rowdata?.EndDate)
            setSubject(rowdata?.Subject)
            setSelectedRow(rowdata?.AnnouncementID)
            setIsActive((rowdata?.IsActive))
            setOpen(true)
            // }
        }
        return (
            <YsecFont className={`yf-document-edit action-icon`}
                onClick={handleData}
            />
        )
    }

    const handleSubmitData = async (e: any) => {
        e.preventDefault()
        if (fromDate === "") {
            setErr(1)
        }
        else if (toDate === "") {
            setErr(2)
        }
        else {
            const payload = {
                announcementID: selectedRow,
                companyId: userId?.companyId,
                hierachyId: selectedBrand,
                fullName: userId?.userName,
                createdDate: new Date().toISOString()?.split("T")[0],
                startDate: fromDate,
                endDate: toDate,
                subject: subject,
                isActive: Boolean(isActive),
                createdBy: userId?.user
            }
            AxiosLayout.post("/Employee/EmpAnnouncementTrans", payload).then((res: any) => {
                if (res?.data?.Message?.includes("Successfully")) {
                    setFromDate("")
                    setToDate("")
                    setSubject("")
                    setSelectedRow(0)
                    setIsActive(true)
                    setOpen(false)
                    getData()
                    setAlertMessage(res.data?.Message)
                }
                else {
                    setErrorMessage(res?.data?.Message)
                }
            })
        }
    }
    const handleClear = () => {
        setFromDate("")
        setToDate("")
        setSubject("")
        setIsActive(true)
    }
    const handleOpen = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand!!!")
        } else {
            setOpen(true)
        }
    }
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Employee</Breadcrumb.Item>
                            <Breadcrumb.Item active>Employee Announcements</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm p-0 ${open !== true && 'cancel'} ${(open === true) && "disbutn"}`}
                            onClick={handleOpen}
                            disabled={(open === true)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 history  ${open === true && 'cancel'}`} onClick={() => {

                            setOpen(false)
                        }}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 btn-outline-primary`} >
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>

                    </div>
                </div>

                <div className='manager-container'>

                    <Row className={`p-1 m-1  ${open === false && "bg-white"}`}>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            <YsecSelect className={`md ${open === true && "disableField"}`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                label="Brand" mandatory
                                onChange={(e) => handleSelectBrand(e.target.value)} disabled={open === true}
                            />
                        </Col>
                    </Row>
                    {open === true ? <div className='p-3 pb-5 insudetheight insur-form-center'>
                        <Row className='mt-3'>
                            <Col xs={12} className='mt-2' >
                                <YsecDatePicker key={fromDate}
                                    name="fromDate"
                                    value={fromDate}
                                    className="md"
                                    placeholderText="Select Date"
                                    label="From Date"
                                    error="test message"
                                    onChange={(e) => setFromDate(e.target.value)}
                                    placeholder="DD-MM-YYYY"
                                    ysecType="tab"
                                    ysecFormat="D-MM-YYYY"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y" mandatory
                                />
                                {err === 1 && <label className='error'>Select From Date..</label>}
                            </Col>
                            <Col xs={12} className='mt-2'>
                                <YsecDatePicker key={toDate}
                                    name="toDate"
                                    value={toDate}
                                    className="md"
                                    placeholderText="Select Date"
                                    label="From Date"
                                    error="test message"
                                    onChange={(e) => setToDate(e.target.value)}
                                    placeholder="DD-MM-YYYY"
                                    ysecType="tab"
                                    ysecFormat="D-MM-YYYY"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y" mandatory
                                />
                                {err === 2 && <label className='error'>Select To Date..</label>}
                            </Col>
                            <Col xs={12} className='mt-2'>
                                <YsecTextarea label="Subject" name="subject" value={subject} onChange={(e: any) => setSubject(e.target.value)} />
                            </Col>
                            <Col xs={12} className='mt-4'>
                                <YsecCheckbox
                                    label="IsActive"
                                    className="sm"
                                    name="isActive"
                                    value={isActive}
                                    checked={isActive === true}
                                    onChange={(e: any) => setIsActive(e.target.value)}
                                />
                            </Col>


                            <Col xs={12} className='d-flex mt-3 mb-5 pt-5 justify-content-center justify-content-md-end'>
                                <YsecButton className='mt-3' type='button' onClick={handleSubmitData}>Submit</YsecButton>
                                <YsecButton className='mt-3 ms-2 cancel' onClick={handleClear}>Clear</YsecButton>
                            </Col>
                        </Row>
                    </div> :
                        <div className='katable'>
                            <YsecTable
                                rowData={anndata}
                                columnDefs={staticColumns}
                                filter={true}
                                pagination={false}
                                tableRef={tableRef}
                                // pageSize={20}
                                dragColumnDisable={true}
                                reRender={true}
                            />
                           
                        </div>
                    }
                </div>

            </React.Suspense>
        </div>
    )
}

export default EmployeeAnnouncements;