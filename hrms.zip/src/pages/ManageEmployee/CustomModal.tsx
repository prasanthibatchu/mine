import { Form, Modal } from "react-bootstrap"
import React, { useState } from 'react'
import AxiosLayout from "../../apis/axios";


type Job = {
    Id: number;
    Description: string;
    IsActive?: any;
    ID?: number;
};
interface UserType {
    user: string;
    userName: string;
    companyId: Number;
    // Add more fields if you expect them
}
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
export const CustomModal: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [newIp, setNewIp] = useState<string>("")
    const [selectedJob, setSelectedJob] = useState<number>(0)
    const [chcekSelected, setCheckSelected] = useState<boolean>(true)
    const [err, setErr] = useState<number>(0)
    const handlesubmit = async (e: any) => {
        e.preventDefault()
        if (newIp === "") {
            setErr(1)
        }
        else {
            const payload = {
                refTableId: props?.type,
                id: selectedJob,
                description: newIp,
                companyId: userId?.companyId,
                isActive: chcekSelected,
                userId: userId?.user
            }

            AxiosLayout.post("/Employee/GeneralDataTypesTrans", payload).then((res: any) => {

                if (res.status === 200) {
                    props?.setAlertMessage(res.data.Message)
                    handleClear()
                    props?.getJobCommonData()
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                    handleClear()
                    props?.getJobCommonData()
                }


            })
        }
    }
    const handleClear = () => {
        setNewIp("")
        setSelectedJob(0)
        setCheckSelected(true)
        // props?.setAddName("")
        // props?.setAddType(0)
        // props.setOpen(false)
    }
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">{props?.title}</p>
                <button type="button" className="btn-close" onClick={() => {

                    props?.setAddName("")
                    props?.setAddType(0)
                    handleClear()
                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <YsecInput label={props?.addName} name="newIp" value={newIp} onChange={(e) => setNewIp(e.target.value)} />
                {err === 1 && <label className='error'>Please Enter {props?.addName} ...</label>}
                <Form.Check className="mt-2 opening"
                    type="checkbox"
                    id="isActive"
                    label="IsActive"
                    checked={chcekSelected}
                    onChange={(e) => setCheckSelected(e.target.checked)}
                />

                <div className="d-flex slign-itemd-center justify-content-end mt-3">
                    <YsecButton className="ms-1 me-1" type="button" onClick={handlesubmit} >{selectedJob == 0 ? "Save" : "Update"}</YsecButton>
                    <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
                </div>
            </Modal.Body>
            <Modal.Body className="modaltable">

                <div className="katableee">
                    <table>
                        <tr >
                            <th>Name</th>
                            <th>IsActive</th>
                        </tr>
                        {props?.data?.map((i: Job) => (
                            <tr key={i?.Id} onClick={() => {
                                setNewIp(i?.Description)
                                setSelectedJob(i?.Id)
                                setCheckSelected(i?.IsActive)
                            }}>
                                <td>{i?.Description}</td>
                                <td>
                                    <Form.Check className="mt-2 opening"
                                        type="checkbox"
                                        checked={i?.IsActive === true}
                                    />
                                </td>
                            </tr>
                        ))}
                    </table>
                </div>
            </Modal.Body>
        </Modal>
    )
}

export const CustomInsuranceModal: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [newIp, setNewIp] = useState<string>("")
    const [selectedJob, setSelectedJob] = useState<number>(0)
    const [err, setErr] = useState<number>(0)
    const handleSubmit = async (e: any) => {
        e.preventDefault()
        if (newIp === "") {
            setErr(1)
        }
        else {
            const payload = {
                refTableId: props?.addType,
                id: selectedJob,
                description: newIp,
                companyId: userId?.companyId,
                isActive: true,
                userId: userId?.user
            }

            AxiosLayout.post("/Employee/GeneralDataTypesTrans", payload).then((res: any) => {

                if (res.status === 200) {
                    props?.setAlertMessage(res.data.Message)
                    handleClear()
                    props?.getEmpCommonData()
                    props?.getGeneralData()
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                }


            })

        }
    }
    const handleClear = () => {
        setNewIp("")
        setSelectedJob(0)
    }
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">{props?.title}</p>
                <button type="button" className="btn-close" onClick={() => {
                    handleClear()
                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <YsecInput label="Description" name="newIp" value={newIp} onChange={(e) => setNewIp(e.target.value)} />
                {err === 1 && <label className='error'>Please Enter Description ...</label>}


                <div className="d-flex slign-itemd-center justify-content-end mt-3">
                    <YsecButton className="ms-1 me-1" type="button" onClick={handleSubmit} >{selectedJob == 0 ? "Save" : "Update"}</YsecButton>
                    <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
                </div>
            </Modal.Body>
            <Modal.Body className="modaltable">

                <div className="katableee">
                    <table>
                        <tr >
                            <th>Description</th>
                        </tr>
                        {props?.data?.map((i: Job) => (
                            <tr key={i?.Id} onClick={() => {
                                setNewIp(i?.Description)
                                setSelectedJob(i?.Id)
                            }}>
                                <td>{i?.Description}</td>

                            </tr>
                        ))}
                    </table>
                </div>
            </Modal.Body>
        </Modal>
    )
}

export const CustomPenaltyModal: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [newIp, setNewIp] = useState<string>("")
    const [selectedJob, setSelectedJob] = useState<number>(0)
    const [chcekSelected, setCheckSelected] = useState<boolean>(true)
    const [err, setErr] = useState<number>(0)
    const handleSubmit = async (e: any) => {
        e.preventDefault()
        if (newIp === "") {
            setErr(1)
        }
        else {
            const payload = {
                refTableId: props?.addType,
                id: selectedJob,
                description: newIp,
                companyId: userId?.companyId,
                isActive: chcekSelected,
                userId: userId?.user
            }

            AxiosLayout.post("/Employee/GeneralDataTypesTrans", payload).then((res: any) => {

                if (res.status === 200) {
                    if (res.data?.Message.includes("Successfullly")) {
                        props?.setAlertMessage(res.data.Message)
                        handleClear()
                        props?.getEmpCommonData()
                    }
                    else {
                        props?.setAlertMessage(res.data.Message)

                    }
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                }


            })

        }
    }
    const handleClear = () => {
        setNewIp("")
        setSelectedJob(0)
    }
    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">{props?.title}</p>
                <button type="button" className="btn-close" onClick={() => {
                    handleClear()
                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <YsecInput label="Description" name="newIp" value={newIp} onChange={(e) => setNewIp(e.target.value)} />
                {err === 1 && <label className='error'>Please Enter Description ...</label>}
                <Form.Check className="mt-2 opening"
                    type="checkbox"
                    id="isActive"
                    label="IsActive"
                    checked={chcekSelected}
                    onChange={(e) => setCheckSelected(e.target.checked)}
                />

                <div className="d-flex slign-itemd-center justify-content-end mt-3">
                    <YsecButton className="ms-1 me-1" type="button" onClick={handleSubmit} >{selectedJob == 0 ? "Save" : "Update"}</YsecButton>
                    <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
                </div>
            </Modal.Body>
            <Modal.Body className="modaltable">

                <div className="katableee">
                    <table>
                        <tr >
                            <th>Description</th>
                            <th>IsActive</th>
                        </tr>
                        {props?.data?.filter((i: any) => i.RefTableId === 3)?.map((i: any) => (
                            <tr key={i?.ID} onClick={() => {
                                setNewIp(i?.Description)
                                setSelectedJob(i?.ID)
                                setCheckSelected(i?.IsActive)
                            }}>
                                <td>{i?.Description}</td>
                                <td><Form.Check className="mt-2 opening"
                                    type="checkbox"
                                    checked={i?.IsActive === true}
                                /></td>
                            </tr>
                        ))}
                    </table>
                </div>
            </Modal.Body>
        </Modal>
    )
}