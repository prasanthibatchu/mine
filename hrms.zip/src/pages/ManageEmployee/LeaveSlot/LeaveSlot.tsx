import React, { useEffect, useRef, useState } from 'react'
import dayjs from 'dayjs';
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { DatePicker, DatePickerProps } from 'antd';
import { AddContract } from '../Contracts/AddContract';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const LeaveSlot: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [searchTerm, setSearchTerm] = useState<string>("");
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [selectPosition, setSelectPosition] = useState<number>(0)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [selectDept, setSelectDept] = useState<number>(0)
    const [slotData, setSlotData] = useState<any[]>([])
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [itemsPerPage, setItemsPerPage] = useState<number>(30);
    const [columns, setColumns] = useState<any[]>([])
    const tableRef = useRef<any>(null);
    const [fiyears, setFiyears] = useState<{ [employeeId: string]: string }>({});
    const [syear, setSyear] = useState<{ [employeeId: string]: string }>({});
    const [tyear, settyear] = useState<{ [employeeId: string]: string }>({});
    const [foyear, setFoyear] = useState<{ [employeeId: string]: string }>({});

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }
                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }
    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }
    // useEffect(() => { 
    //     if(selectedBrand !==0){
    //     getData() }}, [selectedBrand])
    const getData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand!!!")
        }
        else {
            const payload = {
                companyId: userId?.companyId,
                departmentId: selectDept,
                positionId: selectPosition,
                employeeId: selectEmp,
                userId: userId?.user,
                brandId: selectedBrand,
                locationId: locationId,
                //   currencyCode: string
            }
            setLoading(true)
            AxiosLayout.post(`/Employee/GetEmployeeLeaveSlot`, payload).then((res: any) => {
                if (res.status === 200) {
                    // setSlotData(res.data?.Table)
                    if (res?.data?.Table && res?.data?.Table.length > 0) {
                        setSlotData(res?.data?.Table);
                        const firstRow = res.data.Table[0];
                        const editColumn = {
                            id: "edit",
                            header: "Edit",
                            filter: false,
                            size: 50,
                            columnType: "display",
                            cell: ({ row }: { row: any }) => {
                                const { EmployeeId } = row.original;
                                return (

                                    <div className='text-center cursor-pointer'>
                                        <EditData rowKeyValue={EmployeeId} rowdata={row?.original} />
                                    </div>
                                );
                            },
                        };
                        const deleteColumn = {
                            id: "delete",
                            header: "Delete",
                            filter: false,
                            size: 50,
                            columnType: "display",
                            cell: ({ row }: { row: any }) => {
                                const { EmployeeId } = row.original;
                                return (
                                    <div className="text-center cursor-pointer" >
                                        <DeleteData rowKeyValue={EmployeeId} />
                                    </div>
                                );
                            },
                        };
                        const dynamicColumns = [...Object.keys(firstRow).map((key) => {
                            if (key === 'DOE') {
                                return {
                                    id: key,
                                    header: key,
                                    columnType: 'display',
                                    size: 100,
                                    cell: ({ row }: { row: any }) => {
                                        const { DOE } = row.original;
                                        return (
                                            <>{DOE?.split("T")[0]}</>
                                        );
                                    },

                                };
                            }
                            if (key === '1st Year') {
                                return {
                                    id: key,
                                    header: key,
                                    columnType: 'display',
                                    size: 100,
                                    cell: ({ row }: { row: any }) => {
                                        const employeeId = row.original.EmployeeId;
                                        const value = fiyears[employeeId] ?? row.original["1st Year"];

                                        const handleChange = (e: any) => {
                                            const newValue = e.target.value;
                                            setFiyears(prev => ({
                                                ...prev,
                                                [employeeId]: newValue
                                            }));
                                        };

                                        return (
                                            <YsecInput className="slotinput"
                                                name={`fiyear-${employeeId}`}
                                                value={fiyears[employeeId]}
                                                defaultValue={row.original["1st Year"]}
                                                onChange={handleChange}
                                                type={"number"}
                                            />
                                        );
                                    },
                                };
                            }
                            if (key === '2nd Year') {
                                return {
                                    id: key,
                                    header: key,
                                    columnType: 'display',
                                    size: 100,
                                    cell: ({ row }: { row: any }) => {
                                        const employeeId = row.original.EmployeeId;
                                        const value = syear[employeeId] ?? row.original["2nd Year"];

                                        const handleChange = (e: any) => {
                                            const newValue = e.target.value;
                                            setSyear(prev => ({
                                                ...prev,
                                                [employeeId]: newValue
                                            }));
                                        };

                                        return (
                                            <YsecInput className="slotinput"
                                                name={`syear-${employeeId}`}
                                                value={syear[employeeId]}
                                                defaultValue={row.original["2nd Year"]}
                                                onChange={handleChange}
                                                type={"number"}
                                            />
                                        );
                                    },
                                };
                            }
                            if (key === '3rd Year') {
                                return {
                                    id: key,
                                    header: key,
                                    columnType: 'display',
                                    size: 100,
                                    cell: ({ row }: { row: any }) => {
                                        const employeeId = row.original.EmployeeId;
                                        const value = tyear[employeeId] ?? row.original["3rd Year"];

                                        const handleChange = (e: any) => {
                                            const newValue = e.target.value;
                                            settyear(prev => ({
                                                ...prev,
                                                [employeeId]: newValue
                                            }));
                                        };

                                        return (
                                            <YsecInput className="slotinput"
                                                name={`tyear-${employeeId}`}
                                                value={tyear[employeeId]}
                                                defaultValue={row.original["3rd Year"]}
                                                onChange={handleChange}
                                                type={"number"}
                                            />
                                        );
                                    },
                                };
                            }
                            if (key === '4th Year') {
                                return {
                                    id: key,
                                    header: key,
                                    columnType: 'display',
                                    size: 100,
                                    cell: ({ row }: { row: any }) => {
                                        const employeeId = row.original.EmployeeId;
                                        const value = foyear[employeeId] ?? row.original["4th Year"];

                                        const handleChange = (e: any) => {
                                            const newValue = e.target.value;
                                            setFoyear(prev => ({
                                                ...prev,
                                                [employeeId]: newValue
                                            }));
                                        };

                                        return (
                                            <YsecInput className="slotinput"
                                                name={`foyear-${employeeId}`}
                                                value={foyear[employeeId]}
                                                defaultValue={row.original["4th Year"]}
                                                onChange={handleChange}
                                                type={"number"}
                                            />
                                        );
                                    },
                                };
                            }
                            return {
                                id: key,
                                header: key,
                                filter: true,
                                size: 100
                            };
                        }), editColumn, deleteColumn];

                        setColumns(dynamicColumns);
                        setLoading(false)
                    } else {
                        setSlotData([]);
                        setColumns([]);
                        setLoading(false)
                    }
                }
            })
        }
    }

    const EditData = ({ rowKeyValue, rowdata }: { rowKeyValue: any, rowdata: any }) => {

        const handleData = () => {



        }
        return (
            <YsecFont className={`yf-document-edit action-icon`}
                onClick={handleData}
            />
        )
    }
    const DeleteData = ({ rowKeyValue }: { rowKeyValue: any }) => {

        const handleData = () => {

            AxiosLayout.get(`/Employee/DeleteEmployeeSlotLeave?EmployeeId=${rowKeyValue}&UserId=${userId?.user}`).then((res: any) => {
                if (res.data?.Status === 1) {
                    setFiyears({})
                    setSyear({})
                    settyear({})
                    setFoyear({})
                    setSlotData([])
                    setColumns([])
                    getData()
                }
                else {
                    setErrorMessage(res?.data?.Message)
                }
            })

        }
        return (
            <YsecFont className={`yf-delete-bin-2 action-icon`}
                onClick={handleData}
            />
        )
    }

    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Employee</Breadcrumb.Item>
                            <Breadcrumb.Item active>Leave Slot</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <YsecButton type="button" className={`sm p-0 btn-outline-primary`} >
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>

                    </div>
                </div>

                <div className='manager-container '>

                    <Row className={`p-2 mt-1 mb-1  `}>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            <YsecSelect className={`md `}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                label="Brand" mandatory
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>

                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            <YsecDropdown className="md"
                                name="dept"
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}

                                value={selectDept}
                                onChange={(e: any) => setSelectDept(e.target.value)}
                                label="Department"
                                mandatory
                                  defaultSelectedValue="0"
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            <YsecDropdown className="md"
                                name="position"
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All" },
                                    ...positionsData?.filter((j: any) => j.DepartmentId == selectDept)?.map((i: any) => ({
                                        id: i?.PostionId,
                                        Name: i?.Position
                                    }))

                                ]}
                                value={selectPosition}
                                onChange={(e: any) => setSelectPosition(e.target.value)}
                                label="Position"
                                mandatory
                                  defaultSelectedValue="0"
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            
                            <YsecDropdown
                                label="Employee" mandatory  value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                data={[
                                    { empId: 0, empName: "Select" },
                                    ...empData?.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))
                                ]}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                  defaultSelectedValue="0"
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            <YsecButton className='md w-100 mt-3 mt-md-4' type="button" onClick={getData}>Show</YsecButton>
                        </Col>
                    </Row>

                    <div className='katable m-1 bg-white pt-2 pb-2'>
                        {slotData?.length > 0 && columns?.length > 0 ? (
                            <YsecTable
                                rowData={slotData}
                                columnDefs={columns}
                                filter={true}
                                pagination={true}
                                tableRef={tableRef}
                                pageSize={20}
                                dragColumnDisable={true}
                                reRender={true}

                            />
                        ): <p className='mb-0 p-3 text-center'>No data Found Here...</p>}


                    </div>

                </div>

            </React.Suspense>
        </div>
    )
}

export default LeaveSlot;