import React, { useEffect, useRef, useState } from 'react'
import dayjs from 'dayjs';
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { DatePicker, DatePickerProps } from 'antd';
import { AddContract } from '../Contracts/AddContract';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const CustomCell2: React.FC<any> = ({ value }) => {


    return (
        <div className={"text-start"}>
            {value}
        </div>
    );
};
const PerformanceEvolution: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [searchTerm, setSearchTerm] = useState<string>("");
    const [searchTerm2, setSearchTerm2] = useState<string>("");
    const [dept, setDept] = useState<number>(0)
    const [staffTotal, setStaffTotal] = useState<number | null>(null)
    const [deptData, setDeptData] = useState<any[]>([])
    const [empdata, setEmpData] = useState<any[]>([])
    const [err, setErr] = useState<number>(0)
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [itemsPerPage, setItemsPerPage] = useState<number>(25);
    // Default to current month/year (always use dayjs)
    const [selectedMonth, setSelectedMonth] = useState<dayjs.Dayjs | null>(() => dayjs());
    const [edit, setEdit] = useState<boolean>(false)
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [contractId, setContractId] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [brandData, setBrandData] = useState<any[]>([])
    const [view, setView] = useState<boolean>(false)
    const [adddata, setAddData] = useState<boolean>(false)
    const [addDetails, setAdDetails] = useState<any>({ leave: "", warn_letter: "", late_mins: "", others: "" })
    const [performanceScore, setPerformanceScore] = useState<any[]>([])
    const [noView, setNoView] = useState<boolean>(false)
    const tableRef = useRef<any>(null)
    useEffect(() => {
        getData()
        getMasterData()
    }, [])

    const getData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setDeptData(res.data?.DepartmentList)
                setLoading(false)
            }
        })
    }
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    setSelectedBrand(res.data.BrandList[0]?.BrandId)
                    setLocationId(res.data.BrandList[0]?.LocationId)
                    setLoading(false)
                }

            }
        })
    }

    const onChangeDate: DatePickerProps['onChange'] = (date, dateString) => {
        setSelectedMonth(date ? dayjs(date) : null);
    };
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    const getAllData = async () => {
        setLoading(true)
        await AxiosLayout.get(`/Performance/GetPerformanceEvaluationData?CompanyId=${userId?.companyId}&DepId=${dept}&MonthDate=${selectedMonth?.format('MM') + "-" + selectedMonth?.format('YYYY')}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setStaffTotal(res?.data?.Table?.length)
                if(res.data?.Table!==null){
                setEmpData(res.data?.Table)
                }
                setLoading(false)
            }
        })
    }

    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 150 },
        { id: 'FullName', header: 'Staff Name', filter: true, size: 150 },
        { id: 'DOE', header: 'DOE', filter: true, size: 150 },
        { id: 'Department', header: 'Department Group', filter: true, size: 150 },
        { id: 'Score', header: 'Evaluation Score(%)', filter: true, size: 150 },
        { id: 'Remarks', header: 'Remarks', filter: true, size: 150 },
        { id: 'g_action', header: 'Group Action', filter: true, size: 150 },
        {
            id: "g_action",
            header: "Group Action",
            filter: false,
            cell: ({ row }: { row: any }) => {
                const { EmployeeId } = row.original;

                return (
                      <div className='text-center'>
                    <EditGroupData rowKeyValue={EmployeeId} rowdata={row?.original}/>
                    </div>
                );
            },
        },
        {
            id: "history",
            header: "History",
            filter: false,
            cell: ({ row }: { row: any }) => {
                const { EmployeeId } = row.original;

                return (
                      <div className='text-center'>
                    <ViewData rowKeyValue={EmployeeId}  rowdata={row?.original} />
                    </div>
                );
            },
        },
         {
            id: "hr_remarks",
            header: "HR Remarks",
            filter: false,
            cell: ({ row }: { row: any }) => {
                const { EmployeeId } = row.original;

                return (
                      <div className='text-center'>
                    <AddData rowKeyValue={EmployeeId}  rowdata={row?.original} />
                    </div>
                );
            },
        },
      

    ]

    const EditGroupData = ({ rowKeyValue,rowdata }: { rowKeyValue: any ,rowdata:any}) => {
  
    
        const handleData = () => {

            setSelectEmp(rowdata?.EmployeeId)
            setContractId(rowdata?.ContractId)
            setSelectedBrand(brandData[0]?.BrandId || 0)
            setLocationId(brandData[0]?.LocationId || 0)
            setEdit(true)
        }
        return (
            <YsecFont className={`yf-document-edit action-icon`}
                onClick={handleData}
            />
        )
    }
    const ViewData =({ rowKeyValue,rowdata }: { rowKeyValue: any ,rowdata:any}) => {
        const handleData = () => {
            AxiosLayout.get(`/Performance/GetPerformanceScoreHistory?EmployeeId=${Number(rowKeyValue)}&UserId=${userId?.user}`).then((res: any) => {
                if (res.status === 200) {

                    if (res?.data?.Table?.length > 0) {
                        setPerformanceScore(res.data?.Table)
                        setView(true)
                    }
                    else {
                        setNoView(true)
                    }
                }
            })
        }
        return (
            <YsecFont className={`yf-edit-view-eye action-icon`}
                onClick={handleData}
            />
        )
    }
    const AddData =({ rowKeyValue,rowdata }: { rowKeyValue: any ,rowdata:any}) => {
        return (
            <YsecFont className={`yf-add-circle action-icon`}
                onClick={() => {
                    
                    setSelectEmp(rowdata?.EmployeeId)
                    setContractId(rowdata?.ContractId)
                    setAddData(true)
                }}
            />
        )
    }
    const handleDept = async (val: any) => {
        setDept(Number(val))
        // if (Number(val) !== 0) {
        //     const ddept = deptData?.filter((i: any) => i.DepartmentId === Number(val))
        //     setSelectedBrand(ddept[0]?.BrandId)
        //     setLocationId(ddept[0]?.LocationId)

        // }


    }


    const onChange = (e: any) => {
        const { name, value } = e.target
        setAdDetails({ ...addDetails, [name]: value })
    }
    const handleRemarksUpdate = async (e: any) => {
        e.preventDefault()
        const payload = {
            monthDate: selectedMonth?.format('MM') + "-" + selectedMonth?.format('YYYY'),
            employeeId: selectEmp,
            leaveRemarks: addDetails.leave,
            wlRemarks: addDetails.warn_letter,
            lmRemarks: addDetails.late_mins,
            otherRemarks: addDetails.others,
            userId: userId?.user
        }
        AxiosLayout.post(`/Performance/SaveOrUpdateHrRemarks?userId=${userId?.user}`, payload, { userId: userId?.user }).then((res: any) => {
            if (res?.data?.Message?.includes("Succefully")) {
                setAdDetails({ leave: "", warn_letter: "", late_mins: "", others: "" })
                setAddData(false)
            }
        })
    }
    const dataArray2 = performanceScore?.map(
        (i: any) => ({
            month: i.MonthDate,
            dept: i.Department,
            score: i.Score,
            remarks: i.Remarks,
            hr_remarks: i.Score,
            warn_remark: i.wlRemarks,
            late_remarks: i.lmRemarks,
            other_remarks: i.otherRemarks,
            id: i.PerformanceID,
        }),
    );
    // const 
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Employee</Breadcrumb.Item>
                            <Breadcrumb.Item active>Performance Evaluations</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <YsecButton type="button"
                            className={`sm p-0 btn-outline-primary `} onClick={getAllData}
                        >
                            <YsecFont className="yf-clock" />
                        </YsecButton>


                    </div>
                </div>
                <div className='manager-container  bg-white'>
                    <Row className='p-2 mt-1 mb-1 '>
                        <Col xs={12} md={6} lg={3}>
                            <div className='d-block'>
                                <label className='w-100'>Select Month</label>
                                <DatePicker
                                    onChange={onChangeDate}
                                    picker="month"
                                    className='w-100'
                                    value={selectedMonth}
                                />
                            </div>
                        </Col>
                        <Col xs={12} md={6} lg={3}>
                           
                            <YsecDropdown
                                objectNameKey="deptName"
                                objectValueKey="deptid"
                                data={[
                                    { deptid: 0, deptName: "All" },
                                    ...deptData?.map((i: any) => ({
                                        deptid: i?.DepartmentId,
                                        deptName: i?.Department
                                    }))

                                ]}
                                value={dept}
                                onChange={(e) => handleDept(e.target.value)}
                                label="Department"
                                  defaultSelectedValue="0"
                            />
                        </Col>
                        <Col xs={12} md={6} lg={3}>
                            <YsecInput label="Staff Total" value={staffTotal} name="staffTotal" disabled className='disableField' />
                        </Col>
                        <Col xs={12} md={6} lg={3} >
                            <YsecButton className='md w-100 mt-3 mt-md-4' type="button" onClick={getAllData}>Show</YsecButton>
                        </Col>
                    </Row>
                    <div>
                        
                        <div className='katable contractstable'>
                            <YsecTable
                    rowData={empdata}
                    columnDefs={staticColumns}
                    filter={true}
                    pagination={true}
                    tableRef={tableRef}
                    pageSize={20}
                    dragColumnDisable={true}
                    reRender={true}
                />
                           
                        </div>
                        
                    </div>
                </div>
                {edit === true && <Modal size="xl"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    show={edit} onHide={() => {
                        setEdit(false)
                    }}>
                    <Modal.Header> <p className="modal-title opening" id="exampleModalLabel">Contract</p>
                        <button type="button" className="btn-close" onClick={() => {
                            setEdit(false)
                        }} aria-label="Close"></button></Modal.Header>
                    <Modal.Body><AddContract selectedBrand={selectedBrand} selectBrand={selectedBrand} selectEmp={selectEmp} locationId={locationId} brandData={brandData} setLocationId={setLocationId} contractId={contractId} setSelectedBrand={setSelectedBrand} getData={getAllData} /></Modal.Body>
                </Modal>}


                {adddata === true && <Modal size="lg"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    show={adddata} onHide={() => {
                        setAddData(false)
                    }}>
                    <Modal.Header> <p className="modal-title opening" id="exampleModalLabel">HR Remarks</p>
                        <button type="button" className="btn-close" onClick={() => {
                            setAddData(false)
                        }} aria-label="Close"></button></Modal.Header>
                    <Modal.Body>
                        <Row>
                            <Col xs={12}>
                                <YsecInput label="Leave(Sick/Unpaid/Annual)" name="leave" value={addDetails?.leave} onChange={onChange} />
                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Warning Letter" name="warn_letter" value={addDetails?.warn_letter} onChange={onChange} />
                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Late Minutes" name="late_mins" value={addDetails?.late_mins} onChange={onChange} />
                            </Col>
                            <Col xs={12}>
                                <YsecInput label="Others" name="others" value={addDetails?.others} onChange={onChange} />
                            </Col>
                            <Col xs={12} className='d-flex mt-3 justify-content-center'>
                                <YsecButton className='me-1' type='button' onClick={handleRemarksUpdate}>Save</YsecButton>
                                <YsecButton className='ms-1 cancel' type='button' onClick={() => setEdit(false)}>Close</YsecButton>

                            </Col>
                        </Row>
                    </Modal.Body>
                </Modal>}
                {noView === true && <Modal size="sm"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    show={noView} onHide={() => {
                        setNoView(false)
                    }}>
                    <Modal.Header> <p className="modal-title opening" id="exampleModalLabel">Info</p>
                        <button type="button" className="btn-close" onClick={() => {
                            setNoView(false)
                        }} aria-label="Close"></button></Modal.Header>
                    <Modal.Body>
                        <p className='text-center opening'>Score Rating History Not Found For This Employee</p>
                        <div className='text-center mt-2'>
                            <YsecButton className='cancel d-block mx-auto' type='button' onClick={() => setNoView(false)}>OK</YsecButton>
                        </div>
                    </Modal.Body>
                </Modal>}
                {view === true && <Modal size="xl"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                    show={view} onHide={() => {
                        setView(false)
                    }}>
                    <Modal.Header> <p className="modal-title opening" id="exampleModalLabel">Performance Score History Details</p>
                        <button type="button" className="btn-close" onClick={() => {
                            setView(false)
                        }} aria-label="Close"></button></Modal.Header>
                    <Modal.Body>
                        <div>
                            <div className=" p-2">
                                <YsecInput
                                    className="sm "
                                    icon='yf-search'
                                    value={searchTerm2}
                                    placeholder="Search"
                                    onChange={(e) => {
                                        setSearchTerm2(e.target.value);
                                    }}
                                />
                            </div>
                            <div className='katableee contractstable modaltableheight'>
                                <Table
                                    columns={[
                                        { key: 'month', title: 'Month', dataType: DataType.String },
                                        { key: 'dept', title: 'Department', dataType: DataType.String },
                                        { key: 'score', title: 'Score', dataType: DataType.String },
                                        { key: 'remarks', title: 'Remarks', dataType: DataType.String },
                                        { key: 'hr_remarks', title: 'HR Leave Remarks', dataType: DataType.String },
                                        { key: 'warn_remark', title: 'Warning Letter Remarks', dataType: DataType.String },
                                        { key: 'late_remarks', title: 'Late Minute Remarks', dataType: DataType.String },
                                        { key: 'other_remarks', title: 'Other Remarks', dataType: DataType.String },
                                    ]}
                                    data={dataArray2}
                                    rowKeyField={'id'}
                                    noData={{
                                        text: 'No Data Found'
                                    }}
                                    searchText={searchTerm2}
                                />
                            </div>
                        </div>
                    </Modal.Body>
                </Modal>}
            </React.Suspense>
        </div>
    )
}
export default PerformanceEvolution;