import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row, Tab, Tabs } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import { FamilyTable, InsuranceTable } from './Insur_FamilyTable';
import { CustomViewDocModal } from '../CustomDocViewModal';
import { CustomInsuranceModal } from '../CustomModal';



const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));



interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}
enum RefTableIDs {
    Select = 0,
    Relation = 1,
    MaritalStatus = 2,
    PenaltyTypes = 3,
    ExtraPaymentTypes = 4,
    PersCmntTypes = 5,
    Qualification = 6,
    OverTimeTypes = 7,
}
export const FamilyDetailsForm: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [showDocs, setShowDocs] = useState<boolean>(false)
    const [docData, setDocData] = useState<any[]>([])
    const fileref = useRef<HTMLInputElement | any>(null)
    const [openModal, setOpenModal] = useState<boolean>(false)
    const [title, setTitle] = useState<string>("")
    const [addType, setAddType] = useState<number>(0)
    const [customData, setCustomData] = useState<any[]>([])
    useEffect(() => {
        getDocData()
        if (props?.familyId !== 0) {
            const data = props?.familyData?.filter((i: any) => i.FamilyId == (props?.familyId));
            props?.setFamilyDetails({
                title: data[0]?.Title,
                fname: data[0]?.FirstName,
                lname: data[0]?.LastName,
                mname: data[0]?.MarriedName,
                govid: data[0]?.IdNumber,
                relation: data[0]?.Relation,
                marital_status: data[0]?.MaritalStatusId,
                email: data[0]?.Email,
                country: data[0]?.CountryId,
                addres: data[0]?.Address,
                dist: data[0]?.District,
                phone: data[0]?.Phone,
                mobile: data[0]?.Mobile,
                isActive: data[0]?.IsActive
            })
            props?.setDob(data[0]?.DateOfBirth?.split("T")[0]);
            props?.setMarriageDate(data[0]?.MarriageDate?.split("T")[0]);
            props?.setContactId(data[0]?.ContactID);
            const ch_edData = props?.edData?.filter((i: any) => i.FamilyId == props?.familyId);
            const formattededucationData = ch_edData?.map((item: any) => ({
                education: item?.Education || "",
                year: item?.Year || "",
                remarks: item?.Remarks || "",
            }));
            props?.setEdData(formattededucationData?.length ? formattededucationData : []);
        }
    }, [])
    const getDocData = () => {
        AxiosLayout.get(`/Common/GetDocumentDetails?EmployeeId=${props?.selectEmp}&DocTypeId=${DocumentType?.EmpInsurance}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setDocData(res?.data)
                props?.setDocFilesData(res?.data)
            }
        })
    }
    const addEntry = () => {
        const edData = props.edData;
        // If no rows, always allow adding
        if (edData.length === 0) {
            props.setEdData([{ education: "", year: "", remarks: "" }]);
            return;
        }
        // If only one row, allow adding if any field is filled
        if (edData.length === 1) {
            const first = edData[0];
            if (first.education || first.year || first.remarks) {
                props.setEdData([...edData, { education: "", year: "", remarks: "" }]);
            }
            return;
        }
        // For multiple rows, check if last row has any field filled
        const last = edData[edData.length - 1];
        if (last.education || last.year || last.remarks) {
            props.setEdData([...edData, { education: "", year: "", remarks: "" }]);
        }
    };
    const updateEntry = (index: number, field: any, value: any) => {
        const updatedData = props.edData.map((item: any, i: any) =>
            i === index ? { ...item, [field]: value } : item
        );
        props.setEdData(updatedData);
    };
    const removeEntry = (index: number) => {
        const updatedData = props.edData.filter((_: any, i: any) => i !== index);
        props.setEdData(updatedData);
    };

    const onChangeFamilyDetails = (e: any) => {
        props?.setFamilyDetails({ ...props?.familyDetails, [e.target.name]: e.target.value })
    }
    const handleSave = async (e: any) => {
        e.preventDefault();
        props?.setErr(0)
        if (props?.familyDetails.title == 0) {
            props.setErr(1)
        }
        else if (props?.familyDetails.fname == "") {
            props.setErr(2)
        }
        else if (props?.familyDetails.lname == "") {
            props.setErr(3)
        }
        else if (props?.familyDetails.relation == 0) {
            props.setErr(4)
        }
        else if (props?.familyDetails.marital_status == 0) {
            props.setErr(5)
        }
        else if (props?.familyDetails.country == 0) {
            props.setErr(6)
        }
        else {

            const formattedEdDate = props?.edData?.map((item: any, index: number) => ({
                educationId: item?.EducationId || 0,
                education: item?.Education || "",
                year: item?.Year || "",
                isActive: true,
                remarks: item?.Remarks || "",
                isEmpEducation: true,
                id: index + 1,
            }));

            const payload = {
                contactId: props?.contactId,
                employeeId: Number(props?.selectEmp),
                relationid: props?.familyDetails?.relation,
                title: props?.familyDetails?.title,
                firstName: props?.familyDetails?.fname,
                lastName: props?.familyDetails?.lname,
                fullName: props?.familyDetails?.fname + " " + props?.familyDetails?.lname,
                marriedName: props?.familyDetails?.mname,
                idNumber: props?.familyDetails?.govid,
                dateOfBirth: props?.dob||"",
                maritalStatusId: props?.familyDetails?.marital_status,
                marriageDate: props?.marriageDate||"",
                email: props?.familyDetails?.email,
                countryId: props?.familyDetails?.country,
                address: props?.familyDetails?.addres,
                district: props?.familyDetails?.dist,
                phone: props?.familyDetails?.phone,
                mobile: props?.familyDetails?.mobile,
                isActive: props?.familyDetails?.isActive,
                gender: "",
                userId: userId?.user,
                uploadDocPath: "",
                uploadDoctypeId: DocumentType?.EmpInsurance,

                empFamilyEducations: formattedEdDate
            }

            AxiosLayout.post("/Employee/SaveandUpdateEmpFamilyDetails", payload).then((res: any) => {
                if (res.data.Message?.includes("Success")) {
                    props?.setFamilyDetails({ title: 0, fname: "", lname: "", mname: "", govid: "", relation: 0, marital_status: 0, email: "", country: 0, addres: "", dist: "", phone: "", mobile: "", isActive: false })
                    props?.setDob("")
                    props?.setMarriageDate("")
                    props?.setEdData([])
                    props?.getFamilyInsurData()
                    props?.setAlertMessage(res.data.Message)
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                }
            })
        }
    }
    const handleUploadFileButtonClick = () => {
        fileref.current?.click();
    };
    const handleFileChange = (e: any) => {
        const selectedFiles = Array.from(e.target.files);
        props?.setFamilyFiles([...props.familyFiles, ...selectedFiles]);
        // \\192.168.248.197\Share\VigneshG\Suribet\EMP_CONTRACT
    };
    useEffect(() => {
        if (addType !== 0) {
            setOpenModal(false)
            getGeneralData()
        }
    }, [addType])

    const getGeneralData = () => {
        AxiosLayout.get(`/Employee/GetGeneralDataTypes?tableid=${addType}&CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setCustomData(res.data)
                setOpenModal(true)
            }

        })
    }
    return (
        <div className='p-3'>
            <Row>
                <Col xs={12} md={6} lg={3}>
                    <YsecInput label="Employee Id" value={props?.selectEmp} disabled className='disableField' />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecSelect
                        className="md"
                        name="title"
                        objectNameKey="title_name"
                        objectValueKey="title_id"
                        data={[
                            { title_id: "", title_name: "Select Title" },
                            { title_id: "Mr", title_name: "Mr" },
                            { title_id: "Ms", title_name: "Ms" },

                        ]}
                        value={props?.familyDetails.title}
                        onChange={onChangeFamilyDetails}
                        label="Title"
                        mandatory
                    />
                    {props?.err === 1 && <label className='error'>Please Select Title...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="fname" value={props?.familyDetails.fname} onChange={onChangeFamilyDetails} className="md" label="First Name"
                        mandatory />
                    {props?.err === 2 && <label className='error'>Please Enter Your First Name ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="lname" value={props?.familyDetails.lname} onChange={onChangeFamilyDetails} className="md" label="Last Name"
                        mandatory />
                    {props?.err === 3 && <label className='error'>Please Enter Your Last Name ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecInput label="Married Name" name="mname" value={props?.familyDetails.mname} onChange={onChangeFamilyDetails} className="md" />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecInput label="Govt ID" name="govid" value={props?.familyDetails.govid} onChange={onChangeFamilyDetails} className="md" />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecDatePicker key={props?.dob}
                        name="dob"
                        value={props?.dob}
                        className="md"
                        label="Date of Birth"
                        error="test message"
                        onChange={(e) => props?.setDob(e.target.value)}
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="1000_Y"
                        ysecMaxDate="1000_Y"
                    />
                </Col>
                <Col xs={12} md={6} lg={3} className='d-flex'>
                    <div className='jobselect me-1'>
                        <YsecSelect
                            className="md"
                            name="relation"
                            objectNameKey="relation_name"
                            objectValueKey="id"
                            data={
                                props?.empRelation?.map((i: any) => ({
                                    id: i.id,
                                    relation_name: i.RelationDescription
                                }))
                            }
                            value={props?.familyDetails.relation}
                            onChange={onChangeFamilyDetails}
                            label="Relation"
                            mandatory
                        />
                        {props?.err === 4 && <label className='error'>Please Select Relation...</label>}
                    </div>
                    <div className='mt-4'>
                        <YsecButton type='button' onClick={() => {
                            setTitle("Relation")
                            setAddType(RefTableIDs?.Relation)
                            setOpenModal(true)
                        }} className='cancel' >
                            <YsecFont className='yf-plus-add' />
                        </YsecButton></div>
                </Col>
                <Col xs={12} md={6} lg={3} className='d-flex'>
                    <div className='jobselect me-1'>
                        <YsecSelect
                            className="md"
                            name="marital_status"
                            objectNameKey="name"
                            objectValueKey="id"
                            data={props?.maritalStatusData?.map((i: any) => ({
                                id: i.MaritalStatusId,
                                name: i.MaritalStatusName
                            }))}
                            value={props?.familyDetails.marital_status}
                            onChange={onChangeFamilyDetails}
                            label="Marital Status"
                            mandatory
                        />
                        {props?.err === 5 && <label className='error'>Please Select Marital Status...</label>}
                    </div>
                    <div className='mt-4'>
                        <YsecButton type='button' onClick={() => {
                            setTitle("Marital Status")
                            setAddType(RefTableIDs?.MaritalStatus)
                            setOpenModal(true)
                        }} className='cancel' >
                            <YsecFont className='yf-plus-add' />
                        </YsecButton></div>
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecDatePicker key={props?.marriageDate}
                        name="marriageDate"
                        value={props?.marriageDate}
                        className="md"
                        label="Marriage Date"
                        error="test message"
                        onChange={(e) => props?.setMarriageDate(e.target.value)}
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="1000_Y"
                        ysecMaxDate="1000_Y"
                    />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecInput label="Email" name="email" value={props?.familyDetails.email} onChange={onChangeFamilyDetails} className="md" />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecSelect
                        className="md"
                        name="country"
                        objectNameKey="name"
                        objectValueKey="id"
                        data={props?.countriesData?.map((i: any) => ({
                            id: i.CountryId,
                            name: i.CountryName
                        }))}
                        value={props?.familyDetails.country}
                        onChange={onChangeFamilyDetails}
                        label="Country"
                        mandatory
                    />
                    {props?.err === 6 && <label className='error'>Please Select Country...</label>}
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecInput label="Place / District" name="place_district" value={props?.familyDetails.place_district} onChange={onChangeFamilyDetails} />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecInput label="Phone" type="number" name="phone" value={props?.familyDetails.phone} onChange={onChangeFamilyDetails} />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecInput label="Mobile" type="number" name="mobile" value={props?.familyDetails.mobile} onChange={onChangeFamilyDetails} />
                </Col>
                <Col xs={12} md={6} lg={3}>
                    <YsecTextarea label="Address" className="sm" name="addres" value={props?.familyDetails.addres} onChange={onChangeFamilyDetails} />
                </Col>
            </Row>

            <div className='katableee katablefixheightt mt-1'>

                <table>
                    <thead>
                        <tr>
                            <th>Education</th>
                            <th>Year</th>
                            <th>Remarks</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        {props?.edData.map((entry: any, index: number) => (
                            <tr key={index}>
                                <td >

                                    <YsecInput className="sm"
                                        name="education"
                                        value={entry.education}
                                        onChange={(e) => updateEntry(index, "education", e.target.value)}
                                    />
                                </td>
                                <td>
                                    <YsecInput className="sm"
                                        name="year"
                                        value={entry.year}
                                        onChange={(e) => updateEntry(index, "year", e.target.value)}
                                    />

                                </td>

                                <td>
                                    <YsecInput className="sm"
                                        name="remarks"
                                        value={entry.remarks}
                                        onChange={(e) => updateEntry(index, "remarks", e.target.value)}

                                    />
                                </td>


                                <td>
                                    <YsecFont className='yf-delete-bin-2' onClick={() => removeEntry(index)} /></td>
                            </tr>
                        ))}
                        {/* Show add new row only if allowed by the logic above */}
                        {(() => {
                            const edData = props.edData;
                            if (edData.length === 0) return (
                                <tr><td colSpan={12} className='addrow' onClick={addEntry}>Click here to add new row</td></tr>
                            );
                            if (edData.length === 1) {
                                const first = edData[0];
                                if (first.education || first.year || first.remarks) {
                                    return <tr><td colSpan={12} className='addrow' onClick={addEntry}>Click here to add new row</td></tr>;
                                }
                                return null;
                            }
                            const last = edData[edData.length - 1];
                            if (last.education || last.year || last.remarks) {
                                return <tr><td colSpan={12} className='addrow' onClick={addEntry}>Click here to add new row</td></tr>;
                            }
                            return null;
                        })()}
                    </tbody>

                </table>
            </div>
            <Row>
                <Col xs={12} sm={4}>
                    <YsecButton className='mt-2 w-100 cancel'>Scan Doc</YsecButton>
                </Col>
                <Col xs={12} sm={4}>
                    <YsecButton type="button" className='mt-2 w-100 cancel' onClick={handleUploadFileButtonClick}>
                        Upload Doc
                    </YsecButton>
                    <input
                        ref={fileref}
                        type="file"
                        // multiple
                        accept=".pdf,.doc,.docx"
                        style={{ display: 'none' }}
                        onChange={handleFileChange}
                    />
                </Col>
                <Col xs={12} sm={4}>
                    <YsecButton className='mt-2 w-100 cancel' type='button' onClick={() => { setShowDocs(true) }}>View Doc</YsecButton>
                </Col>

                <Col xs={12} className='d-flex mt-2  justify-content-center justify-content-md-end'>
                    <YsecButton className='mt-1' type="button" onClick={handleSave}>Submit</YsecButton>
                    <YsecButton className='mt-1 ms-2 cancel' onClick={() => props.setOpen(false)}>Clear</YsecButton>
                </Col>
            </Row>
            {showDocs === true && <CustomViewDocModal open={showDocs} setOpen={setShowDocs} data={docData} />}
            {openModal === true && <CustomInsuranceModal open={openModal} setOpen={setOpenModal} data={customData} addType={addType} title={title} getEmpCommonData={props?.getEmpCommonData} setAlertMessage={props?.setAlertMessage} setErrorMessage={props?.setErrorMessage} getGeneralData={getGeneralData} />}
        </div>
    )
}