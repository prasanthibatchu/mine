
import { DataType, Table } from 'ka-table';
import React, { useRef } from 'react'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
}

export const FamilyTable: React.FC<any> = (props) => {
    const tableReff = useRef<any>(null)
    const staticColumns = [
        { id: 'Title', header: 'Title', filter: true, size: 100 },
        { id: 'FirstName', header: 'First Name', filter: true, size: 100 },
        { id: 'LastName', header: 'Last Name', filter: true, size: 100 },
        { id: 'MarriedName', header: 'Married Name', filter: true, size: 100 },
        { id: 'IdNumber', header: 'Id Number', filter: true, size: 100 },
        { id: 'DateOfBirth', header: 'Date Of Birth', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { DateOfBirth } = row.original;
                return (
                  <>{DateOfBirth?.split("T")[0]}</> 
                );
            }, },
        { id: 'RelationDescription', header: 'Relation', filter: true, size: 100 },
        { id: 'MaritalStatusDescription', header: 'Marital Status', filter: true, size: 100 },
        { id: 'MarriageDate', header: 'Marriage Date', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { MarriageDate } = row.original;
                return (
                  <>{MarriageDate?.split("T")[0]}</> 
                );
            }, },
        { id: 'Email', header: 'Email', filter: true, size: 100 },
        { id: 'Country', header: 'Country', filter: true, size: 100 },
        { id: 'Address', header: 'Address', filter: true, size: 100 },
        { id: 'District', header: 'District', filter: true, size: 100 },
        { id: 'Phone', header: 'Phone', filter: true, size: 100 },
        { id: 'Mobile', header: 'Mobile', filter: true, size: 100 },
        { id: 'IsActive', header: 'IsActive', filter: true, size: 100 , cell: ({ row }: { row: any }) => {
                const { IsActive } = row.original;
                return (
                    <div className='text-center'>
                    <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} /></div>
                );
            },},
        {
            id: "edit",
            header: "Edit",
            filter: false,
            cell: ({ row }: { row: any }) => {
                const { FamilyId } = row.original;

                return (
                     <div className='text-center'>
                    <EditAction rowKeyValue={FamilyId} /></div>
                );
            },
        }

    ]
   
    const EditAction = ({ rowKeyValue }: { rowKeyValue: any }) => {

        return (
            <YsecFont className='yf-document-edit' onClick={() => {
                props?.setFamilyDetails({ title: 0, fname: "", lname: "", mname: "", govid: "", relation: 0, marital_status: 0, email: "", country: 0, addres: "", dist: "", phone: "", mobile: "", isActive: false })
                props?.setDob("")
                props?.setMarriageDate("")
                props?.setContactId(0)
                props?.setInsurDetails({ company: "", ins_amt: "", currency: 0 })
                props?.setStartDate("")
                props?.setEdData([])
                props?.setEndDate("")
                props?.setFamilyId(rowKeyValue);
                props?.setOpen(true)
            }} />
        )
    }

    return (
        <div className="katable">
            <div className='katable contractstable'>
              
                <YsecTable
                    rowData={props?.familyData}
                    columnDefs={staticColumns}
                    filter={true}
                    pagination={false}
                    tableRef={tableReff}
                    // pageSize={20}
                    dragColumnDisable={true}
                    reRender={true}
                />
            </div>
        </div>
    )
}


export const InsuranceTable: React.FC<any> = (props) => {
    const tableRef = useRef<any>(null)

    const staticColumns = [
        { id: 'CompanyName', header: 'Company Name', filter: true, size: 150 },
        { id: 'StartDate', header: 'Start Date', filter: true, size: 150, cell: ({ row }: { row: any }) => {
                const { StartDate } = row.original;
                return (
                  <>{StartDate?.split("T")[0]}</> 
                );
            },  },
        { id: 'EndDate', header: 'End Date', filter: true, size: 150 , cell: ({ row }: { row: any }) => {
                const { EndDate } = row.original;
                return (
                  <>{EndDate?.split("T")[0]}</> 
                );
            }, },
        { id: 'InsuranceAmount', header: 'Insurance Amount', filter: true, size: 150 },
        { id: 'CurrencyName', header: 'Currency', filter: true, size: 150 },
        {
            id: "edit",
            header: "Edit",
            filter: false,
            cell: ({ row }: { row: any }) => {
                const { InsuranceDetailId } = row.original;

                return (
                    <div className='text-center'>
                    <EditInsuranceAction rowKeyValue={InsuranceDetailId} /></div>
                );
            },
        }

    ]

    const EditInsuranceAction = ({ rowKeyValue }: { rowKeyValue: any }) => {

        return (
            <YsecFont className='yf-document-edit' onClick={() => {
                props?.setFamilyDetails({ title: 0, fname: "", lname: "", mname: "", govid: "", relation: 0, marital_status: 0, email: "", country: 0, addres: "", dist: "", phone: "", mobile: "", isActive: false })
                props?.setDob("")
                props?.setMarriageDate("")
                props?.setContactId(0)
                props?.setInsurDetails({ company: "", ins_amt: "", currency: 0 })
                props?.setStartDate("")
                props?.setEdData([])
                props?.setEndDate("")
                props?.setInsuranceId(rowKeyValue);
                props?.setOpen(true)
            }} />
        )
    }
    return (
        <div className="katable">
            <div className='katable contractstable'>
                <YsecTable
                    rowData={props?.insurdata}
                    columnDefs={staticColumns}
                    filter={true}
                    pagination={false}
                    tableRef={tableRef}
                    // pageSize={20}
                    dragColumnDisable={true}
                    reRender={true}
                />
            </div>
        </div>
    )
}