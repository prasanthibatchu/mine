import React, { useEffect, useState } from 'react'
import { Breadcrumb, Col, Row, Tab, Tabs } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import { FamilyTable, InsuranceTable } from './Insur_FamilyTable';
import { FamilyDetailsForm } from './FamilyDetalsForm';
import { InsuranceDetailsForm } from './InsurDetailsForm';
import LoadingSpinner from '../../Loader/Loader';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}


const InsuranceAndFamilyDetails: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [itemsPerPage, setItemsPerPage] = useState<number>(20);
    const [open, setOpen] = useState<boolean>(false)
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [activeTab, setActiveTab] = useState<string>("family");
    const [familyData, setFamilyData] = useState<any[]>([])
    const [insurdata, setInsurData] = useState<any[]>([])
    const [edData, setEdData] = useState<any[]>([])
    const [insuranceId, setInsuranceId] = useState<number>(0);
    const [familyId, setFamilyId] = useState<number>(0);
    const [maritalStatusData, setMaritalStatusData] = useState<any[]>([])
    const [countriesData, setCountriesData] = useState<any[]>([])
    const [insufiles, setInsuFiles] = useState<any[]>([]);
    const [familyFiles, setFamilyFiles] = useState<any[]>([]);
    const [empRelation, setEmpRelation] = useState<any[]>([])
    const [currencyData, setCurrencyData] = useState<any[]>([])

    const [familyDetails, setFamilyDetails] = useState<any>({ title: 0, fname: "", lname: "", mname: "", govid: "", relation: 0, marital_status: 0, email: "", country: 0, addres: "", dist: "", phone: "", mobile: "", isActive: false });

    const [dob, setDob] = useState<string>("");
    const [marriageDate, setMarriageDate] = useState<string>("");
    const [contactId, setContactId] = useState<number>(0);
    const [err, setErr] = useState<number>(0)
    const [insurDetails, setInsurDetails] = useState<any>({ company: "", ins_amt: "", currency: 0 })
    const [start_date, setStartDate] = useState<string>("");
    const [end_date, setEndDate] = useState<string>("");
    const [docFilesData, setDocFilesData] = useState<any[]>([])
    const [loading, setLoading] = useState<boolean>(false);

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmploygeneralList()
        getEmpCommonData()
    }, []);
    useEffect(() => {
        handleClear()
    }, [selectEmp, selectedBrand])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                    }
                }
                if (res.data.CurrencyList !== null) {
                    setCurrencyData(res.data.CurrencyList)
                }
                setLoading(false)
            }
        })
    }
    const getEmploygeneralList = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res?.data)
                setLoading(false)
            }
        })
    }
    useEffect(() => {
        if (selectEmp !== 0) {
            if (selectedBrand == 0) {
                setErrorMessage("Please Select Brand...");
            } else {
                getFamilyInsurData()
            }
        }

    }, [selectEmp, selectedBrand])
    const getFamilyInsurData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }
        else if (selectEmp == 0) {
            setErrorMessage("Please Select Employee...")
        }
        else {
            AxiosLayout.get(`/Employee/GetEmpFamilyandEducationDetails?Employeeid=${selectEmp}&UserId=${userId?.user}`
            ).then((res: any) => {
                if (res.status === 200) {
                    setFamilyData(res?.data?.Table)
                    setInsurData(res?.data?.Table2)
                    setEdData(res?.data?.Table1)
                }
            })
        }

    }
    const getEmpCommonData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeeCommonData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                if (res.data.Countries !== null) {
                    setCountriesData(res.data.Countries)
                }
                if (res.data.MaritalStatuses !== null) {
                    setMaritalStatusData(res.data.MaritalStatuses)
                }
                if (res.data.EmpRelations !== null) {
                    setEmpRelation(res.data.EmpRelations)
                }
                setLoading(false)
            }
        })

    }
    const handleClear = () => {
        setFamilyDetails({ title: 0, fname: "", lname: "", mname: "", govid: "", relation: 0, marital_status: 0, email: "", country: 0, addres: "", dist: "", phone: "", mobile: "", isActive: false })
        setDob("")
        setMarriageDate("")
        setContactId(0)
        setInsurDetails({ company: "", ins_amt: "", currency: 0 })
        setStartDate("")
        setEdData([])
        setEndDate("")
        setFamilyId(0)
        setInsuranceId(0)
    }
    const hanadleUpdateData = async () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }
        else if (selectEmp == 0) {
            setErrorMessage("Please Select Employee...")
        }
        else {
            setOpen(true)
        }
    }
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Employee</Breadcrumb.Item>
                            <Breadcrumb.Item active>Insurance And Family Details</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm p-0 ${open !== true && 'cancel'} ${(open === true) && "disbutn"}`} onClick={hanadleUpdateData} disabled={(open === true)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 history  ${open === true && 'cancel'}`} onClick={() => {

                            setOpen(false)
                        }}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>

                    </div>
                </div>

                <div className='manager-container'>
                    <Row className='p-2 m-1  bg-white'>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >
                            <YsecSelect className={`md ${open === true && "disableField"}`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                label="Brand" mandatory
                                onChange={(e) => {setSelectedBrand(e.target.value)
                                    setSelectEmp(0)
                                }}
                                disabled={open === true}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >

                            <YsecDropdown className={`md ${open === true && "disableField"}`}
                                label="Employee" mandatory value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                data={[
                                    { empId: 0, empName: "Select" },
                                    ...empData?.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))
                                ]}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                disabled={open === true}
                                defaultSelectedValue="0"
                            />
                        </Col>
                        {/* <Col xs={12} sm={6} md={2} lg={1} xl={1} className='p-1 d-flex align-items-end'>
                            <YsecButton type="button" className="md btn btn-primary w-100" onClick={getEmployeeContractData} >Display</YsecButton>
                        </Col> */}
                    </Row>

                    <>

                        <div className='p-2'>
                            <Tabs
                                activeKey={activeTab} // Controlled active tab
                                onSelect={(k: any) => setActiveTab(k)}
                                className="mb-3"
                            >
                                <Tab eventKey="family" title="Family Details">
                                    {open === false ?
                                        <FamilyTable familyData={familyData} open={open} setOpen={setOpen} activeTabe={activeTab} setActiveTab={setActiveTab} selectEmp={selectEmp} setSelectEmp={setSelectEmp} familyId={familyId} setFamilyId={setFamilyId} edData={edData} setEdData={setEdData} empRelation={empRelation} maritalStatusData={maritalStatusData} countriesData={countriesData} familyDetails={familyDetails} setFamilyDetails={setFamilyDetails} dob={dob} setDob={setDob} marriageDate={marriageDate} setMarriageDate={setMarriageDate} contactId={contactId} setContactId={setContactId} insuranceId={insuranceId} setInsuranceId={setInsuranceId} insurdata={insurdata} currencyData={currencyData} insurDetails={insurDetails} setInsurDetails={setInsurDetails} start_date={start_date} setStartDate={setStartDate} end_date={end_date} setEndDate={setEndDate} insufiles={insufiles} setInsuFiles={setInsuFiles} familyFiles={familyFiles} setFamilyFiles={setFamilyFiles} />
                                        :
                                        <FamilyDetailsForm open={open} setOpen={setOpen} activeTabe={activeTab} setActiveTab={setActiveTab} selectEmp={selectEmp} setSelectEmp={setSelectEmp} edData={edData} setEdData={setEdData} familyData={familyData} familyId={familyId} setFamilyId={setFamilyId} empRelation={empRelation} maritalStatusData={maritalStatusData} countriesData={countriesData} familyDetails={familyDetails} setFamilyDetails={setFamilyDetails} dob={dob} setDob={setDob} marriageDate={marriageDate} setMarriageDate={setMarriageDate} contactId={contactId} setContactId={setContactId} err={err} setErr={setErr} insufiles={insufiles} setInsuFiles={setInsuFiles} familyFiles={familyFiles} setFamilyFiles={setFamilyFiles} getFamilyInsurData={getFamilyInsurData} setAlertMessage={setAlertMessage} setErrorMessage={setErrorMessage} docFilesData={docFilesData} setDocFilesData={setDocFilesData} getEmpCommonData={getEmpCommonData} />}
                                </Tab>
                                <Tab eventKey="insurance" title="Insurance Details">
                                    {open === false ? <InsuranceTable insurdata={insurdata} open={open} setOpen={setOpen} activeTabe={activeTab} setActiveTab={setActiveTab} selectEmp={selectEmp} setSelectEmp={setSelectEmp} insuranceId={insuranceId} setInsuranceId={setInsuranceId} familyDetails={familyDetails} setFamilyDetails={setFamilyDetails} dob={dob} setDob={setDob} marriageDate={marriageDate} setMarriageDate={setMarriageDate} contactId={contactId} setContactId={setContactId} nsurDetails={insurDetails} setInsurDetails={setInsurDetails} start_date={start_date} setStartDate={setStartDate} end_date={end_date} setEndDate={setEndDate} edData={edData} setEdData={setEdData} insufiles={insufiles} setInsuFiles={setInsuFiles} familyFiles={familyFiles} setFamilyFiles={setFamilyFiles} />
                                        :
                                        <InsuranceDetailsForm open={open} setOpen={setOpen} activeTabe={activeTab} setActiveTab={setActiveTab} selectEmp={selectEmp} setSelectEmp={setSelectEmp} insuranceId={insuranceId} setInsuranceId={setInsuranceId} insurdata={insurdata} currencyData={currencyData} insurDetails={insurDetails} setInsurDetails={setInsurDetails} start_date={start_date} setStartDate={setStartDate} end_date={end_date} setEndDate={setEndDate} err={err} setErr={setErr} familyId={familyId} contactId={contactId} familyDetails={familyDetails} insufiles={insufiles} setInsuFiles={setInsuFiles} familyFiles={familyFiles} setFamilyFiles={setFamilyFiles} setAlertMessage={setAlertMessage} setErrorMessage={setErrorMessage} getFamilyInsurData={getFamilyInsurData} />}
                                </Tab>

                            </Tabs>
                        </div>

                    </>
                </div>
            </React.Suspense>
        </div>
    )
}
export default InsuranceAndFamilyDetails;