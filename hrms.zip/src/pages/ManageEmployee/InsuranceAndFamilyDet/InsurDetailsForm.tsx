import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Container, Row, Tab, Tabs } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import { FamilyTable, InsuranceTable } from './Insur_FamilyTable';
import { CustomViewDocModal } from '../CustomDocViewModal';



const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));



interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
export enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}
export const InsuranceDetailsForm: React.FC<any> = (props) => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [isInsured, setIsInsured] = useState<boolean>(false);
    const [showDocs, setShowDocs] = useState<boolean>(false)
    const [docData, setDocData] = useState<any[]>([])
    const fileref = useRef<HTMLInputElement | any>(null)

    useEffect(() => {
        getDocData()
        if (props?.insuranceId !== 0) {
            const data = props?.insurdata?.filter((i: any) => i.InsuranceDetailId == props?.insuranceId)
            props?.setInsurDetails({ company: data[0]?.CompanyName, ins_amt: data[0]?.InsuranceAmount, currency: data[0]?.CurrencyId })
            props?.setStartDate(data[0]?.StartDate?.split("T")[0])
            props?.setEndDate(data[0]?.EndDate?.split("T")[0])
            setIsInsured(data[0]?.IsInsured)
        }

    }, [])

    const getDocData = () => {
        AxiosLayout.get(`/Common/GetDocumentDetails?EmployeeId=${props?.selectEmp}&DocTypeId=${DocumentType?.EmpInsurance}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setDocData(res?.data)
            }
        })
    }
    const onChangeInsureDetails = (e: any) => {
        props?.setInsurDetails({ ...props?.insurDetails, [e.target.name]: e.target.value })
    }
    const handleSave = async (e: any) => {
        e.preventDefault();
        props?.setErr(0)

        if (props?.insurDetails.company === "") {
            props?.setErr(7);
        }
        else if (props?.start_date === "") {
            props?.setErr(8);
        }
        else if (props?.end_date === "") {
            props?.setErr(9);
        }
        else if (props?.insurDetails.ins_amt === "") {
            props?.setErr(10);
        }
        else if (props?.insurDetails.currency === 0) {
            props?.setErr(11);
        }
        else {
            const payload = {
                insuranceid: Number(props?.insuranceId),
                familyId: props?.familyId,
                contractID: props?.contactId,
                relation: props?.familyDetails?.relation,
                userId: userId?.user,
                insured: isInsured,
                employeeID: Number(props?.selectEmp),
                insuranceCompName: props?.insurDetails.company,
                insuranceStartDate: props?.start_date,
                insuranceEndDate: props?.end_date,
                insuranceAmount: props?.insurDetails.ins_amt,
                currencyId: Number(props?.insurDetails.currency),
                // documentPath: "",
                // documentTypeId: 0,
                // uploadDocPath: "",
                // uploadDocTypeId: 0,
                // employeeEducations: [
                //     {
                //         educationId: 0,
                //         education: "",
                //         year: "",
                //         remarks: "",
                //         isEmpEducaton: true
                //     }
                // ]
            }

            AxiosLayout.post("/Employee/SaveUpdateEmpFamilyInsurance", payload).then((res: any) => {
                if (res.data.Status === 1) {
                    props?.setInsurDetails({ company: "", ins_amt: "", currency: 0 })
                    props?.setStartDate("")
                    props?.setEndDate("")
                    props?.getFamilyInsurData()
                    props?.setAlertMessage(res.data.Message)
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                }
            })
        }
    }

    const handleUploadFileButtonClick = () => {
        fileref.current?.click();
    };
    const handleFileChange = (e: any) => {
        const selectedFiles = Array.from(e.target.files);
        props?.setInsuFiles([...props.insufiles, ...selectedFiles]);
        // \\192.168.248.197\Share\VigneshG\Suribet\EMP_CONTRACT
    };
    return (
        <div className='p-3 pb-5 insudetheight insur-form-center'>

            <Row>
                <Col xs={12} >
                    <YsecInput label="Company" name="company" value={props?.insurDetails.company} onChange={onChangeInsureDetails} mandatory />
                    {props?.err === 7 && <label className='error'>Please Enter Company Name ...</label>}
                </Col>

                <Col xs={12} >
                    <YsecDatePicker key={props?.start_date}
                        name="start_date"
                        value={props?.start_date}
                        className="md"
                        label="Start Date"
                        error="test message"
                        onChange={(e) => props?.setStartDate(e.target.value)}
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="1000_Y"
                        ysecMaxDate="1000_Y"
                        mandatory
                    />
                    {props?.err === 8 && <label className='error'>Please Select Start Date...</label>}
                </Col>

                <Col xs={12} >
                    <YsecDatePicker key={props?.end_date}
                        name="end_date"
                        value={props?.end_date}
                        className="md"
                        label="End Date"
                        mandatory
                        error="test message"
                        onChange={(e) => props?.setEndDate(e.target.value)}
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="1000_Y"
                        ysecMaxDate="1000_Y"
                    />
                    {props?.err === 9 && <label className='error'>Please Select End Date...</label>}
                </Col>
                <Col xs={12} >
                    <YsecInput label="Insurance Amount" name="ins_amt" value={props?.insurDetails.ins_amt} onChange={onChangeInsureDetails} />
                    {props?.err === 10 && <label className='error'>Please Enter Insurance Amount...</label>}
                </Col>
                <Col xs={12} >
                    <YsecSelect
                        className="md"
                        name="currency"
                        objectNameKey="name"
                        objectValueKey="id"
                        data={[
                            { id: 0, name: "Select" },
                            ...props?.currencyData?.map((i: any) => ({
                                id: i.CurrencyId,
                                name: i.Currency
                            }))

                        ]}
                        value={props?.insurDetails.currency}
                        onChange={onChangeInsureDetails}
                        label="Currency"
                        mandatory
                    />
                    {props?.err === 11 && <label className='error'>Please Select Currency...</label>}
                </Col>

                <Col xs={12} sm={4}>
                    <YsecButton className='mt-3 w-100 cancel'>Scan Doc</YsecButton>
                </Col>
                <Col xs={12} sm={4}>
                    <YsecButton type="button" className='mt-3 w-100 cancel' onClick={handleUploadFileButtonClick}>
                        Upload Doc
                    </YsecButton>
                    <input
                        ref={fileref}
                        type="file"
                        // multiple
                        accept=".pdf,.doc,.docx"
                        style={{ display: 'none' }}
                        onChange={handleFileChange}
                    />
                </Col>
                <Col xs={12} sm={4}>
                    <YsecButton className='mt-3 w-100 cancel' type='button' onClick={() => { setShowDocs(true) }}>View Doc</YsecButton>
                </Col>

                <Col xs={12} className='d-flex mt-5 pt-5 justify-content-center justify-content-md-end'>
                    <YsecButton className='mt-3' type='button' onClick={handleSave}>Submit</YsecButton>
                    <YsecButton className='mt-3 ms-2 cancel' onClick={() => props.setOpen(false)}>Clear</YsecButton>
                </Col>
            </Row>
            {showDocs === true && <CustomViewDocModal open={showDocs} setOpen={setShowDocs} data={docData} />}
        </div>


    )
}