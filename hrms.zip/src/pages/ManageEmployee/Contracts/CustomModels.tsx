import { Col, Form, Modal, Row } from "react-bootstrap"
import React, { useEffect, useState } from 'react'
import AxiosLayout from "../../../apis/axios";


type Job = {
    ID: number;
    Description: string;
    IsActive?: any;
    DepartmentId: number;
    Department: string;
};
interface UserType {
    user: string;
    userName: string;
    companyId: Number;
    // Add more fields if you expect them
}
export enum ContractFormTypes {
    ContractType = 1,
    SubDepartment = 2,
    Position = 3,
    Insurance = 4,
    Pension = 5,
    SalaryType = 6,
    Bank = 7,
    ReportingTo = 8,
    PerformanceEvaluvation = 9,
    TeamLead = 10
}
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));

export const ContractModal: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [newIp, setNewIp] = useState<string>("")
    const [selectedJob, setSelectedJob] = useState<number>(0)
    const [chcekSelected, setCheckSelected] = useState<boolean>(true)
    const [position, setPosition] = useState<string>("")
    const [err, setErr] = useState<number>(0)
    const handlesubmit = async (e: any) => {
        e.preventDefault()
        if (newIp === "") {
            setErr(1)
        }
        else if (props?.addName === "Position" && position === "") {
            setErr(2)
        }
        else {
            if (props?.addName === "Contract Type") {
                const payload = {
                    refTableId: ContractFormTypes?.ContractType,
                    id: selectedJob,
                    description: newIp,
                    companyId: userId?.companyId,
                    isActive: chcekSelected,
                    userId: userId?.user,
                    code: 0,
                    hierachyId: 0,
                    hierachyMainId: 0,
                    sortOrder: 0
                }
                AxiosLayout.post("/Contract/ContractCommonDataTrans", payload).then((res: any) => {
                    if (res.data.Message?.includes("Success")) {
                        props?.setAlertMessage(res.data.Message)
                        props?.getContractCommonData()
                        handleClear()
                    }
                    else {
                        props?.setErrorMessage(res.data.Message)

                        props?.getContractCommonData()
                        handleClear()
                    }
                })
            }
            else if (props?.addName === "Sub Department" || props?.addName === "Position") {
                const payloadDept = {
                    referenceId: props?.addName === "Sub Department" ? ContractFormTypes?.SubDepartment : ContractFormTypes?.Position,
                    typeId: props?.addName === "Sub Department" ? 4 : 5,
                    description: props?.addName === "Sub Department" ? newIp : position,
                    companyId: userId?.companyId,
                    departmentId: props?.addName === "Sub Department" ? selectedJob : Number(newIp),
                    userId: userId?.user,
                }
                AxiosLayout.post("/Contract/HierachyTrans", payloadDept).then(async (res: any) => {
                    if (res.data.Message?.includes("Success")) {
                        props?.setAlertMessage(res.data.Message)
                        props?.setPositionsData([])
                        props?.setDepartmentdata([])
                        props?.setCommonData([])
                        props?.setData([])
                        props?.setPosData([])
                        props?.getContractCommonData()
                        handleClear()
                        props?.getMasterData()
                    }
                    else {
                        props?.setErrorMessage(res.data.Message)
                    }
                })
            }
        }
    }
    const handleClear = () => {
        setNewIp("")
        setSelectedJob(0)
        setCheckSelected(true)
        setPosition("")
        // props?.setAddName("")
        // props?.setAddType(0)
        props.setOpen(false)
    }

    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">{props?.title}</p>
                <button type="button" className="btn-close" onClick={() => {
                    props?.setAddName("")
                    handleClear()
                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                {props?.addName !== "Position" && <><YsecInput label={props?.addName} name="newIp" value={newIp} onChange={(e) => setNewIp(e.target.value)} />
                    {err === 1 && <label className='error'>Please Enter {props?.addName} ...</label>}</>}
                {props?.addName === "Contract Type" && <Form.Check className="mt-2 opening"
                    type="checkbox"
                    id="isActive"
                    label="IsActive"
                    checked={chcekSelected}
                    onChange={(e) => setCheckSelected(e.target.checked)}
                />}
                {props?.addName === "Position" && <Row>
                    <Col xs={12}>
                        <YsecSelect className="md"
                            name="newIp"
                            objectNameKey="Name"
                            objectValueKey="id"
                            data={[
                                { id: 0, Name: "Select" },
                                ...props?.data?.map((i: any) => ({
                                    id: i?.DepartmentId,
                                    Name: i?.Department
                                }))
                            ]}

                            value={newIp}
                            onChange={(e) => setNewIp(e.target.value)}
                            label="Department"
                            mandatory
                        />
                        {err === 1 && <label className='error'>Please Select Sub Department ...</label>}
                    </Col>
                    <Col xs={12} className="mt-2">
                        <YsecInput label="Position" name="newIp" value={position} onChange={(e) => setPosition(e.target.value)} mandatory />
                        {err === 2 && <label className='error'>Please Enter Position ...</label>}
                    </Col>
                </Row>}
                <div className="d-flex slign-itemd-center justify-content-end mt-3">
                    <YsecButton className="ms-1 me-1" type="button" onClick={(e: any) => {
                        handlesubmit(e)
                    }} >Save</YsecButton>
                    <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
                </div>
            </Modal.Body>
            <Modal.Body className="modaltable">
                <div className="katableee">
                    <table>
                        <tr >
                            <th>Description</th>
                        </tr>
                        {props?.addName === "Contract Type" && <>
                            {props?.data?.map((i: Job) => (
                                <tr key={i?.ID} onClick={() => {
                                    setNewIp(i?.Description)
                                    setSelectedJob(i?.ID)
                                    setCheckSelected(i?.IsActive)
                                }}>
                                    <td>{i?.Description}</td>
                                </tr>
                            ))}
                        </>}
                        {props?.addName === "Sub Department" && <>
                            {props?.data?.map((i: Job) => (
                                <tr key={i?.DepartmentId} onClick={() => {
                                    setNewIp(i?.Department)
                                    setSelectedJob(i?.DepartmentId)
                                }}>
                                    <td>{i?.Department}</td>
                                </tr>
                            ))}
                        </>}
                        {props?.addName === "Position" && <>
                            {props?.posData?.filter((j: any) => j.DepartmentId == Number(newIp)).map((i: any) => (
                                <tr key={i?.PostionId} onClick={() => {
                                    setPosition(i?.Position)
                                    setSelectedJob(i?.PostionId)
                                }}>
                                    <td>{i?.Position}</td>
                                </tr>
                            ))}
                        </>}
                    </table>
                </div>
            </Modal.Body>
        </Modal>
    )
}

export const InsuranceModal: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [insurId, setInsurId] = useState<number>(0)
    const [desc, setDesc] = useState<string>("")
    const [levelId, setLevelId] = useState<number>(0)
    const [doctor, setDoctor] = useState<number>(0)
    const [empContr, setEmpContr] = useState<number>(0)
    const [comContr, setCompContr] = useState<number>(0)
    const [isActive, setIsActive] = useState<boolean>(true)
    const [err, setErr] = useState<number>(0)

    const handleClear = () => {
        setDesc("")
        setLevelId(0)
        setDoctor(0)
        setEmpContr(0)
        setCompContr(0)
        setInsurId(0)
        setIsActive(true)
    }
    const handleSubmit = async (e: any) => {
        e.preventDefault()
        if (desc == "") {
            setErr(1)
        }
        else if (levelId == 0) {
            setErr(2)
        }
        else if (doctor == 0) {
            setErr(3)
        }

        else {
            const payload2 = {
                refTableId: ContractFormTypes?.Insurance,
                insuranceId: insurId,
                description: desc,
                insuranceLevelId: levelId,
                doctorId: doctor,
                amount: empContr,
                isActive: isActive,
                insuranceAmtByComp: comContr,
                locationId: props?.locationId,
                userId: userId?.user
            }

            AxiosLayout.post("/Contract/InsuranceTrans", payload2).then((res: any) => {
                if (res.data.Message?.includes("Success")) {
                    props?.setAlertMessage(res.data.Message)
                    props?.setInsurData([])
                    props?.setEmpInsurances([])
                    props?.setDoctors([])
                    props?.getInsurGenData()
                    props?.getInsurData()
                    props?.getContractCommonData()
                    handleClear()
                    props.setOpen(false)
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                    handleClear()
                }
            })
        }
    }

    return (
        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">{props?.title}</p>
                <button type="button" className="btn-close" onClick={() => {
                    handleClear()
                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <Row>
                    <Col xs={12} sm={6}>
                        <YsecInput name="desc" value={desc} label="Insurance Description" mandatory onChange={(e: any) => setDesc(e.target.value)} />
                        {err === 1 && <label className='error'>Please Enter Insurance Description...</label>}
                    </Col>
                    <Col xs={12} sm={6}>
                        <YsecSelect className="md"
                            name="levelId"
                            objectNameKey="Name"
                            objectValueKey="id"
                            data={[
                                { id: 0, Name: "Select" },
                                ...props?.empInsurance?.map((i: any) => ({
                                    id: i?.InsuranceId,
                                    Name: i?.Description
                                }))
                            ]}
                            value={levelId}
                            onChange={(e: any) => setLevelId(e.target.value)}
                            label="Insurance Level"
                            mandatory
                        />
                        {err === 2 && <label className='error'>Please Select Insurance Level...</label>}
                    </Col>
                    <Col xs={12} sm={6}>
                        <YsecSelect className="md"
                            name="doctor"
                            objectNameKey="Name"
                            objectValueKey="id"
                            data={[
                                { id: 0, Name: "Select" },
                                ...props?.doctors?.map((i: any) => ({
                                    id: i?.DoctorId,
                                    Name: i?.FullName
                                }))
                            ]}
                            value={doctor}
                            onChange={(e: any) => setDoctor(e.target.value)}
                            label="Doctor"
                            mandatory
                        />
                        {err === 3 && <label className='error'>Please Select Doctor...</label>}
                    </Col>
                    <Col xs={12} sm={6}>
                        <YsecInput name="empContr" value={empContr} label="Employee Contribution" mandatory onChange={(e: any) => setEmpContr(e.target.value)} />
                    </Col>
                    <Col xs={12} sm={6}>
                        <YsecInput name="comContr" value={comContr} label="Company Contribution" mandatory onChange={(e: any) => setCompContr(e.target.value)} />
                    </Col>
                    <Col xs={12} sm={6}>
                        <Form.Check className="mt-2 opening"
                            type="checkbox"
                            id="isActive"
                            label="IsActive"
                            checked={isActive}
                            onChange={(e) => setIsActive(e.target.checked)}
                        />
                    </Col>
                </Row>
                <div className="d-flex slign-itemd-center justify-content-end mt-3">
                    <YsecButton className="ms-1 me-1" type="button" onClick={handleSubmit} >Save</YsecButton>
                    <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
                </div>
            </Modal.Body>
            <Modal.Body className="modaltable">
                <div className="katableee">
                    <table>
                        <tr >
                            <th>Insurance Description</th>
                            <th>Employee Contribution</th>
                            <th>Company Contribution</th>
                            <th>IsActive</th>
                        </tr>
                        {props?.data?.map((i: any) => (
                            <tr key={i?.InsuranceId} onClick={() => {
                                setDesc(i?.Description)
                                setLevelId(i?.InsuranceLevelId)
                                setDoctor(i?.DoctorId)
                                setEmpContr(i?.Amount)
                                setCompContr(i?.InsuranceAmtByComp)
                                setIsActive(i?.IsActive)
                                setInsurId(i?.InsuranceId)
                            }}>
                                <td>{i?.Description}</td>
                                <td>{i?.Amount}</td>
                                <td>{i?.InsuranceAmtByComp}</td>
                                <td> <Form.Check className="mt-2 opening"
                                    type="checkbox"
                                    checked={i?.IsActive === true}
                                /></td>
                            </tr>
                        ))}
                    </table>
                </div>
            </Modal.Body>
        </Modal>
    )
}

export const PensionModel: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [details, setDetails] = useState<any>({ pen_name: "", pen_prime: 0, pen_percentage: "", werkgerversedeel: "", werkenmersdeel: "" })
    const [isActive, setIsActive] = useState<boolean>(true)
    const [pensper, setPenPer] = useState<any>(0)
    const [werkg, setWerkG] = useState<any>(0)
    const [werkn, setWerkN] = useState<any>(0)
    const [err, setErr] = useState<number>(0)
    const [selectedRow, setSelectedRow] = useState<number>(0)
    const [totalamt, setTotalAmt] = useState<number>(0)
    useEffect(() => {
        setDetails({ pen_name: "Pension Premie", pen_percentage: props?.pensionPerc[0]?.PensionPercentage, werkgerversedeel: props?.pensionPerc[0]?.WerkgeversdeelPercentage, werkenmersdeel: props?.pensionPerc[0]?.WerknemersdeelPercentage })
    }, [])
    useEffect(() => {
        if (details?.pen_prime !== 0 && details?.pen_prime !== undefined) {
            const dataaa = props?.grossSal?.filter((i: any) => i.Id == details?.pen_prime)
            setTotalAmt(dataaa[0]?.GrossSalary)
            const penperr = Math.round((dataaa[0]?.GrossSalary * (details?.pen_percentage / 100)) * 100) / 100
            setPenPer(penperr)
            setWerkG(Math.round((penperr * (details?.werkgerversedeel / 100)) * 100) / 100)
            setWerkN(Math.round((penperr * (details?.werkenmersdeel / 100)) * 100) / 100)
            setDetails({ ...details, pen_name: "Pension Premie" + "-" + (Math.round((penperr * (details?.werkenmersdeel / 100)) * 100) / 100).toFixed(2) })
        }
    }, [details?.pen_prime])
    const onChange = async (e: any) => {
        setDetails({ ...details, [e.target.name]: e.target.value })
    }
    const handleClear = () => {
        setDetails({ pen_name: "", pen_prime: 0, pen_percentage: "", werkgerversedeel: "", werkenmersdeel: "" })
        setPenPer(0)
        setWerkG(0)
        setWerkN(0)
        setSelectedRow(0)
        setTotalAmt(0)
    }
    const handleSubmit = async (e: any) => {
        e.preventDefault()
        if (details?.pension_premium == 0) {
            setErr(1)
        }
        else {
            const payloadpen = {
                pensionpremieId: selectedRow,
                description: details?.pen_name,
                totalAmmount: totalamt,
                empContributionper: details?.werkgerversedeel,
                compContributionPer: details?.werkenmersdeel,
                empContributionAmount: werkg,
                compContributionAmount: werkn,
                pensionPercentage: details?.pen_percentage,
                pensionAmount: pensper,
                isActive: isActive,
                companyId: userId?.companyId,
                userId: userId?.user,
                totalAmmountid: details?.pen_prime
            }
            AxiosLayout.post("/Contract/PensionTrans", payloadpen).then((res: any) => {
                if (res?.data?.Message?.includes("Success")) {
                    setDetails({ pen_name: "", pen_prime: 0, pen_percentage: "", werkgerversedeel: "", werkenmersdeel: "" })
                    setPenPer(0)
                    setWerkG(0)
                    setWerkN(0)
                    setSelectedRow(0)
                    setTotalAmt(0)
                    props?.setCommonData([])
                    props?.getPensionPrimeData()
                    props?.getContractCommonData()
                    props?.setAlertMessage(res.data.Message)
                    props.setOpen(false)
                }
                else {
                    props?.setErrorMessage(res.data.Message)
                }
            })
        }
    }

    return (
        <Modal
            {...props}
            size="xl"
            aria-labelledby="contained-modal-title-vcenter"
            centered
            show={props.open} onHide={() => {
                props.setOpen(false)
            }}
        >
            <Modal.Header>
                <p className="modal-title opening" id="exampleModalLabel">Pension</p>
                <button type="button" className="btn-close" onClick={() => {
                    handleClear()
                    props.setOpen(false)
                }} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <Row>
                    <Col xs={12} sm={6}>
                        <YsecInput label="PensioenPrimieName" mandatory name="pen_name" value={details?.pen_name} disabled />
                    </Col>
                    <Col xs={12} sm={6}>
                        <YsecSelect className="md"
                            name="pen_prime"
                            objectNameKey="Name"
                            objectValueKey="id"
                            data={[
                                { id: 0, Name: "Select" },
                                ...props?.grossSal?.map((i: any) => ({
                                    id: i?.Id,
                                    Name: i?.GrossSalary
                                }))
                            ]}
                            value={details.pen_prime}
                            onChange={(e: any) => {
                                const dataaa = props?.grossSal?.filter((i: any) => i.Id == e.target.value)

                                const setDd = props?.penSionPrimeData?.filter((i: any) => i?.TotalAmount == dataaa[0]?.GrossSalary)

                                setSelectedRow(setDd[0]?.PensionpremieId)
                                setIsActive(setDd[0]?.IsActive)
                                onChange(e)
                            }}
                            label="PensioenPremie"
                            mandatory
                        />
                        {err === 3 && <label className='error'>Please Select PensioenPremie...</label>}

                    </Col>
                    <Col xs={9}>
                        <YsecInput label="Pensioen (in % )" mandatory name="pen_percentage" value={details?.pen_percentage} disabled />
                    </Col>
                    <Col xs={3} className="d-flex align-items-end justify-content-center">
                        <span className="w-100 pen1">{pensper?.toFixed(2)}</span>
                    </Col>
                    <Col xs={9}>
                        <YsecInput label="Werkgeversdeel (in % )" mandatory name="werkgerversedeel" value={details?.werkgerversedeel} disabled />
                    </Col>
                    <Col xs={3} className="d-flex align-items-end justify-content-center">
                        <span className="w-100 pen2">{werkg?.toFixed(2)}</span>
                    </Col>
                    <Col xs={9}>
                        <YsecInput label="Werknemersdeel (in % )" mandatory name="werkenmersdeel" value={details?.werkenmersdeel} disabled />
                    </Col>
                    <Col xs={3} className="d-flex align-items-end justify-content-center">
                        <span className="w-100 pen3">{werkn?.toFixed(2)}</span>
                    </Col>
                    <Col xs={12}>
                        <Form.Check className="mt-2 opening"
                            type="checkbox"
                            id="isActive"
                            label="IsActive"
                            checked={isActive}
                            onChange={(e) => setIsActive(e.target.checked)}
                        />
                    </Col>
                    <Col xs={12}>
                        <div className="d-flex slign-itemd-center justify-content-end mt-1">
                            <YsecButton className="ms-1 me-1" type="button" onClick={handleSubmit}  >Save</YsecButton>
                            <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
                        </div>
                    </Col>
                </Row>
            </Modal.Body>
            <Modal.Body className="modaltable">
                <div className="katableee pensiontable">
                    <table>
                        <thead>
                            <tr >
                                <th>Pension Premie Name</th>
                                <th>Total Amnt</th>
                                <th>Pensioen Amnt</th>
                                <th>Werknem Amnt</th>
                                <th>Werkgev Amnt</th>
                                <th>IsActive</th>
                            </tr>
                        </thead>
                        <tbody>
                            {props?.penSionPrimeData?.map((i: any) => (
                                <tr key={i?.PensionpremieId} onClick={() => {
                                    setSelectedRow(i?.PensionpremieId)
                                    const ddata = props?.grossSal?.filter((j: any) => Number(j?.GrossSalary) === Number(i?.TotalAmount))
                                    setDetails({ ...details, pen_prime: ddata[0]?.Id })
                                    setIsActive(i?.IsActive)
                                }}>
                                    <td>{i?.Description}</td>
                                    <td>{i?.TotalAmount}</td>
                                    <td>{i?.PensionAmount}</td>
                                    <td>{i?.EmpContributionAmount}</td>
                                    <td>{i?.CompContrinutionAmount}</td>
                                    <td> <Form.Check className="mt-2 opening"
                                        type="checkbox"
                                        checked={i?.IsActive === true}
                                    /></td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </Modal.Body>
        </Modal>
    )
}