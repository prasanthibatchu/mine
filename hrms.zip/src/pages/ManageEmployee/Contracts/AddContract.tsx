import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Row } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import { ContractModal, InsuranceModal, PensionModel } from './CustomModels';
import { BankModal } from './BankModel';
import { CustomViewDocModal } from '../CustomDocViewModal';

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
export enum RefTableIDs {
    Select = 0,
    Relation = 1,
    MaritalStatus = 2,
    PenaltyTypes = 3,
    ExtraPaymentTypes = 4,
    PersCmntTypes = 5,
    Qualification = 6,
    OverTimeTypes = 7,
}
export enum ContractFormTypes {
    ContractType = 1,
    SubDepartment = 2,
    Position = 3,
    Insurance = 4,
    Pension = 5,
    SalaryType = 6,
    Bank = 7,
    ReportingTo = 8,
    PerformanceEvaluvation = 9,
    TeamLead = 10
}
export enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecMultipleCheck = React.lazy(() => import("Layout/YsecMultipleCheck2"))

export const AddContract: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [open, setOpen] = useState<boolean>(false)
    const [addName, setAddName] = useState<string>("")
    const [titledialog, setTitleDialog] = useState<string>("")
    const [addType, setAddType] = useState<number>(0)
    const [customData, setCustomData] = useState<any[]>([])
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [openInsur, setOpenInsur] = useState<boolean>(false)
    const fileref = useRef<HTMLInputElement | any>(null)
    const [data, setData] = useState<any[]>([])
    const [posData, setPosData] = useState<any[]>([])
    const [openBank, setOpenBank] = useState<boolean>(false)
    const [openPen, setOpenPen] = useState<boolean>(false)
    const [commonData, setCommonData] = useState<any>([])
    const [insurData, setInsurData] = useState<any[]>([])
    const [empInsurance, setEmpInsurances] = useState<any[]>([])
    const [doctors, setDoctors] = useState<any[]>([])
    const [docData, setDocData] = useState<any[]>([])
    const [showDocs, setShowDocs] = useState<boolean>(false)
    const [userData, setUserData] = useState<any>({ contract_type: 0, insurance: 0, pension_premium: 0, company: 0, dept: 0, position: 0, no_months: 0, no_days: 0, nis: "", tin: "", salary: "", payment: "", salary_per_hr: "", currency: 0, salary_type: 0, ac_num: "", remarks: "", prob_period: 0, exc_rate: "", usd_salary: "", month_gross: "", bank: 0, blacklist: false, reason: "", enter_txt: "", brandd: 0, annual_salary: "", vpf: "", report_to: 0, team_lead: 0, uanno: "", nominee: "" })
    const [hod, setHod] = useState<any[]>([])
    const [verify_txt, setverifyTxt] = useState<any>(null)
    const [start_date, setStartDate] = useState<string>("")
    const [end_date, setEndDate] = useState<string>("")
    const [term_date, setTermDate] = useState<string>("")
    const [prob_end, setProbEnd] = useState<string>("")
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [currencyData, setCurrencyData] = useState<any[]>([])
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [files, setFiles] = useState<any[]>([]);
    const [penSionPrimeData, setPensionPrimeData] = useState<any[]>([])
    const [pensionPerc, setPensionPerc] = useState<any[]>([])
    const [grossSal, setGrosSal] = useState<any[]>([])
    const [err, setErr] = useState<number>(0)
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        if (Number(props?.contractId) !== 0)
            AxiosLayout.get(`/Contract/GetContract?ContractID=${props?.contractId}&UserId=${userId?.user}`).then((res: any) => {
                if (res.status === 200) {
                    setUserData({
                        contract_type: res.data?.ContractTypeId,
                        insurance: res.data?.InsuranceId,
                        pension_premium: res.data?.PensionpremieId,
                        company: res.data?.CompanyId,
                        dept: res.data?.DepartmentId,
                        position: res.data?.PositionId,
                        //  no_months: res.data?.,
                        //  no_days: res.data?.,
                        nis: res.data?.NISNo,
                        tin: res.data?.TINNo,
                        salary: res.data?.Salary,
                        payment: res.data?.PaymentPercentage,
                        salary_per_hr: res.data?.SalaryPerHour,
                        currency: res.data?.CurrencyId,
                        salary_type: res.data?.SalaryTypeId,
                        ac_num: res.data?.BankAccountNumber,
                        remarks: res.data?.Remarks,
                        prob_period: res.data?.ProbationPeriod,
                        prob_end: res.data?.ProbationEndDate,
                        exc_rate: res.data?.ExRate,
                        usd_salary: res.data?.USDSalary,
                        month_gross: res.data?.GrossSalary,
                        bank: res.data?.BankId,
                        blacklist: res.data?.BlackList,
                        reason: res.data?.TerminationReason,
                        brandd: 0,
                        annual_salary: res?.data?.Salary,
                        vpf: res?.data?.VPF,
                        report_to: res?.data?.ReportingTo,
                        team_lead: res?.data?.TeamLead,
                        uanno: res?.data?.UANNo,
                        nominee: res?.data?.Nominee
                    })
                    setStartDate(res.data?.Startdate)
                    setEndDate(res.data?.EndDate)
                    setTermDate(res.data?.TerminationDate)                 
                    let hodArr = res.data?.ReportingTo?.split(",") || [];
                    hodArr = hodArr
                        .map((v: string) => Number(v))
                        .filter((v: number) => !isNaN(v) && v !== 0);
                 
                    setHod(hodArr);
                }

            })
    }, [])
    useEffect(() => {
        getMasterData()
        getContractCommonData()
        getInsurData()
        getInsurGenData()
        getDocData()
        generateVerifyText()
        getPensionPrimeData()
    }, [])

    const getMasterData = () => {
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.CurrencyList !== null) {
                    setCurrencyData(res.data.CurrencyList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }
            }
        })
    }
    const generateVerifyText = () => {
        const randomNum = Array.from({ length: 10 }, () => Math.floor(Math.random() * 10)).join("");
        setverifyTxt(randomNum)
    }
    useEffect(() => { getContractCommonData() }, [props?.selectedBrand])
    const getContractCommonData = () => {
        AxiosLayout.get(`/Contract/GetContractCommonData?BrandId=${props?.selectedBrand}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setCommonData(res?.data)
            }
        })
    }
    const getInsurData = () => {
        AxiosLayout.get(`/Contract/GetInsuranceDetails?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setInsurData(res.data)
            }
        })
    }

    const getInsurGenData = () => {
        AxiosLayout.get(`/Contract/GetInuranceGeneralData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setEmpInsurances(res.data?.Empinsurances)
                setDoctors(res.data?.Doctors)
            }
        })
    }
    const getDocData = () => {
        AxiosLayout.get(`/Common/GetDocumentDetails?EmployeeId=${props?.selectEmp}&DocTypeId=${DocumentType?.EmpContract}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setDocData(res?.data)
            }
        })
    }
    useEffect(() => {
        if (addType !== 0) {
            setOpen(false)
            getGeneralData()
        }
    }, [addType])

    const getGeneralData = () => {
        AxiosLayout.get(`/Employee/GetGeneralDataTypes?tableid=${addType}&CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setCustomData(res.data)
                setOpen(true)
            }

        })
    }
    const getPensionPrimeData = () => {
        AxiosLayout.get(`/Contract/GetPensionPremieDetails?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setPensionPrimeData(res.data?.Table)
                setPensionPerc(res?.data?.Table1)
                setGrosSal(res?.data?.Table2)
            }
        })
    }
    const onChange = (e: any) => {
        const { name, value } = e.target
        setUserData({ ...userData, [name]: value })
    }

    const ContractTypeData = commonData?.filter((i: any) => i.RefTableId === ContractFormTypes?.ContractType)
    const Insurances = commonData?.filter((i: any) => i.RefTableId === ContractFormTypes?.Insurance)
    const Pension_premium = commonData?.filter((i: any) => i.RefTableId === ContractFormTypes?.Pension)
    const SalaryTypeData = commonData?.filter((i: any) => i.RefTableId === ContractFormTypes?.SalaryType)
    const Bankdata = commonData?.filter((i: any) => i.RefTableId === ContractFormTypes?.Bank)
    const HodData = commonData?.filter((i: any) => i.RefTableId === ContractFormTypes?.ReportingTo)

    const handleUploadFileButtonClick = () => {
        fileref.current?.click();
    };

    const handleFileChange = (e: any) => {
        const selectedFiles = Array.from(e.target.files);
        setFiles([...props.files, ...selectedFiles]);
        // \\192.168.248.197\Share\VigneshG\Suribet\EMP_CONTRACT
    };
    const handleSelectBrand = (value: any) => {

        const desc = brandData.filter(i => i.BrandId === Number(value))
        props?.setSelectedBrand(desc[0]?.BrandId)
        props?.setLocationId(desc[0]?.LocationId)
    }
    const getMasterData2 = () => {
        const timer = setTimeout(() => {
            AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
            ).then((res: any) => {
                if (res.status === 200) {
                    if (res.data?.DepartmentList !== null) {
                        setDepartmentdata(res.data.DepartmentList)
                    }
                    if (res.data.PositionList !== null) {
                        setPositionsData(res.data.PositionList)
                    }
                }
            })
        }, 4000);
        return () => clearTimeout(timer);
    }


    const handleValidation = async (e: any) => {
        e.preventDefault();
        setErr(0)
        if (userData.contract_type == 0) {
            setErr(1)
        }
        else if (userData.insurance == 0) {
            setErr(2)
        } else if (userData.company == 0) {
            setErr(3)
        }
        else if (props?.selectBrand == 0) {
            setErr(4)
        } else if (userData.dept == 0) {
            setErr(5)
        } else if (userData.position == 0) {
            setErr(6)
        } else if (start_date == "") {
            setErr(7)
        }
        else if (userData.salary == "") {
            setErr(8)
        } else if (userData.currency == 0) {
            setErr(9)
        }
        else if (userData.salary_type == "") {
            setErr(10)
        }

        else if (userData.enter_txt == "" || userData?.enter_txt == undefined) {
            setErr(11)
        }
        else if (userData.enter_txt !== verify_txt) {

            setErr(12)
        }
        else {
            const payload = {
                contractId: props?.contractId,
                employeeId: Number(props?.selectEmp),
                contractTypeId: userData.contract_type,
                startdate: start_date,
                endDate: end_date,
                duration: 0,
                hierachyId: selectedBrand,
                companyId: userId?.companyId,
                locationId: props?.locationId,
                insuranceId: userData.insurance,
                terminationDate: term_date,
                terminationReason: userData.reason,
                terminationReasonOld: "",
                currencyId: userData.currency,
                salary: userData.salary,
                departmentId: userData.dept,
                positionId: userData.position,
                isActive: true,
                remarks: userData.remarks,
                probationPeriod: userData.prob_period,
                probationEndDate: prob_end,
                salaryTypeId: userData.salary_type,
                signed: true,
                pensionpremieId: userData?.pension_premium,
                blackList: userData?.blacklist,
                blackListReason: "",
                nisNo: userData.nis,
                tinNo: userData.tin,
                salaryPerHour: userData.salary_per_hr,
                paymentPercentage: userData?.payment,
                exRate: userData.exc_rate,
                pensionSystemTypeId: 0,
                pensionCompanyId: 0,
                lunch: 0,
                allowance: 0,
                transport: 0,
                reportingTo: userData?.report_to,
                teamLead: userData?.team_lead,
                usdSalary: userData.usd_salary,
                ltBonus: 0,
                bankAccountNumber: userData.ac_num,
                bankId: userData.bank,
                rotaHours: 0,
                saturdayRotaHrs: 0,
                saturdayLunchHrs: 0,
                totalLunchHrs: 0,
                workingHrs: 0,
                satworkingHrs: 0,
                totalHours: 0,
                grossSalary: userData.month_gross,
                userId: userId?.user,
                documentPath: "",
                uploadDocPath: "",
                uploadDoctypeId: DocumentType?.EmpContract,
                vpf: userData.vpf,
                uanNo: userData.uanno,
                nominee: userData.nominee,
            }
            AxiosLayout.post("/Contract/EmployeeContractsTrans", payload).then((res: any) => {
                if (res.data.Status === 1) {
                    handleClear()
                    getMasterData()
                    props?.getData()
                    generateVerifyText()
                    getPensionPrimeData()
                    setAlertMessage(res.data.Message)
                }
                else {
                    setErrorMessage(res.data.Message)
                }
            })
        }
    }

    const handleClear = () => {
        setUserData({ contract_type: 0, insurance: 0, pension_premium: 0, company: 0, dept: 0, position: 0, no_months: 0, no_days: 0, nis: "", tin: "", salary: "", payment: "", salary_per_hr: "", currency: 0, salary_type: 0, ac_num: "", remarks: "", prob_period: 0, exc_rate: "", usd_salary: "", month_gross: "", bank: 0, blacklist: false, reason: "", enter_txt: "", brandd: 0, annual_salary: "", vpf: "", report_to: 0, team_lead: 0, uanno: "", nominee: "" })
        setStartDate("")
        setEndDate("")
        setOpen(false)
    }
    return (
        <div className="p-1">
            <React.Suspense>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                {open === true && (
                    <ContractModal open={open} setOpen={setOpen} title={titledialog} addName={addName} setAddName={setAddName} data={data} getJobCommonData={getGeneralData} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} posData={posData} getContractCommonData={getContractCommonData} getMasterData={getMasterData2} setPositionsData={setPositionsData} setDepartmentdata={setDepartmentdata} setCommonData={setCommonData} setData={setData} setPosData={setPosData} locationId={props?.locationId} />

                )}

                {openInsur === true && (
                    <InsuranceModal open={openInsur} setOpen={setOpenInsur} title={titledialog} data={data} getJobCommonData={getGeneralData} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} empInsurance={empInsurance} doctors={doctors} getInsurGenData={getInsurGenData} getInsurData={getInsurData} getContractCommonData={getContractCommonData} setInsurData={setInsurData} setEmpInsurances={setEmpInsurances} setDoctors={setDoctors} locationId={props?.locationId} />

                )}

                {openBank === true && (
                    <BankModal open={openBank} setOpen={setOpenBank} data={data} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} setCommonData={setCommonData} getContractCommonData={getContractCommonData} locationId={props?.locationId} />

                )}

                {openPen === true && <PensionModel data={data} open={openPen} setOpen={setOpenPen} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} pensionPerc={pensionPerc} grossSal={grossSal} penSionPrimeData={penSionPrimeData} getPensionPrimeData={getPensionPrimeData} setCommonData={setCommonData} getContractCommonData={getContractCommonData} locationId={props?.locationId} />}

                <div className="p-2 m-1 formsheight">
                    <Card>
                        <Card.Header><p className='opening mb-0'>Contracts</p></Card.Header>
                        <Card.Body>
                            <form>
                                <Row>
                                    <Col xs={12} md={6} lg={3} className='d-flex'>
                                        <div className='jobselect me-1'>
                                            <YsecSelect className="md"
                                                name="contract_type"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...ContractTypeData?.map((i: any) => ({
                                                        id: i?.ID,
                                                        Name: i?.Description
                                                    }))
                                                ]}
                                                value={userData.contract_type}
                                                onChange={onChange}
                                                label="Contract Type"
                                                mandatory
                                            />
                                            {err === 1 && <label className='error'>Select Contract Type..</label>}
                                        </div>
                                        <div className='mt-4'>
                                            <YsecButton type='button' onClick={() => {
                                                setTitleDialog("Contract Type")
                                                setAddName("Contract Type")
                                                setData(ContractTypeData)
                                                setOpen(true)
                                            }} className='cancel' >
                                                <YsecFont className='yf-plus-add' />
                                            </YsecButton></div>
                                    </Col>
                                    <Col xs={12} md={6} lg={3} className='d-flex'>
                                        <div className='jobselect me-1'>
                                            <YsecSelect className="md"
                                                name="insurance"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...Insurances?.map((i: any) => ({
                                                        id: i?.ID,
                                                        Name: i?.Description
                                                    }))
                                                ]}
                                                value={userData.insurance}
                                                onChange={onChange}
                                                label="Insurance"
                                                mandatory
                                            />
                                            {err === 2 && <label className='error'>Select Insurance..</label>}
                                        </div>
                                        <div className='mt-4'>
                                            <YsecButton type='button' className='cancel' onClick={() => {
                                                setTitleDialog("Insurance")
                                                setData(insurData)
                                                setOpenInsur(true)
                                            }}  >
                                                <YsecFont className='yf-plus-add' />
                                            </YsecButton></div>
                                    </Col>
                                    <Col xs={12} md={6} lg={3} className='d-flex'>
                                        <div className='jobselect me-1'>
                                            <YsecSelect className="md"
                                                name="pension_premium"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...Pension_premium?.map((i: any) => ({
                                                        id: i?.ID,
                                                        Name: i?.Description
                                                    }))
                                                ]}
                                                value={userData.pension_premium}
                                                onChange={onChange}
                                                label="Pension Premium"
                                            />
                                        </div>
                                        <div className='mt-4'>
                                            <YsecButton type='button' className='cancel' onClick={() => {

                                                setData(positionsData)
                                                setOpenPen(true)
                                            }}>
                                                <YsecFont className='yf-plus-add' />
                                            </YsecButton></div>
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecSelect className="md"
                                            name="company"
                                            objectNameKey="Name"
                                            objectValueKey="id"
                                            data={[
                                                { id: 0, Name: "Select Company" },
                                                { id: userId?.companyId, Name: userId?.company },

                                            ]}
                                            value={userData.company}
                                            onChange={onChange}
                                            label="Company"
                                            mandatory
                                        />
                                        {err === 3 && <label className='error'>Select Company..</label>}

                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecSelect name="selectBrand"
                                            objectNameKey="BrandName"
                                            objectValueKey="BrandId"
                                            data={[
                                                { BrandId: 0, BrandName: "Select" },
                                                ...brandData?.map((i: any) => ({
                                                    BrandId: i?.BrandId,
                                                    BrandName: i?.Brand
                                                }))
                                            ]}
                                            value={props?.selectBrand}
                                            label="Brand" mandatory
                                            onChange={handleSelectBrand}
                                        />

                                        {err === 4 && <label className='error'>Select Brand..</label>}
                                    </Col>
                                    <Col xs={12} md={6} lg={3} className='d-flex'>
                                        <div className='jobselect me-1'>
                                            <YsecSelect className="md"
                                                name="dept"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...departmentData?.map((i: any) => ({
                                                        id: i?.DepartmentId,
                                                        Name: i?.Department
                                                    }))
                                                ]}

                                                value={userData.dept}
                                                onChange={onChange}
                                                label="Department"
                                                mandatory
                                            />
                                            {err === 5 && <label className='error'>Select Sub Department..</label>}
                                        </div>
                                        <div className='mt-4'>
                                            <YsecButton type='button' className='cancel' onClick={() => {
                                                setTitleDialog("Sub Department")
                                                setAddName("Sub Department")
                                                setData(departmentData)
                                                setOpen(true)
                                            }} >
                                                <YsecFont className='yf-plus-add' />
                                            </YsecButton></div>
                                    </Col>

                                    <Col xs={12} md={6} lg={3} className='d-flex'>
                                        <div className='jobselect me-1'>
                                            <YsecSelect className="md"
                                                name="position"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...positionsData?.filter((j: any) => j.DepartmentId == userData.dept)?.map((i: any) => ({
                                                        id: i?.PostionId,
                                                        Name: i?.Position
                                                    }))

                                                ]}
                                                value={userData.position}
                                                onChange={onChange}
                                                label="Position"
                                                mandatory
                                            />
                                            {err === 6 && <label className='error'>Select Position..</label>}
                                        </div>
                                        <div className='mt-4'>
                                            <YsecButton type='button' className='cancel' onClick={() => {
                                                setTitleDialog("Position")
                                                setAddName("Position")
                                                setData(departmentData)
                                                setPosData(positionsData)
                                                setOpen(true)
                                            }}  >
                                                <YsecFont className='yf-plus-add' />
                                            </YsecButton></div>
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecDatePicker
                                            name="start_date"
                                            value={start_date}
                                            className="md"
                                            placeholderText="Select Date"
                                            label="Start Date"
                                            mandatory
                                            error="test message"
                                            onChange={(e) => props.setStartDate(e.target.value)}
                                            placeholder="DD-MM-YYYY"
                                            ysecType="tab"
                                            ysecFormat="D-MM-YYYY"
                                            ysecMinDate="1000_Y"
                                            ysecMaxDate="1000_Y"
                                        />
                                        {err === 7 && <label className='error'>Select Start Date..</label>}

                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecDatePicker
                                            name="end_date"
                                            value={end_date}
                                            className="md"
                                            placeholderText="Select Date"
                                            label="End Date"
                                            error="test message"
                                            onChange={(e) => props.setEndDate(e.target.value)}
                                            placeholder="DD-MM-YYYY"
                                            ysecType="tab"
                                            ysecFormat="D-MM-YYYY"
                                            ysecMinDate="1000_Y"
                                            ysecMaxDate="1000_Y"
                                        />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecSelect className="md"
                                            name="prob_period"
                                            objectNameKey="Name"
                                            objectValueKey="id"
                                            data={[
                                                { id: 0, Name: "Select" },
                                                { id: 1, Name: "1" },
                                                { id: 2, Name: "2" },
                                                { id: 3, Name: "3" },
                                                { id: 4, Name: "4" },
                                                { id: 5, Name: "5" },
                                                { id: 6, Name: "6" }

                                            ]}
                                            value={userData.prob_period}
                                            onChange={onChange}
                                            label="Probation Period"
                                        />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecDatePicker
                                            name="prob_end"
                                            value={prob_end}
                                            className="md"
                                            placeholderText="Select Date"
                                            label="Probation End"
                                            error="test message"
                                            onChange={(e) => props.setProbEnd(e.target.value)}
                                            placeholder="DD-MM-YYYY"
                                            ysecType="tab"
                                            ysecFormat="D-MM-YYYY"
                                            ysecMinDate="1000_Y"
                                            ysecMaxDate="1000_Y"
                                        />



                                    </Col>
                                    <Col xs={12} md={6} lg={3}>

                                        <YsecInput type="number" placeholder="Enter No of Months" name="no_months" value={userData.no_months} onChange={onChange} label="No of Months" />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="number" placeholder="Enter No of Days" name="no_days" value={userData.no_days} onChange={onChange} label="No of Days" />

                                    </Col>

                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="text" placeholder="Enter Salary" name="salary" value={userData.salary} onChange={onChange} label="Salary" mandatory />
                                        {err === 8 && <label className='error'>Enter Salary..</label>}

                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="text" placeholder="Enter Payment" name="payment" value={userData.payment} onChange={onChange} label="Payment (%)" />
                                    </Col>

                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="text" placeholder="Enter Salary" name="salary_per_hr" value={userData.salary_per_hr} onChange={onChange} label="Salary (Per Hour)" />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>



                                        <YsecSelect
                                            className="md"
                                            name="currency"
                                            objectNameKey="title_name"
                                            objectValueKey="title_id"
                                            data={[
                                                { title_id: 0, title_name: "Select" },
                                                ...currencyData.map((i: any) => ({
                                                    title_id: i.CurrencyId,
                                                    title_name: i.Currency
                                                }))

                                            ]}
                                            value={userData?.currency}
                                            onChange={onChange}
                                            label="Currency"
                                            mandatory
                                        />
                                        {err === 9 && <label className='error'>Select Currency..</label>}
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="text" placeholder="Enter Exchange Rate" name="exc_rate" value={userData.exc_rate} onChange={onChange} label="Exchange Rate" />


                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecSelect className="md"
                                            name="salary_type"
                                            objectNameKey="Name"
                                            objectValueKey="id"
                                            data={[
                                                { id: 0, Name: "Select" },
                                                ...SalaryTypeData?.map((i: any) => ({
                                                    id: i?.ID,
                                                    Name: i?.Description
                                                }))
                                            ]}

                                            value={userData.salary_type}
                                            onChange={onChange}
                                            label="Salary Type"
                                            mandatory
                                        />
                                        {err === 10 && <label className='error'>Select Salary Type..</label>}

                                    </Col>
                                    {userId?.companyId === 69 && <>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecInput type="text" placeholder="Enter USD Salary" name="usd_salary" value={userData.usd_salary} onChange={onChange} label="USD Salary" />


                                        </Col>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecInput type="text" placeholder="Enter Monthly Gross" name="month_gross" value={userData.month_gross} onChange={onChange} label="Monthly Gross" />


                                        </Col>
                                    </>}
                                    {userId?.companyId === 78 && <>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecInput type="text" placeholder="Enter Annual Salary" name="annual_salary" value={userData.annual_salary} onChange={onChange} label="Annual Salary" />


                                        </Col>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecInput type="text" placeholder="Enter VPF" name="vpf" value={userData.vpf} onChange={onChange} label="VPF" />

                                        </Col>
                                    </>}
                                    <Col xs={12} md={6} lg={3} className='d-flex'>
                                        <div className='jobselect me-1'>
                                            <YsecSelect className="md"
                                                name="bank"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...Bankdata?.map((i: any) => ({
                                                        id: i?.ID,
                                                        Name: i?.Description
                                                    }))
                                                ]}

                                                value={userData.bank}
                                                onChange={onChange}
                                                label="Bank"
                                                mandatory
                                            />
                                        </div>
                                        <div className='mt-4'>
                                            <YsecButton type='button' className='cancel' onClick={() => {

                                                setData(Bankdata)
                                                setOpenBank(true)
                                            }} >
                                                <YsecFont className='yf-plus-add' />
                                            </YsecButton></div>
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="text" placeholder="Enter Account Number" name="ac_num" value={userData.ac_num} onChange={onChange} label="Account Number" />

                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="text" placeholder="Enter NIS No" name="nis" value={userData.nis} onChange={onChange} label="NIS No" />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="text" placeholder="Enter TIN" name="tin" value={userData.tin} onChange={onChange} label="TIN No" />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <Row>
                                            <Col xs={12}>
                                                <YsecDatePicker
                                                    name="term_date"
                                                    value={term_date}
                                                    className="md"
                                                    placeholderText="Select Date"
                                                    label="Termination Date"
                                                    error="test message"
                                                    onChange={(e) => props.setTermDate(e.target.value)}
                                                    placeholder="DD-MM-YYYY"
                                                    ysecType="tab"
                                                    ysecFormat="D-MM-YYYY"
                                                    ysecMinDate="1000_Y"
                                                    ysecMaxDate="1000_Y"
                                                />
                                            </Col>
                                            <Col xs={12} className='mt-2 mb-2'>
                                                <YsecCheckbox
                                                    label="Black List"
                                                    className="sm "
                                                    name="blacklist"
                                                    value={userData?.blacklist}
                                                    onChange={onChange}
                                                />
                                            </Col>
                                        </Row>
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecTextarea type="text" placeholder="Enter Reason" name="reason" value={userData.reason} onChange={onChange} label="Reason" />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecTextarea type="text" placeholder="Enter Remarks" name="remarks" value={userData.remarks} onChange={onChange} label="Remarks" />
                                    </Col>
                                    {userId?.companyId === 69 &&
                                        <Col xs={12} md={6} lg={3}>

                                            <YsecMultipleCheck
                                                className="md"
                                                name="hod"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...HodData?.map((i: any) => ({
                                                        id: i?.ID,
                                                        Name: i?.Description
                                                    }))
                                                ]}
                                                value={hod}
                                                onChange={(selected: any) => {
                                                    // Always set array of unique ids only (merge with previous, remove duplicates)
                                                    let newIds: number[] = [];
                                                    if (Array.isArray(selected)) {
                                                        if (selected.length > 0 && typeof selected[0] === 'object' && selected[0] !== null && 'id' in selected[0]) {
                                                            newIds = selected.map((item: any) => Number(item.id)).filter((id: any) => !isNaN(id));
                                                        } else {
                                                            newIds = selected.map((id: any) => Number(id)).filter((id: any) => !isNaN(id));
                                                        }
                                                    } else if (selected !== undefined && selected !== null) {
                                                        if (typeof selected === 'object' && 'id' in selected) {
                                                            newIds = [Number(selected.id)].filter((id: any) => !isNaN(id));
                                                        } else {
                                                            newIds = [Number(selected)].filter((id: any) => !isNaN(id));
                                                        }
                                                    }
                                                    // Merge with previous, remove duplicates
                                                    setHod((prev: any[]) => Array.from(new Set([...(prev || []), ...newIds])));
                                                }}
                                                label="HOD"
                                                multiple={true}
                                            />
                                        </Col>}
                                    {userId?.companyId === 78 && <>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecSelect className="md"
                                                name="report_to"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...HodData?.map((i: any) => ({
                                                        id: i?.ID,
                                                        Name: i?.Description
                                                    }))
                                                ]}

                                                value={userData.report_to}
                                                onChange={onChange}
                                                label="Salary Type"
                                                mandatory
                                            />
                                        </Col>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecSelect className="md"
                                                name="team_lead"
                                                objectNameKey="Name"
                                                objectValueKey="id"
                                                data={[
                                                    { id: 0, Name: "Select" },
                                                    ...HodData?.map((i: any) => ({
                                                        id: i?.ID,
                                                        Name: i?.Description
                                                    }))
                                                ]}

                                                value={userData.team_lead}
                                                onChange={onChange}
                                                label="Salary Type"
                                                mandatory
                                            />
                                        </Col>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecInput type="text" placeholder="Enter UAN Number" name="uanno" value={userData.uanno} onChange={onChange} label="UAN No" />

                                        </Col>
                                        <Col xs={12} md={6} lg={3}>
                                            <YsecInput type="text" placeholder="Enter Nominee" name="nominee" value={userData.nominee} onChange={onChange} label="Nominee" />

                                        </Col>
                                    </>}
                                    <Col xs={12} md={6} lg={3}>

                                        <YsecInput type="text" placeholder="Verify Text" name="verify_txt" value={verify_txt} label="Verify Text" disabled className='greentxt' />
                                    </Col>
                                    <Col xs={12} md={6} lg={3}>
                                        <YsecInput type="number" placeholder="Enter Text" name="enter_txt" value={userData.enter_txt} onChange={onChange} label="Enter Text" mandatory />
                                        {err === 11 && <label className='error'>Please Enter The Text..</label>}
                                        {err === 12 && <label className='error'>Invcorrect Captcha. Please Enter The Correct Captch to Proceed...</label>}
                                    </Col>


                                </Row>
                                <div className='d-block d-md-flex align-items-center justify-content-end'>


                                    <YsecButton type="button" className='mt-3 me-2 w-100  cancel text-nowrap' onClick={handleUploadFileButtonClick}>
                                        Upload File
                                    </YsecButton>
                                    <input
                                        ref={fileref}
                                        type="file"
                                        // multiple
                                        accept=".pdf,.doc,.docx"
                                        style={{ display: 'none' }}
                                        onChange={handleFileChange}
                                    />


                                    <YsecButton className='mt-3 me-2 w-100  cancel text-nowrap'>Scan Doc</YsecButton>


                                    <YsecButton className='mt-3 me-2 w-100  cancel text-nowrap' type='button' onClick={() => { setShowDocs(true) }}>View Doc</YsecButton>

                                </div>



                            </form>
                            <Row className='mt-5 customButns'>
                                <Col xs={12} className='d-flex justify-content-end'>
                                    <YsecButton className="me-1 ms-1 cancel" type="button" onClick={handleClear}>Cancel</YsecButton>
                                    <YsecButton className="me-1 ms-1" type="button" onClick={handleValidation}>Save</YsecButton>
                                </Col>
                            </Row>
                        </Card.Body>
                    </Card>
                </div>
                {showDocs === true && <CustomViewDocModal open={showDocs} setOpen={setShowDocs} data={docData} />}
            </React.Suspense>
        </div>

    );
};
