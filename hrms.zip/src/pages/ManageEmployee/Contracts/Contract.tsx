import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import '../ManageEmployee.scss'
import AxiosLayout from '../../../apis/axios';
import { AddContract } from './AddContract';
import LoadingSpinner from '../../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}
const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};

const Contracts: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [open, setOpen] = useState<boolean>(false)
    const [contractData, setContractData] = useState<any[]>([])
    const [contractId, setContractId] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [locationId, setLocationId] = useState<number>(0)
    const [loading, setLoading] = useState<boolean>(false);
    const tableRef = useRef<any>(null);

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, []);
    useEffect(() => {
        if (selectEmp !== 0) {
            if (selectedBrand == 0) {
                setErrorMessage("Please Select Brand...");
            } else {
                getEmployeeContractData();
            }
        }
    }, [selectEmp, selectedBrand]);

    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                setLoading(false)
            }
        })
    }

    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }



    const getEmployeeContractData = async () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }
        else if (selectEmp == 0) {
            setErrorMessage("Please Select Employee...")
        }
        else {
            await AxiosLayout.get(`/Contract/GetEmployeeContractDetails?EmployeeId=${selectEmp}&UserId=${userId?.user}`).then((res: any) => {
                if (res.status === 200) {
                    if (res.data?.Table !== null) {
                        setContractData(res.data?.Table)

                    }
                }
            })
        }
    }


    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }




    const hanadleUpdateData = async () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }
        else if (selectEmp == 0) {
            setErrorMessage("Please Select Employee...")
        }
        else {
            if (contractData?.length !== 0) {
                const dataa = contractData?.filter(i => i?.ActiveContractId !== 0)
                if (dataa?.length !== 0) {
                    setContractId(dataa[0]?.ActiveContractId)
                    setOpen(true)
                }
                else {
                    setOpen(true)
                }
            }
            else {
                setOpen(true)
            }

        }
    }
    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 150 },
        { id: 'Employee', header: 'Employee', filter: true, size: 150 },
        { id: 'Company', header: 'Company', filter: true, size: 150 },
        { id: 'Brand', header: 'Brand', filter: true, size: 150 },
        { id: 'Department', header: 'Department', filter: true, size: 150 },
        { id: 'Position', header: 'Position', filter: true, size: 150 },
        { id: 'StartDate', header: 'Start Date', filter: true, size: 150 },
        { id: 'EndDate', header: 'End Date', filter: true, size: 150 },
        { id: 'ContractType', header: 'Contract Type', filter: true, size: 150 },
        { id: 'Insurance', header: 'Insurance', filter: true, size: 150 },
        { id: 'PensionPremium', header: 'Pension Premium', filter: true, size: 150 },
        { id: 'Salary', header: 'Salary', filter: true, size: 150 },
        { id: 'PaymentPercentage', header: 'Payment(%)', filter: true, size: 150 },
        {
            id: 'IsActive', header: 'IsActive', filter: true, size: 150, cell: ({ row }: { row: any }) => {
                const { IsActive } = row.original;
                return (
                    <div className='text-center'>
                        <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} /></div>
                );
            },
        },
        { id: 'TerminationDate', header: 'Termination Date', filter: true, size: 150 },
        { id: 'TerminationReason', header: 'Termination Reason', filter: true, size: 150 },
        { id: 'Remarks', header: 'Reason', filter: true, size: 150 },

    ]
    return (
        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Employee</Breadcrumb.Item>
                            <Breadcrumb.Item active>Contracts</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm p-0 ${open !== true && 'cancel'} ${(open === true) && "disbutn"}`}
                            onClick={hanadleUpdateData}
                            disabled={(open === true)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 history  ${open === true && 'cancel'}`} onClick={() => {
                            getEmployeeContractData()
                            setOpen(false)
                        }}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>

                    </div>
                </div>

                <div className='manager-container'>

                    <Row className='p-2 m-1'>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >
                            <YsecSelect className={`md ${open === true && "disableField"}`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                label="Brand" mandatory
                                onChange={(e) => handleSelectBrand(e.target.value)}
                                disabled={open === true}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2} className='p-1' >
                           
                            <YsecDropdown
                                label="Employee" mandatory  value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                data={[
                                    { empId: 0, empName: "Select" },
                                    ...empData?.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))
                                ]}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                defaultSelectedValue="0"
                            />
                        </Col>
                       
                    </Row>
                    {open === true ? <AddContract selectedBrand={selectedBrand} selectBrand={selectedBrand} selectEmp={selectEmp} locationId={locationId} brandData={brandData} setLocationId={setLocationId} contractId={contractId} getData={getEmployeeData} /> :
                        <>

                            <div className='katable contractstable m-1 bg-white pt-2 pb-2'>
                                {contractData?.length > 0 ? (

                                    <YsecTable
                                        rowData={contractData}
                                        columnDefs={staticColumns}
                                        filter={true}
                                        pagination={true}
                                        tableRef={tableRef}
                                        pageSize={20}
                                        dragColumnDisable={true}

                                    />
                                ) : <p className='mb-0 p-3 text-center'>No data Found Here...</p>}

                            </div>


                        </>}
                </div>

            </React.Suspense>
        </div>
    );
};
export default Contracts;