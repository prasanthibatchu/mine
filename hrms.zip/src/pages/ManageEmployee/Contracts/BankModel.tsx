import { Col, Form, Modal, Row } from "react-bootstrap"
import React, { useEffect, useRef, useState } from 'react'
import AxiosLayout from "../../../apis/axios";
import YsecFont from "Layout/YsecFont";


type Job = {
  ID: number;
  Description: string;
  IsActive?: any;
  DepartmentId: number;
  Department: string;
};
interface UserType {
  user: string;
  userName: string;
  companyId: Number;
  // Add more fields if you expect them
}
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));


export const BankModal: React.FC<any> = (props) => {
  const userString = localStorage.getItem('_user');
  const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
  const [details, setDetails] = useState<any>({ bank_id: 0, bank_name: "", comp_name: "", com_ac: "", branch_name: "", branch_id: 0, ifsc: "", currency: 0 })
  const [isActive, setIsActive] = useState<boolean>(true)
  const [bankData, setBankData] = useState<any[]>([])
  const [currencyData, setCurrencyData] = useState<any[]>([])
  const [branchData, setBranchData] = useState<any[]>([])
  const [bankDetails, setBankDetails] = useState<any[]>([])
  const [err, setErr] = useState<number>(0)
  const onChange = async (e: any) => {
    setDetails({ ...details, [e.target.name]: e.target.value })
  }
  const handleClear = () => {

  }
  useEffect(() => {
    getData()

  }, [])
  const getData = () => {
    const payload = {
      bankHierarchyId: 0,
      bankBranchId: 0,
      companyId: userId?.companyId,
      locationId: props?.locationId,
      userId: userId?.user
    }
    AxiosLayout.post("/Contract/GetBranch", payload).then((res: any) => {
      if (res?.status === 200) {
        setBankData(res?.data?.Table)
        setCurrencyData(res?.data?.Table1)
        setBankDetails(res?.data?.Table2)
        setBranchData(res?.data?.Table3)
      }
    })
  }
  useEffect(() => {
    if (details?.bank_id !== 0) {
      const dataa = bankDetails.filter((i: any) => i.BankHierarchyId == details?.bank_id)
      setDetails({ ...details, comp_name: dataa[0]?.CompanyName, com_ac: dataa[0]?.CompanyName })
      // setDetails({comp_name: dataa[0]?.CompanyName, com_ac:  dataa[0]?.Company Account})
    }
  }, [details?.bank_id])
  useEffect(() => {
    if (details?.branch_id !== 0) {
      const dataa = branchData.filter((i: any) => i.BranchId == details?.branch_id)
      const currencyval=currencyData?.filter((i:any)=>i.CurrencyCode===dataa[0]?.CurrencyCode)
      setDetails({ ...details, ifsc: dataa[0]?.IfcCode, currency: currencyval[0]?.CurrencyId })
      setIsActive(dataa[0]?.IsActive)
    }
  }, [details?.branch_id])
  const [openS, setOpenS] = useState<boolean>(false)
  const ref = useRef<HTMLDivElement>(null)
  const filtered = details.bank_name
    ? bankData?.filter((opt: any) => opt.Name.toLowerCase().includes(details.bank_name.toLowerCase()))
    : bankData;

  const [openB, setOpenB] = useState<boolean>(false)
  const refB = useRef<HTMLDivElement>(null)
  const filteredfB = details.branch_name
    ? branchData?.filter((opt: any) => opt.Branch.toLowerCase().includes(details.branch_name.toLowerCase()))
    : branchData;



  const handleSubmit = async (e: any) => {
    e.preventDefault()
    if (details?.bank_name === "") {
      setErr(1)
    }
    else if (details?.comp_name === "") {
      setErr(2)
    }
    else if (details?.branch_name === "") {
      setErr(3)
    }
    else if (details?.ifsc === "") {
      setErr(4)
    }
    else if (details?.currency == 0) {
      setErr(5)
    }
    else {
      const payload = {
        bankName: details?.bank_name,
        branchName: details?.branch_name,
        ifscCode: details?.ifsc,
        currencyId: details?.currency,
        isActive: isActive,
        companyId: userId?.companyId,
        locationId: props?.locationId,
        companyAccNo: details?.com_ac,
        companyName: details?.comp_name,
        userId: userId?.user
      }
      AxiosLayout.post("/Contract/EmployeeBankAccountDetailsTrans", payload).then((res: any) => {
        if (res?.data?.Status === 1) {
          if (res?.data?.Message?.includes("success")) {
            props?.setAlertMessage(res.data.Message)
            setDetails({ bank_id: 0, bank_name: "", comp_name: "", com_ac: "", branch_name: "", branch_id: 0, ifsc: "", currency: 0 })
            props?.setCommonData([])
            props?.getContractCommonData()
            // getData()
            props.setOpen(false)
          }
          else {
            props?.setErrorMessage(res.data.Message)
            setDetails({ bank_id: 0, bank_name: "", comp_name: "", com_ac: "", branch_name: "", branch_id: 0, ifsc: "", currency: 0 })
            // getData()
            props.setOpen(false)
          }
        }
        else {
          props?.setErrorMessage(res.data.Message)
        }
      })
    }

  }
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      show={props.open} onHide={() => {
        props.setOpen(false)
      }}
    >
      <Modal.Header>
        <p className="modal-title opening" id="exampleModalLabel">Add Bank</p>
        <button type="button" className="btn-close" onClick={() => {
          handleClear()
          props.setOpen(false)
        }} aria-label="Close"></button>
      </Modal.Header>
      <Modal.Body>
        <Row>
          <Col xs={12} md={6}>
            <label className="opening">Bank Name <span className="mandatory">*</span></label>
            <div ref={ref} style={{ position: "relative", width: "100%" }}>
              <input name="bank_name" value={details?.bank_name} onChange={(e: any) => {
                onChange(e)
                setOpenS(true)
              }}
                onFocus={() => setOpenS(true)}
                autoComplete="off"
                style={{ width: "100%", paddingRight: 30 }}
              />
              <span
                style={{
                  position: "absolute",
                  right: 8,
                  top: "50%",
                  transform: "translateY(-50%)",
                  cursor: "pointer",
                  userSelect: "none",
                  width: 24,
                  height: 24,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#888"
                }}
                onMouseDown={e => {
                  e.preventDefault();
                  setOpenS(o => !o);
                }}
                aria-label="Show options"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="black" className="bi bi-caret-down-fill" viewBox="0 0 16 16">
                  <path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z" />
                </svg>
              </span>
              {openS && filtered.length > 0 && (<div
                style={{
                  position: "absolute",
                  top: "100%",
                  left: 0,
                  right: 0,
                  background: "#fff",
                  border: "1px solid #ccc",
                  zIndex: 10,
                  maxHeight: 180,
                  overflowY: "auto"
                }}
              >
                {filtered.map((opt: any) => (
                  <div
                    key={opt.id} className="opening"
                    style={{
                      padding: "6px 12px",
                      cursor: "pointer",
                      background: details?.bank_name === opt.Name ? "#eee" : "#fff"
                    }}
                    onMouseDown={() => {
                      setDetails((prev: any) => ({
                        ...prev,
                        bank_name: opt.Name,
                        bank_id: opt.id
                      }));

                      setOpenS(false);
                    }}
                  >
                    {opt.Name}
                  </div>
                ))}
              </div>
              )}

            </div>
            {err === 1 && <label className='error'>Please Select/Enter Bank Name...</label>}
          </Col>
          <Col xs={12} md={6}>
            <YsecInput label="Company Name" name="comp_name" value={details.comp_name} onChange={onChange} mandatory />
            {err === 2 && <label className='error'>Please Enter Company Name...</label>}
          </Col>
          <Col xs={12} md={6}>
            <YsecInput label="Company A/C" name="com_ac" value={details.com_ac} onChange={onChange} />
          </Col>
          <Col xs={12} md={6}>

            <label className="opening">Branch Name <span className="mandatory">*</span></label>
            <div ref={refB} style={{ position: "relative", width: "100%" }}>
              <input name="branch_name" value={details?.branch_name} onChange={(e: any) => {
                onChange(e)
                setOpenB(true)
              }}
                onFocus={() => setOpenB(true)}
                autoComplete="off"
                style={{ width: "100%", paddingRight: 30 }}
              />
              <span
                style={{
                  position: "absolute",
                  right: 8,
                  top: "50%",
                  transform: "translateY(-50%)",
                  cursor: "pointer",
                  userSelect: "none",
                  width: 24,
                  height: 24,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#888"
                }}
                onMouseDown={e => {
                  e.preventDefault();
                  setOpenB(o => !o);
                }}
                aria-label="Show options"
              >
                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="black" className="bi bi-caret-down-fill" viewBox="0 0 16 16">
                  <path d="M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z" />
                </svg>
              </span>
              {openB && filtered.length > 0 && (<div
                style={{
                  position: "absolute",
                  top: "100%",
                  left: 0,
                  right: 0,
                  background: "#fff",
                  border: "1px solid #ccc",
                  zIndex: 10,
                  maxHeight: 180,
                  overflowY: "auto"
                }}
              >
                {filteredfB.map((opt: any) => (
                  <div
                    key={opt.BranchId} className="opening"
                    style={{
                      padding: "6px 12px",
                      cursor: "pointer",
                      background: details?.branch_name === opt.Name ? "#eee" : "#fff"
                    }}

                    onMouseDown={() => {
                      setDetails((prev: any) => ({
                        ...prev,
                        branch_name: opt.Branch,
                        branch_id: opt.BranchId
                      }));

                      setOpenB(false);
                    }}
                  >
                    {opt.Branch}
                  </div>
                ))}
              </div>
              )}

            </div>
            {err === 3 && <label className='error'>Please Select/Enter Branch Name...</label>}
          </Col>
          <Col xs={12} md={6}>
            <YsecInput label="IFSC Code" name="ifsc" value={details.ifsc} onChange={onChange} mandatory />
            {err === 4 && <label className='error'>Please Enter IFSC Code...</label>}
          </Col>
          <Col xs={12} md={6}>
            <YsecSelect className="md"
              name="currency"
              objectNameKey="Name"
              objectValueKey="id"
              data={

                currencyData?.map((i: any) => ({
                  id: i?.CurrencyId,
                  Name: i?.CurrencyCode
                }))
              }
              value={details?.currency}
              onChange={onChange}
              label="Currency"
              mandatory
            />
            {err === 5 && <label className='error'>Please Select Currency Code...</label>}
          </Col>
          <Col xs={12} md={6}>
            <Form.Check className="mt-2 opening"
              type="checkbox"
              id="isActive"
              label="IsActive"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
            />
          </Col>
          <Col xs={12} md={6}>
            <div className="d-flex slign-itemd-center justify-content-end mt-3">
              <YsecButton className="ms-1 me-1" type="button" onClick={handleSubmit} >Save</YsecButton>
              <YsecButton className="ms-1 me-1 cancel" type="button" onClick={handleClear} >Clear</YsecButton>
            </div>
          </Col>

        </Row>
      </Modal.Body>
    </Modal>
  )
}