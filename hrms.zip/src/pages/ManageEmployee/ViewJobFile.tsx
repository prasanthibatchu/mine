import React, { useEffect, useRef } from "react";
import { renderAsync } from "docx-preview";

interface FilePreviewProps {
  fileUrl: string;
}
const DocxPreview: React.FC<{ file: File }> = ({ file }) => {
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (file && containerRef.current) {
            // Clear previous content
            containerRef.current.innerHTML = "";
            const reader = new FileReader();
            reader.onload = async (e) => {
                if (e.target && e.target.result) {
                    await renderAsync(
                        e.target.result as ArrayBuffer,
                        containerRef.current!
                    );
                }
            };
            reader.readAsArrayBuffer(file);
        }
    }, [file]);

    return (
        <div
            ref={containerRef}
            style={{
                border: '1px solid #ccc',
                padding: 8,
                marginTop: 8,
                maxHeight: 700,
                overflow: 'auto',
                background: '#fff'
            }}
        />
    );
};
export const ViewJobFile: React.FC<FilePreviewProps> = ({ fileUrl }) => {
  const ext = fileUrl?.split(".").pop()?.toLowerCase().split("?")[0];
  const containerRef = useRef<HTMLDivElement>(null);


useEffect(() => {
  if (ext === "docx" && fileUrl && containerRef.current) {
    containerRef.current.innerHTML = "";
    fetch(fileUrl)
      .then(res => res.arrayBuffer())
      .then(buffer => {
        renderAsync(buffer, containerRef.current as HTMLDivElement, undefined, { debug: false });
      })
      .catch(err => {
        containerRef.current!.innerHTML = "Failed to load document.";
        console.error("Error loading docx:", err);
      });
  }
}, [fileUrl, ext]);
  if (!fileUrl) return <div>No file selected.</div>;

  if (ext === "pdf") {
    return (
      <iframe
        src={fileUrl}
        title="PDF Preview"
        width="100%"
        height="600"
        style={{ border: "none" }}
      />
    );
  }

  if (ext === "docx") {
    return (
        
      <div
        ref={containerRef}
        style={{
          width: "100%",
          minHeight: "600px",
          border: "1px solid #ccc",
          overflow: "auto",
          padding: 8,
        }}
      />
    );
  }

  return (
    <div>
      <a href={fileUrl} target="_blank" rel="noopener noreferrer">
        Download/View File
      </a>
    </div>
  );
};