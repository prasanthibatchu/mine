import React, { useEffect, useRef, useState } from 'react'
import dayjs from 'dayjs';
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { DatePicker, DatePickerProps } from 'antd';
import { AddContract } from '../Contracts/AddContract';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const FoodHandlers: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [searchTerm, setSearchTerm] = useState<string>("");
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [itemsPerPage, setItemsPerPage] = useState<number>(20);
    const [open, setOpen] = useState<boolean>(false)
    const [err, setErr] = useState<number>(0)
    const [selectedRow, setSelectedRow] = useState<number>(0)
    const [handlerData, setHandlerData] = useState<any[]>([])
    const tableRef = useRef<any>(null)

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                    setLoading(false)
                }

            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }
    useEffect(() => {
        if (selectEmp !== 0) {
            if (selectedBrand == 0) {
                setErrorMessage("Please Select Brand...");
            } else {
                getFoodHandlerData();
            }
        }
    }, [selectEmp, selectedBrand]);
    const getFoodHandlerData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetFoodHandlerDetails?EmployeeId=${selectEmp}&BrandId=${selectedBrand}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setHandlerData(res.data?.Table)
                setLoading(false)
            }
        })
    }
    const staticColumns = [
        { id: 'Department', header: 'Department', filter: true, size: 150 },
        { id: 'SubDepartment', header: 'Sub Department', filter: true, size: 150 },
        { id: 'Position', header: 'Position', filter: true, size: 150 },
        { id: 'FoodhandlerIssueDate', header: 'Foodhandler Issue Date', filter: true, size: 150 },
        { id: 'FoodhandlerExpireDate', header: 'Foodhandler Expire Date', filter: true, size: 150 },
        { id: 'IsActive', header: 'IsActive', filter: true, size: 150 },
    ]

    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Employee</Breadcrumb.Item>
                            <Breadcrumb.Item active>Food Handlers</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm p-0 ${open !== true && 'cancel'} ${(open === true) && "disbutn"}`}
                            // onClick={handleOpen}
                            disabled={(open === true)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 history  ${open === true && 'cancel'}`} onClick={() => {

                            setOpen(false)
                        }}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 btn-outline-primary`} >
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>

                    </div>
                </div>

                <div className='manager-container bg-white'>
                    <Row className={`p-2 mt-1 mb-1  `}>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            <YsecSelect className={`md ${open === true && "disableField"}`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                label="Brand" mandatory
                                onChange={(e) => handleSelectBrand(e.target.value)} disabled={open === true}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} lg={2} xl={2}  >
                            <YsecDropdown className={`md ${open === true && "disableField"}`}
                                label="Employee" mandatory  value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                data={[
                                    { empId: 0, empName: "Select" },
                                    ...empData?.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))
                                ]}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                 disabled={open === true}
                                  defaultSelectedValue="0"
                            />
                        </Col>
                    </Row>
                    <div>
                        
                        <div className='katable'>
                            <YsecTable
                                rowData={handlerData}
                                columnDefs={staticColumns}
                                filter={true}
                                pagination={false}
                                tableRef={tableRef}
                                // pageSize={20}
                                dragColumnDisable={true}
                                reRender={true}
                            />

                        </div>
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}

export default FoodHandlers;