import React, { useCallback, useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row, Tab, Tabs } from 'react-bootstrap'
import '../ManageEmployee.scss'
import { DataType, Table } from 'ka-table';
import AxiosLayout from '../../../apis/axios';
import { EmployeeDetails } from './EmployeeDetails';
import { GeneralDetails } from './GeneralDetails';
import LoadingSpinner from '../../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}



const Registration: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [itemsPerPage, setItemsPerPage] = useState<number>(30);
    const [empData, setEmpData] = useState<any[]>([])
    const [open, setOpen] = useState<boolean>(false)
    const [brandData, setBrandData] = useState<any[]>([])
    const [filteredData, setFilteredData] = useState<any[]>([]);
    const [selectedBrand, setSelectedBrand] = useState<string>("")
    const [selectedBrandDesc, setSelectedBrandDesc] = useState<string>("")
    const [user, setUser] = useState<any>({ cand_id: "0", title: "", fname: "", lname: "", govtid: "", nationality: "", religion: "", phone: "", mobile: "", emergency_num: "", country: "0", email: "", marital_status: "0", blood_group: "", job_title: "", qualification: 0, recruited_by: 0, place_of_birth: "", district: "", address: "", diseases: "", allergies: "", police_remarks: "", relation: "", driving_licence: "false", police_clearance: "false", drug_test: "false", still_being_treated: "false", SOR: "false", cbbextract: "false", own_transport: "false", badge: "false", medical_history: "false", bill_weight: "", notice_period: "", aadhar_no: "" })
    const [carrer_start_date, setCareerStartDate] = useState<string>("")
    const [resign_date, setResignDate] = useState<string>("")
    const [photo, setPhoto] = useState<string>("")
    const [docs, setDocs] = useState<any[]>([])
    const [files, setFiles] = useState<any[]>([]);
    const [modalOpen, setModalOpen] = useState<boolean>(false);
    const [currentIndex, setCurrentIndex] = useState<number>(0);
    const [over, setOver] = useState<boolean>(false);
    const [selectedFiles, setSelectedFiles] = useState<any[]>([]);
    const [searchTerm, setSearchTerm] = useState<string>("");
    const [selectAll, setSelectAll] = useState<boolean>(false);
    const [documentContent, setDocumentContent] = useState<string>("");
    const inputRef = useRef<HTMLInputElement | null>(null);
    const [idValidDate, setIdValidDate] = useState<string>("")
    const [dob, setDob] = useState<string>("")
    const [actualDob, setActualDob] = useState<string>("")
    const [mar_date, setMarDate] = useState<string>("")
    const [date_of_employment, setDateOfEmployement] = useState<string>("")
    const [err, setErr] = useState<number>(0)
    const [activeTab, setActiveTab] = useState<string>("emp");
    const [edData, setEdData] = useState<any>([]); // (See <attachments> above for file contents. You may not need to search or read the file again.)
    const [expData, setExpData] = useState<any>([]);
    const [skills, setSkills] = useState<any>([])
    const [skillsDesc, setSkillsDesc] = useState<any[]>([])
    const [yearExp, setYearExp] = useState<string>("")
    const [hobbies, settHobbiies] = useState<any[]>([])
    const [hobbyDesc, sethobbyDesc] = useState<any[]>([])
    const [selectedEmpId, setSelectedEmpId] = useState<number>(0)
    const [docpaths, setDocPaths] = useState<any>([])
    const [docTypeId, setDocTypeId] = useState<number>(0)
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const tableRef = useRef<any>(null);

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => {
        getGeneralData()
        getMasterData()
    }, []);

    const getGeneralData = () => {
        setLoading(true);
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setFilteredData(res.data)
                setLoading(false);
            }
        })
    }

    const getMasterData = () => {
        setLoading(true);
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    setLoading(false);
                }
            }
        })
    }

    const handleOpen = () => { setOpen(!open) }
    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee ID', filter: true, size: 80 },
        { id: 'FullName', header: 'Name', filter: true, size: 100 },
        { id: 'IdNumber', header: 'Id Number', filter: true, size: 100 },
        { id: 'DOE', header: 'DOE', filter: true, size: 100 },
        { id: 'DOB', header: 'DOB', filter: true, size: 100 },
        { id: 'Phone', header: 'Phone', filter: true, size: 100 },
        { id: 'Country', header: 'Country', filter: true, size: 100 },
        { id: 'MaritalStatus', header: 'Marital Status', filter: true, size: 100 },
        { id: 'Brand', header: 'Brand', filter: true, size: 100 },
        { id: 'Department', header: 'Department', filter: true, size: 100 },
        { id: 'Position', header: 'Position', filter: true, size: 100 },
        {
            id: "edit",
            header: "",
            filter: false, size: 30,
            cell: ({ row }: { row: any }) => {
                const { EmployeeId } = row.original;

                return (
                      <div className='text-center'>
                    <EditData rowKeyValue={EmployeeId} rowdata={row?.original} /></div>
                );
            },
        },
    ];
    const dataArray = filteredData?.map(
        (i, index) => ({
            empId: i.EmployeeId,
            emps: i.FullName,
            govt_id: i.IdNumber,
            marital_status: i.MaritalStatus,
            doe: i.DOE,
            dob: i.DOB,
            phone: i.Phone,
            brand: i.Brand,
            dept: i.Department,
            position: i.Position,
            country: i.Country,

            id: i.EmployeeId,
        }),
    );
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray?.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);
    const handleData = async (e: any) => {
        e.preventDefault()
        setErr(0)
        if (user.title === "") {
            setErr(1)
        }
        else if (user.fname === "") {
            setErr(2)
        }
        else if (user.lname === "") {
            setErr(3)
        }
        else if (user.govtid === "") {
            setErr(4)
        }
        else if (dob === "") {
            setErr(5)

        } else if (user.mobile === "") {
            setErr(6)
        } else if (user.marital_status === "" || user.marital_status == 0) {
            setErr(7)
        } else if (date_of_employment === "") {
            setErr(16)
        } else if (user.job_title === "") {
            setErr(18)
        } else if (user.address === "") {
            setErr(23)
        }
        else {

            handleSave()
        }


        // Validate education details

    }
    const handleSave = async () => {
        const formattedEducations = edData?.map((item: any, index: number) => ({
            educationId: index + 1,
            employeeId: selectedEmpId,
            education: item.degree || "",
            year: item.year || "",
            result: item.result || ""
        }));
        const formattedSkills = skills?.map((item: any, index: number) => ({
            skillId: index + 1,
            employeeId: selectedEmpId,
            skills: item?.skill || "",
            yearOfExperience: item?.years || ""
        }));
        const formattedHobbie = hobbies?.map((item: any, index: number) => ({
            hobbbyId: index + 1,
            employeeId: selectedEmpId,
            hobby: item?.hobbie || "",
        }));
        const formattedExp = expData?.map((item: any, index: number) => ({
            employeeId: selectedEmpId,
            company: item?.company_name || "",
            position: item?.role || "",
            joiningDate: item?.join_date || "",
            toDate: item?.to_date || "",
            contactPerson: item?.cont_person || "",
            contactNo: item?.contact_no || "",
        }));
        const payload = {
            candidateID: user.cand_id,
            employeeId: selectedEmpId,
            companyId: userId?.companyId,
            userId: userId?.user,
            title: user.title,
            firstName: user.fname,
            lastName: user.lname,
            idNumber: user.govtid,
            idValidDate: idValidDate,
            nationality: user.nationality,
            religion: user.religion,
            dob: dob,
            actualDOB: actualDob,
            phone: user.phone,
            mobile: user.mobile,
            emergencyNumber: user.emergency_num,
            countryId: user.country,
            email: user.email,
            maritalStatusId: user.marital_status,
            marrriageDate: mar_date,
            doe: date_of_employment,
            bloodGroup: user.blood_group,
            qualificationId: user.qualification,
            district: user.district,
            jobTitle: user.job_title,
            recruitedBy: user.recruited_by,
            placeOfBirth: user.place_of_birth,
            address: user.address,
            diseases: user.diseases,
            allergies: user.allergies,
            policeRemarks: user.police_remarks,
            relation: user.relation,
            billingWeightage: user.bill_weight,
            noticePeriod: Number(user.notice_period),
            careerStartDate: carrer_start_date,
            resignationDate: resign_date,
            isActive: true,
            isVerified: true,
            driversLicence: user.driving_licence,
            drugTest: user.drug_test,
            sor: user.SOR,
            ownTransport: user.own_transport,
            medicalHistory: user.medical_history,
            policeClearance: user.police_clearance,
            stillBeingTreated: user.still_being_treated,
            cbbExtract: user.cbbextract,
            badge: user.badge,
            employeeImage: photo.slice(22),
            employeeEducations: formattedEducations,
            employeeSkills: formattedSkills,
            employeeHobbies: formattedHobbie,
            empWorkExperiences: formattedExp,
            employeeImageURL: "",
            documentPath: "",
            documentTypeId: DocumentType?.EmpRegistration,
            uploadDocPath: "",
            uploadDocTypeId: DocumentType?.EmpRegistration,



        }
        await AxiosLayout.post("/Registration/EmployeeTrans", payload).then((res: any) => {
            if (res.data.Status === 1) {
                handleClear()
                getGeneralData()
                setAlertMessage(res.data.Message)
            }
            else {
                setErrorMessage(res.data.Message)
            }
        })

    }
    const handleClear = () => {
        setUser({ cand_id: "0", title: "", fname: "", lname: "", govtid: "", nationality: "", religion: "", phone: "", mobile: "", emergency_num: "", country: "0", email: "", marital_status: "0", blood_group: "", job_title: "", qualification: 0, recruited_by: 0, place_of_birth: "", district: "", address: "", diseases: "", allergies: "", police_remarks: "", relation: "", driving_licence: "No", police_clearance: "No", drug_test: "No", still_being_treated: "No", SOR: "No", cbbextract: "No", own_transport: "No", badge: "No", medical_history: "No", bill_weight: "", notice_period: "", aadhar_no: "" })
        setEdData([])
        setExpData([])
        setSkills([]);
        setYearExp("")
        setSkillsDesc([]);
        sethobbyDesc([])
        settHobbiies([])
        setActiveTab("emp")
        setDateOfEmployement("")
        setActualDob("")
        setDob("")
        setIdValidDate("")
        setDocs([])
        setPhoto("")
        setOpen(false)
        setMarDate("")
        setCareerStartDate("")
        setResignDate("")
    }
    const EditData = ({ rowKeyValue, rowdata }: { rowKeyValue: any, rowdata: any }) => {

        const handleData = () => {
            AxiosLayout.get(`/Registration/GetEmployeeDetailById?EmployeeId=${Number(rowKeyValue)}&UserId=${userId?.user}`).then((res: any) => {
                if (res.status === 200) {
                    setUser({
                        cand_id: res.data.CandidateID,
                        title: res.data.Title,
                        fname: res.data.FirstName,
                        lname: res.data.LastName,
                        govtid: res.data.IdNumber,
                        nationality: res.data.Nationality,
                        religion: res.data.Religion,
                        phone: res.data.Phone,
                        mobile: res.data.Mobile,
                        emergency_num: res.data.EmergencyNumber,
                        country: res.data.CountryId,
                        email: res.data.Email,
                        marital_status: res.data.MaritalStatusId,
                        blood_group: res.data.BloodGroup,
                        job_title: res.data.JobTitle,
                        qualification: res.data.QualificationId,
                        recruited_by: res.data.RecruitedBy,
                        place_of_birth: res.data.PlaceOfBirth,
                        district: res.data.District,
                        address: res.data.Address,
                        diseases: res.data.Diseases,
                        allergies: res.data.Allergies,
                        police_remarks: res.data.PoliceRemarks,
                        relation: res.data.Relation,
                        driving_licence: JSON.stringify(res.data.DriversLicence),
                        police_clearance: JSON.stringify(res.data.PoliceClearance),
                        drug_test: JSON.stringify(res.data.DrugTest),
                        still_being_treated: JSON.stringify(res.data.StillBeingTreated),
                        SOR: JSON.stringify(res.data.SOR),
                        cbbextract: JSON.stringify(res.data.CBBExtract),
                        own_transport: JSON.stringify(res.data.OwnTransport),
                        badge: JSON.stringify(res.data.Badge),
                        medical_history: JSON.stringify(res.data.MedicalHistory),
                        bill_weight: res.data.BillingWeightage,
                        notice_period: res.data.NoticePeriod,
                        aadhar_no: res.data.AadhaarNo,
                    })
                    setDob(res.data.DOB?.split("T")[0])
                    setIdValidDate(res.data.IdValidDate?.split("T")[0])
                    setActualDob(res.data.ActualDOB?.split("T")[0])
                    setDateOfEmployement(res.data.DOE?.split("T")[0])
                    setDocTypeId(res?.data?.DocumentTypeId)
                    setCareerStartDate(res?.data?.CareerStartDate?.split("T")[0])
                    setResignDate(res?.data?.ResignationDate?.split("T")[0])
                    // setDob(res.data.DOB?.split("T")[0])
                    // setDob(res.data.DOB?.split("T")[0])

                    // const [photo, setPhoto] = useState("")
                    // const [docs, setDocs] = useState([])
                    const formattedEdData = res.data?.EmployeeEducations?.map((item: any) => ({
                        degree: item.Education || "",
                        year: item.Year ||"",
                        gpa: item.Result || "",
                        city: ""
                    }));
                    setEdData(formattedEdData?.length ? formattedEdData : []);

                    const formattedExpData = res.data?.EmpWorkExperiences?.map((item: any) => ({
                        company_name: item.Company || "",
                        role: item?.Position || "",
                        join_date: item.JoiningDate || "",
                        to_date: item?.ToDate || ""
                    }));
                    setExpData(formattedExpData?.length ? formattedExpData : []);
                    const formattedSkillData = res.data?.EmployeeSkills?.map((item: any) => ({
                        skill: item.Skills || "",
                        years: item?.YearOfExperience || ""
                    }));
                    setSkills(formattedSkillData?.length ? formattedSkillData : []);
                    const formattedHobbyData = res.data?.EmployeeHobbies?.map((item: any) => ({
                        hobbie: item.Hobby || ""
                    }));
                    settHobbiies(formattedHobbyData?.length ? formattedHobbyData : []);
                    setPhoto(`data:image/png;base64,${res.data?.EmployeeImage}`)
                    setSelectedEmpId(Number(rowKeyValue))
                    handleOpen()
                }
            })


        }
        return (
            <YsecFont className={`yf-document-edit action-icon`}
                onClick={handleData}
            />
        )
    }
    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    return (

        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header  d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Manage Employee</Breadcrumb.Item>
                            <Breadcrumb.Item active>Registration</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end m-1 gap-1'>
                        <YsecButton type="button" className={`sm p-0 ${open !== true && 'cancel'}`} onClick={() => setOpen(true)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 ${open === true && 'cancel'}`} onClick={() => {
                            handleClear();
                            setOpen(false)
                        }}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>
                        <YsecButton type="button" className={`sm p-0 btn-outline-primary`} >
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className="manager-container  pb-1">
                    {open === true ? <>
                        <div className='p-3  m-2'>
                            <Tabs
                                activeKey={activeTab} // Controlled active tab
                                onSelect={(k: any) => setActiveTab(k)}
                                id="uncontrolled-tab-example"
                                className="mb-3"
                            >
                                <Tab eventKey="emp" title="Employee Details">
                                    <EmployeeDetails user={user} setUser={setUser} idValidDate={idValidDate} setIdValidDate={setIdValidDate} dob={dob} setDob={setDob} actualDob={actualDob} setActualDob={setActualDob} date_of_employment={date_of_employment} setDateOfEmployement={setDateOfEmployement} photo={photo} setPhoto={setPhoto} docs={docs} setDocs={setDocs} err={err} selectedEmpId={selectedEmpId} files={files} setFiles={setFiles} modalOpen={modalOpen} setModalOpen={setModalOpen} currentIndex={currentIndex} setCurrentIndex={setCurrentIndex} over={over} setOver={setOver} inputRef={inputRef} selectedFiles={selectedFiles} setSelectedFiles={setSelectedFiles} searchTerm={searchTerm} setSearchTerm={setSearchTerm} selectAll={selectAll} setSelectAll={setSelectAll} documentContent={documentContent} setDocumentContent={setDocumentContent} mar_date={mar_date} setMarDate={setMarDate} docTypeId={docTypeId} carrer_start_date={carrer_start_date} setCareerStartDate={setCareerStartDate} resign_date={resign_date} setResignDate={setResignDate} />
                                </Tab>
                                <Tab eventKey="general" title="General Details">
                                    <GeneralDetails edData={edData} setEdData={setEdData} expData={expData} setExpData={setExpData} skills={skills} setSkills={setSkills} skillsDesc={skillsDesc} yearExp={yearExp} setYearExp={setYearExp} hobbies={hobbies} hobbyDesc={hobbyDesc} settHobbiies={settHobbiies} err={err} selectedEmpId={selectedEmpId} />
                                </Tab>

                            </Tabs>
                        </div>
                    </> : <>

                       
                        <div className='katable  bg-white pt-2 pb-2'>
                            {filteredData?.length !== 0 ?
                                <YsecTable
                                    rowData={filteredData}
                                    columnDefs={staticColumns}
                                    filter={true}
                                    pagination={true}
                                    tableRef={tableRef}
                                    pageSize={20}
                                    dragColumnDisable={true}
                                    reRender={true}

                                />
                            :<p className='mb-0 p-3 text-center'>No data Found Here...</p>}
                           
                        </div>
                        
                    </>}
                </div>
                {open === true &&
                    <Row className='customButns'>
                        <Col xs={12} className='d-flex justify-content-end  mt-2'>
                            <YsecButton className="me-1 ms-1 cancel" type="button" onClick={handleClear}>Cancel</YsecButton>
                            <YsecButton className="me-1 ms-1" type="button" onClick={handleData}>Save</YsecButton>

                        </Col>
                    </Row>}
            </React.Suspense>
        </div>
    );
};

export default Registration