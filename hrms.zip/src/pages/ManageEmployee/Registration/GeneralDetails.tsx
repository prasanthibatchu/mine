import React from 'react'
import { Card, Col, Row } from 'react-bootstrap';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecCountrySelect = React.lazy(() =>
  import("Layout/YsecCountrySelect2")
);
interface UserType {
  user: string;
  userName: string;
  companyId: number;
  company?: string;
}

export const GeneralDetails: React.FC<any> = (props) => {
  // (See <attachments> above for file contents. You may not need to search or read the file again.)
  const addEntry = () => {
    const edData = props.edData;
    // If no rows, always allow adding
    if (edData.length === 0) {
      props.setEdData([{ degree: "", year: "", result: "" }]);
      return;
    }
    // If only one row, allow adding if any field is filled
    if (edData.length === 1) {
      const first = edData[0];
      if (first.degree || first.year || first.result) {
        props.setEdData([...edData, { degree: "", year: "", result: "" }]);
      }
      return;
    }
    // For multiple rows, check if last row has any field filled
    const last = edData[edData.length - 1];
    if (last.degree || last.year || last.result) {
      props.setEdData([...edData, { degree: "", year: "", result: "" }]);
    }
  };
  const updateEntry = (index: number, field: any, value: any) => {
    const updatedData = props.edData.map((item: any, i: any) =>
      i === index ? { ...item, [field]: value } : item
    );
    props.setEdData(updatedData);
  };
  const removeEntry = (index: number) => {
    const updatedData = props.edData.filter((_: any, i: any) => i !== index);
    props.setEdData(updatedData);
  };

  // (See <attachments> above for file contents. You may not need to search or read the file again.)
  const addEntryWork = () => {
    const expData = props.expData;
    if (expData.length === 0) {
      props.setExpData([{ company_name: "", role: "", join_date: "", to_date: "", cont_person: "", contact_no: "" }]);
      return;
    }
    if (expData.length === 1) {
      const first = expData[0];
      if (first.company_name || first.role || first.join_date || first.to_date || first.cont_person || first.contact_no) {
        props.setExpData([...expData, { company_name: "", role: "", join_date: "", to_date: "", cont_person: "", contact_no: "" }]);
      }
      return;
    }
    const last = expData[expData.length - 1];
    if (last.company_name || last.role || last.join_date || last.to_date || last.cont_person || last.contact_no) {
      props.setExpData([...expData, { company_name: "", role: "", join_date: "", to_date: "", cont_person: "", contact_no: "" }]);
    }
  };
  const updateEntryWork = (index: number, field: any, value: any) => {
    const updatedData = props.expData.map((item: any, i: any) =>
      i === index ? { ...item, [field]: value } : item
    );
    props?.setExpData(updatedData);
  };
  const removeEntryWork = (index: number) => {
    const updatedData = props.expData.filter((_: any, i: any) => i !== index);
    props?.setExpData(updatedData);
  };

  // (See <attachments> above for file contents. You may not need to search or read the file again.)
  const addEntrySkills = () => {
    const skills = props.skills;
    if (skills.length === 0) {
      props.setSkills([{ skill: "", years: "" }]);
      return;
    }
    if (skills.length === 1) {
      const first = skills[0];
      if (first.skill || first.years) {
        props.setSkills([...skills, { skill: "", years: "" }]);
      }
      return;
    }
    const last = skills[skills.length - 1];
    if (last.skill || last.years) {
      props.setSkills([...skills, { skill: "", years: "" }]);
    }
  };
  const updateEntrySkills = (index: number, field: any, value: any) => {
    const updatedData = props.skills.map((item: any, i: any) =>
      i === index ? { ...item, [field]: value } : item
    );
    props?.setSkills(updatedData);
  };
  const removeEntrySkills = (index: number) => {
    const updatedData = props.skills.filter((_: any, i: any) => i !== index);
    props?.setSkills(updatedData);
  };

  // (See <attachments> above for file contents. You may not need to search or read the file again.)
  const addEntryHobby = () => {
    const hobbies = props.hobbies;
    if (hobbies.length === 0) {
      props.settHobbiies([{ hobbie: "" }]);
      return;
    }
    if (hobbies.length === 1) {
      const first = hobbies[0];
      if (first.hobbie) {
        props.settHobbiies([...hobbies, { hobbie: "" }]);
      }
      return;
    }
    const last = hobbies[hobbies.length - 1];
    if (last.hobbie) {
      props.settHobbiies([...hobbies, { hobbie: "" }]);
    }
  };
  const updateEntryHobby = (index: number, field: any, value: any) => {
    const updatedData = props.hobbies.map((item: any, i: any) =>
      i === index ? { ...item, [field]: value } : item
    );
    props?.settHobbiies(updatedData);
  };
  const removeEntryHobby = (index: number) => {
    const updatedData = props.hobbies.filter((_: any, i: any) => i !== index);
    props?.settHobbiies(updatedData);
  };
  return (

    <div className="p-4 formsheight">
      <Row>
        <Col xs={12} lg={6} className='mt-2'>
          <h6 className='opening'>Education Details</h6>
          <div className='katableee katablefixheight'>

            <table>
              <thead>
                <tr>
                  <th>Education</th>
                  <th>Year</th>
                  <th>Result</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {props?.edData.map((entry: any, index: number) => (
                  <tr key={index}>
                    <td >

                      <YsecInput className="sm"
                        name="degree"
                        value={entry.degree}
                        onChange={(e) => updateEntry(index, "degree", e.target.value)}
                      />
                    </td>
                    <td>
                      <YsecInput className="sm"
                        name="year"
                        value={entry.year}
                        onChange={(e) => updateEntry(index, "year", e.target.value)}
                      />

                    </td>

                    <td>
                      <YsecInput className="sm"
                        name="result"
                        value={entry.result}
                        onChange={(e) => updateEntry(index, "result", e.target.value)}

                      />
                    </td>


                    <td>
                      <YsecFont className='yf-delete-bin-2' onClick={() => removeEntry(index)} /></td>
                  </tr>
                ))}
                {/* Show add new row only if allowed by the logic above */}
                {(() => {
                  const edData = props.edData;
                  if (edData.length === 0) return (
                    <tr><td colSpan={12} className='addrow' onClick={addEntry}>Click here to add new row</td></tr>
                  );
                  if (edData.length === 1) {
                    const first = edData[0];
                    if (first.degree || first.year || first.result) {
                      return <tr><td colSpan={12} className='addrow' onClick={addEntry}>Click here to add new row</td></tr>;
                    }
                    return null;
                  }
                  const last = edData[edData.length - 1];
                  if (last.degree || last.year || last.result) {
                    return <tr><td colSpan={12} className='addrow' onClick={addEntry}>Click here to add new row</td></tr>;
                  }
                  return null;
                })()}
              </tbody>

            </table>
          </div>
        </Col>
        <Col xs={12} lg={6} className='mt-2'>
          <h6 className='opening'>Skills</h6>
          <div className='katableee katablefixheight'>

            <table>
              <thead>
                <tr>
                  <th>Skills</th>
                  <th>Year Of Experience</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {props?.skills.map((entry: any, index: number) => (
                  <tr key={index}>
                    <td >

                      <YsecInput className="sm"
                        name="skill"
                        value={entry.skill}
                        onChange={(e) => updateEntrySkills(index, "skill", e.target.value)}
                      />
                    </td>
                    <td>
                      <YsecInput className="sm"
                        name="years"
                        value={entry.years}
                        onChange={(e) => updateEntrySkills(index, "years", e.target.value)}
                      />
                    </td>
                    <td>
                      <YsecFont className='yf-delete-bin-2' onClick={() => removeEntrySkills(index)} />

                    </td>
                  </tr>
                ))}
                {/* Show add new row only if allowed by the logic above */}
                {(() => {
                  const skills = props.skills;
                  if (skills.length === 0) return (
                    <tr><td colSpan={12} className='addrow' onClick={addEntrySkills}>Click here to add new row</td></tr>
                  );
                  if (skills.length === 1) {
                    const first = skills[0];
                    if (first.skill || first.years) {
                      return <tr><td colSpan={12} className='addrow' onClick={addEntrySkills}>Click here to add new row</td></tr>;
                    }
                    return null;
                  }
                  const last = skills[skills.length - 1];
                  if (last.skill || last.years) {
                    return <tr><td colSpan={12} className='addrow' onClick={addEntrySkills}>Click here to add new row</td></tr>;
                  }
                  return null;
                })()}
              </tbody>

            </table>
          </div>
        </Col>
        <Col xs={12} lg={6} className='mt-2'>
          <h6 className='opening'>Experience</h6>
          <div className='katableee katablefixheight'>

            <table>
              <thead>
                <tr>
                  <th>Company</th>
                  <th>Position</th>
                  <th>Joining Date</th>
                  <th>Till Date</th>
                  <th>Contact Person</th>
                  <th>Contact Number</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {props?.expData.map((entry: any, index: number) => (
                  <tr key={index}>
                    <td >

                      <YsecInput className="sm"
                        name="company_name"
                        value={entry.company_name}
                        onChange={(e) => updateEntryWork(index, "company_name", e.target.value)}
                      />

                    </td>
                    <td>
                      <YsecInput className="sm"
                        name="role"
                        value={entry.role}
                        onChange={(e) => updateEntryWork(index, "role", e.target.value)}
                      />
                    </td>

                    <td>
                      <YsecDatePicker
                        name="join_date"
                        value={entry.join_date}
                        className="sm"
                        error="test message"
                        onChange={(e) => updateEntryWork(index, "join_date", e.target.value)}
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="10_D"
                        ysecMaxDate="1000_Y"
                      />
                    </td>
                    <td>
                      <YsecDatePicker
                        name="to_date"
                        value={entry.to_date}
                        className="sm"
                        error="test message"
                        onChange={(e) => updateEntryWork(index, "to_date", e.target.value)}
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="10_D"
                        ysecMaxDate="1000_Y"
                      />
                    </td>
                    <td>
                      <YsecInput className="sm"
                        name="cont_person"
                        value={entry.cont_person}
                        onChange={(e) => updateEntryWork(index, "cont_person", e.target.value)}
                      />
                    </td>
                    <td>
                      <YsecInput className="sm"
                        name="contact_no"
                        value={entry.contact_no}
                        onChange={(e) => updateEntryWork(index, "contact_no", e.target.value)}
                      />
                    </td>
                    <td>
                      <YsecFont className='yf-delete-bin-2' onClick={() => removeEntryWork(index)} />
                    </td>
                  </tr>
                ))}
                {/* Show add new row only if allowed by the logic above */}
                {(() => {
                  const expData = props.expData;
                  if (expData.length === 0) return (
                    <tr><td colSpan={12} className='addrow' onClick={addEntryWork}>Click here to add new row</td></tr>
                  );
                  if (expData.length === 1) {
                    const first = expData[0];
                    if (first.company_name || first.role || first.join_date || first.to_date || first.cont_person || first.contact_no) {
                      return <tr><td colSpan={12} className='addrow' onClick={addEntryWork}>Click here to add new row</td></tr>;
                    }
                    return null;
                  }
                  const last = expData[expData.length - 1];
                  if (last.company_name || last.role || last.join_date || last.to_date || last.cont_person || last.contact_no) {
                    return <tr><td colSpan={12} className='addrow' onClick={addEntryWork}>Click here to add new row</td></tr>;
                  }
                  return null;
                })()}
              </tbody>

            </table>
          </div>
        </Col>
        <Col xs={12} lg={6} className='mt-2'>
          <h6 className='opening'>Hobby</h6>
          <div className='katableee katablefixheight'>
            <table>
              <thead>
                <tr>
                  <th>Hobby</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {props?.hobbies.map((entry: any, index: number) => (
                  <tr key={index}>
                    <td >
                      <YsecInput className="sm"
                        name="hobbie"
                        value={entry.hobbie}
                        onChange={(e) => updateEntryHobby(index, "hobbie", e.target.value)}
                      />
                    </td>
                    <td>
                      <YsecFont className='yf-delete-bin-2' onClick={() => removeEntryHobby(index)} /></td>
                  </tr>
                ))}
                {/* Show add new row only if allowed by the logic above */}
                {(() => {
                  const hobbies = props.hobbies;
                  if (hobbies.length === 0) return (
                    <tr><td colSpan={12} className='addrow' onClick={addEntryHobby}>Click here to add new row</td></tr>
                  );
                  if (hobbies.length === 1) {
                    const first = hobbies[0];
                    if (first.hobbie) {
                      return <tr><td colSpan={12} className='addrow' onClick={addEntryHobby}>Click here to add new row</td></tr>;
                    }
                    return null;
                  }
                  const last = hobbies[hobbies.length - 1];
                  if (last.hobbie) {
                    return <tr><td colSpan={12} className='addrow' onClick={addEntryHobby}>Click here to add new row</td></tr>;
                  }
                  return null;
                })()}
              </tbody>
            </table>
          </div>
        </Col>
      </Row>
    </div>
  );
};

