import React, { useCallback, useEffect, useRef, useState } from 'react'
import AxiosLayout from '../../../apis/axios';
import { Breadcrumb, Card, Col, Form, Modal, Row } from 'react-bootstrap';
import Webcam from "react-webcam";
import { CustomModal } from '../CustomModal';
import { CustomViewDocModal } from '../CustomDocViewModal';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecCountrySelect = React.lazy(() =>
    import("Layout/YsecCountrySelect2")
);
interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

export enum RefTableIDs {
    Select = 0,
    Relation = 1,
    MaritalStatus = 2,
    PenaltyTypes = 3,
    ExtraPaymentTypes = 4,
    PersCmntTypes = 5,
    Qualification = 6,
    OverTimeTypes = 7,
}
export enum DocumentType {
    EmpRegistration = 1,
    EmpLeave = 2,
    EmpException = 3,
    EmpContract = 5,
    EmpWarning = 6,
    EmpInsurance = 7,
    EmpFoodHandler = 9,
    EmpPersonalComments = 10
}

export const EmployeeDetails: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [candidatesData, setCandidatesData] = useState<any[]>([])
    const [qualData, setQualData] = useState<any[]>([])
    const [MaritalStatusData, setMaritalStatusData] = useState<any[]>([])
    const [countriesData, setCountriesData] = useState<any[]>([])
    const [recruitData, setRecruitData] = useState<any[]>([])
    const [empRelation, setEmpRelation] = useState<any[]>([])
    const imgUploadRef = useRef<HTMLInputElement>(null);
    const fileref = useRef<HTMLInputElement | any>(null)
    const [open, setOpen] = useState<boolean>(false)
    const [addName, setAddName] = useState<string>("")
    const [titledialog, setTitleDialog] = useState<string>("")
    const [addType, setAddType] = useState<number>(0)
    const [customData, setCustomData] = useState<any[]>([])
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [showDocs, setShowDocs] = useState<boolean>(false)
    const [docData, setDocData] = useState<any[]>([])
    // web cam /////////////
    const [showWebcam, setShowWebcam] = useState<boolean>(false);
    const [webcamDevices, setWebcamDevices] = useState<any[]>([]);
    const [selectedDevice, setSelectedDevice] = useState<any>(null);
    const webcamRef = useRef<HTMLInputElement | any>(null);
    const videoConstraints = {
        deviceId: selectedDevice ? { exact: selectedDevice } : undefined,
        width: { ideal: 190 },
        height: { ideal: 190 },
    };

    const capture = useCallback(async () => {
        if (webcamRef.current) {
            const photoSrc = webcamRef.current.getScreenshot();
            props?.setPhoto(photoSrc);
        }

    }, [webcamRef]);

    const handleSelectDevice = (event: any) => {
        setSelectedDevice(event.target.value);
    };

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => {
        if (navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) {
            navigator.mediaDevices
                .enumerateDevices()
                .then((devices) => {
                    const webcamDevices = devices.filter(
                        (device) => device.kind === "videoinput"
                    );
                    setWebcamDevices(webcamDevices);
                    // Set the selected device to the first webcam found by default (optional)
                    if (webcamDevices.length > 0) {
                        setSelectedDevice(webcamDevices[0].deviceId);
                    }
                })
                .catch((err) => console.error("Error enumerating devices:", err));
        } else {
            console.error("enumerateDevices is not supported in this browser.");
        }
    }, []);

    useEffect(() => {
        // Get access to the webcam stream using getUserMedia and videoConstraints
        if (selectedDevice) {
            navigator.mediaDevices
                .getUserMedia({ video: videoConstraints })
                .then((stream) => {
                    if (webcamRef.current) {
                        webcamRef.current.srcObject = stream;
                    }
                })
                .catch((err) => console.error("Error accessing webcam:", err));
        }
    }, [selectedDevice, videoConstraints]);

    // //////////////////
    useEffect(() => {
        getEmpCommonData()
        getDocData()
    }, [])

    useEffect(() => {
        if (addType !== 0) {
            setOpen(false)
            getGeneralData()
        }
    }, [addType])

    const getGeneralData = () => {
        AxiosLayout.get(`/Employee/GetGeneralDataTypes?tableid=${addType}&CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setCustomData(res.data)
                setOpen(true)
            }

        })
    }

    const getEmpCommonData = () => {
        AxiosLayout.get(`/Employee/GetEmployeeCommonData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                if (res.data.Countries !== null) {
                    setCountriesData(res.data.Countries)
                }
                if (res.data.MaritalStatuses !== null) {
                    setMaritalStatusData(res.data.MaritalStatuses)
                }
                if (res.data.Qualifications !== null) {
                    setQualData(res.data.Qualifications)
                }
                if (res.data.RecruitedBy !== null) {
                    setRecruitData(res.data.RecruitedBy)
                }
                if (res.data.candfromrec !== null) {
                    setCandidatesData(res.data.candfromrec)
                }
                if (res.data.EmpRelations !== null) {
                    setEmpRelation(res.data.EmpRelations)
                }
            }
        })

    }
    const getDocData = () => {
        AxiosLayout.get(`/Common/GetDocumentDetails?EmployeeId=${props?.selectedEmpId}&DocTypeId=${DocumentType?.EmpRegistration}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setDocData(res?.data)
            }
        })
    }
    const onChange = (e: any) => {
        const { name, value } = e.target
        props?.setUser({ ...props?.user, [name]: value })
    }

    const onChangeFun = (e: any) => {
        const { name, value } = e.target
        props?.setUser({ ...props?.user, [name]: value?.value })
    }

    const handleUploadPhoto = async (e: any) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                const base64String = reader.result;

                props?.setPhoto(base64String);
            };
            reader.readAsDataURL(file);
        } else {
            console.log("No file selected.");
        }
    }

    const fileUpload = async (e: any) => {

        var arr = [];
        for (var i = 0; i < e.target.files.length; i++) {
            var type = e.target.files[i].type;

            // Filter for specific file types (optional)
            // if (type === "image/jpeg" || type === "image/jpg" || type === "image/png") {
            const doc = e.target.files[i];
            arr?.push(doc);
            // } else {
            //   alert("Please select only JPEG, JPG, PNG Images..");
            // }
        }

        // Update the files state
        props.setDocs([...props.docs, ...arr]);
    };

    const handleFileChange = (e: any) => {
        const selectedFiles = Array.from(e.target.files);
        props?.setFiles([...props.files, ...selectedFiles]);
        // \\192.168.248.197\Share\VigneshG\Suribet\EMP_CONTRACT
    };

    const handleDrop = (e: any) => {
        e.preventDefault();
        const droppedFiles = Array.from(e.dataTransfer.files);
        props?.setFiles((prevFiles: any) => [...prevFiles, ...droppedFiles]);
        props?.setOver(false);
    };

    const handleRemoveFile = (index: number) => {
        const newFiles = [...props.files];
        newFiles.splice(index, 1);
        props?.setFiles(newFiles);
    };
    const openModal = (index: number) => {
        props.setCurrentIndex(index);

        const currentFile = props.files[index];

        if (currentFile.type.includes("text")) {
            // Read text files
            const reader = new FileReader();
            reader.onload = (e: any) => props.setDocumentContent(e.target.result); // Store text content
            reader.readAsText(currentFile);
        } else if (currentFile.type.includes("pdf")) {
            // For PDFs, no additional processing is needed
            props.setDocumentContent(""); // Clear content for unsupported or non-text files
        } else {
            props.setDocumentContent(""); // Clear content for unsupported or non-text files
        }

        props.setModalOpen(true);
    };

    const closeModal = () => {
        props.setModalOpen(false);
        props.setDocumentContent("");
    };

    const nextFile = () => {
        props.setCurrentIndex((prevIndex: any) => (prevIndex + 1) % props.files.length);
    };

    const prevFile = () => {
        props.setCurrentIndex((prevIndex: any) => (prevIndex - 1 + props.files.length) % props.files.length);
    };

    const handleMultipleDelete = () => {
        const newFiles = props?.files.filter((_: any, index: number) => !props?.selectedFiles.includes(index));
        props?.setFiles(newFiles);
        props?.setSelectedFiles([]); // Clear selected files after deletion
    };

    const toggleFileSelection = (index: number) => {
        if (props?.selectedFiles.includes(index)) {
            props?.setSelectedFiles(props?.selectedFiles.filter((i: any) => i !== index)); // Deselect file
        } else {
            props?.setSelectedFiles([...props?.selectedFiles, index]); // Select file
        }
    };
    const filteredFiles = props?.files.filter((file: any) =>
        file.name.toLowerCase().includes(props?.searchTerm.toLowerCase())
    );

    const handleSelectAll = () => {
        if (props?.selectAll) {
            props?.setSelectedFiles([]); // Deselect all
        } else {
            const filteredIndexes = filteredFiles.map((_: any, index: number) => index);
            props?.setSelectedFiles(filteredIndexes); // Select all filtered files
        }
        props?.setSelectAll(!props?.selectAll); // Toggle the select-all checkbox state
    };

    const handleRetake = (e: any) => {
        e.preventDefault()
        props?.setPhoto("")
    }
    const handleUploadButtonClick = () => {
        imgUploadRef.current?.click();
    };
    const handleUploadFileButtonClick = () => {
        fileref.current?.click();
    };

    return (

        <div className='p-1 formsheight'>
            <Row className="p-1 pb-3 part-1">
                <Col xs={12} md={6} lg={3} >
                    <YsecSelect
                        className={`md ${props?.selectedEmpId !== 0 && "disableField"}`}
                        name="cand_id"
                        objectNameKey="candidate_name"
                        objectValueKey="candidate_id"
                        data={[
                            ...candidatesData?.map(i => ({
                                candidate_id: i?.CandidateID,
                                candidate_name: i?.Description
                            }))
                        ]}
                        value={props?.user.cand_id}
                        onChange={onChange}
                        label="Candidate"
                        disabled={props?.selectedEmpId !== 0}
                    />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecSelect
                        className="md"
                        name="title"
                        objectNameKey="title_name"
                        objectValueKey="title_id"
                        data={[
                            { title_id: "", title_name: "Select Title" },
                            { title_id: "Mr", title_name: "Mr" },
                            { title_id: "Ms", title_name: "Ms" },

                        ]}
                        value={props?.user.title}
                        onChange={onChange}
                        label="Title"
                        mandatory
                    />
                    {props.err === 1 && <label className='error'>Select Title...</label>}
                </Col>

                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="fname" value={props?.user.fname} onChange={onChange} placeholder="Enter First Name" className="md" label="First Name"
                        mandatory />
                    {props.err === 2 && <label className='error'>Enter Your First Name ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="lname" value={props?.user.lname} onChange={onChange} placeholder="Enter Last Name" className="md" label="Last Name"
                        mandatory />
                    {props.err === 3 && <label className='error'>Enter Your Last Name ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="govtid" value={props?.user.govtid} onChange={onChange} placeholder="Enter Govt. ID" className="md" label="Govt. ID"
                        mandatory />
                    {props.err === 4 && <label className='error'>Enter Your Govt. ID ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecDatePicker
                        name="idValidDate"
                        value={props?.idValidDate}
                        className="md"
                        label="ID Valid Date"
                        error="test message"
                        // onChange={onChangeDate}
                        onChange={async (e) => await props.setIdValidDate(e.target.value)}
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="1000_Y"
                        ysecMaxDate="1000_Y"
                        placeholder="DD-MM-YYYY"
                        wrapperClass
                        multipleSelect={false}
                    />

                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="nationality" value={props?.user.nationality} onChange={onChange} placeholder="Enter Nationality" className="md" label="Nationality"
                    />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="religion" value={props?.user.religion} onChange={onChange} placeholder="Enter Religion" className="md" label="Religion"
                    />
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecDatePicker
                        name="dob"
                        value={props?.dob}
                        className="md"
                        placeholderText="Select Date"
                        label="Date of Birth"
                        mandatory
                        error="test message"
                        onChange={(e) => props?.setDob(e.target.value)}
                        placeholder="DD-MM-YYYY"
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="1000_Y"
                        ysecMaxDate="1000_Y"
                    />
                    {props.err === 5 && <label className='error'>Select Your Date of Birth ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecDatePicker
                        name="actualDob"
                        value={props?.actualDob}
                        className="md"
                        placeholderText="Select Date"
                        label="Actual DOB"
                        error="test message"
                        onChange={(e) => props?.setActualDob(e.target.value)}
                        placeholder="DD-MM-YYYY"
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="1000_Y"
                        ysecMaxDate="1000_Y"
                    />
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecInput type="number" name="phone" value={props?.user.phone} onChange={onChange} placeholder="Enter Phone" className="md" label="Phone" />
                    {/* <YsecCountrySelect
                        label="Phone"
                        selection="code"
                        error="test message"
                        id="testID"
                        placeholder="Enter Phone"
                        activePhoneCode="91"
                        name="phone"
                        value={props?.user.phone}
                        onChange={(val: any) => onChangeFun({ target: { name: "phone", value: val } })}                  
                    /> */}
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecInput type="number" name="mobile" value={props?.user.mobile} onChange={onChange} placeholder="Enter Mobile Number" className="md" label="Mobile Number" mandatory />

                    {/* <YsecCountrySelect
                        label="Mobile Number"
                        selection="code"
                        error="test message"
                        id="testID"
                        placeholder="Enter Mobile Number"
                        activePhoneCode="91"
                        name="mobile"
                        value={props?.user.mobile}
                        mandatory
                        onChange={(val: any) => onChangeFun({ target: { name: "mobile", value: val } })}
                    /> */}
                    {props.err === 6 && <label className='error'>Enter Your Mobile Number ...</label>}

                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecInput type="number" name="emergency_num" value={props?.user.emergency_num} onChange={onChange} placeholder="Enter Emergency Number" className="md" label="Emergency Number" />

                    {/* <YsecCountrySelect
                        label="Emergency Number"
                        selection="code"
                        error="test message"
                        id="testID"
                        placeholder="Enter Emergency Number"
                        activePhoneCode="91"
                        name="emergency_num"
                        value={props?.user.emergency_num}
                        onChange={(val: any) => onChangeFun({ target: { name: "emergency_num", value: val } })}
                    /> */}
                </Col>

                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="email" value={props?.user.email} onChange={onChange} placeholder="Enter Email" className="md" label="Email"
                    />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecSelect
                        className="md"
                        name="marital_status"
                        objectNameKey="status_name"
                        objectValueKey="status_id"
                        data={[
                            ...MaritalStatusData.map(i => ({
                                status_id: i.MaritalStatusId,
                                status_name: i.MaritalStatusName
                            }))

                        ]}
                        value={props?.user.marital_status}
                        onChange={onChange}
                        label="Marital Status"
                        mandatory
                    />
                    {props.err === 7 && <label className='error'>Select Your Marital Status ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecDatePicker
                        name="mar_date"
                        value={props?.mar_date}
                        className="md"
                        placeholderText="Select Date"
                        label="Marriage Date"
                        error="test message"
                        onChange={(e) => props?.setMarDate(e.target.value)}
                        placeholder="DD-MM-YYYY"
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="100_Y"
                        ysecMaxDate="1000_Y"

                    />
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecDatePicker
                        name="date_of_employment"
                        value={props?.date_of_employment}
                        className="md"
                        placeholderText="Select Date"
                        label="Date of Employement"
                        error="test message"
                        onChange={(e) => props?.setDateOfEmployement(e.target.value)}
                        placeholder="DD-MM-YYYY"
                        ysecType="tab"
                        ysecFormat="D-MM-YYYY"
                        ysecMinDate="100_Y"
                        ysecMaxDate="1000_Y"
                        mandatory
                    />
                    {props.err === 16 && <label className='error'>Select Your Date of Employement ...</label>}
                </Col>

                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="job_title" value={props?.user.job_title} onChange={onChange} placeholder="Enter Job Title" className="md" label="Job Title" mandatory
                    />
                    {props.err === 18 && <label className='error'>Enter Job Title ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecSelect
                        className="md"
                        name="recruited_by"
                        objectNameKey="rec_name"
                        objectValueKey="rec_id"
                        data={[
                            ...recruitData.map(i => ({
                                rec_id: i.Id,
                                rec_name: i.Description
                            }))
                        ]}
                        value={props?.user.recruited_by}
                        onChange={onChange}
                        label="Recruited By"
                    />
                </Col>
                <Col xs={12} md={6} lg={3} className='d-flex'>
                    <div className='jobselect me-1'>
                        <YsecSelect
                            className="md"
                            name="qualification"
                            objectNameKey="qual_name"
                            objectValueKey="qual_id"
                            data={[
                                ...qualData.map(i => ({
                                    qual_id: i.QualificationId,
                                    qual_name: i.QualificationName
                                }))
                            ]}
                            value={props?.user.qualification}
                            onChange={onChange}
                            label="Qualification (Highest)"
                        />
                    </div>
                    <div className='mt-4'>
                        <YsecButton type='button' onClick={() => {
                            setTitleDialog("Qualifications")
                            setAddName("Description")
                            // setOpen(true)
                            setAddType(RefTableIDs?.Qualification)
                        }} className='cancel' >
                            <YsecFont className='yf-plus-add' />
                        </YsecButton></div>
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecSelect
                        className="md"
                        name="country"
                        objectNameKey="country_name"
                        objectValueKey="country_id"
                        data={[

                            ...countriesData.map(i => ({
                                country_id: i.CountryId,
                                country_name: i.CountryName
                            }))

                        ]}
                        value={props?.user.country}
                        onChange={onChange}
                        label="Country"
                        mandatory
                    />
                    {props.err === 13 && <label className='error'>Select Your Country ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="place_of_birth" value={props?.user.place_of_birth} onChange={onChange} placeholder="Enter Place of Birth" className="md" label="Place of Birth" />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="district" value={props?.user.district} onChange={onChange} placeholder="Enter Place/District" className="md" label="Place/District" />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecInput type="text" name="relation" value={props?.user.relation} onChange={onChange} placeholder="Enter Father/Husband" className="md" label="Father/Husband" />
                </Col>

                <Col xs={12} md={6} lg={3} >

                    <YsecTextarea type="text" name="diseases" value={props?.user.diseases} onChange={onChange} placeholder="Enter Diseases" className="md" label="Diseases" />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecTextarea type="text" name="allergies" value={props?.user.allergies} onChange={onChange} placeholder="Enter Allergies" className="md" label="Allergies" />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecTextarea type="text" name="police_remarks" value={props?.user.police_remarks} onChange={onChange} placeholder="Enter Police Remarks" className="md" label="Police Remarks" />
                </Col>
                <Col xs={12} md={6} lg={3} >

                    <YsecTextarea type="text" name="address" value={props?.user.address} onChange={onChange} placeholder="Enter Address" className="md" label="Address" mandatory />
                    {props.err === 23 && <label className='error'>Enter Your Address ...</label>}
                </Col>
                <Col xs={12} md={6} lg={3} >
                    <YsecInput type="text" name="blood_group" value={props?.user.blood_group} onChange={onChange} placeholder="Enter Blood Group" className="md" label="Blood Group" />
                </Col>
                {userId?.companyId === 78 && <>
                    <Col xs={12} md={6} lg={3} >
                        <YsecInput type="text" name="bill_weight" value={props?.user.bill_weight} onChange={onChange} placeholder="Enter Billing Weightage" className="md" label="Billing Weightage" />
                    </Col>
                    <Col xs={12} md={6} lg={3} >
                        <YsecInput type="number" name="notice_period" value={props?.user.notice_period} onChange={onChange} placeholder="Enter Notice Period" className="md" label="Notice Period" />
                    </Col>
                    <Col xs={12} md={6} lg={3} >
                        <YsecDatePicker
                            name="carrer_start_date"
                            value={props?.carrer_start_date}
                            className="md"
                            label="Career Start Date"
                            error="test message"
                            onChange={(e) => props?.setCareerStartDate(e.target.value)}
                            placeholder="DD-MM-YYYY"
                            ysecType="tab"
                            ysecFormat="D-MM-YYYY"
                            ysecMinDate="100_Y"
                            ysecMaxDate="1000_Y"                            
                        />
                    </Col>
                    <Col xs={12} md={6} lg={3} >
                        <YsecDatePicker
                            name="resign_date"
                            value={props?.resign_date}
                            className="md"
                            label="Resign Date"
                            error="test message"
                            onChange={(e) => props?.setResignDate(e.target.value)}
                            placeholder="DD-MM-YYYY"
                            ysecType="tab"
                            ysecFormat="D-MM-YYYY"
                            ysecMinDate="100_Y"
                            ysecMaxDate="1000_Y"                            
                        />
                    </Col>
                    <Col xs={12} md={6} lg={3} >
                        <YsecInput type="text" name="aadhar_no" value={props?.user.aadhar_no} onChange={onChange} placeholder="Enter Aadhar Number" className="md" label="Aadhar Number" />
                    </Col>
                </>}
            </Row>
            <Row className="p-1 ps-0 pb-3 mt-2">
                <Col xs={12} lg={4} xl={2} className='data_size'>
                    <Row>
                        <Col xs={6} className='mb-1'>
                            <p>Driving Licence</p>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            {/* (See <attachments> above for file contents. You may not need to search or read the file again.) */}
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="driving_licence"
                                        value={"true"}
                                        checked={props?.user.driving_licence === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="driving_licence"
                                        value={"false"}
                                        checked={props?.user.driving_licence === "false"}
                                        onChange={onChange}
                                    /> No
                                </div></div>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <p>Drug Test</p>
                        </Col>
                        <Col xs={6} className='mb-1' >
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="drug_test"
                                        value={"true"}
                                        checked={props?.user.drug_test === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="drug_test"
                                        value={"false"}
                                        checked={props?.user.drug_test === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <p>SOR</p>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="SOR"
                                        value={"true"}
                                        checked={props?.user.SOR === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="SOR"
                                        value={"false"}
                                        checked={props?.user.SOR === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                    </Row>

                </Col>
                <Col xs={12} lg={4} xl={2} className='data_size'>
                    <Row>
                        <Col xs={6} className='mb-1'>
                            <p>Own Transport</p>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="own_transport"
                                        value={"true"}
                                        checked={props?.user.own_transport === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="own_transport"
                                        value={"false"}
                                        checked={props?.user.own_transport === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <p>Medical History</p>
                        </Col>
                        <Col xs={6} className='mb-1'  >
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="medical_history"
                                        value={"true"}
                                        checked={props?.user.medical_history === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="medical_history"
                                        value={"false"}
                                        checked={props?.user.medical_history === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <p>Police Clearance</p>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="police_clearance"
                                        value={"true"}
                                        checked={props?.user.police_clearance === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="police_clearance"
                                        value={"false"}
                                        checked={props?.user.police_clearance === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                    </Row>

                </Col>
                <Col xs={12} lg={4} xl={2} className='data_size'>
                    <Row>
                        <Col xs={6} className='mb-1'>
                            <p>Stil Being Treated</p>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="still_being_treated"
                                        value={"true"}
                                        checked={props?.user.still_being_treated === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="still_being_treated"
                                        value={"false"}
                                        checked={props?.user.still_being_treated === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <p>CBB Extract</p>
                        </Col>
                        <Col xs={6} className='mb-1' >
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="cbbextract"
                                        value={"true"}
                                        checked={props?.user.cbbextract === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="cbbextract"
                                        value={"false"}
                                        checked={props?.user.cbbextract === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <p>Badge</p>
                        </Col>
                        <Col xs={6} className='mb-1'>
                            <div className="d-flex p-1 bordercolor justify-content-evenly justify-content-lg-start">
                                <div className='me-1'>
                                    <input
                                        type="radio"
                                        name="badge"
                                        value={"true"}
                                        checked={props?.user.badge === "true"}
                                        onChange={onChange}
                                    /> Yes
                                </div>
                                <div className='ms-1'>
                                    <input
                                        type="radio"
                                        name="badge"
                                        value={"false"}
                                        checked={props?.user.badge === "false"}
                                        onChange={onChange}
                                    /> No
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Col>
                <Col xs={12} lg={12} xl={6} className='data_size'>
                    <Row>
                        <Col xs={12} md={4}>
                            <div className='d-flex align-items-center h-100 justify-content-center bordercolor'>
                                {props?.photo ? (
                                    <img src={props?.photo} width={"190px"} />
                                ) : showWebcam ? (
                                    <Webcam
                                        ref={webcamRef}
                                        audio={false}
                                        screenshotFormat="image/jpeg"
                                        videoConstraints={videoConstraints}
                                    />
                                ) : (
                                    <div className='d-flex align-items-center h-100'>
                                        <p className='text-center mb-0 p-5'>No Image Data</p>
                                    </div>
                                )}
                            </div>
                        </Col>
                        <Col xs={12} md={4}>
                            <Row>
                                {showWebcam ? (
                                    <>
                                        <Col xs={12}>
                                            <YsecButton className='mt-1 mb-1 w-100 cancel' onClick={(e: any) => {
                                                handleRetake(e)
                                                capture();

                                            }}>Capture</YsecButton>
                                        </Col>
                                        <Col xs={12}>
                                            <YsecButton className='mt-1 mb-1 w-100' type="button" onClick={() => setShowWebcam(false)}>
                                                Cancel
                                            </YsecButton>
                                        </Col></>
                                ) :
                                    <Col xs={12}><YsecButton className='mt-1 mb-1 w-100 cancel' onClick={(e => {
                                        setShowWebcam(true);
                                    })}>Webcam</YsecButton></Col>}
                                <Col xs={12}>

                                    <YsecButton className='mt-1 mb-1 w-100 cancel' onClick={handleUploadButtonClick}>
                                        Upload Photo
                                    </YsecButton>
                                    <input
                                        ref={imgUploadRef}
                                        type="file"
                                        // multiple
                                        accept=".jpg,.jpeg,.png"
                                        style={{ display: 'none' }}
                                        onChange={handleUploadPhoto}
                                    />
                                </Col>
                            </Row>
                        </Col>
                        <Col xs={12} md={4}>
                            <Row>
                                <Col xs={12}><YsecButton className='mt-1 mb-1 w-100 cancel' >Scan</YsecButton></Col>
                                <Col xs={12}>
                                    <YsecButton className='mt-1 mb-1 w-100 cancel' type='button' onClick={handleUploadFileButtonClick}>
                                        Upload File
                                    </YsecButton>
                                    <input
                                        ref={fileref}
                                        type="file"
                                        // multiple
                                        accept=".pdf,.doc,.docx"
                                        style={{ display: 'none' }}
                                        onChange={handleFileChange}
                                    />
                                </Col>
                                <Col xs={12}><YsecButton className='mt-1 mb-1 w-100 cancel' type='button' onClick={() => { setShowDocs(true) }}>View Doc</YsecButton></Col>
                            </Row></Col>

                    </Row>
                </Col>


            </Row>
            {open === true && (
                <CustomModal open={open} setOpen={setOpen} title={titledialog} addName={addName} setAddName={setAddName} data={customData} type={addType} setAddType={setAddType} getJobCommonData={getGeneralData} setAlertMessage={setAlertMessage} alertMessage={alertMessage} errorMessage={errorMessage} setErrorMessage={setErrorMessage} />

            )}
            {showDocs === true && <CustomViewDocModal open={showDocs} setOpen={setShowDocs} data={docData} />}
        </div>
    );
};

