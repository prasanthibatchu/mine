import React, { useEffect, useRef, useState } from "react";
import "./Teams.scss";
import { useEdgesState } from "reactflow";
import AxiosLayout from "../../apis/axios";

import { Accordion, Breadcrumb, Col, Row } from "react-bootstrap";
import { DraggableUser } from "./Teams";

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));



export const EmpData: React.FC<any> = (props) => {
    const [searchText, setSearchText] = useState<string>("");
    const [filteredAssignedEmployees, setFilteredAssignedEmployees] = useState(props?.empData?.filter((i: any) => i.Teams && i.Teams.trim() !== ""));
    const [filteredUnassignedEmployees, setFilteredUnassignedEmployees] = useState(props?.empData?.filter((i: any) => !i.Teams || i.Teams.trim() === ""));

    useEffect(() => {
        setFilteredAssignedEmployees(props?.empData?.filter((i: any) => i.Teams && i.Teams.trim() !== ""));
        setFilteredUnassignedEmployees(props?.empData?.filter((i: any) => !i.Teams || i.Teams.trim() === ""));
    }, [props?.empData]);
    // Update filtered employees when search text changes
    useEffect(() => {
        handleFilter();
    }, [searchText, props.empData]);
    const handleFilter = () => {
        if (searchText.trim() === "") {
            // Show all employees if search text is empty
            setFilteredAssignedEmployees(props?.empData?.filter((i: any) => i.Teams && i.Teams.trim() !== ""));
            setFilteredUnassignedEmployees(props?.empData?.filter((i: any) => !i.Teams || i.Teams.trim() === ""));
        } else {
            // Filter employees based on search text
            const assignedFiltered = props?.empData?.filter((i: any) =>
                (i.Teams && i.Teams.trim() !== "") &&
                i.FullName.toLowerCase().includes(searchText.toLowerCase())
            );
            const unassignedFiltered = props?.empData?.filter((i: any) =>
                (!i.Teams || i.Teams.trim() === "") &&
                i.FullName.toLowerCase().includes(searchText.toLowerCase())
            );
            setFilteredAssignedEmployees(assignedFiltered);
            setFilteredUnassignedEmployees(unassignedFiltered);
        }
    };

    return (

        <div className='emp-teamdata'>
            <div className="d-flex">
                <div className="w-100 me-1">
                    <YsecInput
                        placeholder="Search"
                        className="w-100 sm"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                        name="searchText"
                        type="search" icon='yf-search'
                    />
                </div>
                </div>
              <div className="pt-1 pb-1">
                  <Accordion>
                <Accordion.Item eventKey="0">
                        <Accordion.Header>Assigned Employees</Accordion.Header>
                        <Accordion.Body className='empfildata'> 
                             {filteredAssignedEmployees.length > 0 ? (
                                filteredAssignedEmployees.map((i:any) => (
                                    <DraggableUser key={i.EmployeeId} user={i} chartContactIds={props.chartContactIds} nodes={props.nodes} activeTab={props?.activeTab}  isOrgChart={props?.isOrgChart}  setIsIsOrgChart={props?.setIsIsOrgChart} nodeData={props?.nodeData}  nodesc={props?.nodes} nodeLength={props?.nodeLength}  taegetTeam={props?.taegetTeam}>
                                        <div key={i.EmployeeId} className='mt-2 mb-2 d-flex align-items-start'>
                                            {/* Employee Image */}
                                            <img
                                                src={`data:image/png;base64,${i.EmployeeImage}`}
                                                className='empimg me-2'
                                                alt="Employee"
                                            />
                                            {/* Employee Details */}
                                            <div className='flex-grow-1'>
                                                <p className='mb-0 fw-bold'>{i.FullName}</p>
                                                <p className='mb-0'>Employee Id: {i.EmployeeId}</p>
                                                <p className='mb-0'>{i.Position}</p>
                                            </div>
                                            {/* Team Count */}
                                            <div className='d-flex justify-content-end align-items-center'>
                                                <p className='mb-0'>
                                                    {i.Teams.split(',').length} Teams
                                                </p>
                                            </div>
                                        </div>
                                    </DraggableUser>
                                ))
                            ) : (
                                <p className='text-muted'>No assigned employees found.</p>
                            )}
                        </Accordion.Body>
                    </Accordion.Item>
                    <Accordion.Item eventKey="1">
                        <Accordion.Header>Unassigned Employees</Accordion.Header>
                        <Accordion.Body>
                            {filteredUnassignedEmployees.length > 0 ? (
                                filteredUnassignedEmployees.map((i:any) => (
                                    <DraggableUser key={i.EmployeeId} user={i} chartContactIds={props.chartContactIds} nodes={props.nodes}  activeTab={props?.activeTab} isOrgChart={props?.isOrgChart}  setIsIsOrgChart={props?.setIsIsOrgChart} nodeData={props?.nodeData}  nodesc={props?.nodes} nodeLength={props?.nodeLength}  taegetTeam={props?.taegetTeam}>
                                        <div key={i.EmployeeId} className='mt-2 mb-2 d-flex align-items-start'>
                                            {/* Employee Image */}
                                            <img
                                                src={`data:image/png;base64,${i.EmployeeImage}`}
                                                className='empimg me-2'
                                                alt="Employee"
                                            />
                                            {/* Employee Details */}
                                            <div className='flex-grow-1'>
                                                <p className='mb-0 fw-bold'>{i.FullName}</p>
                                                <p className='mb-0'>Employee Id: {i.EmployeeId}</p>
                                                <p className='mb-0'>{i.Position}</p>
                                            </div>
                                        </div>
                                    </DraggableUser>
                                ))
                            ) : (
                                <p className='text-muted'>No unassigned employees found.</p>
                            )}
                        </Accordion.Body>
                    </Accordion.Item>
                    </Accordion>
                </div>

        </div>
    );
};

