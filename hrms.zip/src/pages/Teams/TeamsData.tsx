import React, { useEffect, useRef, useState } from "react";
import "./Teams.scss";
import { useEdgesState } from "reactflow";
import AxiosLayout from "../../apis/axios";

import { Breadcrumb, Col, Row } from "react-bootstrap";
import { DraggableUser } from "./Teams";

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));



export const TeamsData: React.FC<any> = (props) => {
    const [searchText, setSearchText] = useState<string>("");
    const [filteredTeams, setFilteredTeams] = useState<any[]>([]);
    useEffect(() => {
        setFilteredTeams(props.teamlist);
    }, [props.teamlist]);
    useEffect(() => {
        handleFilter()
    }, [searchText])
    const handleFilter = () => {
        if (searchText === "") {
            setFilteredTeams(props?.teamlist);
        } else {
            const filtered = props?.teamlist?.filter((team: any) =>
                team.TeamName.toLowerCase().includes(searchText.toLowerCase())
            );
            setFilteredTeams(filtered);
        }
    };

    return (

        <>
            <div className="d-flex">
                <div className="w-100 me-1">
                    <YsecInput
                        placeholder="Search"
                        className="w-100 sm"
                        value={searchText}
                        onChange={(e) => setSearchText(e.target.value)}
                        name="searchText"
                        type="search" icon='yf-search'
                    />
                </div>
                {/* <YsecButton className="sm" type="button" onClick={handleFilter}>
                    Find
                </YsecButton> */}
            </div>

            <div className="mt-3 pb-1 emp-teamdata">
                {filteredTeams?.length > 0 ? (
                    <ul className="team-list listdata" >
                        {filteredTeams.map((i, index) => (
                            <li key={i?.TeamId} className='mb-1' >
                                <DraggableUser key={i?.TeamId} user={i} chartContactIds={props.chartContactIds} nodes={props.nodes} activeTab={props?.activeTab} isOrgChart={props?.isOrgChart}  setIsIsOrgChart={props?.setIsIsOrgChart} setSelectTeamId={props?.setSelectTeamId} setSelectedTeamName={props?.setSelectedTeamName} setTeamTypeId={props?.setTeamTypeId} nodeData={props?.nodeData} nodesc={props?.nodes} nodeLength={props?.nodeLength} taegetTeam={props?.taegetTeam}>
                                    <YsecButton
                                        type="button"
                                        className="w-100 teamsbtn"
                                        onClick={() => {
                                            props.setSelectTeamId(i?.TeamId);
                                            props?.setSelectedTeamName(i?.TeamName);
                                            props?.setTeamTypeId(i?.TypeId)
                                            props?.setIsIsOrgChart(i?.IsOrgChart)
                                        }}

                                    >

                                        <img
                                            src={`data:image/png;base64,${i?.EmployeeImage}`}
                                            className='empimg me-2'
                                            alt="Employee"
                                        />
                                        {/* Employee Details (expanded to fill space) */}
                                        <div className='flex-grow-1'>
                                            <p className='mb-0 fw-bold'>{i?.TeamName}</p>
                                            <p className='mb-0 fw-normal'>{i?.FullName}</p>
                                            <p className='mb-0 fw-normal'>{i?.Position}</p>

                                        </div>
                                        {/* Team Count (pushed to the end) */}
                                        <div className='d-flex justify-content-end align-items-center'>
                                            <p className='mb-0 '>
                                                {i?.TypeName}
                                            </p>
                                        </div>



                                    </YsecButton>
                                </DraggableUser>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p className="text-muted">No teams found.</p>
                )}

            </div>
        </>
    );
};

