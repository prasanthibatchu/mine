// Extend window type for React Flow instance
declare global {
    interface Window {
        __reactFlowInstance?: any;
    }
}
import React, { use, useCallback, useEffect, useRef, useState } from "react";
import "./Teams.scss";
import ReactFlow, { addEdge, applyEdgeChanges, applyNodeChanges, Controls, useEdgesState, useNodesState } from "reactflow";
import AxiosLayout from "../../apis/axios";
import { DndProvider, useDrag, useDrop } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
import { Breadcrumb, Col, Modal, Row, Tab, Tabs } from "react-bootstrap";
import { TeamsHistory } from "./TeamsHistory";
import { TeamsData } from "./TeamsData";
import { EmpData } from "./EmpData";
import "reactflow/dist/style.css";
import LoadingSpinner from "../Loader/Loader";

const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
// const DRAG_TYPE = "EMPLOYEE";
export const DRAG_TYPE = "ORG_USER_OR_TEAM";
interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}
function buildLevelMap(nodes: any) {
    const levelMap: any = {};
    nodes?.forEach((member: any) => {
        const parentId = member?.ParentId || 0;
        if (!levelMap[parentId]) {
            levelMap[parentId] = [];
        }
        levelMap[parentId].push(member);
    });
    return levelMap;
}

function calculateSubtreeWidths(levelMap: any, parentId: any) {
    const members = levelMap[parentId] || [];
    if (members.length === 0) return 1;
    let totalWidth = 0;
    members?.forEach((member: any) => {
        member.subtreeWidth = calculateSubtreeWidths(levelMap, member.ContactId);
        totalWidth += member.subtreeWidth;
    });
    return totalWidth;
}

function positionNodes(levelMap: any, parentId: any, level: any, xOffset: any, spacingX: any, spacingY: any, margin: any, newNodes: any, newEdges: any, parentNodeId: any = null) {
    const members = levelMap[parentId] || [];
    let currentX = xOffset;
    members.forEach((member: any) => {
        const subtreeWidth = member.subtreeWidth || 1;
        const visualWidth = subtreeWidth * spacingX + Math.max(0, subtreeWidth - 1) * margin;
        const nodeX = currentX + visualWidth / 2 - spacingX / 2;
        const nodeY = level * spacingY;
        newNodes.push({
            ...member,
            id: `${member.ContactId}`,
            position: { x: nodeX, y: nodeY },
            data: { ...member.data },
        });
        if (parentNodeId) {
            newEdges.push({
                id: `e${parentNodeId}-${member.ContactId}`,
                source: `${parentNodeId}`,
                target: `${member.ContactId}`,
                type: "smoothstep",
            });
        }
        positionNodes(
            levelMap,
            member.ContactId,
            level + 1,
            currentX,
            spacingX,
            spacingY,
            margin,
            newNodes,
            newEdges,
            member.ContactId
        );
        currentX += visualWidth + margin;
    });
}

function relayout(nodes: any, setNodes: any, setEdges: any) {
    const levelMap = buildLevelMap(nodes);
    calculateSubtreeWidths(levelMap, 0);
    const newNodes: any = [];
    const newEdges: any = [];
    const spacingX = 200, spacingY = 200, margin = 60;
    positionNodes(levelMap, 0, 0, 0, spacingX, spacingY, margin, newNodes, newEdges);
    setNodes(newNodes);
    setEdges(newEdges);
}
const getNodeLevel: any = (contactId: any, nodes: any) => {
    const node = nodes.find((n: any) => n.ContactId === contactId);
    if (!node || !node.ParentId || node.ParentId === 0) return 0;
    const parentNode = nodes.find((n: any) => n.ContactId === node.ParentId);
    if (!parentNode) return 0;
    return 1 + getNodeLevel(parentNode.ContactId, nodes);
};
export const DraggableUser = ({ user, chartContactIds, nodes, children, activeTab, isOrgChart, setIsIsOrgChart, nodeData, nodesc, nodeLength, setSelectTeamId, setSelectedTeamName, setTeamTypeId, taegetTeam }: {
    user: any, chartContactIds: any, nodes: any, children?: React.ReactNode, activeTab: any, isOrgChart: boolean, setIsIsOrgChart: boolean, nodeData: any, nodesc: any, nodeLength: number, taegetTeam?: any, setSelectTeamId?: (id: number) => void,
    setSelectedTeamName?: (name: string) => void, setTeamTypeId?: (typeId: number) => void
}) => {

    const [alertMsg, setAlertMsg] = useState<string>("");
    const selectIsOrgChart = nodeData?.IsOrgChart ?? false
    const selectTypeId = nodeData?.TypeId ?? 0
    const [{ isDragging }, drag, preview] = useDrag(() => ({
        type: DRAG_TYPE,
        item: () => {
            const draggedEmp = { ...user, TypeId: user.TypeId ?? 0, IsOrgChart: user?.IsOrgChart ?? false };

            // Employees tab: always show message
            if (activeTab === "employee") {

                if (nodeLength !== 0 && !isOrgChart && draggedEmp.TypeId === 1) {
                    setAlertMsg("Please drag team to build Organization hierarchy")
                    return;
                }
                if (nodeLength !== 0 && !isOrgChart && draggedEmp.IsOrgChart && draggedEmp.TypeId !== 1) {
                    setAlertMsg("Please drag team to build Organization hierarchy");
                    return;
                }
                if (nodeLength !== 0 && selectTypeId === 0 && draggedEmp.TypeId === 3) {
                    setAlertMsg("Invalid drop");
                    return;
                }
                if (taegetTeam?.TypeId === 2 && draggedEmp.TypeId === 0) {
                    return;
                }
            }

            // Teams tab logic
            if (activeTab === "teams") {
                // Only allow TypeId 1 (Company) to be dragged in Teams tab, not in Employees tab
                if (draggedEmp.TypeId === 1 && activeTab !== "teams") {
                    setAlertMsg("Please drag team to build Organization hierarchy");
                    return;
                }
                if (selectTypeId === 1 && draggedEmp.IsOrgChart && draggedEmp.TypeId !== 1) {
                    setAlertMsg("Please drag team to build Organization hierarchy");
                    return;
                }
                // If isOrgChart true and dragging TypeId 2 (Org Chart), show message
                if (nodeLength == 0 && draggedEmp.IsOrgChart && draggedEmp.TypeId !== 1) {
                    setAlertMsg("Please drag Company to start Organization hierarchy");
                    return;
                }
                if (taegetTeam?.TypeId === 3 && draggedEmp.TypeId !== 0) {
                    setAlertMsg("Please drag team to build Organization hierarchy");
                    return;
                }
                if (taegetTeam?.TypeId === 2 && draggedEmp.TypeId !== 3) {
                    return;
                }

                // If dragging TypeId 3 (Teams), must have mandatory drop of TypeId 2 (Org Chart)
                if (draggedEmp.TypeId === 3) {

                    if (nodeLength === 0 && selectTypeId !== 1) {
                        setAlertMsg("Please drag Company to start Organization hierarchy");
                        return;
                    }
                }
                if (draggedEmp.TypeId !== 3) {
                    // If selected node is TypeId 3 and dragging item is TypeId 3, show invalid drop
                    if (selectTypeId === 1 && draggedEmp.TypeId !== 3) {
                        return;
                    }

                }


                if (taegetTeam?.TypeId === 3 && draggedEmp.TypeId === 3) {
                    setAlertMsg("Invalid drop");
                    return;
                }
                else if (taegetTeam?.TypeId === 1 && draggedEmp.TypeId !== 3) {
                    setAlertMsg("Invalid drop");
                    return;
                }
            }

            return draggedEmp;
        },
        collect: (monitor) => ({
            isDragging: !!monitor.isDragging(),
        }),
    }), [user, isOrgChart, nodeLength, selectTypeId, taegetTeam]);
    let level = null;
    if (chartContactIds?.has(user.ContactId) && nodes) {
        level = getNodeLevel(user.ContactId, nodes);
    }

    return (<>

        <Row ref={drag} onDoubleClick={() => {
            if (activeTab === "teams") {
                setSelectTeamId?.(user?.TeamId);
                setSelectedTeamName?.(user?.TeamName);
                setTeamTypeId?.(user?.TypeId);
            }
        }}
            className={`dragcards ${isDragging ? " dragged" : ""} ${chartContactIds?.has(user.ContactId) ? " in-org-chart" : ""} d-flex align-items-center ps-0 pe-0 me-0 ms-0`}
        >
            <Col xs={1} sm={1} md={1} lg={1} className="d-flex align-items-center">
                <YsecFont className="yf-drag dragimg" />
            </Col>
            <Col xs={2} sm={2} md={2} lg={2} className="d-flex align-items-center">
                <img
                    src={`data:image/png;base64,${user.EmployeeImage}`}
                    className='empimg2 me-2'
                    alt="Employee"
                />
            </Col>
            <Col xs={5} sm={5} md={4} lg={4} className="d-flex align-items-center">
                {activeTab === "employee" && <><div className="ps-1">
                    <p className="mb-0 fw-bold textsize">{user.FullName}</p>
                    <p className="mb-0 textsize"><span className="textcol">Employee ID:</span> {user.EmployeeId}</p>
                    <p className="mb-0 textsize">{user.Position}</p>

                </div> </>}
                {activeTab === "teams" && <><div className="ps-1">
                    <p className="mb-0 fw-bold textsize">{user.TeamName}</p>
                    <p className="mb-0 textsize">{user.FullName}</p>
                    <p className="mb-0 textsize">{user.Position}</p>


                </div> </>}
            </Col>
            <Col xs={1} sm={1} md={2} lg={2} className="d-flex align-items-center p-0 m-0">
                {activeTab === "employee" && <>
                    {level !== null && (
                        <p className="mb-0 textsize3">
                            <b><span>Level:</span>{level}</b>
                        </p>
                    )}
                </>}
            </Col>
            <Col xs={2} sm={2} md={3} lg={3} className={`d-flex align-items-center justify-content-end ${activeTab === "employee" && 'teamcount'}`}>

                {activeTab === "teams" && <p className='mb-0 fw-normal textsize'>
                    {user?.TypeName}
                </p>}
                {activeTab === "employee" && <>
                    {user?.TeamCount === 0 ? <></> : <div>
                        {/* yf-family    2 persons    yf-user-single*/}
                        {user?.TeamCount === 1 && <YsecFont className=" yf-user-single textsize" />}
                        {user?.TeamCount > 1 && <YsecFont className="yf-announcement textsize2" />}


                        <p className="textsize">{user?.TeamCount}</p></div>}
                </>}


            </Col>
        </Row>

        <Modal show={!!alertMsg} onHide={() => setAlertMsg("")} centered>
            <Modal.Header closeButton>
                <Modal.Title>Alert</Modal.Title>
            </Modal.Header>
            <Modal.Body>{alertMsg}</Modal.Body>
            <Modal.Footer>
                <YsecButton type="button" onClick={() => setAlertMsg("")}>Close</YsecButton>
            </Modal.Footer>
        </Modal>
    </>)
}
const OrgChart = ({ nodes, setNodes, edges, setEdges, selectedNodeId, setSelectedNodeId, alertMsg, setAlertMsg, teamTypeId, activeTab, isOrgChart }: { nodes: any, setNodes: any, edges: any, setEdges: any, selectedNodeId: any, setSelectedNodeId: any, alertMsg: any, setAlertMsg: any, teamTypeId: number, activeTab: string, isOrgChart: boolean }) => {
    const [showModal, setShowModal] = useState<boolean>(false);
    const [showContent, setShowContent] = useState<string>("")
    const [actionModal, setActionModal] = useState<boolean>(false);
    const [currentItem, setCurrentItem] = useState<any>(null);
    const handleModal = () => { setShowModal(!showModal) }
    const handleActionModal = () => setActionModal(!actionModal);
     let isGroup=false
    const [, drop] = useDrop({
        accept: DRAG_TYPE,
        drop: (item: any, monitor: any) => {

            if (nodes.some((node: any) => node.ContactId === item.ContactId)) {
                setAlertMsg("This user already exists in the chart")
                return;
            }
            if (nodes.length === 0) {
                // No existing nodes, directly create a new node
                addNewNode(item, monitor);
                return;
            }
            // Check if a node is selected
            if (!selectedNodeId) {
                // alert("Please select a node to connect the dropped item.");
                handleModal()
                return;
            }
            const selectedNode = nodes.find((node: any) => node.id === selectedNodeId);
            if (!selectedNode) {
                handleModal()
                return;
            }


            setCurrentItem(item);
            setActionModal(true);
        },
    });
    const [alertMsge, setAlertMsge] = useState<string>("");
    const getNodeLevel: any = (node: any, nodes: any) => {
        if (!node || !node.ParentId || node.ParentId === 0) return 0;
        const parentNode = nodes.find((n: any) => n.ContactId === node.ParentId);
        if (!parentNode) return 0;
        return 1 + getNodeLevel(parentNode, nodes);
    };
    const performAction = (action: any) => {
        const selectedNode = nodes.find((node: any) => node.id === selectedNodeId);
        const isTopLevel = selectedNode?.ParentId === 0;
      
        switch (action) {
            case "parent":
                addParentNode(currentItem, selectedNode);
                break;
            case "child":
                addChildNode(currentItem, selectedNodeId);
                break;
            case "replace":
                replaceNode(currentItem, selectedNodeId);
                break;
            case "left":
                if (!isTopLevel) addSiblingNode(currentItem, selectedNodeId, 'left');
                break;
            case "right":
                if (!isTopLevel) addSiblingNode(currentItem, selectedNodeId, 'right');

                break;
            case "merge":
                mergeNodes(currentItem, selectedNodeId);
                break;
            default:
                // Cancel action
                break;
        }

        // Close the action modal
        setActionModal(false);
    };
const mergeNodes = (item: any, selectedNodeId: any) => {
    // 1. Find the selected node
    const selectedNode = nodes.find((n: any) => n.id === selectedNodeId);
// let isGroup=false;
    if (!selectedNode) return;

    // 2. Determine the group id
    const groupContactId = selectedNode.MergedContactId || selectedNode.ContactId;

    // 3. Find all current group members (keep their own ContactId, but same MergedContactId and ParentId)
    const groupedData = nodes.filter(
        (n: any) => n.MergedContactId === groupContactId || n.ContactId === groupContactId
    ).map((member: any) => ({
        ...member,
        // Ensure each member keeps its own ContactId
        ContactId: member.ContactId,
        MergedContactId: groupContactId,
        ParentId: selectedNode.ParentId ?? 0,
    }));

    // 4. Add the new member (with its own ContactId, same MergedContactId and ParentId)
    const newMember = {
        ...item,
        id: `${item.ContactId}`,
        ParentId: selectedNode.ParentId ?? 0,
        ContactId: item.ContactId,
        MergedContactId: groupContactId,
        LevelId: selectedNode.LevelId,
    };
    // Avoid duplicate ContactId in group
  const updatedMembers = [...groupedData.filter((m:any) => m.ContactId !== newMember.ContactId), newMember];

    // 5. Remove old group members from nodes
    const otherNodes = nodes.filter(
        (n: any) => !(n.MergedContactId === groupContactId || n.ContactId === groupContactId)
    );

 const mergedContactIdCounts: Record<string, number> = {};
    updatedMembers.forEach((m: any) => {
        mergedContactIdCounts[m.MergedContactId] = (mergedContactIdCounts[m.MergedContactId] || 0) + 1;
    });

    const updatedNodes = [
        ...otherNodes,
        ...updatedMembers.map((member: any) => {
            // If more than one member shares this MergedContactId, apply border
             isGroup = mergedContactIdCounts[member.MergedContactId] > 1;
            return {
                ...member,
                id: `${member.ContactId}`,
                ParentId: member.ParentId,
                ContactId: member.ContactId,
                MergedContactId: groupContactId,
                LevelId: member.LevelId,
                EmployeeImage: member.EmployeeImage,
                data: {
                    label: (
                        <div
                            // style={isGroup ? {
                            //     border: "2px solid #1976d2",
                            //     borderRadius: "12px",
                            //     padding: "6px",
                            //     boxShadow: "0 1px 4px rgba(25,118,210,0.12)",
                            //     margin: "2px"
                            // } : {}}
                        >
                            <img
                                src={`data:image/png;base64,${member.EmployeeImage}`}
                                className="empimg me-2"
                                alt={member.FullName}
                            />
                            <div className="m-0 p-2 cardstyle">
                                <p className="mb-0 p-1 fw-bold">{member.FullName}</p>
                                <p className="mb-0 p-1">{member.Position}</p>
                            </div>
                        </div>
                    ),
                },
            };
        })
    ];
    relayout(updatedNodes, setNodes, setEdges);
};
  
    const addParentNode = (item: any, selectedNode: any) => {
        // Find the selected node's previous parent id
        const prevParentId = selectedNode.ParentId || 0;
        const isRoot = prevParentId === 0;

        // Create new parent node (the dropped item)
        const newParent = {
            ...item,
            id: `${item.ContactId}`,
            ParentId: prevParentId, // If root, this is 0; otherwise, the old parent
            ContactId: item.ContactId,
            data: {
                label: (
                    <>
                        <img src={`data:image/png;base64,${item.EmployeeImage}`} className="empimg me-2" alt="Employee" />
                        <div className="m-0 p-2 cardstyle">
                            <p className="mb-0 p-1 fw-bold">{item.FullName}</p>
                            <p className="mb-0 p-1">{item.Position}</p>
                        </div>
                    </>
                ),
            },
        };

        // Update selected node to have new parent (the dropped item)
        const updatedNodes = nodes.map((n: any) => {
            if (n.id === selectedNode.id) {
                return { ...n, ParentId: newParent.ContactId };
            }
            return n;
        });

        // Add the new parent node to the list
        const allNodes = [...updatedNodes, newParent];

        // If you track level explicitly, recalculate levels here.

        // Now relayout the tree
        relayout(allNodes, setNodes, setEdges);
    };
    const addChildNode = (item: any, selectedId: any) => {
        const parentNode = nodes.find((n: any) => n.id === selectedId);
        const newNode = {
            ...item,
            id: `${item.ContactId}`,
            ParentId: parentNode.ContactId,
            ContactId: item.ContactId,
            data: {
                label: (
                    <>
                        <img src={`data:image/png;base64,${item.EmployeeImage}`} className="empimg me-2" alt="Employee" />
                        <div className="m-0 p-2 cardstyle">
                            <p className="mb-0 p-1 fw-bold">{item.FullName}</p>
                            <p className="mb-0 p-1">{item.Position}</p>
                        </div>
                    </>
                ),
            }
        };
        relayout([...nodes, newNode], setNodes, setEdges);
    };

    const replaceNode = (item: any, selectedId: any) => {
        const oldNode = nodes.find((node: any) => node.id === selectedId);
        if (!oldNode) return;

        // 1. Build new node with same ParentId as old node
        const newNode = {
            ...item,
            id: `${item.ContactId}`,
            ParentId: oldNode.ParentId,
            ContactId: item.ContactId,
            data: {
                label: (
                    <>
                        <img src={`data:image/png;base64,${item.EmployeeImage}`} className="empimg me-2" alt="Employee" />
                        <div className="m-0 p-2 cardstyle">
                            <p className="mb-0 p-1 fw-bold">{item.FullName}</p>
                            <p className="mb-0 p-1">{item.Position}</p>
                        </div>
                    </>
                ),
            }
        };

        // 2. Update children to point to new node as parent
        const updatedNodes = nodes.map((n: any) => {
            if (n.id === selectedId) {
                // Replace the node
                return newNode;
            }
            // Re-parent children
            if (n.ParentId === oldNode.ContactId) {
                return { ...n, ParentId: newNode.ContactId };
            }
            return n;
        });

        // 3. Re-layout as before
        relayout(updatedNodes, setNodes, setEdges);
    };

    const addSiblingNode = (item: any, selectedId: any, direction: any) => {
        const selectedNode = nodes.find((n: any) => n.id === selectedId);
        if (!selectedNode) return;

        // Find all siblings (including the selected node) with the same parent
        const siblings = nodes.filter((n: any) => n.ParentId === selectedNode.ParentId);

        // Find the index of the selected node among siblings
        const siblingIndexes = siblings.map((n: any) => n.id);
        const selectedIdx = siblingIndexes.indexOf(selectedId);

        // Prepare the new node
        const newNode = {
            ...item,
            id: `${item.ContactId}`,
            ParentId: selectedNode.ParentId,
            ContactId: item.ContactId,
            data: {
                label: (
                    <>
                        <img src={`data:image/png;base64,${item.EmployeeImage}`} className="empimg me-2" alt="" />
                        <div className="m-0 p-2 cardstyle">
                            <p className="mb-0 p-1 fw-bold">{item.FullName}</p>
                            <p className="mb-0 p-1">{item.Position}</p>
                        </div>
                    </>
                ),
            }
        };

        // Find all nodes with the same parent in the main nodes array
        const nodesClone = [...nodes];
        // Find indexes in the main nodes array of all siblings
        const mainSiblingIndexes = siblings.map((sibling: any) =>
            nodesClone.findIndex((n: any) => n.id === sibling.id)
        );
        const mainSelectedIdx = nodesClone.findIndex((n: any) => n.id === selectedId);

        // Decide where to insert
        let insertAt;
        if (direction === 'left') {
            // Insert before the selected node
            insertAt = mainSelectedIdx;
        } else {
            // Insert after the selected node (could be at the end)
            insertAt = mainSelectedIdx + 1;
        }
        nodesClone.splice(insertAt, 0, newNode);

        // Relayout
        relayout(nodesClone, setNodes, setEdges);
    };

    const addNewNode: any = (item: any) => {
        const newNode = {
            ...item,
            id: `${item.ContactId}`,
            ParentId: 0,
            ContactId: item.ContactId,
            data: {
                label: (
                    <>
                        <img src={`data:image/png;base64,${item.EmployeeImage}`} className="empimg me-2" alt="Employee" />
                        <div className="m-0 p-2 cardstyle">
                            <p className="mb-0 p-1 fw-bold">{item.FullName}</p>
                            <p className="mb-0 p-1">{item.Position}</p>
                        </div>
                    </>
                ),
            }
        };
        relayout([...nodes, newNode], setNodes, setEdges);
    };

    const onNodesChange = useCallback(
        (changes: any) => setNodes((nds: any) => applyNodeChanges(changes, nds)),
        [setNodes]
    );

    const onEdgesChange = useCallback(
        (changes: any) => setEdges((eds: any) => applyEdgeChanges(changes, eds)),
        [setEdges]
    );

    const onNodeClick = (event: any, node: any) => {
        setSelectedNodeId(node.id);
    };
    console.log(nodes)
    return (
        <>
            <div className="reactflowhh" ref={node => { drop(node); }}>
                {/* Add ref and onInit to get React Flow instance for fitView */}
                <ReactFlow
                    nodes={nodes}
  
                    edges={edges}
                    onNodesChange={onNodesChange}
                    onEdgesChange={onEdgesChange}
                    onNodeClick={onNodeClick}
                    fitView
                    onInit={instance => {
                        if (typeof window !== 'undefined') {
                            window.__reactFlowInstance = instance;
                        }
                    }}
                >
                    <Controls />
                </ReactFlow>
                {/* Fit view on node drop or node change */}
                {(() => {
                    // This effect runs after every node change to fit view
                    // Use a custom event to trigger fitView after node drop
                    React.useEffect(() => {
                        if (typeof window !== 'undefined' && window.__reactFlowInstance && nodes.length > 0) {
                            window.__reactFlowInstance.fitView({ padding: 0.2, duration: 500 });
                        }
                    }, [nodes]);
                    return null;
                })()}
            </div>
            <Modal show={showModal} onHide={handleModal} aria-labelledby="contained-modal-title-vcenter"
                centered>
                <Modal.Header closeButton>
                    <Modal.Title>Alert!</Modal.Title>
                </Modal.Header>
                <Modal.Body>Please select a node to connect the dropped item.</Modal.Body>
                <Modal.Footer>
                    <YsecButton type="button" onClick={handleModal}>
                        Close
                    </YsecButton>

                </Modal.Footer>
            </Modal>
            <Modal show={actionModal} onHide={handleActionModal} centered>
                <Modal.Header closeButton>
                    <Modal.Title><p style={{ fontSize: "small" }}>Please select the position you want to place</p></Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div className="d-flex justify-content-center mt-1">
                        <YsecButton type="button" className={`md  ${nodes.find((n: any) => n.id === selectedNodeId)?.TypeId === 1 && "disabledbtn"}`} onClick={() => {
                            performAction("parent")
                        }}
                            disabled={nodes.find((n: any) => n.id === selectedNodeId)?.TypeId === 1}
                        >
                            Top
                        </YsecButton>
                    </div>
                    <div className="d-flex d-flex justify-content-center align-items-center mt-2">
                        <YsecButton type="button" className={`md me-2 ${nodes.find((n: any) => n.id === selectedNodeId)?.ParentId === 0 && "disabledbtn"}`} onClick={() => performAction("left")} disabled={nodes.find((n: any) => n.id === selectedNodeId)?.ParentId === 0}>
                            Left
                        </YsecButton>
                        {(() => {
                            const selectedNode = nodes.find((n: any) => n.id === selectedNodeId);
                            if (selectedNode) {
                                // Try to get image from node data
                                let imgSrc = "";
                                if (selectedNode.EmployeeImage) {
                                    imgSrc = `data:image/png;base64,${selectedNode.EmployeeImage}`;
                                } else if (selectedNode.data && selectedNode.data.label && selectedNode.data.label.props) {
                                    // Try to extract from label if present
                                    const children = selectedNode.data.label.props.children;
                                    if (Array.isArray(children)) {
                                        const imgChild = children.find((c: any) => c && c.type === "img");
                                        if (imgChild && imgChild.props && imgChild.props.src) {
                                            imgSrc = imgChild.props.src;
                                        }
                                    }
                                }
                                return (
                                    <img
                                        src={imgSrc}
                                        alt={selectedNode.FullName}
                                        style={{ width: "25%" }}
                                         onClick={() => performAction("merge")}
                                    />
                                );
                            }
                            return null;
                        })()}
                        <YsecButton type="button" className={`md ms-1 ${nodes.find((n: any) => n.id === selectedNodeId)?.ParentId === 0 && "disabledbtn"}`} onClick={() => performAction("right")} disabled={nodes.find((n: any) => n.id === selectedNodeId)?.ParentId === 0}>
                            Right
                        </YsecButton>
                    </div>
                    <div className="d-flex justify-content-center mt-2">
                        <YsecButton type="button" className="md" onClick={() => performAction("child")}>
                            Bottom
                        </YsecButton>
                    </div>
                    <div className="d-flex justify-content-around mt-3">
                        <YsecButton type="button" className="md" onClick={() => performAction("replace")}>
                            Replace
                        </YsecButton>
                        <YsecButton type="button" className="md" onClick={handleActionModal}>
                            Cancel
                        </YsecButton>
                    </div>
                </Modal.Body>

            </Modal>
            <Modal show={!!alertMsge} onHide={() => setAlertMsge("")} centered>
                <Modal.Header closeButton>
                    <Modal.Title>Alert</Modal.Title>
                </Modal.Header>
                <Modal.Body>{alertMsge}</Modal.Body>
                <Modal.Footer>
                    <YsecButton type="button" onClick={() => setAlertMsge("")}>Close</YsecButton>
                </Modal.Footer>
            </Modal>
        </>
    )
}

const Teams: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [teamlist, setTeamList] = useState<any[]>([]);
    const [nodes, setNodes] = useNodesState<any>([]);
    const [edges, setEdges] = useEdgesState<any>([]);
    const [selectTeamId, setSelectTeamId] = useState<any>(null);
    const [selectedTeamName, setSelectedTeamName] = useState<string>("");
    const [empData, setEmpData] = useState<any[]>([]);
    const [alertMsg, setAlertMsg] = useState<string>("");
    const [alertSucMsg, setAlertSucMsg] = useState<string>("");
    const [open, setOpen] = useState<boolean>(true)
    const [activeTab, setActiveTab] = useState<string>("teams");
    const chartContactIds = new Set(nodes.map((n: any) => n.ContactId));
    const [selectedNodeId, setSelectedNodeId] = useState<any>(null);
    const [teamname, setTeamName] = useState<string>("")
    const printRef = useRef<HTMLDivElement | any>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const reactFlowInstanceRef = useRef<any>(null);
    const [teamTypeId, setTeamTypeId] = useState<number>(0)
    const [teamDatails, setTeamDetails] = useState<any[]>([])
    const [isOrgChart, setIsIsOrgChart] = useState<boolean>(false)
    const [nodeData, setNodeData] = useState<any>({})
    console.log(nodes,"***************************************")
    useEffect(() => {
        if (alertMsg) {
            const timer = setTimeout(() => {
                setAlertMsg('');
            }, 5000);
            return () => clearTimeout(timer);
        }
    }, [alertMsg]);
    useEffect(() => {
        if (alertSucMsg) {
            const timer = setTimeout(() => {
                setAlertSucMsg('');
            }, 5000);

            return () => clearTimeout(timer);
        }
    }, [alertSucMsg]);
    useEffect(() => {
        getEmpData();
        getTeamData();
    }, []);
    useEffect(() => {
        if (activeTab === "teams" && nodes.length > 0) {
            setTimeout(() => {
                reactFlowInstanceRef.current?.fitView({
                    padding: 0.4,
                    // duration: 800, // duration in milliseconds for smooth animation
                });
            }, 50);
        }
    }, [activeTab, nodes]);
    useEffect(() => {
        if (selectTeamId !== null) {
            if (teamTypeId !== 1) {
                getTeamDetails();
            }
        }
    }, [selectTeamId]);
    useEffect(() => {
        const ddata = nodes?.find((i: any) => i.ContactId == selectedNodeId)
        setNodeData(ddata)
    }, [selectedNodeId])

    const getEmpData = () => {
        setLoading(true)
        AxiosLayout.get(
            `/Team/GetEmployeeDetails?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data);
                setLoading(false)
            }
        });
    };
    const getTeamData = () => {
        setLoading(true)
        AxiosLayout.get(
            `/Team/GetTeamList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setTeamList(res.data);
                setLoading(false)
            }
        });
    };
    const getTeamDetails = () => {
        setLoading(true)

        AxiosLayout.get(
            `/Team/GetTeamDetails?TeamId=${selectTeamId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setTeamDetails(teamDatails)

                if (teamTypeId !== 1) {
                    const teamDetailss = res?.data?.Details;
                    const teamss=teamlist?.find((i:any)=>i.TeamId==selectTeamId)
                    console.log(teamss,"hiiiiiiiiiiii")
                    const dataa=teamDetailss.find((i:any)=>i.MergedContactId===teamss?.ContactId)
                    console.log(dataa,"sdf")
                    const nodesToBuild = teamDetailss?.map((member: any) => ({
                        id: `${member.ContactId}`,
                        FullName: member.FullName,
                        Position: member.Position,
                        Department: member.Department,
                        ParentId: member.ParentId,
                        ContactId: member.ContactId,
                        TypeId: member.TypeId,
                        MergedContactId:member?.MergedContactId,
                        EmployeeImage: member.EmployeeImage,
                        LevelId:member?.LevelId || 0,
                        data: {
                            label: (
                                <div style={{border:(dataa?.ContactId===member?.ContactId || teamss.ContactId==member?.ContactId) ? "2px solid #1976d2" : "none",borderRadius:"12px",padding:"6px",boxShadow:"0 1px 4px rgba(25,118,210,0.12)",margin:"2px"}}>
                                    <img
                                        src={`data:image/png;base64,${member.EmployeeImage}`}
                                        className="empimg me-2"
                                        alt="Employee"
                                    />
                                    <div className="m-0 p-2 cardstyle">
                                        <p className="mb-0 p-1 fw-bold">{member.FullName}</p>
                                        <p className="mb-0 p-1">{member.Position}</p>
                                    </div>
                                </div>
                            ),
                        },
                    }));
                    relayout(nodesToBuild, setNodes, setEdges);
                }
                setLoading(false)
            }
        });
    };

    const getDescendantNodeIds: any = (parentId: any, nodes: any) => {
        let descendants = [];
        const children = nodes.filter((node: any) => node.ParentId === nodes.find((n: any) => n.id === parentId)?.ContactId);
        for (const child of children) {
            descendants.push(child.id);
            descendants = descendants.concat(getDescendantNodeIds(child.id, nodes));
        }
        return descendants;
    };
    useEffect(() => {
        const handleKeyDown = (event: any) => {
            if (
                (event.key === "Delete" || event.key === "Backspace") &&
                selectedNodeId &&
                nodes.length > 0 &&
                open === false // Only when the diagram is open
            ) {
                // 1. Get all descendants of the selected node
                const descendantIds = getDescendantNodeIds(selectedNodeId, nodes);
                // 2. Prepare a set of all node ids to delete (selected + descendants)
                const allToDelete = new Set([selectedNodeId, ...descendantIds]);
                // 3. Remove all nodes and edges related to them
                setNodes(nds => nds.filter(node => !allToDelete.has(node.id)));
                setEdges(eds => eds.filter(edge => !allToDelete.has(edge.source) && !allToDelete.has(edge.target)));
                setSelectedNodeId(null);
            }
        };

        window.addEventListener("keydown", handleKeyDown);
        return () => window.removeEventListener("keydown", handleKeyDown);
    }, [selectedNodeId, nodes, edges, open, setNodes, setEdges]);
    const handlePrint = () => {
        window.print();
    };
    const handleSave = () => {
        const levelMap = new Map();
        levelMap.set(0, 0);

        const calculateLevelId: any = (nodeId: any) => {
            if (levelMap.has(nodeId)) {
                return levelMap.get(nodeId);
            }
            const parentEdge = edges.find((edge: any) => edge.target === nodeId);
            if (!parentEdge) {
                return 0;
            }
            const parentLevel = calculateLevelId(parentEdge.source);
            const currentLevel = parentLevel + 1;
            levelMap.set(nodeId, currentLevel);
            return currentLevel;
        };
        if (teamname === "" && selectedTeamName === "") {
            setAlertMsg("Enter Team Name..")
            return;
        }
        setLoading(true)
        const teamData = {
            teamId: selectTeamId || 0,
            teamName: selectedTeamName === "" ? teamname : selectedTeamName,
            tags: "",
            hierachyId: userId?.companyId,
            remarks: "",
            isActive: true,
            userId: userId?.user,
            details: nodes.map((node: any, index: number) => {

                const labelChildren = node.data.label.props.children;

                const fullName = labelChildren.find((child: any) => child.type === "strong")?.props.children || "";
                const position = labelChildren[labelChildren.length - 1] || "";
                const employeeImage = labelChildren.find((child: any) => child.type === "img")?.props.src || "";

                const levelId = calculateLevelId(node.id);

                return {
                    teamId: Number(selectTeamId) || 0,
                    teamNumber: index + 1,
                    contactId: node?.ContactId,
                    fullName: node.FullName,
                    parentId: node?.ParentId,
                    levelId: Number(levelId),
                    department: node?.Department,
                    position: node.Position,
                    employeeImage: employeeImage.slice(22),
                };
            }),
        };


        AxiosLayout.post("/Team/TeamTrans", teamData)
            .then((res: any) => {
                if (res.data.Status === 1) {
                    setAlertSucMsg(res.data.Message)
                    getEmpData();
                    getTeamData();
                    setActiveTab("teams")
                    setTeamName("")
                    setNodes([]);
                    setEdges([]);
                    setSelectedTeamName("")
                    setSelectedNodeId(null)
                    setSelectTeamId(null)
                    setLoading(false)
                }
            })

    };

    return (
        <DndProvider backend={HTML5Backend}>
            <div className="p-1">
                {loading === true && <LoadingSpinner show={loading} />}
                <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                    {alertMsg && (
                        <div className="alert alert-danger" role="alert">
                            {alertMsg}
                        </div>
                    )}
                    {alertSucMsg && (
                        <div className="alert alert-success" role="alert">
                            {alertSucMsg}
                        </div>
                    )}
                    {open === true ? <TeamsHistory setActiveTab={setActiveTab} setSelectTeamId={setSelectTeamId} selectTeamId={selectTeamId} setSelectedTeamName={setSelectedTeamName} setOpen={setOpen} /> :
                        <>
                            <div className="header d-flex row flex-wrap">
                                <div className="col">
                                    <Breadcrumb>
                                        <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                                        <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
                                        <Breadcrumb.Item active>Teams</Breadcrumb.Item>
                                    </Breadcrumb>
                                </div>
                                <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                                    <YsecButton type="button" className={`sm btn leave ${open ? "btn-outline-primary" : "history"} `} onClick={() => setOpen(false)}>
                                        <YsecFont className='yf-plus-add' />
                                    </YsecButton>
                                    <YsecButton type="button" className={`sm  ${open === false ? "btn-outline-primary" : "history"}`} onClick={() => setOpen(true)}>
                                        <YsecFont className="yf-clock" />
                                    </YsecButton>
                                    <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                                        <YsecFont className="yf-printer-scan" />
                                    </YsecButton>
                                </div>
                            </div>

                            <div >

                                <div className="teamcontainer">

                                    <Row>
                                        <Col xs={12} md={7} lg={8}>
                                            <Row>
                                                <Col xs={12} className="d-flex">
                                                    <h6 className="textcolor">Team Name:</h6>
                                                    {selectedTeamName !== "" ? (
                                                        <YsecInput
                                                            name="selectedTeamName"
                                                            value={selectedTeamName}
                                                            disabled
                                                            className="sm ms-3 me-3"
                                                            placeholder="Team Name"
                                                        />
                                                    ) : (
                                                        <YsecInput
                                                            name="teamname"
                                                            value={teamname}
                                                            onChange={(e) => setTeamName(e.target.value)}
                                                            mandatory
                                                            className="sm ms-3 me-3"
                                                            placeholder="Enter Team Name"
                                                        />
                                                    )}

                                                </Col>
                                            </Row>
                                            <div className="tabsheight print-chart-area" ref={printRef} >



                                                <OrgChart
                                                    // nodes={nodes}
                                                    nodes={nodes.map((node) => ({
                                                        ...node,
                                                        className: node.id === selectedNodeId ? "selected-node" : "default-node", // Add className based on selection
                                                    }))}
                                                    setNodes={setNodes}
                                                    edges={edges}
                                                    setEdges={setEdges}
                                                    selectedNodeId={selectedNodeId}
                                                    setSelectedNodeId={setSelectedNodeId}
                                                    alertMsg={alertMsg} setAlertMsg={setAlertMsg}
                                                    teamTypeId={teamTypeId}
                                                    activeTab={activeTab}
                                                    isOrgChart={isOrgChart}
                                                />



                                            </div>
                                            <div className={"d-flex justify-content-end"}>
                                                {/* {selectedTeamName == "" && <div className="w-100"><YsecInput name="" value={teamname} onChange={(e) => setTeamName(e.target.value)} mandatory className="w-100" label="Team Name" placeholder="Enter Team Name" /></div>} */}
                                                <YsecButton className={`m-1 mt-3`} type="button" onClick={handleSave}>Save</YsecButton>
                                                <YsecButton className="m-1 mt-3 cancel" type="button" onClick={() => {
                                                    setNodes([]);
                                                    setEdges([])
                                                    setSelectedTeamName("")
                                                    setSelectTeamId(null)
                                                    setTeamName("")
                                                    setSelectedNodeId(null)
                                                    setTeamTypeId(0)
                                                }}>Clear</YsecButton>

                                            </div>

                                        </Col>

                                        <Col xs={12} md={5} lg={4}>
                                            <YsecInput label="Company" mandatory value={userId?.company} className="sm" />
                                            <Tabs
                                                activeKey={activeTab}
                                                onSelect={(k: any) => setActiveTab(k)}
                                                className="mb-3 mt-3"
                                            >
                                                <Tab eventKey="employee" title={
                                                    <span>
                                                        <YsecFont className="yf-user-multiple pe-1" />
                                                        Members
                                                    </span>}>
                                                    <EmpData empData={empData} chartContactIds={chartContactIds} nodes={nodes} activeTab={activeTab} isOrgChart={isOrgChart} setIsIsOrgChart={setIsIsOrgChart} nodeData={nodeData} nodeLength={nodes?.length} taegetTeam={teamlist.find((i: any) => i.TeamId == selectTeamId)} />
                                                </Tab>
                                                <Tab eventKey="teams"

                                                    title={
                                                        <span>
                                                            <YsecFont className="yf-work-order pe-1" />
                                                            Teams
                                                        </span>
                                                    }
                                                >
                                                    <TeamsData teamlist={teamlist} setSelectTeamId={setSelectTeamId} selectTeamId={selectTeamId} setSelectedTeamName={setSelectedTeamName} teamTypeId={teamTypeId} setTeamTypeId={setTeamTypeId} chartContactIds={chartContactIds} activeTab={activeTab} isOrgChart={isOrgChart} setIsIsOrgChart={setIsIsOrgChart} nodeData={nodeData} nodes={nodes} nodeLength={nodes?.length} taegetTeam={teamlist.find((i: any) => i.TeamId == selectTeamId)} />
                                                </Tab>
                                            </Tabs>
                                        </Col>

                                    </Row>
                                </div>
                            </div>
                        </>}
                </React.Suspense>
            </div>
        </DndProvider>
    );
};
export default Teams;
