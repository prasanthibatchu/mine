import React, { useEffect, useRef, useState } from "react";
import "./Teams.scss";
import { useEdgesState } from "reactflow";
import AxiosLayout from "../../apis/axios";

import { Breadcrumb, Col, Row } from "react-bootstrap";
import LoadingSpinner from "../Loader/Loader";

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}





export const TeamsHistory: React.FC<any> = (props) => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const printRef = useRef<HTMLDivElement | any>(null);
 const [teamdata, setTeamData] = useState<any[]>([]);
  const [teamDetails, setTeamDetails] = useState<any[]>([]);
  const [selectedTeamId, setSelectedTeamId] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<any>(null);

  useEffect(() => {
    getData()
  }, []);

  const getData = async () => {
    setLoading(true)
    const res = await AxiosLayout(`/Team/GetAllTeams?CompanyId=${userId?.companyId}&UserId=${userId?.user}`);
    if (res.status === 200) {
      if (res?.data?.Table !== null) {
        setTeamData(res?.data?.Table)
      }
      if (res?.data?.Table1 !== null) {
        setTeamDetails(res?.data?.Table1)
      }
      setLoading(false)
    }
  }
  // if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  const handleEdit = (id:number, name:string) => {
    props.setSelectTeamId(Number(id))
    props?.setSelectedTeamName(name)
    props.setActiveTab("employee")
    props?.setOpen(false)

  }
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow: any = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Teams History</title>');
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (

        <div className="p-2">
                 {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className="header d-flex row flex-wrap">
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
                            <Breadcrumb.Item active>Teams</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm btn leave ${props?.open === true ? "history" : "btn-outline-primary"} `} onClick={() => props?.setOpen(false)}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <YsecButton type="button" className={`sm  ${props?.open === false ? "btn-outline-primary" : "history"}`} onClick={() => props?.setOpen(true)}>
                            <YsecFont className="yf-clock" />
                        </YsecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                  <div className='bg-white mt-2 p-2' ref={printRef}>
                     <Row>
          <Col xs={12} md={4}>
            {/* <React.Suspense fallback={<>Loading...</>}> */}
              <YsecSelect
                className="md"
                name="selectTeam"
                objectNameKey="TeamName"
                objectValueKey="TeamId"
                data={[
                  { TeamId: 0, TeamName: "Select" },
                  ...teamdata?.map(i => ({
                    TeamId: i?.TeamId,
                    TeamName: i?.TeamName
                  }))
                ]}
                value={selectedTeamId || 0}
                onChange={e => {
                  const value = Number(e.target.value);
                  setSelectedTeamId(value !== 0 ? value : null);
                }}
                label="Team"
                mandatory
              />
            {/* </React.Suspense> */}
          </Col>
          <Col xs={12} md={5}></Col>
          <Col xs={12} md={3} className='d-flex align-items-center justify-content-center justify-content-md-end pe-5'>
            <p className='filterclear mb-0' onClick={() => {
              setSelectedTeamId(null);
            }}>Clear filters</p>
          </Col>
          </Row>
          <div className='katableee mt-2 '>
          <table>
            <thead>
              <tr>
                <th></th>
                <th>Team Name</th>
                <th>Created On</th>
                <th>Created By</th>
                <th>Team Strength</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {teamdata?.map((i) => (
                <React.Fragment key={i.TeamId}>
                  <tr className='dataaa'
                  >
                    <td className='editaction'>
                      <YsecFont
                        className={selectedTeamId === i.TeamId ? "yf-chevron-down iconss" : "yf-chevron-right iconss"}
                        onClick={() =>
                          setSelectedTeamId(
                            selectedTeamId === i.TeamId ? null : i.TeamId
                          )
                        }
                      />

                    </td>
                    <td>{i.TeamName}</td>
                    <td>{i.CreatedOn}</td>
                    <td>{i.CreatedBy}</td>
                    <td>{i.TeamStrength} Members</td>
                    <td className='editaction'> <YsecFont className="yf-pen iconss" onClick={() => handleEdit(i.TeamId, i.TeamName)} /></td>
                  </tr>
                  {selectedTeamId === i.TeamId && (
                    <tr>
                      <td colSpan={1}></td>
                      <td colSpan={11} >
                        <table className="details-table" >
                          <thead>
                            <tr>
                              <th>Member Name</th>
                              <th>Designation</th>
                              <th>Employee Id</th>
                              <th>Created On</th>
                              <th>Team Level</th>
                              <th>Reporting To</th>
                              <th>Last Activity</th>
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {teamDetails
                              .filter(t => t.TeamId === i.TeamId)
                              .map((member, idx) => (
                                <tr key={member.EmployeeId || idx}>
                                  <td className={member.Status === "InActive" ? 'strike-inactive' : undefined}>{member.MemberName}</td>
                                  <td className={member.Status === "InActive" ? 'strike-inactive' : undefined}>{member.Position}</td>
                                  <td className={member.Status === "InActive" ? 'strike-inactive' : undefined}>{member.EmployeeId}</td>
                                  <td className={member.Status === "InActive" ? 'strike-inactive' : undefined}>{member.CreatedOn}</td>
                                  <td className={member.Status === "InActive" ? 'strike-inactive' : undefined}>{member.TeamLevel}</td>
                                  <td className={member.Status === "InActive" ? 'strike-inactive' : undefined}>{member.ReportingTo}</td>
                                  <td className={member.Status === "InActive" ? 'strike-inactive' : undefined}>{member.LastActivity}</td>
                                  <td><p className={member.Status==="InActive" ?"inactivestatus mb-0 d-flex align-items-center justify-content-center":"activestatus mb-0 d-flex align-items-center justify-content-center"}>{member.Status}</p></td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </td>
                    </tr>
                  )}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
                  </div>
            </React.Suspense>
        </div>
    );
};

