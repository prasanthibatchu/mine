import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from 'jodit-react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const LeaveBalance: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const [selectedPosition, setSelectedPosition] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const tableRef = useRef<any>(null);
    const [leaveBalanceData, setLeaveBalanceData] = useState<any[]>([])
    const [columns, setColumns] = useState<any[]>([])
    const [printData, setPrintData] = useState<boolean>(false)
    const editor = useRef<any>(null);
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }
                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }

    const handlegetData = () => {
        const payload = {
            companyId: userId?.companyId,
            departmentId: selectedDept,
            positionId: selectedPosition,
            employeeId: selectEmp,
            fromDate: selectedDate,
            toDate: selectedDate,
            userId: userId?.user,
            brandId: selectedBrand,
            locationId: locationId,
            //   currencyCode: string
        }

        if (locationId == 4) {
            setLoading(true)
            AxiosLayout.post("/EmployeeReport/GetCurrentLeaveBalance_ForCasino", payload).then((res: any) => {
                if (res.status === 200) {
                    if (res?.data?.Table && res?.data?.Table.length > 0) {
                        setLeaveBalanceData(res?.data?.Table);
                        const firstRow = res.data.Table[0];
                        const dynamicColumns = Object.keys(firstRow).map((key) => ({
                            id: key,
                            header: key,
                            filter: true,
                            size: 158,
                        }));
                        setColumns(dynamicColumns);
                        setLoading(false)

                    } else {
                        setLeaveBalanceData([]);
                        setColumns([]);
                        setLoading(false)

                    }
                }
            })
        }
        else {
            setLoading(true)
            AxiosLayout.post("/EmployeeReport/GetCurrentLeaveBalance", payload).then((res: any) => {
                if (res.status === 200) {
                    if (res?.data?.Table && res?.data?.Table.length > 0) {
                        setLeaveBalanceData(res?.data?.Table);
                        const firstRow = res.data.Table[0];
                        const dynamicColumns = Object.keys(firstRow).map((key) => ({
                            id: key,
                            header: key,
                            filter: true,
                            size: 158,
                        }));
                        setColumns(dynamicColumns);
                        setLoading(false)


                    } else {
                        setLeaveBalanceData([]);
                        setColumns([]);
                        setLoading(false)



                    }
                }

            })
        }
    }

    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };
    const exportDataAsExcel = () => {
        if (leaveBalanceData.length === 0) {
            alert("No data to export.");
            return;
        }

        const worksheet = XLSX.utils.json_to_sheet(leaveBalanceData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Leave Balance");

        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'LeaveBalance.xlsx');
    };
    const exportEditorContentAsExcel = () => {
        if (!editor.current) {
            alert("Editor is not ready.");
            return;
        }

        const html = editor.current?.value;
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const tables = doc.querySelectorAll('table');

        if (!tables.length) {
            alert("No tables found.");
            return;
        }

        let mergedSheet: any = {};
        let sheetRowOffset = 0;

        tables.forEach((table, index) => {
            const sheet = XLSX.utils.table_to_sheet(table, { raw: true });

            // Copy each row and cell to the merged sheet with row offset
            Object.keys(sheet).forEach((key) => {
                if (key === '!ref') return;
                const cell = sheet[key];
                const cellRef = XLSX.utils.decode_cell(key);
                const newCellRef = XLSX.utils.encode_cell({ c: cellRef.c, r: cellRef.r + sheetRowOffset });
                mergedSheet[newCellRef] = cell;
            });

            const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
            sheetRowOffset += range.e.r + 2; // Add empty line between tables
        });

        // Calculate new sheet range
        mergedSheet['!ref'] = XLSX.utils.encode_range({
            s: { c: 0, r: 0 },
            e: { c: 10, r: sheetRowOffset }
        });

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, mergedSheet, 'Staff List');

        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'LeaveBalance.xlsx');
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Leave Balance</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All Departments" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)} defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "Select Position" },
                                    ...positionsData?.filter((j: any) => j.DepartmentId == selectedDept)?.map((i: any) => ({
                                        id: i?.PostionId,
                                        Name: i?.Position
                                    }))
                                ]}
                                value={selectedPosition}
                                onChange={(e) => setSelectedPosition(e.target.value)} defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "Select Employee" },
                                    ...empData?.filter(j => j.EmploymentStatus === "Active" && j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName   
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDatePicker
                                name="selectedDate"
                                value={selectedDate}
                                className="md"
                                placeholderText="Select Date"
                                error="test message"
                                onChange={(e) => setSelectedDate(e.target.value)}
                                placeholder="DD-MM-YYYY"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-D"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecButton type='button' className={"w-100"} onClick={() => {
                                setPrintData(false)
                                handlegetData()
                            }}>Show</YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end'>

                            <YsecButton onClick={() => {
                                setPrintData(true)
                                handlegetData()
                            }}
                                className={`w-100`}
                                type="button"

                            >
                                Print
                            </YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end  csv'>

                            <YsecButton
                                className={`w-100 ${leaveBalanceData.length === 0 ? "disbutn" : ""}`}
                                type="button"
                                onClick={exportDataAsExcel}
                                // onClick={() => { if (printData === true) { exportEditorContentAsExcel() } else { exportDataAsExcel() } }}
                                disabled={leaveBalanceData.length === 0}
                            >
                                Export
                            </YsecButton>
                        </Col>
                    </Row>


                    <div className='mt-2'>

                        {printData === false ?
                            <div className='katable '>

                                {leaveBalanceData?.length > 0 && columns?.length > 0 && (

                                    <YsecTable
                                        rowData={leaveBalanceData}
                                        columnDefs={columns}
                                        filter={true}
                                        pagination={true}
                                        tableRef={tableRef}
                                        pageSize={20}
                                        dragColumnDisable={true}
                                        reRender={true}

                                    />
                                )}
                            </div>
                            :
                            <>
                                <Row>
                                    <Col xs={0} lg={2}></Col>
                                    <Col xs={12} lg={8}>

                                        <JoditEditor
                                            ref={editor}
                                            value={`      
                                             <div >
                                             <div style="display: flex;  justify-items: end;">    
                               
                                <h6 style="width:55%;text-align:end"  class="stafftitle">${userId?.company}</h6>
                                 <p  style="width:45%;text-align:end">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                </div>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" >Employee's Current Leave Balance</h5>
                                </div>            
                                <div class="katableee">       
                                             <table width="100%" border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; font-size: 12px;">
                                            <thead>
                                                <tr>
                                                <th colSpan="3" style="border:none !important;background-color:unset !important"></th>
                                                <th colSpan="2">Earned Leaves</th>
                                                <th colSpan="2">Sold</th>
                                                <th colSpan="2">Taken</th>
                                                <th colSpan="1"  style="border:none !important;background-color:unset !important"></th>
                                                </tr>
                                                <tr>
                                               <th>EmpId</th>
                                               <th>Name</th>
                                               <th>DOE</th>
                                               <th>Annual</th>
                                               <th>Holiday(DIL)</th>
                                               <th>Annual</th>
                                               <th>Holiday(DIL)</th>
                                                <th>Annual</th>
                                               <th>Holiday(DIL)</th>
                                               <th>Leave Bal</th>
                                                </tr>
                                            </thead>
                                            ${leaveBalanceData?.length !== 0 ? `<tbody>
                                                ${leaveBalanceData.map(row => `
                                                <tr>
                                                   <td>${row?.EmployeeId}</td>
                                                   <td>${row?.EmployeeName}</td>
                                                   <td>${row?.JoinDate}</td>
                                                   <td>${row?.EarnedLeaves}</td>
                                                   <td>${row?.HolidaysLeaveBalance}</td>
                                                   <td>${row?.SoldLeave}</td>
                                                   <td>${row?.SoldHoliday}</td>
                                                   <td>${row?.LeavesTaken}</td>
                                                   <td>${row?.HolidayLeave}</td>
                                                   <td>${row?.CurrentLeaveBalance}</td>
                                                </tr>
                                                `).join('')}
                                            </tbody>`
                                                    :
                                                    `<tbody><tr><td colSpan="10">No Results Found</td></tbody>`}
                                            </table>                       
                                                      
                                               </div>         
                                            `}
                                            config={config}

                                        />
                                    </Col>
                                    <Col xs={0} lg={2}></Col>
                                </Row>

                            </>}
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}

export default LeaveBalance;