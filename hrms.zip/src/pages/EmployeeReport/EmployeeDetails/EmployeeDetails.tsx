import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const EmployeeDetails: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const tableRef = useRef<any>(null);
    const tableRef2 = useRef<any>(null);
    const tableRef3 = useRef<any>(null);
    const [contractData, setContractData] = useState<any[]>([])
    const [contractColumn, setContractColumn] = useState<any[]>([])
    const [leaveData, setLeaveData] = useState<any[]>([])
    const [leaveColumn, setLeaveColumn] = useState<any[]>([])
    const [familyData, setFamilyData] = useState<any[]>([])

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                    setLoading(false)
                }
                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }
    const handleGetData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }
        else if (selectEmp == 0) {
            setErrorMessage("Please Select Employee...")
        }
        else {
            getContractData()
            getLeaveData()
            getFamilyInsurData()
        }
    }
    const getContractData = async () => {
        setLoading(true)
        await AxiosLayout.get(`/Contract/GetEmployeeContractDetails?EmployeeId=${selectEmp}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                if (res.data?.Table !== null) {
                    setContractData(res.data?.Table)
                    if (res.data?.Table?.length !== 0) {
                        const firstRow = res?.data?.Table[0];
                        const dynamicColumns = Object?.keys(firstRow).map((key) => {
                            if (key === 'IsActive') {
                                return {
                                    id: key,
                                    header: key,
                                    columnType: 'display',
                                    size: 100,
                                    cell: ({ row }: { row: any }) => {
                                        const { IsActive } = row.original;
                                        return (
                                            <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} />
                                        );
                                    },

                                };
                            }
                            return {
                                id: key,
                                header: key,
                                filter: true,
                                size: 100
                            };
                        });

                        setContractColumn(dynamicColumns);
                    }
                }
                setLoading(false)
            }
        })
    }
    const getLeaveData = async () => {
        setLoading(true)
        await AxiosLayout.get(`/LeaveDetails/GetEmployeesLeaveList?CompanyId=${userId?.companyId}&Employeeid=${selectEmp}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                if (res?.data !== null) {
                    if (res?.data.length !== 0) {
                        setLeaveData(res?.data)
                        if (res.data?.length !== 0) {
                            const firstRow = res?.data[0];
                            const dynamicColumnss = Object?.keys(firstRow).map((key) => ({
                                id: key,
                                header: key,
                                filter: true,
                                size: 100,
                            }));
                            setLeaveColumn(dynamicColumnss);
                        }
                    }
                }
                setLoading(false)
            }
        })
    }
    const getFamilyInsurData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmpFamilyandEducationDetails?Employeeid=${selectEmp}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                setFamilyData(res?.data?.Table)
                setLoading(false)
            }
        })
    }


    const staticContractColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 100 },
        { id: 'Employee', header: 'Employee', filter: true, size: 100 },
        { id: 'Company', header: 'Company', filter: true, size: 100 },
        { id: 'Brand', header: 'Brand', filter: true, size: 100 },
        { id: 'Department', header: 'Department', filter: true, size: 100 },
        { id: 'Position', header: 'Position', filter: true, size: 100 },
        { id: 'StartDate', header: 'Start Date', filter: true, size: 100 },
        { id: 'EndDate', header: 'End Date', filter: true, size: 100 },
        { id: 'ContractType', header: 'Contract Type', filter: true, size: 100 },
        { id: 'Insurance', header: 'Insurance', filter: true, size: 100 },
        { id: 'PensionPremium', header: 'Pension Premium', filter: true, size: 100 },
        { id: 'Salary', header: 'Salary', filter: true, size: 100 },
        { id: 'PaymentPercentage', header: 'Payment(%)', filter: true, size: 100 },
        {
            id: 'IsActive', header: 'IsActive', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { IsActive } = row.original;
                return (
                    <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} />
                );
            },
        },
        { id: 'TerminationDate', header: 'Termination Date', filter: true, size: 100 },
        { id: 'TerminationReason', header: 'Termination Reason', filter: true, size: 100 },
        { id: 'Remarks', header: 'Reason', filter: true, size: 100 },
        { id: 'ActiveContractId', header: 'Active Contract Id', filter: true, size: 100 },


    ]
    const staticLeaveColumns = [
        { id: 'LeaveDes', header: 'Leave Type', filter: true, size: 100 },
        {
            id: 'ApplyDate', header: 'Applied Date', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { ApplyDate } = row.original;
                return (
                    <>{ApplyDate?.split("T")[0]}</>
                );
            },
        },
        {
            id: 'FromDate', header: 'From Date', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { FromDate } = row.original;
                return (
                    <>{FromDate?.split("T")[0]}</>
                );
            },
        },
        {
            id: 'ToDate', header: 'To Date', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { ToDate } = row.original;
                return (
                    <>{ToDate?.split("T")[0]}</>
                );
            },
        },
        { id: 'Hours', header: 'Total Hours', filter: true, size: 100 },
        { id: 'Remarks', header: 'Remarks', filter: true, size: 100 },
        { id: 'Days', header: 'No. Of Days', filter: true, size: 100 },
        {
            id: 'IsSoldHolidayLeave', header: 'Holiday Leave', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { IsSoldHolidayLeave } = row.original;
                return (
                    <input type='checkbox' value={IsSoldHolidayLeave} name='IsSoldHolidayLeave' checked={IsSoldHolidayLeave === true} />
                );
            },
        },
        {
            id: 'AsSeen', header: 'As Seen', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { AsSeen } = row.original;
                return (
                    <input type='checkbox' value={AsSeen} name='AsSeen' checked={AsSeen === true} />
                );
            },
        },
        {
            id: 'IsActive', header: 'Is Active', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { IsActive } = row.original;
                return (
                    <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} />
                );
            },
        },
        {
            id: 'IsApproved', header: 'Is Approved', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { IsApproved } = row.original;
                return (
                    <input type='checkbox' value={IsApproved} name='IsApproved' checked={IsApproved === true} />
                );
            },
        },
        {
            id: 'Isverified', header: 'Is Verified', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { Isverified } = row.original;
                return (
                    <input type='checkbox' value={Isverified} name='Isverified' checked={Isverified === true} />
                );
            },
        },
    ]
    const staticFamilyColumns = [
        { id: 'FirstName', header: 'Full Name', filter: true, size: 100 },
        { id: 'MarriedName', header: 'Married Name', filter: true, size: 100 },
        { id: 'IdNumber', header: 'Id Number', filter: true, size: 100 },
        { id: 'RelationDescription', header: 'Relation Desc', filter: true, size: 100 },
        {
            id: 'DateOfBirth', header: 'Date of Birth', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { DateOfBirth } = row.original;
                return (
                    <>{DateOfBirth?.split("T")[0]}</>
                );
            },
        },
        { id: 'MaritalStatusDescription', header: 'Marital Status Desc', filter: true, size: 100 },
        { id: 'IsSoldHolidayLeave', header: 'Phone', filter: true, size: 100 },
        { id: 'Mobile', header: 'Mobile', filter: true, size: 100 },
        { id: 'Email', header: 'Emial', filter: true, size: 100 },
        { id: 'Address', header: 'Address', filter: true, size: 100 },
        { id: 'Country', header: 'Country', filter: true, size: 100 },
        { id: 'District', header: 'District', filter: true, size: 100 },
        {
            id: 'Insured', header: 'Insured', filter: true, size: 100, cell: ({ row }: { row: any }) => {
                const { Insured } = row.original;
                return (
                    <input type='checkbox' value={Insured} name='Insured' checked={Insured === true} />
                );
            },
        },
    ]

    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Employee Details</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>

                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "Select Employee" },
                                    ...empData?.filter(j => j.EmploymentStatus === "Active" && j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>

                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className={"w-100"} onClick={handleGetData}>Show</YsecButton>
                        </Col>

                    </Row>


                    <div className='mt-2'>

                        <Card>
                            <Card.Header className='pt-0 pb-0'><p className='opening mb-0'>Contract Details</p></Card.Header>
                            <Card.Body className='cardbodyy'>
                                <div className='katable cardtable'>
                                    <YsecTable
                                        rowData={contractData}
                                        columnDefs={contractData?.length !== 0 ? contractColumn : staticContractColumns}
                                        filter={true}
                                        pagination={false}
                                        tableRef={tableRef}
                                        pageSize={20}
                                        dragColumnDisable={true}
                                        reRender={true}

                                    />

                                </div>
                            </Card.Body>
                        </Card>

                        <Card className='mt-3'>
                            <Card.Header className='pt-0 pb-0'><p className='opening mb-0'>Leave Details</p></Card.Header>
                            <Card.Body className='cardbodyy'>
                                <div className='katable cardtable'>
                                    <YsecTable
                                        rowData={leaveData}
                                        columnDefs={staticLeaveColumns}
                                        filter={true}
                                        pagination={false}
                                        tableRef={tableRef2}
                                        pageSize={20}
                                        dragColumnDisable={true}
                                        reRender={true}

                                    />

                                </div>
                            </Card.Body>
                        </Card>

                        <Card className='mt-3'>
                            <Card.Header className='pt-0 pb-0'><p className='opening mb-0'>Family Details</p></Card.Header>
                            <Card.Body className='cardbodyy'>
                                <div className='katable cardtable'>
                                    <YsecTable
                                        rowData={familyData}
                                        columnDefs={staticFamilyColumns}
                                        filter={true}
                                        pagination={false}
                                        tableRef={tableRef3}
                                        pageSize={20}
                                        dragColumnDisable={true}
                                        reRender={true}

                                    />

                                </div>
                            </Card.Body>
                        </Card>

                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}

export default EmployeeDetails;