import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from "jodit-react";


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}


const StaffHistory: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const [selectedPosition, setSelectedPosition] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString()?.split("T")[0])

    const [salaryPeriodData, setSalaryPeriodData] = useState<any[]>([])
    const [fromPeriod, setFromPeriod] = useState<number>(0);
    const [toPeriod, setToPeriod] = useState<number>(0);
    const [table, setTable] = useState<any[]>([])
    const [table1, setTable1] = useState<any[]>([])
    const [table2, setTable2] = useState<any[]>([])
    const [table3, setTable3] = useState<any[]>([])
    const [table4, setTable4] = useState<any[]>([])
    const [exceptionsByEmp, setExceptionsByEmp] = useState<Record<number, any[]>>({});
    const editor = useRef<any>(null);
    // Example usage:
    const today = new Date();
    const formattedDate = formatFullDateWithWeek(today);
    function formatFullDateWithWeek(date: any) {
        // Options for formatting the date components
        const options: any = {
            weekday: 'short', // 'short' for Mon, Tue, etc.
            month: 'short',   // 'short' for Jan, Feb, etc.
            day: '2-digit',   // '2-digit' for 01, 02, etc.
            year: 'numeric'   // 'numeric' for 2025, 2026, etc.
        };

        // Create a DateTimeFormat instance with the desired locale and options
        // 'en-US' is used here for a common English format, adjust as needed
        const formatter = new Intl.DateTimeFormat('en-US', options);

        // Format the date
        return formatter.format(date);
    }


    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }
                if (res.data.SalaryPeriodList !== null) {
                    setSalaryPeriodData(res.data.SalaryPeriodList)
                }

                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
        setFromPeriod(0)
        setToPeriod(0)
    }

    const handleGetData = () => {
        if (fromPeriod == 0) {
            setErrorMessage("Select From Period..")
        }
        else if (toPeriod == 0) {
            setErrorMessage("Select To Period..")
        }
        else {

            const payload = {
                companyId: userId?.companyId,
                departmentId: selectedDept,
                positionId: selectedPosition,
                employeeId: selectEmp,
                userId: userId?.user,
                brandId: selectedBrand,
                locationId: locationId,
                FromDate: fromPeriod,
                ToDate: toPeriod
            }
            setLoading(true)
            AxiosLayout.post("/EmployeeReport/GetStaffHistoryReport", payload).then((res: any) => {
                if (res.status === 200) {
                    if (res.data?.Table !== null) {
                        setTable(res?.data?.Table)
                        // Group by EmpId
                        const grouped = res.data.Table.reduce((acc: any, item: any) => {
                            if (!acc[item.EmpId]) acc[item.EmpId] = [];
                            acc[item.EmpId].push(item);
                            return acc;
                        }, {});
                        setExceptionsByEmp(grouped);


                    }
                    if (res.data?.Table !== null) {
                        setTable1(res?.data?.Table1)
                    }
                    if (res.data?.Table !== null) {
                        setTable2(res?.data?.Table2)
                    }
                    if (res.data?.Table !== null) {
                        setTable3(res?.data?.Table3)
                    }
                    if (res.data?.Table !== null) {
                        setTable4(res?.data?.Table4)
                    }
                    setLoading(false)
                }
            })
        }
    }



    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };


    let htmlContent = '';


    htmlContent += table4.map((i: any, index: number) => {
        const empExceptions = exceptionsByEmp[i.EmployeeId] || [];
        const leaveTotals = table2.find(l => l.EmployeeId === i.EmployeeId);
        const warningsData = table1?.filter(l => l.EmployeeId === i.EmployeeId);
        const table3data = table3?.filter(l => l.EmployeeId === i.EmployeeId);

        const rows = empExceptions.map((exc: any) => {
            const year = exc.ExceptionYear;
            const month = exc.ExceptionMonth;

            let tdContent = '';
            for (let day = 1; day <= 31; day++) {
                const key = `ExceptionType${day}`;
                const value = exc[key] ?? '';
                tdContent += `<td style="border:1px solid grey !important;">${value}</td>`;
            }

            return `
                    <tr>
                        <td style="border:1px solid grey !important;">${year}</td>
                        <td style="border:1px solid grey !important;">${month}</td>
                        ${tdContent}
                    </tr>
                    
                    `;
        }).join('');

        const warningRows = warningsData?.map((w: any) => {
            return `
            <tr>
        <td>${w?.WarningDate?.split("T")[0] || ""}</td>
        <td>${w?.Warning || ""}</td>
    </tr>
            `
        });
        const trows = table3data?.map((t: any) => {
            return `
           
            <tr>
        <td><span class="stafftextcolor">${t?.LeaveType?.split("T")[0] || ""}</span>&nbsp;&nbsp;&nbsp;&nbsp;${t?.NoOfDays || ""}</td>
    </tr>
    
            `
        });
        const content =
            `
                    <table width="100%">
                        <tr>
                            <td class="stafftextcolor"><b><i>Staff Exceptions and Vacations for</i></b></td>
                            <td><b>${i.EmployeeId}</b></td>
                            <td><b>${i.FullName}</b></td>
                            <td class="stafftextcolor"><b><i>From</i></b></td>
                            <td>${i?.FromDate?.split("T")[0]}</td>
                        </tr>
                        <tr>
                            <td>${i?.Department}</td>
                            <td></td>
                            <td></td>
                            <td class="stafftextcolor"><b><i>To</i></b></td>
                            <td>${i?.ToDate?.split("T")[0]}</td>
                        </tr>
                        </table>

                        <table width="100%" style="border-collapse:separate !important;">
                        <tr>
                            <th style="border:none" class="stafftextcolor"><b><i>Year</i></b></th>
                            <th style="border:none" class="stafftextcolor"><b><i>Month</i></b></th>
                            ${Array.from({ length: 31 }, (_, i) => `<th style="border:none" class="stafftextcolor"><b><i>${i + 1}</i></b></th>`).join('')}
                        </tr>
                        <tr>
                            <td colSpan="33"><hr style="margin:0px !important;border-top:2px solid rgba(var(--primary-surface-darker)) !important;opacity:unset !important" /></td>
                        </tr>
                        ${rows || ''}
                        <tr>
                            <td colSpan="33"><hr style="margin:0px !important;border-top:2px solid rgba(var(--primary-surface-darker)) !important;opacity:unset !important" /></td>
                        </tr>
                    </table>

                     <p class="stafftextcolor"><u><i>Exception Codes</i></u></p>
                    <table width="100%">
                        <tr>
                            <td>W  Working Day</td>
                            <td>D  Days In Lieu</td>
                            <td>U  Unpaid Leave</td>
                            <td>C  Compassionate Leave</td>
                            <td>L  Leave</td>
                        </tr>
                        <tr>
                            <td>Q  No Call No Show</td>
                            <td>T	Sick with Certificate</td>
                            <td>M	Maternity Leave</td>
                            <td>Z	Other</td>
                            <td>H	Sent Home</td>
                        </tr>
                        <tr>
                            <td>V	Annual Leave</td>
                            <td>S	Sick no Certificate</td>
                            <td>N	Matrimony Leave</td>
                            <td>P	Suspension</td>
                            <td>A	Absent</td>
                        </tr>
                        <tr>
                            <td>LS	Late Started</td>
                            <td>LE	Left Earlier</td>
                            <td>F	Free of duty</td>
                            <td></td>
                            <td></td>
                        </tr>
                    </table>
                    <div style="display:flex">
                        <div style="width:50%">
                            <p style="text-align:center" class="stafftextcolor"><u><i>Leave Totals</i></u></p>
                            <table width="100%">
                                <tr>
                                    <td colSpan="4" style="text-align: center;"><span  class="stafftextcolor">Years Of Service</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals?.YearOfService}</td>
                                </tr>
                                <tr>
                                    <td><span  class="stafftextcolor">Vac days accrued</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.EarnedLeaves}</td>
                                    <td><span  class="stafftextcolor">taken</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.TakenLeaves}</td>
                                    <td><span  class="stafftextcolor">Sold</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.SoldLeaves}</td>
                                    <td><span  class="stafftextcolor">Owing</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.LeaveBalance}</td>
                                </tr>
                                <tr>
                                    <td><span  class="stafftextcolor">Acc DIL's</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.HolidayEarnedLeaves}</td>
                                    <td><span  class="stafftextcolor">taken</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.HolidayTakenLeaves}</td>
                                    <td><span  class="stafftextcolor">Sold</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.HolidaySoldLeaves}</td>
                                    <td><span  class="stafftextcolor">Owing</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.HolidayLeaveBalance}</td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <hr style="margin:0px !important;border-top:2px solid rgba(var(--primary-surface-darker)) !important;opacity:unset !important" />
                                    </td>
                                </tr>
                                <tr>
                                    <td><span  class="stafftextcolor">Totals</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.TotalEarnedLeaves}</td>
                                    <td><span  class="stafftextcolor">taken</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.TotalTakenLeaves}</td>
                                    <td><span  class="stafftextcolor">Sold</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.TotalSoldLeaves}</td>
                                    <td><span  class="stafftextcolor">Owing</span>&nbsp;&nbsp;&nbsp;&nbsp;${leaveTotals.TotalLeaveBalance}</td>
                                </tr>
                            </table>
                        </div>
                        <div style="width:50%">
                            <p style="text-align:center" class="stafftextcolor"><u><i>Warnings</i></u></p>
                            <table width="100%">
                                ${(warningRows || '').join('')}
                            </table>
                        </div>
                    </div
                   
                        <div style="width:50%;">
                        <table width="100%">
                        <tbody>
                        ${(trows || "").join('')}
                        </tbody>
                        </table>
                        </div>
                       
                     
${index !== table4.length - 1
                ? `
    <hr style="margin: 40px 0 10px 0; border: none; border-top: 2px solid #333;" />
    <div style="display:flex;justify-content: space-between;">
    <div class="stafftextcolor" style=" font-size: 12px; font-weight: bold;">${formattedDate}</div>
    <div class="stafftextcolor" style="text-align: right; font-size: 12px; font-weight: bold;">Page ${index + 1} of ${table4.length}</div>
         </div>
    <div style="page-break-after: always;"></div>

  `
                : `
    <hr style="margin: 40px 0 10px 0; border: none; border-top: 2px solid #333;" />
    <div style="display:flex;justify-content: space-between;">
      <div class="stafftextcolor" style=" font-size: 12px; font-weight: bold;">${formattedDate}</div>
    <div class="stafftextcolor" style="text-align: right; font-size: 12px; font-weight: bold; ">Page ${index + 1} of ${table4.length}</div>
    </div>
  `}
                    `;
        return content;
    }).join('');



    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Staff History</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All Departments" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)} defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "Select Position" },
                                    ...positionsData?.filter((j: any) => j.DepartmentId == selectedDept)?.map((i: any) => ({
                                        id: i?.PostionId,
                                        Name: i?.Position
                                    }))
                                ]}
                                value={selectedPosition}
                                onChange={(e) => setSelectedPosition(e.target.value)} defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="desc"
                                objectValueKey="id"
                                data={[
                                    { id: 0, desc: "From" },
                                     ...salaryPeriodData?.filter(j =>  j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        id: i?.Period,
                                        desc: i?.PeriodDescription
                                    }))

                                ]}
                                value={fromPeriod}
                                onChange={(e) => {
                                    setFromPeriod(e.target.value)
                                    setToPeriod(e.target.value)
                                }}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="desc"
                                objectValueKey="id"
                                data={[
                                    { id: 0, desc: "To" },
                                    ...salaryPeriodData?.filter(j =>  j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        id: i?.Period,
                                        desc: i?.PeriodDescription
                                    }))

                                ]}
                                value={toPeriod}
                                onChange={(e) => setToPeriod(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "All Employees" },
                                    ...empData?.filter(j => j.EmploymentStatus === "Active" && j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className='w-100' onClick={handleGetData}>Show</YsecButton>
                        </Col>

                    </Row>

                    <Row>
                        <Col md={1} lg={2} className='md-none mt-3'></Col>
                        <Col xs={12} md={10} lg={8} className="offer-letter-padding-lg  mt-3 ">

                            {table4?.length !== 0 ?
                                <div className='staffsummary'>
                                    <JoditEditor
                                        ref={editor}
                                        value={`      
                                                                           
                                             ${htmlContent}                           
                                            `}
                                        config={config}

                                    />
                                </div>
                                : <p className='p-3 bg-white'>No Data Found Here...</p>}
                        </Col>
                        <Col md={1} lg={1} className='md-none  mt-3'></Col>

                    </Row>

                    {/* <div dangerouslySetInnerHTML={{ __html: htmlContent }} /> */}

                </div>
            </React.Suspense>
        </div>
    )
}

export default StaffHistory;