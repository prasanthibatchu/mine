import { DataType, Table } from 'ka-table';
import React, { useRef } from 'react'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

export const LoanTableData: React.FC<any> = (props) => {
    const tableRef = useRef<any>(null)

    const staticColumns = [
        { id: 'EmployeeId', header: 'EmployeeId', filter: true, size: 150 },
        { id: 'EmpName', header: 'FullName', filter: true, size: 150 },
        { id: 'Period_Start', header: 'Period_Start', filter: true, size: 150, cell: ({ row }: { row: any }) => {
                const { Period_Start } = row.original;
                return (
                    <>{Period_Start?.split("T")[0]}</>
                );
            }, },
        { id: 'CompanyDepartment', header: 'CompanyDepartment', filter: true, size: 150 },
        { id: 'CompanyPostion', header: 'CompanyPostion', filter: true, size: 150 },
        { id: 'CurrencyCode', header: 'CurrencyCode', filter: true, size: 150 },
        { id: 'AdvanceDate', header: 'AdvanceDate', filter: true, size: 150 },
        { id: 'PayBackCount', header: 'PayBackCount', filter: true, size: 150 },
        { id: 'StartDate', header: 'StartDate', filter: true, size: 150 , cell: ({ row }: { row: any }) => {
                const { StartDate } = row.original;
                return (
                    <>{StartDate?.split("T")[0]}</>
                );
            },},
        { id: 'EndDate', header: 'EndDate', filter: true, size: 150 , cell: ({ row }: { row: any }) => {
                const { EndDate } = row.original;
                return (
                    <>{EndDate?.split("T")[0]}</>
                );
            },},
        { id: 'Remark', header: 'Remark', filter: true, size: 150 },
        { id: 'Totalsolved', header: 'Totalsolved', filter: true, size: 150 },
        { id: 'saldo', header: 'saldo', filter: true, size: 150 },
        { id: 'amt', header: 'amt', filter: true, size: 150 },
        { id: 'LoanAmount', header: 'LoanAmount', filter: true, size: 150 },

    ]

    return (
        <div className="katable">
            <div className='katable contractstable'>
                {props?.data?.length !== 0 &&
                    <YsecTable
                        rowData={props?.data}
                        columnDefs={staticColumns}
                        filter={true}
                        pagination={false}
                        tableRef={tableRef}
                        // pageSize={20}
                        dragColumnDisable={true}
                        reRender={true}
                    />}
            </div>
        </div>
    )
}