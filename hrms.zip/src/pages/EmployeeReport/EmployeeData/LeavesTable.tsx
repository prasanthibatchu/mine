import { DataType, Table } from 'ka-table';
import React, { useRef } from 'react'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

export const LeavesTableData: React.FC<any> = (props) => {
    const tableRef = useRef<any>(null)

    const staticColumns = [
        { id: 'FullName', header: 'Full Name', filter: true, size: 150 },
        { id: 'Description', header: 'Description', filter: true, size: 150 },
        { id: 'ApplyDate', header: 'Apply Date', filter: true, size: 150 },
        { id: 'FromDate', header: 'From Date', filter: true, size: 150 },
        { id: 'ToDate', header: 'To Date', filter: true, size: 150 },
        { id: 'Hours', header: 'Hours', filter: true, size: 150 },
        { id: 'Remark', header: 'Remark', filter: true, size: 150 },
        { id: 'Status', header: 'Status', filter: true, size: 150 },
        { id: 'Days', header: 'Days', filter: true, size: 150 },
        { id: 'tltleaves', header: 'Title Leaves', filter: true, size: 150 },
        { id: 'LeaveBalance', header: 'Leave Balance', filter: true, size: 150 },
    ]

    return (
        <div className="katable">
            <div className='katable contractstable'>
                {props?.data?.length !==0 &&
                <YsecTable
                    rowData={props?.data}
                    columnDefs={staticColumns}
                    filter={true}
                    pagination={false}
                    tableRef={tableRef}
                    // pageSize={20}
                    dragColumnDisable={true}
                    reRender={true}
                />}
            </div>
        </div>
    )
}