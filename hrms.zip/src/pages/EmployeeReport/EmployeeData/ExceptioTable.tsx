import { DataType, Table } from 'ka-table';
import React, { useRef } from 'react'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

export const ExceptionTableData: React.FC<any> = (props) => {
    const tableRef = useRef<any>(null)

    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 150 },
        { id: 'EmployeeName', header: 'EmployeeName', filter: true, size: 150 },
        { id: 'Department', header: 'Department', filter: true, size: 150 },
        { id: 'Position', header: 'Position', filter: true, size: 150 },
        { id: 'Exceptions', header: 'Exceptions', filter: true, size: 150 },
        { id: 'ExceptionDate', header: 'ExceptionDate', filter: true, size: 150 },
        { id: 'ExcHours', header: 'ExcHours', filter: true, size: 150 },
        { id: 'Remark', header: 'Remark', filter: true, size: 150 },
        { id: 'Paid', header: 'Paid', filter: true, size: 150 },
        { id: 'TotHrs', header: 'TotHrs', filter: true, size: 150 },
        { id: 'Calculated1', header: 'Calculated1', filter: true, size: 150 },
        { id: 'Calculated2', header: 'Calculated2', filter: true, size: 150 },
        { id: 'TotalWorkHrs', header: 'TotalWorkHrs', filter: true, size: 150 },
        { id: 'WorkedHrs', header: 'WorkedHrs', filter: true, size: 150 },
        { id: 'WorkPerc', header: 'WorkPerc', filter: true, size: 150 },
       

    ]

    return (
        <div className="katable">
            <div className='katable contractstable'>
                {props?.data?.length !==0 &&
                <YsecTable
                    rowData={props?.data}
                    columnDefs={staticColumns}
                    filter={true}
                    pagination={false}
                    tableRef={tableRef}
                    // pageSize={20}
                    dragColumnDisable={true}
                    reRender={true}
                />}
            </div>
        </div>
    )
}