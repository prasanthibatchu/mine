import { DataType, Table } from 'ka-table';
import React, { useRef } from 'react'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

export const PenaltyTableData: React.FC<any> = (props) => {
    const tableRef = useRef<any>(null)

    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 150 },
        { id: 'FullName', header: 'Full Name', filter: true, size: 150 },
        { id: 'Department', header: 'Department', filter: true, size: 150 },
        { id: 'Position', header: 'Position', filter: true, size: 150 },
        { id: 'Amount', header: 'Amount', filter: true, size: 150 },
        { id: 'StartDate', header: 'Start Date', filter: true, size: 150 },
        { id: 'EndDate', header: 'End Date', filter: true, size: 150 },
        { id: 'Pdescription', header: 'Pdescription', filter: true, size: 150 },
        { id: 'PayBackCount', header: 'PayBack Count', filter: true, size: 150 },
        { id: 'PenDate', header: 'PenDate', filter: true, size: 150 },
        { id: 'Remark', header: 'Remark', filter: true, size: 150 },
        { id: 'IsActive', header: 'IsActive', filter: true, size: 150, cell: ({ row }: { row: any }) => {
                const { IsActive } = row.original;
                return (
                    <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} />
                );
            }, },
        { id: 'CurrencyCode', header: 'Currency Code', filter: true, size: 150 },
        { id: 'amt', header: 'amt', filter: true, size: 150 },

    ]

    return (
        <div className="katable">
            <div className='katable contractstable'>
                {props?.data?.length !== 0 &&
                    <YsecTable
                        rowData={props?.data}
                        columnDefs={staticColumns}
                        filter={true}
                        pagination={false}
                        tableRef={tableRef}
                        // pageSize={20}
                        dragColumnDisable={true}
                        reRender={true}
                    />}
            </div>
        </div>
    )
}