import { DataType, Table } from 'ka-table';
import React, { useRef } from 'react'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

export const ContractTableData: React.FC<any> = (props) => {
    const tableRef = useRef<any>(null)

    const staticColumns = [
        { id: 'FullName', header: 'Full Name', filter: true, size: 150 },
        { id: 'Start', header: 'Start', filter: true, size: 150 },
        { id: 'Time_end', header: 'Time End', filter: true, size: 150 },
        { id: 'Duration', header: 'Durantion', filter: true, size: 150 },
        { id: 'Termination_date', header: 'Termination Date', filter: true, size: 150 },
        { id: 'TerminationReason', header: 'Termination Reason', filter: true, size: 150 },
        { id: 'ContractType', header: 'Contract Type', filter: true, size: 150 },
        { id: 'CompanyName', header: 'Company Name', filter: true, size: 150 },
        { id: 'InsuranceType', header: 'Insurance Type', filter: true, size: 150 },
        { id: 'Salary', header: 'Salary', filter: true, size: 150 },
        { id: 'CompanyDepartment', header: 'Company Department', filter: true, size: 150 },
        { id: 'CompanyPostion', header: 'Company Position', filter: true, size: 150 },
        { id: 'Remarks', header: 'Remarks', filter: true, size: 150 },


    ]

    return (
        <div className="katable">
            <div className='katable contractstable'>
                {props?.data?.length !==0 &&
                <YsecTable
                    rowData={props?.data}
                    columnDefs={staticColumns}
                    filter={true}
                    pagination={false}
                    tableRef={tableRef}
                    // pageSize={20}
                    dragColumnDisable={true}
                    reRender={true}
                />}
            </div>
        </div>
    )
}