import { DataType, Table } from 'ka-table';
import React, { useRef } from 'react'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));

export const OverTimeTableData: React.FC<any> = (props) => {
    const tableRef = useRef<any>(null)

    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 150 },
        { id: 'EmployeeName', header: 'EmployeeName', filter: true, size: 150 },
        { id: 'OTDate', header: 'OTDate', filter: true, size: 150 },
        { id: 'OTDescription', header: 'OTDescription', filter: true, size: 150 },
        { id: 'OTStartTime', header: 'OTStartTime', filter: true, size: 150 },
        { id: 'OTEndTime', header: 'OTEndTime', filter: true, size: 150 },
        { id: 'OTAmount', header: 'OTAmount', filter: true, size: 150 },
        { id: 'Remark', header: 'Remark', filter: true, size: 150 },
        { id: 'otamt', header: 'otamt', filter: true, size: 150 },
        ]

    return (
        <div className="katable">
            <div className='katable contractstable'>
                {props?.data?.length !== 0 &&
                    <YsecTable
                        rowData={props?.data}
                        columnDefs={staticColumns}
                        filter={true}
                        pagination={false}
                        tableRef={tableRef}
                        // pageSize={20}
                        dragColumnDisable={true}
                        reRender={true}
                    />}
            </div>
        </div>
    )
}