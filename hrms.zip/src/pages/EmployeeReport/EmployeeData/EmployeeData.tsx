import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Col, Modal, Row, Tab, Tabs } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import { ContractTableData } from './ContractTable';
import { LeavesTableData } from './LeavesTable';
import JoditEditor from 'jodit-react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import { AdvanceTableData } from './AdvanceTavle';
import { ExceptionTableData } from './ExceptioTable';
import { PenaltyTableData } from './PenaltyTable';
import { OverTimeTableData } from './OverTimeTable';
import { LoanTableData } from './LoanTable';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}


const EmployeeData: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const [selectedPosition, setSelectedPosition] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [activeTab, setActiveTab] = useState<string>("contract");

    const [salaryPeriodData, setSalaryPeriodData] = useState<any[]>([])
    const [fromPeriod, setFromPeriod] = useState<number>(0);
    const [toPeriod, setToPeriod] = useState<number>(0);
    const [contractTable, setContractTable] = useState<any[]>([])
    const [leavesTable, setLeavesTable] = useState<any[]>([])
    const [printData, setPrintData] = useState<boolean>(false)
    const [exceptionsByEmp, setExceptionsByEmp] = useState<Record<number, any[]>>({});
    const [empPersonalData, setEmpPersonalData] = useState<any[]>([])
    const [edData, setEdData] = useState<any[]>([])
    const editor = useRef<any>(null);
    const [advanceData, setAdvanceData] = useState<any[]>([])
    const [exceptionData, setExceptionData] = useState<any[]>([])
    const [penaltyData, setPenaltyData] = useState<any[]>([])
    const [loanData, setLoanyData] = useState<any[]>([])
    const [overTimeData, setOverTimeData] = useState<any[]>([])

    // Example usage:
    const today = new Date();
    const formattedDate = formatFullDateWithWeek(today);
    function formatFullDateWithWeek(date: any) {
        // Options for formatting the date components
        const options: any = {
            weekday: 'short', // 'short' for Mon, Tue, etc.
            month: 'short',   // 'short' for Jan, Feb, etc.
            day: '2-digit',   // '2-digit' for 01, 02, etc.
            year: 'numeric'   // 'numeric' for 2025, 2026, etc.
        };

        // Create a DateTimeFormat instance with the desired locale and options
        // 'en-US' is used here for a common English format, adjust as needed
        const formatter = new Intl.DateTimeFormat('en-US', options);

        // Format the date
        return formatter.format(date);
    }


    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }
                if (res.data.SalaryPeriodList !== null) {
                    setSalaryPeriodData(res.data.SalaryPeriodList)
                }

                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
        setFromPeriod(0)
        setToPeriod(0)
    }

    const handleGetData = () => {
        if (selectEmp == 0) {
            setErrorMessage("Please Select An Employee..")
        }
        else if (printData === true && fromPeriod === 0) {
            setErrorMessage("Please Select  Salary Period..")
        }

        else {

            const payload = {
                companyId: userId?.companyId,
                departmentId: selectedDept,
                positionId: selectedPosition,
                employeeId: selectEmp,
                userId: userId?.user,
                brandId: selectedBrand,
                locationId: locationId,
                FromDate: fromPeriod,
                ToDate: toPeriod
            }
            setLoading(true)
            AxiosLayout.post("/EmployeeReport/GetEmployeeHistory", payload).then((res: any) => {
                if (res.status === 200) {
                    if (res.data?.Table2 !== null) {
                        setContractTable(res?.data?.Table2)
                    }
                    if (res.data?.Table6 !== null) {
                        setLeavesTable(res?.data?.Table6)
                    }
                    if (res.data?.Table4 !== null) {
                        setLoanyData(res?.data?.Table4)
                    }
                    if (res.data?.Table3 !== null) {
                        setExceptionData(res?.data?.Table3)
                    }
                    if (res.data?.Table5 !== null) {
                        setOverTimeData(res?.data?.Table5)
                    }
                    if (res?.data?.Table1 !== null) {
                        setEmpPersonalData(res?.data?.Table1)
                    }
                    if (res?.data?.Table10 !== null) {
                        setEdData(res?.data?.Table10)
                    }
                    if (res?.data?.Table7 !== null) {
                        setAdvanceData(res?.data?.Table7)
                    }
                    if (res?.data?.Table8 !== null) {
                        setPenaltyData(res?.data?.Table8)
                    }
                    setActiveTab("contract")
                    setLoading(false)
                }
            })
        }
    }



    // const exportDataAsExcel = () => {
    //     if (workData.length === 0) {
    //         alert("No data to export.");
    //         return;
    //     }

    //     const worksheet = XLSX.utils.json_to_sheet(workData);
    //     const workbook = XLSX.utils.book_new();
    //     XLSX.utils.book_append_sheet(workbook, worksheet, "Late And Work Longer Than Shift");

    //     const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    //     saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'LateWorkLongerThanShift.xlsx');
    // };
    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };
    // const exportEditorContentAsExcel = () => {
    //     if (!editor.current) {
    //         alert("Editor is not ready.");
    //         return;
    //     }

    //     const html = editor.current?.value;
    //     const parser = new DOMParser();
    //     const doc = parser.parseFromString(html, 'text/html');
    //     const tables = doc.querySelectorAll('table');

    //     if (!tables.length) {
    //         alert("No tables found.");
    //         return;
    //     }

    //     let mergedSheet: any = {};
    //     let sheetRowOffset = 0;

    //     tables.forEach((table, index) => {
    //         const sheet = XLSX.utils.table_to_sheet(table, { raw: true });

    //         // Copy each row and cell to the merged sheet with row offset
    //         Object.keys(sheet).forEach((key) => {
    //             if (key === '!ref') return;
    //             const cell = sheet[key];
    //             const cellRef = XLSX.utils.decode_cell(key);
    //             const newCellRef = XLSX.utils.encode_cell({ c: cellRef.c, r: cellRef.r + sheetRowOffset });
    //             mergedSheet[newCellRef] = cell;
    //         });

    //         const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
    //         sheetRowOffset += range.e.r + 2; // Add empty line between tables
    //     });

    //     // Calculate new sheet range
    //     mergedSheet['!ref'] = XLSX.utils.encode_range({
    //         s: { c: 0, r: 0 },
    //         e: { c: 10, r: sheetRowOffset }
    //     });

    //     const workbook = XLSX.utils.book_new();
    //     XLSX.utils.book_append_sheet(workbook, mergedSheet, 'Late And Work Longer Than Shift');

    //     const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    //     saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'LateWorkLongerThanShift.xlsx');
    // };


    return (
        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Employee Data</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All Departments" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)} defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "Select Position" },
                                    ...positionsData?.filter((j: any) => j.DepartmentId == selectedDept)?.map((i: any) => ({
                                        id: i?.PostionId,
                                        Name: i?.Position
                                    }))
                                ]}
                                value={selectedPosition}
                                onChange={(e) => setSelectedPosition(e.target.value)} defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="desc"
                                objectValueKey="id"
                                data={[
                                    { id: 0, desc: "From" },
                                    ...salaryPeriodData.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        id: i?.Period,
                                        desc: i?.PeriodDescription
                                    }))

                                ]}
                                value={fromPeriod}
                                onChange={(e) => {
                                    setFromPeriod(e.target.value)
                                    setToPeriod(e.target.value)
                                }}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="desc"
                                objectValueKey="id"
                                data={[
                                    { id: 0, desc: "To" },
                                    ...salaryPeriodData.filter(j => j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        id: i?.Period,
                                        desc: i?.PeriodDescription
                                    }))

                                ]}
                                value={toPeriod}
                                onChange={(e) => setToPeriod(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "All Employees" },
                                    ...empData?.filter(j => (j.EmploymentStatus === "Active" && j.HierachyId === selectedBrand))?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecButton type='button' className='w-100' onClick={() => {
                                setPrintData(false)
                                handleGetData()
                            }}>Show</YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end'>

                            <YsecButton onClick={() => {
                                setPrintData(true)
                                handleGetData()
                            }}
                                className={`w-100`}
                                type="button"
                            >
                                Print
                            </YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end  csv'>

                            <YsecButton
                                // className={`w-100 ${workData.length === 0 ? "disbutn" : ""}`}
                                type="button"
                            // onClick={exportDataAsExcel}
                            // onClick={()=>{if(printData===true){exportEditorContentAsExcel()}else{exportDataAsExcel()}}}
                            // disabled={workData.length === 0}
                            >
                                Export
                            </YsecButton>
                        </Col>
                    </Row>


                    <div className='p-2'>
                        {printData === false ? <>
                            <Tabs
                                activeKey={activeTab} // Controlled active tab
                                onSelect={(k: any) => setActiveTab(k)}
                                className="mb-3"
                            >
                                <Tab eventKey="contract" title="Contract">
                                    <ContractTableData data={contractTable} />
                                </Tab>
                                <Tab eventKey="exception" title="Exception">
                                    <ExceptionTableData data={exceptionData} />
                                </Tab>
                                <Tab eventKey="loan" title="Loan">
                                    <LoanTableData data={loanData} />
                                </Tab>
                                <Tab eventKey="overtime" title="Overtime">
                                    <OverTimeTableData data={overTimeData} />
                                </Tab>
                                <Tab eventKey="leaves" title="Leaves">
                                    <LeavesTableData data={leavesTable} />
                                </Tab>
                                <Tab eventKey="advance" title="Advance">
                                    <AdvanceTableData data={advanceData} />
                                </Tab>
                                <Tab eventKey="penalty" title="Penalty">
                                    <PenaltyTableData data={penaltyData} />
                                </Tab>
                            </Tabs>
                        </>
                            :
                            <>
                            {empPersonalData?.length !==0 &&
                                <JoditEditor
                                    ref={editor}
                                    value={`      
                                            <div >
                                                <div style="display: flex;  justify-items: end;">    
                               
                                                    <h6 style="width:55%;text-align:end"  class="stafftitle">${userId?.company}</h6>
                                                    <p  style="width:45%;text-align:end">
                                                    Date: ${new Date().toISOString()?.split("T")[0]}  
                                                        ${new Date().getHours()}:${new Date().getMinutes()}
                                                    </p>
                                                </div>
                                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" >Employee's History</h5>
                                            </div>      
                                            <p class="stafftitle" style="font-weight:bold">EmployeeId: ${empPersonalData[0]?.EmployeeId || ""}</p>
                                            <div style="display:flex">
                                                   <div class="katableee" style="width:30%;min-width:30% !important;">
                                                        <table width=100%>
                                                                <tr>
                                                                    <th>Last Name</th>
                                                                    <td>${empPersonalData[0]?.LastName || ""}</td>
                                                                </tr>
                                                                <tr>
                                                                    <th>First Name</th>
                                                                    <td>${empPersonalData[0]?.FirstName || ""}</td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Govt ID</th>
                                                                    <td>${empPersonalData[0]?.IdNumber || ""}</td>
                                                                </tr>
                                                                <tr>
                                                                    <th>DOB</th>
                                                                    <td>${empPersonalData[0]?.DOB?.split("T")[0] || ""}</td>
                                                                </tr>
                                                                <tr>
                                                                    <th>DOE</th>
                                                                    <td>${empPersonalData[0]?.DOE?.split("T")[0] || ""}</td>
                                                                </tr>
                                                        </table>
                                                   </div> 
                                                   <div class="katableee" style="width:30%;min-width:30% !important;">
                                                        <table width=100%>
                                                                <tr>
                                                                    <th>Address</th>
                                                                    <td>${empPersonalData[0]?.Address || ""}</td>
                                                                </tr>
                                                                <tr>
                                                                    <th>Mobile</th>
                                                                    <td>${empPersonalData[0]?.Mobile || ""}</td>
                                                                </tr>
                                                        </table>
                                                   </div> 
                                                   <div class="katableee" style="width:40%;min-width:40% !important;">
                                                        <table width=100%>
                                                                <tr>
                                                                    <th>Education</th>
                                                                    <th>Year</th>
                                                                    <th>Result</th>
                                                                </tr>
                                                                ${edData?.length !== 0 ? `<tbody>
                                                                ${edData?.map((i: any) => (
                                        `<tr>
                                                                
                                                                    <td>${i?.Education || ""}</td>
                                                                    <td>${i?.Year || ""}</td>
                                                                    <td>${i?.Result || ""}</td>
                                                                </tr>`
                                    )).join("")}
                                                              </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="3">No Results Found</td></tbody>`}
                                                        </table>
                                                   </div>                                                  
                                            </div>
                                            
                                            <h6>Contract Details</h6>
                                            <div class="katableee" >
                                                   <table width=100%>
                                                        <tr>
                                                            <th>Dept</th>
                                                            <th>Position</th>
                                                            <th>Type</th>
                                                            <th>Duration</th>
                                                            <th>Insurance</th>
                                                            <th>Salary</th>
                                                            <th>Start</th>
                                                            <th>End</th>
                                                            <th>Remarks</th>
                                                            <th>Term Date</th>

                                                        </tr>
                                                           ${contractTable?.length !== 0 ? `<tbody>
                                                        ${contractTable?.map((i: any) => (
                                                `<tr>
                                                           
                                                            <td>${i?.CompanyDepartment || ""}</td>
                                                             <td>${i?.CompanyPostion || ""}</td>
                                                              <td>${i?.ContractType || ""}</td>
                                                              <td>${i?.Duration || ""}</td>
                                                             <td>${i?.InsuranceType || ""}</td>
                                                              <td>${i?.Salary || ""}</td>
                                                              <td>${i?.Start || ""}</td>
                                                             <td>${i?.Time_end || ""}</td>
                                                              <td>${i?.Remarks || ""}</td>
                                                              <td>${i?.Termination_date || ""}</td>
                                                        </tr>`
                                            )).join("")}
                                     </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="10">No Results Found</td></tbody>`}
                                    
                                                        
                                                   </table>
                                                   </div>
<h6>Exceptions Details</h6>
                                            <div class="katableee" >
                                                   <table width=100%>
                                                        <tr>
                                                            <th>Exc Date</th>
                                                            <th>Exc Type</th>
                                                            <th>tot.Wrk.Hrs</th>
                                                            <th>Exc Hours</th>
                                                            <th>Worked Hours</th>
                                                            <th>Work%</th>
                                                            <th>Remarks</th>
                                                            <th>Paid</th>

                                                        </tr>
                                                        ${exceptionData?.length !== 0 ? `<tbody>
                                                        ${exceptionData?.map((i: any) => (
                                                `<tr>
                                                           
                                                            <td>${i?.ExceptionDate || ""}</td>
                                                             <td>${i?.Exceptions || ""}</td>
                                                              <td>${i?.TotHrs || ""}</td>
                                                              <td>${i?.ExcHours || ""}</td>
                                                             <td>${i?.Calculated1 || ""}</td>
                                                              <td>${i?.Calculated2 || ""}</td>
                                                              <td>${i?.Remark || ""}</td>
                                                             <td>${i?.Paid || ""}</td>
                                                        </tr>`
                                            )).join("")}
                                                        <tr>
                                                                <td colSpan="1" style="border:none !important"></td>
                                                                <td>Total</td>
                                                                 <td>${(exceptionData.reduce((sum, item) => Number(item.TotalWorkHrs), 0))}</td>
                                                                <td>${(exceptionData.reduce((sum, item) => sum + Number(item.ExcHours), 0)).toFixed(2)}</td>
                                                                 <td>${(exceptionData.reduce((sum, item) => Number(item.WorkedHrs), 0)).toFixed(2)}</td>
                                                                <td colSpan="1">${(exceptionData.reduce((sum, item) => Number(item.WorkPerc), 0)?.toFixed(2))}</td>
                                                               
                                                                <td colSpan="2" style="border:none !important"></td>

                                                            </tr>
                                                              </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="8">No Results Found</td></tbody>`}
                                                        </table>
                                            </div>
                                            <h6>Loan Details</h6>
                                            <div class="katableee" >
                                                   <table width=100%>
                                                        <tr>
                                                            <th>Emp.Id</th>
                                                            <th>Name</th>
                                                            <th>Desc</th>
                                                            <th>valuta</th>
                                                            <th>Amount</th>
                                                            <th>Start date</th>
                                                            <th>End date</th>
                                                            <th>Total Solved</th>
                                                            <th>Bal</th>
                                                            <th>Remarks</th>


                                                        </tr>
                                                          ${loanData?.length !== 0 ? `<tbody>
                                                        ${loanData?.map((i: any) => (
                                                `<tr>
                                                           
                                                            <td>${i?.EmployeeId || ""}</td>
                                                             <td>${i?.EmpName || ""}</td>
                                                             <td></td>
                                                              <td>${i?.CurrencyCode || ""}</td>
                                                              <td>${i?.amt || "0.00"}</td>
                                                             <td>${i?.StartDate?.split("T")[0] || ""}</td>
                                                              <td>${i?.EndDate?.split("T")[0] || ""}</td>
                                                              <td>${i?.Totalsolved || "0.00"}</td>
                                                             <td>${i?.saldo || "0.00"}</td>
                                                             <td>${i?.Remark || ""}</td>

                                                        </tr>`
                                            )).join("")}
                                                        <tr>
                                                                <td colSpan="2" style="border:none !important"></td>
                                                                <td>Total</td>
                                                                 <td>${loanData[0]?.CurrencyCode}</td>
                                                                <td>${loanData[0]?.LoanAmount}</td>
                                                                 <td colSpan="2" style="border:none !important"></td>
                                                                 <td>${(loanData.reduce((sum, item) => sum + Number(item.Totalsolved), 0)).toFixed(2)}</td>
                                                                <td colSpan="1">${(loanData.at(-1)?.saldo || 0)?.toFixed(2)}</td>
                                                               
                                                                <td colSpan="1" style="border:none !important"></td>

                                                            </tr>
                                                               </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="10">No Results Found</td></tbody>`}
                                                   </table>
                                            </div>


 <h6>Advance Details</h6>
                                                    <div class="katableee" >
                                                   <table width=100%>
                                                        <tr>
                                                            <th>EmpId</th>
                                                            <th>Name</th>
                                                            <th>Desc</th>
                                                            <th>Valuta</th>
                                                            <th>Amount</th>
                                                            <th>Start Date</th>
                                                            <th>End Date</th>
                                                            <th>Total Solved</th>
                                                            <th>Saldo</th>
                                                            <th>Remark</th>

                                                        </tr>
                                                         ${advanceData?.length !== 0 ? `<tbody>
                                                        ${advanceData?.map((i: any) => (
                                                `<tr>
                                                           
                                                            <td>${i?.EmployeeId || ""}</td>
                                                             <td>${i?.FullName || ""}</td>
                                                              <td>${i?.Description || ""}</td>
                                                              <td>${i?.Currency || ""}</td>
                                                             <td>${i?.Amount || ""}</td>
                                                              <td>${i?.Start || ""}</td>
                                                              <td>${i?.End || ""}</td>
                                                              <td>${i?.Totalsolved || ""}</td>
                                                              <td>${i?.saldo || "0.00"}</td>
                                                              <td>${i?.Remark || ""}</td>
                                                        </tr>`
                                            )).join("")}
                                                       
                                                            <tr>
                                                                <td colSpan="2" style="border:none !important"></td>
                                                                <td>Total</td>
                                                                <td>${(advanceData[0]?.Currency)}</td>
                                                                <td>${(advanceData.reduce((sum, item) => sum + Number(item.Amount), 0))}</td>
                                                                <td colSpan="2" style="border:none !important"></td>
                                                                <td colSpan="1">${(advanceData.reduce((sum, item) => sum + Number(item.Totalsolved), 0)?.toFixed(2))}</td>
                                                                <td colSpan="1">${(advanceData.reduce((sum, item) => sum + Number(item.saldo), 0))}</td>
                                                                <td colSpan="1" style="border:none !important"></td>

                                                            </tr>
                                                         </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="10">No Results Found</td></tbody>`}
                                                        
                                                   </table>
                                                   </div>
  <h6>Other Deductions Details</h6>
                                                    <div class="katableee" >
                                                   <table width=100%>
                                                        <tr>
                                                            <th>Emp ID</th>
                                                            <th>Name</th>
                                                            <th>Desc</th>
                                                            <th>Valuta</th>
                                                            <th>Amount</th>
                                                            <th>Start Date</th>
                                                            <th>End Date</th>
                                                            <th>Remark</th>
                                                        </tr>
                                                         ${penaltyData?.length !== 0 ? `<tbody>
                                                        ${penaltyData?.map((i: any) => (
                                                `<tr>
                                                           
                                                            <td>${i?.EmployeeId || ""}</td>
                                                             <td>${i?.FullName || ""}</td>
                                                              <td>${i?.Pdescription || ""}</td>
                                                              <td>${i?.CurrencyCode || ""}</td>
                                                             <td>${i?.amt || ""}</td>
                                                              <td>${i?.StartDate || ""}</td>
                                                              <td>${i?.EndDate || ""}</td>
                                                             <td>${i?.Remark || ""}</td>
                                                        </tr>`
                                            )).join("")}
                                                       
                                                            <tr>
                                                                <td colSpan="2" style="border:none !important"></td>
                                                                <td>Total</td>
                                                                <td>${penaltyData[0]?.CurrencyCode}</td>
                                                                <td>${(penaltyData.reduce((sum, item) => sum + Number(item.amt), 0)?.toFixed(2))}</td>
                                                                <td colSpan="4" style="border:none !important"></td>
                                                            </tr>
                                                        
                                                        </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="8">No Results Found</td></tbody>`}
                                                   </table>
                                                   </div>
                                                   <h6>Overtime Details</h6>
                                                    <div class="katableee" >
                                                   <table width=100%>
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Start Time</th>
                                                            <th>End Time</th>
                                                            <th>Description</th>
                                                            <th>Remark</th>
                                                            <th>Hours</th>
                                                            <th>Amount</th>

                                                        </tr>
                                                         ${overTimeData?.length !== 0 ? `<tbody>
                                                        ${overTimeData?.map((i: any) => (
                                                `<tr>
                                                           
                                                            <td>${i?.OTDate || ""}</td>
                                                             <td>${i?.OTStartTime || ""}</td>
                                                              <td>${i?.OTEndTime || ""}</td>
                                                              <td>${i?.OTDescription || ""}</td>
                                                             <td>${i?.Remark || ""}</td>
                                                              <td>${i?.OTAmount?.toFixed(2) || ""}</td>
                                                              <td>${i?.otamt?.toFixed(2) || ""}</td>
                                                        </tr>`
                                            )).join("")}
                                                       
                                                            <tr>
                                                                <td colSpan="4" style="border:none !important"></td>
                                                                <td>Total</td>
                                                               <td>${(overTimeData.reduce((sum, item) => sum + Number(item.OTAmount), 0))?.toFixed(2)}</td>
                                                                 <td>${(overTimeData.reduce((sum, item) => sum + Number(item.otamt), 0))?.toFixed(2)}</td>

                                                            </tr>
                                                        
                                                           </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="7">No Results Found</td></tbody>`}
                                                   </table>
                                                   </div>
                                                    <h6>Leave Details</h6>
                                                    <div class="katableee" >
                                                   <table width=100%>
                                                        <tr>
                                                            <th>Leave Type</th>
                                                            <th>From Date</th>
                                                            <th>To Date</th>
                                                            <th>Hours</th>
                                                            <th>Days</th>
                                                            <th>Remark</th>
                                                            <th>Em.Leaves</th>
                                                            <th>Taken Leaves</th>
                                                            <th>Leave Balance</th>

                                                        </tr>
                                                         ${leavesTable?.length !== 0 ? `<tbody>
                                                        ${leavesTable?.map((i: any) => (
                                                `<tr>
                                                           
                                                            <td>${i?.Description || ""}</td>
                                                             <td>${i?.FromDate || ""}</td>
                                                              <td>${i?.ToDate || ""}</td>
                                                              <td>${i?.Hours || ""}</td>
                                                             <td>${i?.Days || ""}</td>
                                                              <td>${i?.Remark || ""}</td>
                                                              <td>${i?.tltleaves || ""}</td>
                                                              <td>${Number(i?.tltleaves) - Number(i?.LeaveBalance) || 0}</td>
                                                              <td>${i?.LeaveBalance || ""}</td>
                                                        </tr>`
                                            )).join("")}
                                                       
                                                            <tr>
                                                                <td colSpan="2" style="border:none !important"></td>
                                                                <td>Total</td>
                                                                <td>${(leavesTable.reduce((sum, item) => sum + Number(item.Hours), 0)?.toFixed(2))}</td>
                                                                <td>${(leavesTable.reduce((sum, item) => sum + Number(item.Days), 0)?.toFixed(2))}</td>
                                                                <td colSpan="4" style="border:none !important"></td>
                                                            </tr>
                                                           </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="9">No Results Found</td></tbody>`}
                                                        
                                                   </table>
                                                   </div>
                                    
                                            `}
                                    config={config}

                                />}


                            </>}
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}

export default EmployeeData;