import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from "jodit-react";
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const PensionReport: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const printRef = useRef<any>(null)
    const tableRef = useRef<any>(null);
    const [data, setData] = useState<any[]>([])
    const editor = useRef<any>(null);
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }

                }

                setLoading(false)
            }
        })
    }

    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }
    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }
    const handleGetData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }

        else {
            getEmpDetails()

        }
    }
    const getEmpDetails = () => {
        setLoading(true)

        AxiosLayout.get(`/EmployeeReport/GetEmployeeAccPensionReport?BrandId=${selectedBrand}&EmpId=${selectEmp}&UserId=${userId?.user}`).then((res: any) => {
            if (res?.status === 200) {
                setData(res?.data?.Table)
                setLoading(false)
            }
        })
    }



    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };
    let htmlContent = data?.map((i: any) => {

        return (
            ` <tr>
                <td>${i?.EmployeeId || ""}</td>
                <td>${i?.Title || ""}</td>
                <td>${i?.Employee || ""}</td>
                <td>${i?.OldEmployeeId || ""}</td>
                <td>${i?.Location || ""}</td>
                <td>${i?.OldDepartment || ""}</td>
                <td>${i?.Department || ""}</td>
                <td>${i?.Amount || "0"}</td>
                <td>${i?.Remark || ""}</td>
            </tr>
            <tr>
                <td colSpan="6" style="border:none !important"></td>
                <td>Total</td>
                <td>${i?.Amount?.toFixed(2) || "0.00"}</td>
                <td style="border:none !important"></td>
            </tr>
            <tr><td colSpan="9" style="border:none !important"></td></tr>
            `
        )
    }).join("")

    // First group by company


    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Pension Report</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>



                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "All Employees" },
                                    ...empData?.filter(j => j.EmploymentStatus === "Active"&& j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className={"w-100"} onClick={handleGetData}>Show</YsecButton>
                        </Col>

                    </Row>

                    <Row>
                        <Col xs={0} lg={2}></Col>
                        <Col xs={12} lg={8} >
                            <div className="mx-auto mt-2" >

                                {data?.length !== 0 ?
                                    <>
                                        <JoditEditor
                                            ref={editor}
                                            value={`      
                                             <div >
                                             <div style="display: flex;  justify-items: end;">    
                               
                                <h5 style="width:55%;text-align:end" class="stafftitle">${userId?.company}</h5>
                                 <p  style="width:45%;text-align:end">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                </div>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;"  class="stafftitle" >Employee pension</h5>
                                </div>            
                                
                          <div class="katableee">
                          <table>
                                                <tr>
                                                    <th>Employee Id</th>
                                                    <th>Title</th>
                                                    <th>Full Name</th>
                                                    <th>Old Employee Id</th>
                                                    <th>Location</th>
                                                    <th>Old Department</th>
                                                    <th>Department</th>
                                                    <th>Amount</th>
                                                    <th>Remark</th>
                                                </tr>
                                                ${htmlContent}
                          </table>
                          </div>
                                            `}
                                            config={config}

                                        />
                                    </>
                                    : <p className='p-3 bg-white'>No Records Found...</p>}



                            </div></Col>
                        <Col xs={0} lg={2}></Col>

                    </Row>

                </div>
            </React.Suspense>
        </div>
    )
}

export default PensionReport;