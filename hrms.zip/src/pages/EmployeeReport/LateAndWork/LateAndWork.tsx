import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from 'jodit-react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const LateAndWork: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [selectedFromDate, setSelectedFromDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [selectedToDate, setSelectedToDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [workData, setWorkData] = useState<any[]>([])
    const [expData, setExpData] = useState<any[]>([])
    const tableRef = useRef<any>(null)
    const tableRef2 = useRef<any>(null)

    const [printData, setPrintData] = useState<boolean>(false)
    const editor = useRef<any>(null);
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }

                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }

    const handlegetData = () => {
        const payload = {
            companyId: userId?.companyId,
            departmentId: 0,
            positionId: 0,
            employeeId: selectEmp,
            fromDate: "",
            toDate: "",
            startDate: selectedFromDate,
            endDate: selectedToDate,
            userId: userId?.user,
            brandId: selectedBrand,
            locationId: locationId,
            //   month: string,
            //   accountType: string,
            //   year: string,
            //   currencyCode: string,
            extraPaymentId: 0
        }

        setLoading(true)
        AxiosLayout.post("/EmployeeReport/GetAttedanceLogerShiftreport", payload).then((res: any) => {
            if (res.status === 200) {
                if (res.data?.Table !== null) {
                    setWorkData(res.data?.Table)

                }
                if (res.data?.Table1 !== null) {
                    setExpData(res.data?.Table1)

                }

                setLoading(false)

            }
        })


    }
    const staticWorkColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 100 },
        { id: 'FullName', header: 'Full Name', filter: true, size: 100 },
        { id: 'DeviceLocation', header: 'Device Location', filter: true, size: 100 },
        {
            id: 'Date', header: 'Date', filter: true, size: 100,
            cell: ({ row }: { row: any }) => {
                const { Date } = row.original;
                return <>{Date?.split("T")[0]}</>
            },
        },
        { id: 'PunchIn', header: 'Punch In', filter: true, size: 100 },
        { id: 'PunchOut', header: 'Punch Out', filter: true, size: 100 },
        { id: 'Time', header: 'Time', filter: true, size: 100 },
        { id: 'Rota', header: 'Rota', filter: true, size: 100 },
        { id: 'LateMinutes', header: 'Late Minutes', filter: true, size: 100 },
        { id: 'GoingOutMinutes', header: 'Going Out Minutes', filter: true, size: 100 },
    ]
    const staticExceptionColumns = [
        { id: 'EmployeeId', header: 'Employee Id', filter: true, size: 100 },
        { id: 'FullName', header: 'Full Name', filter: true, size: 100 },
        { id: 'Description', header: 'Description', filter: true, size: 100 },
        { id: 'Hours', header: 'Hours', filter: true, size: 100 },
        { id: 'Remarks', header: 'Remarks', filter: true, size: 100 },
    ]
    const exportDataAsExcel = () => {
        if (workData.length === 0) {
            alert("No data to export.");
            return;
        }

        const worksheet = XLSX.utils.json_to_sheet(workData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Late And Work Longer Than Shift");

        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'LateWorkLongerThanShift.xlsx');
    };
    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };
    const exportEditorContentAsExcel = () => {
        if (!editor.current) {
            alert("Editor is not ready.");
            return;
        }

        const html = editor.current?.value;
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const tables = doc.querySelectorAll('table');

        if (!tables.length) {
            alert("No tables found.");
            return;
        }

        let mergedSheet: any = {};
        let sheetRowOffset = 0;

        tables.forEach((table, index) => {
            const sheet = XLSX.utils.table_to_sheet(table, { raw: true });

            // Copy each row and cell to the merged sheet with row offset
            Object.keys(sheet).forEach((key) => {
                if (key === '!ref') return;
                const cell = sheet[key];
                const cellRef = XLSX.utils.decode_cell(key);
                const newCellRef = XLSX.utils.encode_cell({ c: cellRef.c, r: cellRef.r + sheetRowOffset });
                mergedSheet[newCellRef] = cell;
            });

            const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
            sheetRowOffset += range.e.r + 2; // Add empty line between tables
        });

        // Calculate new sheet range
        mergedSheet['!ref'] = XLSX.utils.encode_range({
            s: { c: 0, r: 0 },
            e: { c: 10, r: sheetRowOffset }
        });

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, mergedSheet, 'Late And Work Longer Than Shift');

        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'LateWorkLongerThanShift.xlsx');
    };
    return (
        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Late And Work Longer Than Shift Details</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>

                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "All Employees" },
                                    ...empData?.filter(j => j.EmploymentStatus === "Active"&& j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDatePicker
                                name="selectedFromDate"
                                value={selectedFromDate}
                                className="md"
                                placeholderText="Select Date"
                                error="test message"
                                onChange={(e) => setSelectedFromDate(e.target.value)}
                                placeholder="DD-MM-YYYY"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-D"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDatePicker
                                name="selectedToDate"
                                value={selectedToDate}
                                className="md"
                                placeholderText="Select Date"
                                error="test message"
                                onChange={(e) => setSelectedToDate(e.target.value)}
                                placeholder="DD-MM-YYYY"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-D"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className={"w-100"} onClick={() => {
                                setPrintData(false)
                                handlegetData()
                            }}>Show</YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end'>

                            <YsecButton onClick={() => {
                                setPrintData(true)
                                handlegetData()
                            }}
                                className={`w-100`}
                                type="button"
                            >
                                Print
                            </YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end  csv'>

                            <YsecButton
                                className={`w-100 ${workData.length === 0 ? "disbutn" : ""}`}
                                type="button"
                                // onClick={exportDataAsExcel}
                                onClick={() => { if (printData === true) { exportEditorContentAsExcel() } else { exportDataAsExcel() } }}
                                disabled={workData.length === 0}
                            >
                                Export
                            </YsecButton>
                        </Col>
                    </Row>

                    <div className='mt-4'>
                        {printData === false ? <>
                            <Card className='cardheight'>
                                <Card.Header className='pt-0 pb-0'><p className='opening mb-0'>Work Longer Than Shift Details</p></Card.Header>
                                <Card.Body className='cardbodyy2'>
                                    <div className='katable cardtable'>
                                        <YsecTable
                                            rowData={workData}
                                            columnDefs={staticWorkColumns}
                                            filter={true}
                                            pagination={false}
                                            tableRef={tableRef}
                                            pageSize={20}
                                            dragColumnDisable={true}
                                            reRender={true}

                                        />

                                    </div>
                                </Card.Body>
                            </Card>

                            <Card className='mt-4'>
                                <Card.Header className='pt-0 pb-0'><p className='opening mb-0'>Exception Details</p></Card.Header>
                                <Card.Body className='cardbodyy2'>

                                    <div className='katable cardtable'>
                                        <YsecTable
                                            rowData={expData}
                                            columnDefs={staticExceptionColumns}
                                            filter={true}
                                            pagination={false}
                                            tableRef={tableRef2}
                                            pageSize={20}
                                            dragColumnDisable={true}
                                            reRender={true}

                                        />

                                    </div>
                                </Card.Body>
                            </Card>
                        </>
                            :
                            <>
                                <JoditEditor
                                    ref={editor}
                                    value={`      
                                             <div >
                                             <div style="display: flex;  justify-items: end;">    
                               
                                <h6 style="width:55%;text-align:end"  class="stafftitle">${userId?.company}</h6>
                                 <p  style="width:45%;text-align:end">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                </div>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" >Employee Worked Longer than Shift</h5>
                                </div>      
                                <h6>Attendance Details</h6>      
                                <div class="katableee">       
                                             <table width="100%" border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; font-size: 12px;">
                                            <thead>
                                                <tr>
                                               <th>Emp Id</th>
                                               <th>Name</th>
                                               <th>Device Location</th>
                                               <th>Date</th>
                                               <th>Punch In</th>
                                               <th>Punch Out</th>
                                               <th>Time</th>
                                               <th>Rota</th>
                                               <th>Late Minutes</th>
                                               <th>Going Out Minutes</th>
                                                </tr>
                                            </thead>
                                           ${expData?.length !== 0 ? `<tbody>
                                            
                                                ${workData.map(row => `
                                                <tr>
                                                   
                                               <td>${row?.EmployeeId || ""}</td>
                                               <td>${row?.FullName || ""}</td>
                                               <td>${row?.DeviceLocation || ""}</td>
                                               <td>${row?.Date?.split("T")[0] || ""}</td>
                                               <td>${row?.PunchIn || ""}</td>
                                               <td>${row?.PunchOut || ""}</td>
                                               <td>${row?.Time || ""}</td>
                                               <td>${row?.Rota || ""}</td>
                                               <td>${row?.LateMinutes || ""}</td>
                                               <td>${row?.GoingOutMinutes || ""}</td>
                                                </tr>
                                                `).join('')}
                                            </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="10">No Results Found</td></tbody>`}
                                            </table>                       
                                              <h6>Exception Details</h6>      
                                <div class="katableee">       
                                             <table width="100%" border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; font-size: 12px;">
                                            <thead>
                                                <tr>
                                               <th>Emp Id</th>
                                               <th>Name</th>
                                               <th>Date</th>
                                               <th>Description</th>
                                               <th>Hours</th>
                                               <th>Remarks</th>
                                                </tr>
                                            </thead>
                                            
                                            ${expData?.length !== 0 ? `<tbody>
                                                ${expData.map(row => `
                                                <tr>
                                                   
                                               <td>${row?.EmployeeId || ""}</td>
                                               <td>${row?.FullName || ""}</td>
                                               <td>${row?.Date || ""}</td>
                                               <td>${row?.Description || ""}</td>
                                               <td>${row?.Hours || ""}</td>
                                               <td>${row?.Remarks || ""}</td>
                                                </tr>
                                                `).join('')}
                                            </tbody>`
                                            :
                                            `<tbody><tr><td colSpan="6">No Results Found</td></tbody>`}
                                            </table>             
                                               </div>         
                                            `}
                                    config={config}

                                />


                            </>}

                    </div>

                </div>
            </React.Suspense>
        </div>
    )
}

export default LateAndWork;