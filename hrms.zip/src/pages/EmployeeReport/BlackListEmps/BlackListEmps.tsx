import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import JoditEditor from 'jodit-react';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const BlackListEmployees: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const tableRef = useRef<any>(null);
    const printRef = useRef<any>(null);
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const [selectedPosition, setSelectedPosition] = useState<number>(0)
    const [pendingContractData, setPendingContractData] = useState<any[]>([])
    const [columns, setColumns] = useState<any[]>([])
    const [salaryPeriodData, setSalaryPeriodData] = useState<any[]>([])
    const [fromPeriod, setFromPeriod] = useState<number>(0);
    const [toPeriod, setToPeriod] = useState<number>(0);
    const [printData, setPrintData] = useState<boolean>(false)
    const editor = useRef<any>(null);

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }
                if (res.data.SalaryPeriodList !== null) {
                    setSalaryPeriodData(res.data.SalaryPeriodList)
                }
                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
        setFromPeriod(0)
        setToPeriod(0)
    }

    const handlegetData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }

        else {
            const payload =
            {
                companyId: userId?.companyId,
                departmentId: selectedDept,
                positionId: selectedPosition,
                employeeId: selectEmp,
                fromDate: fromPeriod,
                toDate: toPeriod,
                userId: userId?.user,
                brandId: selectedBrand,
                locationId: locationId,
                projectId: 0,
                year: 0,
                reportType: 0,
                rotaMonth: true,
                rotaWeekNo: true,
                salaryTypeId: 0,
                basicNumber: 0,
                noofdays: 0
            }

            setLoading(true)
            AxiosLayout.post("/EmployeeReport/GetBlackLists", payload).then((res: any) => {
                if (res.status === 200) {
                    if (res?.data?.Table && res?.data?.Table.length > 0) {
                        setPendingContractData(res?.data?.Table);
                        const firstRow = res.data.Table[0];
                        const dynamicColumns = Object.keys(firstRow).map((key) => {
                            if (key === 'IsActive') {
                                return {
                                    id: key,
                                    header: key,
                                    columnType: 'display',
                                    size: 100,
                                    cell: ({ row }: { row: any }) => {
                                        const { IsActive } = row.original;
                                        return (
                                            <div className='text-center'>
                                                <input type='checkbox' value={IsActive} name='IsActive' checked={IsActive === true} /></div>
                                        );
                                    },
                                }
                            }
                            return {
                                id: key,
                                header: key,
                                filter: true,
                                size: 158,
                            }
                        });
                        setColumns(dynamicColumns);
                        setLoading(false)
                    } else {
                        setPendingContractData([]);
                        setColumns([]);
                        setLoading(false)

                    }
                }

            })
        }

    }


    const exportDataAsExcel = () => {
        if (pendingContractData.length === 0) {
            alert("No data to export.");
            return;
        }

        const worksheet = XLSX.utils.json_to_sheet(pendingContractData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Pension History");

        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'Pending-Contracts.xlsx');
    };
    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };

    return (
        <div className="p-2">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Black List Employees</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All Departments" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)}  defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "Select Position" },
                                    ...positionsData?.filter((j: any) => j.DepartmentId == selectedDept)?.map((i: any) => ({
                                        id: i?.PostionId,
                                        Name: i?.Position
                                    }))
                                ]}
                                value={selectedPosition}
                                onChange={(e) => setSelectedPosition(e.target.value)}  defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="desc"
                                objectValueKey="id"
                                data={[
                                    { id: 0, desc: "From" },
                                    ...salaryPeriodData?.filter(j =>  j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        id: i?.Period,
                                        desc: i?.PeriodDescription
                                    }))

                                ]}
                                value={fromPeriod}
                                onChange={(e) => {
                                    setFromPeriod(e.target.value)
                                    setToPeriod(e.target.value)
                                }}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="desc"
                                objectValueKey="id"
                                data={[
                                    { id: 0, desc: "To" },
                                    ...salaryPeriodData?.filter(j =>  j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        id: i?.Period,
                                        desc: i?.PeriodDescription
                                    }))

                                ]}
                                value={toPeriod}
                                onChange={(e) => setToPeriod(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "All Employees" },
                                    ...empData?.filter(j => j.EmploymentStatus === "Active"&& j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={1} className="mt-2  d-flex align-items-end">
                            <YsecButton type='button' className={"w-100"} onClick={() => {
                                setPrintData(false)
                                handlegetData()
                            }}>Show</YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end'>

                            <YsecButton onClick={() => {
                                setPrintData(true)
                                handlegetData()
                            }}
                                className={`w-100`}
                                type="button"
                            >
                                Print
                            </YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end  csv'>

                            <YsecButton
                                className={`w-100 ${pendingContractData.length === 0 ? "disbutn" : ""}`}
                                type="button"
                                onClick={exportDataAsExcel}
                                disabled={pendingContractData.length === 0}
                            >
                                Export
                            </YsecButton>
                        </Col>
                    </Row>


                    <div className='mt-2'>
                        {printData === false ?
                            <div className='katable ' ref={printRef}>
                                {pendingContractData?.length > 0 && columns?.length > 0 && (
                                    <YsecTable
                                        rowData={pendingContractData}
                                        columnDefs={columns}
                                        filter={true}
                                        pagination={true}
                                        tableRef={tableRef}
                                        pageSize={20}
                                        dragColumnDisable={true}
                                        reRender={true}

                                    />
                                )}
                            </div> :
                            <>
                                <JoditEditor
                                    ref={editor}
                                    value={`      
                                             <div >
                                             <div style="display: flex;  justify-items: end;">    
                               
                                <h6 style="width:55%;text-align:end"  class="stafftitle">${userId?.company}</h6>
                                 <p  style="width:45%;text-align:end">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                </div>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" >Black List Employee Report</h5>
                                </div>            
                                <div class="katableee">       
                                             <table width="100%" border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; font-size: 12px;">
                                            <thead>
                                                <tr>
                                                ${columns.map(col => `<th>${col.header}</th>`).join('')}
                                                </tr>
                                            </thead>
                                            <tbody>
                                                ${pendingContractData.map(row => `
                                                <tr>
                                                    ${columns.map(col => `<td>${row[col.id] !== null ? row[col.id] : ''}</td>`).join('')}
                                                </tr>
                                                `).join('')}
                                            </tbody>
                                            </table>                       
                                                      
                                               </div>         
                                            `}
                                    config={config}

                                />


                            </>}
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}

export default BlackListEmployees;