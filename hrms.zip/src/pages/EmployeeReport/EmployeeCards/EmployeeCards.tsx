import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from "jodit-react";
import JsBarcode from 'jsbarcode';
import { createCanvas } from 'canvas';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}



export const generateBarcodeBase64 = (text: string): string => {
    const canvas = createCanvas();
    JsBarcode(canvas, text, {
        format: 'CODE128',
        displayValue: false,
        height: 40,
        width: 2,
        margin: 0,
    });
    return canvas.toDataURL('image/png');
};


const EmployeeCards: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const [selectedPosition, setSelectedPosition] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [table, setTable] = useState<any[]>([])
    const editor = useRef<any>(null);
    const [changeRadio, setChangeRadio] = useState<string | number>("Automatic")
    const [selectSize, setSelectSize] = useState<string>("14x10")
    const [radiovis, setReadioVis] = useState<string>("Self Fill")
    const [visName, setVisName] = useState<string>("")
    const [posName, setPosName] = useState<string>("")
    const [depName, setDepName] = useState<string>("")
    const [headName, setHeadName] = useState<string>("")

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])

    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }

                setLoading(false)

            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }

    const handleGetData = () => {



        const payload = {
            companyId: selectedBrand,
            employeeId: selectEmp,
            department: selectedDept,
            position: selectedPosition,
            isself: changeRadio === "Self Fill" ? true : false,
            masterCompanyId: userId?.companyId,
            rptdeptid: selectedDept,
            rptposid: selectedPosition,
            userId: userId?.user

        }
        setLoading(true)
        AxiosLayout.post("/EmployeeReport/GetEmpCardDetails", payload).then((res: any) => {
            if (res.status === 200) {
                if (res.data?.Table !== null) {
                    setTable(res?.data?.Table)
                    setLoading(false)
                }
            }
        })
    }




    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };


    let htmlContent = '';
    const tabledata = table.map((i: any, index: number) => {
        const barcodeBase64 = generateBarcodeBase64(i.EmployeeId || '');
        const size1410 = `

                        <div style="width:380px;text-align:center;overflow:auto" >
                            <hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
                            <h5 style="color:#6074B0">${i.CompanyName}</h5>
                            <div style="background-color: #6074B0; padding: 10px; display: flex; justify-content: center;">
                                <div style="background-color: white; padding: 10px; text-align: center; width: 220px; border-radius: 6px;">
                                    <p style="margin: 0 0 6px 0; font-weight: bold;color:red;font-size:large;">${i.StaffId}</p>
                                    <img src="data:image/png;base64,${i.EmployeeImageURL}" alt="Employee" style="width: 180px; height: 180px; border-radius: 4px;" />
                                </div>
                            </div>
                            <p  style="background-color: #6074B0; padding: 10px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"><b>${i.FullName}</b></p>
                            <p  style="background-color: #6074B0; padding: 10px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Department}</p>
                            <p  style="background-color: #6074B0; padding: 10px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Position}</p>
                            <div  style="background-color: #6074B0; padding: 10px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
                                <div style="background-color: white; padding: 10px;padding-top: 0px !important;padding-bottom: 4px !important; text-align: center; width: 220px; border-radius: 6px;">
                                    <img src="${barcodeBase64}" alt="barcode" />
                                    <p style=" margin-bottom:2px;font-size: xx-small;">${i.EmployeeId}</p>
                                </div>
                            </div>

                        </div>

                    `
        const size107 = `

    <div style="width:250px;text-align:center;overflow:auto" >
<hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
<h5 style="color:#6074B0">${i.CompanyName}</h5>
<div style="background-color: #6074B0; padding: 10px; display: flex; justify-content: center;">
  <div style="background-color: white; padding: 10px; text-align: center; width: 150px; border-radius: 6px;">
    <p style="margin: 0 0 6px 0; font-weight: bold;color:red;font-size:large;">${i.StaffId}</p>
    <img src="data:image/png;base64,${i.EmployeeImageURL}" alt="Employee" style="width: 130px; height: 130px; border-radius: 4px;" />
  </div>
</div>
<p  style="background-color: #6074B0; padding: 5px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"><b>${i.FullName}</b></p>
<p  style="background-color: #6074B0; padding: 5px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Department}</p>
<p  style="background-color: #6074B0; padding: 5px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Position}</p>
<div  style="background-color: #6074B0; padding: 5px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
 <div style="background-color: white; padding: 5px;padding-top: 0p2 !important;padding-bottom: 4px !important; text-align: center; width: 200px; border-radius: 6px;">
 <img src="${barcodeBase64}" alt="barcode" />
<p style=" margin-bottom:2px;font-size: xx-small;">${i.EmployeeId}</p>
</div>
</div>

    </div>

    `
        const size910 = `

    <div style="width:360px;text-align:center;overflow:auto" >
<hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
<h5 style="color:#6074B0">${i.CompanyName}</h5>
<div style="background-color: #6074B0; padding: 10px; display: flex; justify-content: center;">
  <div style="background-color: white; padding: 10px; text-align: center; width: 200px; border-radius: 6px;">
    <p style="margin: 0 0 6px 0; font-weight: bold;color:red;font-size:large;">${i.StaffId}</p>
    <img src="data:image/png;base64,${i.EmployeeImageURL}" alt="Employee" style="width:118px; height:85px; border-radius: 4px;" />
  </div>
</div>
<p  style="background-color: #6074B0; padding: 3px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"><b>${i.FullName}</b></p>
<p  style="background-color: #6074B0; padding: 3px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Department}</p>
<p  style="background-color: #6074B0; padding: 3px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Position}</p>
<div  style="background-color: #6074B0; padding: 3px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
 <div style="background-color: white; padding: 10px;padding-top: 0px !important;padding-bottom: 3px !important; text-align: center; width: 150px; border-radius: 6px;">
 <img src="${barcodeBase64}" alt="barcode" />
<p style=" margin-bottom:1px;font-size: xx-small;">${i.EmployeeId}</p>
</div>
</div>

    </div>

    `
        const size95 = `

                    <div style="width:380px;text-align:center;overflow:auto; page-break-inside: avoid; display: inline-block; margin: 5px;">
                        <hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
                        <h5 style="color:#6074B0">${i.CompanyName}</h5>
                        <div style="display:flex">
                            <div style="width:50%">
                                <p  style="background-color: #6074B0; padding: 5px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);min-height:46px !important"><b>${i.FullName}</b></p>
                                <p  style="background-color: #6074B0; padding: 5px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Department}</p>
                                <p  style="background-color: #6074B0; padding: 5px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">${i.Position}</p>
                                <div  style="background-color: #6074B0; padding: 5px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
                                    <div style="background-color: white; padding: 10px;padding-top: 0px !important;padding-bottom: 3px !important; text-align: center; width: 150px; border-radius: 6px;">
                                        <img src="${barcodeBase64}" alt="barcode" />
                                        <p style=" margin-bottom:1px;font-size: xx-small;">${i.EmployeeId}</p>
                                    </div>
                                </div>
                            </div>
                            <div style="width:50%">
                                <div style="background-color: #6074B0; padding: 20px; display: flex; justify-content: center;">
                                    <div style="background-color: white; padding: 2px; text-align: center; width: 130px; border-radius: 6px;">
                                        <p style="margin: 0 0 6px 0; font-weight: bold;color:red;font-size:large;">${i.StaffId}</p>
                                        <img src="data:image/png;base64,${i.EmployeeImageURL}" alt="Employee" style="width:118px; height:85px; border-radius: 4px;" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

    `
        const size104 = `

    <div style="width:320px;text-align:start;overflow:auto;padding:10px;border:1px solid #ccc;margin:10px" >
        <p style="margin-bottom:1px">Deze kaart is eigendom van.</p>
        <h6 style="margin-bottom:1px">Deep Sea Atlantic N.V.</h6>
        <p style="margin-bottom:1px">Sir Winston Churchillweg 808</p>
        <p style="margin-bottom:1px">Tel : (0)370385/6/7</p>
        <p style="margin-bottom:1px">Elke werknemer is veranwoordelijk voor zijn/haar  kaart</p>
        <p style="margin-bottom:1px">Bij verlies hiervan is men verplicht dit aan  te geven</p>
        <p style="margin-bottom:1px">Bij Personeelszaken van Deep Sea Atlantic N.V</p>
        <p style="margin-bottom:1px">Bij het vinden van deze kaart gelieve</p>
        <p style="margin-bottom:1px">contact te maken met Personeelszaken</p>
        <p style="margin-bottom:1px">Deep Sea Atlantic N.V.
        </p>


</div>


    `
        const showdata = selectSize === "14x10" && size1410 || selectSize === "10x7" && size107 || selectSize === "9x10" && size910
        return showdata || selectSize === "9x5" && size95 || selectSize === "10x4" && size104
    }).join("")


    const visitorData = () => {
        const size1410 = `

                        <div style="width:380px;text-align:center;overflow:auto" >
                            <hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
                            <h5 style="color:#6074B0">${headName}</h5>
                            <div style="background-color: #6074B0; padding: 10px; display: flex; justify-content: center;">
                                <div style="background-color: white; padding: 10px; text-align: center; width: 220px; border-radius: 6px;">                           
                                    <div style="width: 180px; height: 180px; border-radius: 4px;">
                                    </div>
                                </div>
                            </div>
                            <div  style="background-color: #6074B0; padding: 20px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"><b>${visName}</b>
                            </div>
                            <div  style="background-color: #6074B0; padding: 20px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">
                            </div>
                            <div  style="background-color: #6074B0; padding: 20px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);">
                            </div>
                            <div  style="background-color: #6074B0; padding: 20px; margin-bottom:4px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
                                <div style="padding: 10px;padding-top: 0px !important;padding-bottom: 4px !important; text-align: center; width: 220px; border-radius: 6px;">
                                   
                                    <div style=" margin-bottom:2px;font-size: xx-small;"></div>
                                </div>
                            </div>

                        </div>

                    `
        const size107 = `

                        <div style="width:250px;text-align:center;overflow:auto" >
                        <hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
                        <h5 style="color:#6074B0">${headName}</h5>
                        <div style="background-color: #6074B0; padding: 10px; display: flex; justify-content: center;">
                        <div style="background-color: white; padding: 10px; text-align: center; width: 150px; border-radius: 6px;">
                            <div style="width: 180px; height: 180px; border-radius: 4px;">
                                                            </div>

                        </div>
                        </div>
                        <p  style="background-color: #6074B0; padding: 15px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"><b>${visName}</b></p>
                        <p  style="background-color: #6074B0; padding: 15px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"></p>
                        <p  style="background-color: #6074B0; padding: 15px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"></p>
                        <div  style="background-color: #6074B0; padding: 15px; margin-bottom:2px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
                        <div style=" padding: 5px;padding-top: 0px !important;padding-bottom: 4px !important; text-align: center; width: 200px; border-radius: 6px;">
                        <p style=" margin-bottom:2px;font-size: xx-small;"></p>
                        </div>
                        </div>

                        </div>

    `
        const size910 = `

                    <div style="width:360px;text-align:center;overflow:auto" >
                    <hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
                    <h5 style="color:#6074B0">${headName}</h5>
                    <div style="background-color: #6074B0; padding: 10px; display: flex; justify-content: center;">
                    <div style="background-color: white; padding: 10px; text-align: center; width: 200px; border-radius: 6px;">
                    <div style="width: 180px; height: 180px; border-radius: 4px;">
                                                        </div>
                        </div>
                    </div>
                    <p  style="background-color: #6074B0; padding: 10px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"><b>${visName}</b></p>
                    <p  style="background-color: #6074B0; padding: 10px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"></p>
                    <p  style="background-color: #6074B0; padding: 10px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"></p>
                    <div  style="background-color: #6074B0; padding: 10px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
                    <div style=" padding: 10px;padding-top: 0px !important;padding-bottom: 3px !important; text-align: center; width: 150px; border-radius: 6px;">
                    <p style=" margin-bottom:1px;font-size: xx-small;"></p>
                    </div>
                    </div>

                    </div>

    `
        const size95 = `

                    <div style="width:380px;text-align:center;overflow:auto; page-break-inside: avoid; display: inline-block; margin: 5px;">
                        <hr style="border-top:10px solid #6074B0 !important;opacity:unset !important;"/>
                        <h5 style="color:#6074B0">${headName}</h5>
                        <div style="display:flex">
                            <div style="width:50%">
                                <p  style="background-color: #6074B0; padding: 5px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);min-height:46px !important;padding-top:10px"><b>${visName}</b></p>
                                <p  style="background-color: #6074B0; padding: 20px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"></p>
                                <p  style="background-color: #6074B0; padding: 20px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);"></p>
                                <div  style="background-color: #6074B0; padding: 20px; margin-bottom:1px;background-image:  linear-gradient(to right, #92A0C9, white , #92A0C9);display: flex; justify-content: center;">
                                    <div style=" padding: 20px;padding-top: 0px !important;padding-bottom: 3px !important; text-align: center; width: 150px; border-radius: 6px;">
                                        
                                        <p style=" margin-bottom:1px;font-size: xx-small;"></p>
                                    </div>
                                </div>
                            </div>
                            <div style="width:50%">
                                <div style="background-color: #6074B0; padding: 20px; display: flex; justify-content: center;">
                                    <div style="padding: 2px; text-align: center; width: 130px; border-radius: 6px;">
                                         <div style="width: 129px; height: 129px; border-radius: 4px;background-color:white">
                                    </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

    `
        const size104 = `

                    <div style="width:320px;text-align:start;overflow:auto;padding:10px;border:1px solid #ccc;margin:10px" >
                        <p style="margin-bottom:1px">Deze kaart is eigendom van.</p>
                        <h6 style="margin-bottom:1px">Deep Sea Atlantic N.V.</h6>
                        <p style="margin-bottom:1px">Sir Winston Churchillweg 808</p>
                        <p style="margin-bottom:1px">Tel : (0)370385/6/7</p>
                        <p style="margin-bottom:1px">Elke werknemer is veranwoordelijk voor zijn/haar  kaart</p>
                        <p style="margin-bottom:1px">Bij verlies hiervan is men verplicht dit aan  te geven</p>
                        <p style="margin-bottom:1px">Bij Personeelszaken van Deep Sea Atlantic N.V</p>
                        <p style="margin-bottom:1px">Bij het vinden van deze kaart gelieve</p>
                        <p style="margin-bottom:1px">contact te maken met Personeelszaken</p>
                        <p style="margin-bottom:1px">Deep Sea Atlantic N.V.
                        </p>


                </div>


    `
        const showdata = selectSize === "14x10" && size1410 || selectSize === "10x7" && size107 || selectSize === "9x10" && size910
        return showdata || selectSize === "9x5" && size95 || selectSize === "10x4" && size104
    }

    htmlContent += changeRadio === "Visitor" ? visitorData() : tabledata;

    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Employee Cards</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All Departments" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)} defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "Select Position" },
                                    ...positionsData?.filter((j: any) => j.DepartmentId == selectedDept)?.map((i: any) => ({
                                        id: i?.PostionId,
                                        Name: i?.Position
                                    }))
                                ]}
                                value={selectedPosition}
                                onChange={(e) => setSelectedPosition(e.target.value)} defaultSelectedValue="0"
                            /></Col>

                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "All Employees" },
                                    ...empData?.filter(j => j.EmploymentStatus === "Active"&& j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                        empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>


                    </Row>
                    <Row>
                        <Col xs={12} md={1} lg={1} className='md-none mt-3'></Col>
                        <Col xs={12} md={12} lg={8} className="offer-letter-padding-lg  mt-3 ">

                            {table?.length !== 0 ?
                                <div className='staffsummary'>
                                    <JoditEditor
                                        ref={editor}
                                        value={`      
                                                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(390px, 1fr)); gap: 5px; justify-items: center;">                    
                                             ${htmlContent}    
                                             </div>                       
                                            `}
                                        config={config}

                                    />
                                </div>
                                : <p className='p-3 bg-white'>No Data Found Here...</p>}
                        </Col>
                        <Col xs={12} md={12} lg={3} className='md-none  mt-3'>
                            <Row>
                                <Col xs={12}>
                                    <YsecSelect className={`md `} label="Size"
                                        objectNameKey="name"
                                        objectValueKey="id"
                                        data={[
                                            { id: "14x10", name: "14x10" },
                                            { id: "9x5", name: "9x5" },
                                            { id: "10x7", name: "10x7" },
                                            { id: "9x10", name: "9x10" },
                                            { id: "10x4", name: "10x4" },
                                        ]}
                                        value={selectSize}
                                        onChange={(e) => setSelectSize(e.target.value)}

                                    />
                                </Col>
                                <Col xs={12}>
                                    <YsecRadio
                                        label="Automatic"
                                        name="changeRadio"
                                        className="test"
                                        id="leaveValue1"
                                        value={"Automatic"}
                                        onChange={(e: any) => {
                                            setChangeRadio(e.target.value)
                                        }}
                                        checked={changeRadio == "Automatic"}
                                    />
                                    <YsecRadio
                                        label="Self Fill"
                                        name="changeRadio"
                                        id="leaveValue2"
                                        className="test"
                                        value={"Self Fill"}
                                        onChange={(e: any) => {
                                            setChangeRadio(e.target.value)
                                            setReadioVis(e.target.value)
                                        }}
                                        checked={changeRadio == "Self Fill"}
                                    />
                                    <YsecRadio
                                        label="Visitor"
                                        name="changeRadio"
                                        className="test" value={"Visitor"}
                                        id="leaveValue3"
                                        onChange={(e: any) => {
                                            setChangeRadio(e.target.value)
                                            setReadioVis(e.target.value)
                                        }}
                                        checked={changeRadio == "Visitor"}
                                    />
                                    <YsecRadio
                                        label="Front"
                                        name="changeRadio"
                                        className="test"
                                        value={"Front"}
                                        id="leaveValue4"
                                        onChange={(e: any) => {
                                            setChangeRadio(e.target.value)
                                        }}
                                        checked={changeRadio == "Front"}
                                    />
                                    <YsecRadio
                                        label="Back"
                                        name="changeRadio"
                                        className="test"
                                        value={"Back"}
                                        id="leaveValue5"
                                        // onChange={(e: any) => {
                                        //     setChangeRadio(e.target.value)
                                        // }}
                                        // checked={changeRadio == "Back"}
                                        disabled
                                    />
                                </Col>
                                <Col xs={12}>
                                    <YsecInput label="Header" name="headName" value={headName} onChange={(e: any) => setHeadName(e.target.value)} />
                                </Col>
                                {radiovis === "Self Fill" &&
                                    <Col xs={12}>
                                        <YsecInput label="Department" name="depName" value={depName} onChange={(e: any) => setDepName(e.target.value)} />
                                    </Col>}
                                {radiovis === "Visitor" &&
                                    <Col xs={12}>
                                        <YsecInput label="Visitor Name" name="visName" value={visName} onChange={(e: any) => setVisName(e.target.value)} />
                                    </Col>
                                }
                                <Col xs={12}>
                                    <YsecInput label="Position" disabled={changeRadio !== "Self Fill"} name="posName" value={posName} onChange={(e: any) => setPosName
                                        (e.target.value)} />
                                </Col>
                                <Col xs={12} className="mt-2">
                                    <YsecButton type='button' className='w-100' onClick={handleGetData}>Show</YsecButton>
                                </Col>
                            </Row>

                        </Col>


                    </Row>

                    {/* <div dangerouslySetInnerHTML={{ __html: htmlContent }} /> */}

                </div>
            </React.Suspense>
        </div>
    )
}

export default EmployeeCards;