import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from "jodit-react";

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const CustomCell: React.FC<any> = ({ value }) => {
    let className = value === "Active"
        ? "active"
        : value === "In Active"
            ? "inactive"
            : undefined;

    return (
        <div className={className}>
            {value}
        </div>
    );
};
const LogReport: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [selectedFromDate, setSelectedFromDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [selectedToDate, setSelectedToDate] = useState<string>(new Date().toISOString()?.split("T")[0])
        const editor = useRef<any>(null);
const [data,setData]=useState<any[]>([])
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);



    const handleGetData = () => {
        if (selectedFromDate == "") {
            setErrorMessage("Please Select From Date...")
        }
        else if (selectedToDate === "") {
            setErrorMessage("Please Select To Date...")
        }

        else {
            getEmpDetails()

        }
    }
    const getEmpDetails = () => {
        setLoading(true)
        const payload = {

            companyId: userId?.companyId,
            departmentId: 0,
            positionId: 0,
            employeeId: 0,
            fromDate: selectedFromDate,
            toDate: selectedToDate,
            userId: userId?.user,
            brandId: 0,
            locationId: 0,
            projectId: 0,
            year: 0,
            reportType: 0,
            rotaMonth: true,
            rotaWeekNo: true,
            salaryTypeId: 0,
            basicNumber: 0,
            noofdays: 0

        }
        AxiosLayout.post("/EmployeeReport/GetLogReport", payload).then((res: any) => {
            if (res?.status === 200) {
                setData(res?.data?.Table)
                setLoading(false)
            }
        })
    }
    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };
    let htmlContent = '';
     htmlContent += data.map((i: any, index: number) => {
        return `
        <tr>
            <td>${i.UserName}</td>
            <td>${i.Action}</td>
            <td>${i.Form}</td>
            <td>${i.LogDetails}</td>
            <td>${i.UpdateDate?.split("T")[0]}</td>
        </tr>
        `
    }).join("")
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Log Report</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                       
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDatePicker
                                name="selectedFromDate"
                                value={selectedFromDate}
                                className="md"
                                placeholderText="Select Date"
                                error="test message"
                                onChange={(e) => setSelectedFromDate(e.target.value)}
                                placeholder="DD-MM-YYYY"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-D"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                            /></Col>
                            <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDatePicker
                                name="selectedToDate"
                                value={selectedToDate}
                                className="md"
                                placeholderText="Select Date"
                                error="test message"
                                onChange={(e) => setSelectedToDate(e.target.value)}
                                placeholder="DD-MM-YYYY"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-D"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className={"w-100"} onClick={handleGetData}>Show</YsecButton>
                        </Col>

                    </Row>

                 
                    <Row>
                        <Col xs={0} lg={2}></Col>
                        <Col xs={12} lg={8}>
                            <div className="mx-auto mt-2" >

                                {data?.length !== 0 ?
                                    <>
                                        <JoditEditor
                                            ref={editor}
                                            value={`      
                                             <div >
                                             <div style="display: flex;  justify-items: end;">    
                               
                                <h6 style="width:55%;text-align:end"  class="stafftitle">${userId?.company}</h6>
                                 <p  style="width:45%;text-align:end">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                </div>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" >Log Report</h5>
                                </div>            
                                <div class="katableee">       
                                <table width="100%;">
                                <tr>
                                    <th>User Name</th>
                                    <th>Action</th>
                                    <th>Module</th>
                                    <th>Log Details</th>
                                    <th>Update Date</th>
                                </tr>
                            ${htmlContent}
                            </table>                                   
                                                      
                                               </div>         
                                            `}
                                            config={config}

                                        />
                                    </>
                                    : <p className='p-3 bg-white nodata' >No Data Found Here...</p>}



                            </div></Col>
                        <Col xs={0} lg={2}></Col>

                    </Row>
                </div>
            </React.Suspense>
        </div>
    )
}

export default LogReport;