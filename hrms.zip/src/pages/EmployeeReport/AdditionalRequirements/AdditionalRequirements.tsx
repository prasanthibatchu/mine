import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from "jodit-react";
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const AdditionalRequirements: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const tableRef = useRef<any>(null);
    const [addreqData, setaddreqData] = useState<any[]>([])
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const editor = useRef<any>(null);
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }

                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                setLoading(false)
            }
        })
    }
   

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
    }
    const handleGetData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }

        else {
            getEmpDetails()

        }
    }
    const getEmpDetails = () => {
        setLoading(true)
        const payload = {
            companyId: userId?.companyId,
            departmentId: selectedDept,
            positionId: 0,
            employeeId: 0,
           
            userId: userId?.user,
            brandId: selectedBrand,
            locationId:locationId,
            projectId: 0,
            year: 0,
            reportType: 0,
            rotaMonth: true,
            rotaWeekNo: true,
            salaryTypeId: 0,
            basicNumber: 0,
            noofdays: 0
        }
        AxiosLayout.post("/EmployeeReport/GetAdditionalReport", payload).then((res: any) => {
            if (res?.status === 200) {
                setaddreqData(res?.data?.Table)
                setLoading(false)
            }
        })
    }



    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };
let htmlContent = '';

const grouped = addreqData?.reduce((acc: any, curr: any) => {
    const deptId = curr?.SupDepartmentID || 'Unknown';
    if (!acc[deptId]) acc[deptId] = [];
    acc[deptId].push(curr);
    return acc;
}, {});
// Sort departments numerically or alphabetically
const sortedDeptIds = Object.keys(grouped) // or parseInt(a)-parseInt(b) if numeric

sortedDeptIds.forEach((deptId) => {
    const deptGroup = grouped[deptId];
    const firstEmp = deptGroup[0];

    htmlContent += `
      

        <div class="katableee">
            <table width="100%" border="1" cellspacing="0" cellpadding="4">
                <tr>
                    <td colSpan="2" style="border:none !important;font-weight:bold !important;background-color: #d1d5db !important;color:black !important">${firstEmp?.SupDepartment}</td>
                </tr>
                <tr>
                    <th>EmpID</th>
                    <th>Name</th>
                    <th>DOB</th>
                    <th>Job Title</th>
                    <th>Driver Licence</th>
                    <th>Police Clearance</th>
                    <th>CBB Extract</th>
                    <th>Badge</th>
                    <th>SOR</th>
                </tr>
                ${deptGroup.map((emp:any) => `
                    <tr>
                        <td>${emp?.EmpID || ''}</td>
                        <td>${emp?.EmpName || ''}</td>
                        <td>${emp?.DateOfBirth || ''}</td>
                        <td>${emp?.JobTitle || ''}</td>
                        <td>${emp?.DriverLiecense || ''}</td>
                        <td>${emp?.PoliceClearance || ''}</td>
                        <td>${emp?.CBBExtract || ''}</td>
                        <td>${emp?.Badge || ''}</td>
                        <td>${emp?.SOR || ''}</td>
                    </tr>
                `).join('')}
            </table>
        </div>
    `;
});
    const exportDataAsExcel = () => {
        if (addreqData.length === 0) {
            alert("No data to export.");
            return;
        }

        const worksheet = XLSX.utils.json_to_sheet(addreqData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Additional Requirements");

        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'Additional_Requirements.xlsx');
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Additional Requiremnets</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All Departments" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)}  defaultSelectedValue="0"
                            /></Col>

                       

                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className={"w-100"} onClick={handleGetData}>Show</YsecButton>
                        </Col>
  <Col xs={12} sm={6} md={1} className='mt-1  d-flex align-items-end  csv'>

                            <YsecButton
                                className={`w-100 ${addreqData.length === 0 ? "disbutn" : ""}`}
                                type="button"
                                onClick={exportDataAsExcel}
                                disabled={addreqData.length === 0}
                            >
                                Export
                            </YsecButton>
                        </Col>
                    </Row>

                    <Row>
                        <Col xs={0} lg={2}></Col>
                        <Col xs={12} lg={8}>
                            <div className="mx-auto mt-2" >

                                {addreqData?.length !== 0 ?
                                    <>
                                        <JoditEditor
                                            ref={editor}
                                            value={`      
                                             <div >
                                             <div style="display: flex;  justify-items: end;">    
                               
                                <h5 style="width:50%;text-align:end" class="stafftitle">${userId?.company}</h5>
                                 <p  style="width:50%;text-align:end">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                </div>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" >Additional Requirement Report</h5>
                                </div>            
                                
                            ${htmlContent}      
                                            `}
                                            config={config}

                                        />
                                    </>
                                    : <p className='p-3 bg-white'>No Data Found Here...</p>}



                            </div></Col>
                        <Col xs={0} lg={2}></Col>

                    </Row>

                </div>
            </React.Suspense>
        </div>
    )
}

export default AdditionalRequirements;