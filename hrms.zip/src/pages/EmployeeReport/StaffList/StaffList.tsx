import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from "jodit-react";
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));

interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}


const StaffList: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const [departmentData, setDepartmentdata] = useState<any[]>([])
    const [positionsData, setPositionsData] = useState<any[]>([])
    const [selectedDept, setSelectedDept] = useState<number>(0)
    const [selectedPosition, setSelectedPosition] = useState<number>(0)
    const [empData, setEmpData] = useState<any[]>([])
    const [selectEmp, setSelectEmp] = useState<number>(0)
    const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString()?.split("T")[0])
    const [data, setData] = useState<any[]>([])
    const [sdata, setSData] = useState<any[]>([])

    const editor = useRef<any>(null);

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
        getEmployeeData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }
                }
                if (res.data?.DepartmentList !== null) {
                    setDepartmentdata(res.data.DepartmentList)
                }
                if (res.data.PositionList !== null) {
                    setPositionsData(res.data.PositionList)
                }
                setLoading(false)
            }
        })
    }
    const getEmployeeData = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res: any) => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
        setSelectEmp(0)
    }

    const handleGetData = () => {
        const payload = {
            companyId: userId?.companyId,
            departmentId: selectedDept,
            positionId: selectedPosition,
            employeeId: selectEmp,
            userId: userId?.user,
            brandId: selectedBrand,
            locationId: locationId,
        }
        setLoading(true)
        AxiosLayout.post("/EmployeeReport/GetCurrentStaffList", payload).then((res: any) => {
            if (res.status === 200) {
                if (res.data?.Table !== null) {
                    setData(res?.data?.Table)
                }
                if (res.data?.Table1 !== null) {
                    setSData(res?.data?.Table1)
                }
                setLoading(false)
            }
        })
    }



    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };

    const grouped = sdata?.reduce((acc: any, curr: any) => {
        const dept = curr?.DepartmentName || "Unknown";
        if (!acc[dept]) acc[dept] = [];
        acc[dept].push(curr);
        return acc;
    }, {});




    const sortedDepartments = Object?.keys(grouped).sort((a, b) =>
        a.localeCompare(b)
    );
    let htmlContent = '';


    sortedDepartments.forEach((dept) => {
        const firstEmp = grouped[dept][0];

        htmlContent += `
       
    <table width="100%">
     <tr>
                                    <td  colspan="2" style="width:25%">
                                    <b> ${data[0]?.CompanyName || ''} </b>                           
                                    </td>
                                    <td style="width:25%">
                                    <b style="padding-right:10px;">Male </b>${data[0]?.Male || '0'}
                                    </td>
                                    <td style="width:25%">
                                    <b style="padding-right:10px;">Female </b>${data[0]?.Female || '0'}
                                    </td>
                                    <td style="width:25%">
                                    <b style="padding-right:10px;">Total </b>${data[0]?.Total || '0'}
                                    </td>
                                    </tr>  
      <tr>
        <td  colspan="2" style="width:25%"><b>${dept}</b></td>
        <td style="width:25%"> <b style="padding-right:10px;">Male </b>${firstEmp?.Male || '0'}</td>
        <td style="width:25%"><b style="padding-right:10px;">Female </b>${firstEmp?.Female || '0'}</td>
        <td style="width:25%"> <b style="padding-right:10px;">Total </b>${firstEmp?.Total || '0'}</td>

      </tr>
    <tr style="border-top:2px solid black">
    <td></td></tr>
  `;

        // Group employees by Position
        const positionGroups = grouped[dept].reduce((acc: any, emp: any) => {
            const position = emp.Position || 'Unknown';
            if (!acc[position]) acc[position] = [];
            acc[position].push(emp);
            return acc;
        }, {});

        // Sort position names A → Z
        const sortedPositions = Object.keys(positionGroups).sort((a, b) => a.localeCompare(b));

        sortedPositions.forEach((position) => {
            htmlContent += `
      <tr>
        <td colspan="12" style="padding: 5px; background: #eee; text-align: center;">
          ${position}
        </td>
      </tr>
    `;
            positionGroups[position].forEach((emp: any) => {
                htmlContent += `
        <tr>
          <td style="padding: 5px;">${emp.EmployeeId}</td>
          <td style="padding: 5px;">${emp.Name}</td>
          <td style="padding: 5px;">${new Date(emp.DOE).toLocaleDateString()}</td>
          <td style="padding: 5px;">${emp.Mobile}</td>
          <td style="padding: 5px;">${new Date(emp.ContractStartDate).toLocaleDateString()}</td>
        </tr>
      `;
            });
        });

        htmlContent += `</table>`;
    });



    const exportEditorContentAsExcel = () => {
        if (!editor.current) {
            alert("Editor is not ready.");
            return;
        }

        const html = editor.current?.value;
        const parser = new DOMParser();
        const doc = parser.parseFromString(html, 'text/html');
        const tables = doc.querySelectorAll('table');

        if (!tables.length) {
            alert("No tables found.");
            return;
        }

        let mergedSheet: any = {};
        let sheetRowOffset = 0;

        tables.forEach((table, index) => {
            const sheet = XLSX.utils.table_to_sheet(table, { raw: true });

            // Copy each row and cell to the merged sheet with row offset
            Object.keys(sheet).forEach((key) => {
                if (key === '!ref') return;
                const cell = sheet[key];
                const cellRef = XLSX.utils.decode_cell(key);
                const newCellRef = XLSX.utils.encode_cell({ c: cellRef.c, r: cellRef.r + sheetRowOffset });
                mergedSheet[newCellRef] = cell;
            });

            const range = XLSX.utils.decode_range(sheet['!ref'] || 'A1:A1');
            sheetRowOffset += range.e.r + 2; // Add empty line between tables
        });

        // Calculate new sheet range
        mergedSheet['!ref'] = XLSX.utils.encode_range({
            s: { c: 0, r: 0 },
            e: { c: 10, r: sheetRowOffset }
        });

        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, mergedSheet, 'Staff List');

        const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        saveAs(new Blob([wbout], { type: 'application/octet-stream' }), 'staff-list.xlsx');
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Staff List</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "All Departments" },
                                    ...departmentData?.map((i: any) => ({
                                        id: i?.DepartmentId,
                                        Name: i?.Department
                                    }))
                                ]}
                                value={selectedDept}
                                onChange={(e) => setSelectedDept(e.target.value)}
                                defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md`}
                                objectNameKey="Name"
                                objectValueKey="id"
                                data={[
                                    { id: 0, Name: "Select Position" },
                                    ...positionsData?.filter((j: any) => j.DepartmentId == selectedDept)?.map((i: any) => ({
                                        id: i?.PostionId,
                                        Name: i?.Position
                                    }))
                                ]}
                                value={selectedPosition}
                                onChange={(e) => setSelectedPosition(e.target.value)}
                                 defaultSelectedValue="0"
                            /></Col>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecDropdown className={`md `}
                                objectNameKey="empName"
                                objectValueKey="empId"
                                data={[
                                    { empId: 0, empName: "Select Employee" },
                                    ...empData?.filter(j=>j.EmploymentStatus==="Active" && j.HierachyId === selectedBrand)?.map((i: any) => ({
                                        empId: i?.EmployeeId,
                                       empName: i?.EmployeeId + " -- " + i?.FullName
                                    }))

                                ]}
                                value={selectEmp}
                                onChange={(e) => setSelectEmp(e.target.value)}
                                 defaultSelectedValue="0"
                            /></Col>

                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className='w-100' onClick={handleGetData}>Show</YsecButton>
                        </Col>
                        <Col xs={12} sm={6} md={2} className='mt-1 mb-1 csv'>

                            <YsecButton className={`w-100 ${data?.length === 0 && "disbutn"}`}
                                type="button"
                                onClick={exportEditorContentAsExcel}
                                disabled={data?.length === 0}
                            >
                                Export
                            </YsecButton>
                        </Col>
                    </Row>

                    <Row>
                        <Col md={1} lg={2} className='md-none mt-3'></Col>
                        <Col xs={12} md={10} lg={8} className="offer-letter-padding-lg  mt-3 ">
                            {data?.length !== 0 ?
                                <>
                                    <JoditEditor
                                        ref={editor}
                                        value={`      
                                             <div>
                                <p style="text-align:right;margin-bottom:0px;">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" class="stafftitle">Current Staff List</h5>
                                </div>                                                      
                                             ${htmlContent}                           
                                            `}
                                        config={config}

                                    />
                                </>
                                : <p className='p-3 bg-white'>No Data Found Here...</p>}
                        </Col>
                        <Col md={1} lg={1} className='md-none  mt-3'></Col>

                    </Row>

                    {/* <div dangerouslySetInnerHTML={{ __html: htmlContent }} /> */}

                </div>
            </React.Suspense>
        </div>
    )
}

export default StaffList;