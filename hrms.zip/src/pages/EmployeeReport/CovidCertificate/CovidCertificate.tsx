import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Breadcrumb, Card, Col, Modal, Row } from 'react-bootstrap'
import '../EmployeeReport.scss'
import AxiosLayout from '../../../apis/axios';
import LoadingSpinner from '../../Loader/Loader';
import JoditEditor from "jodit-react";
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));
interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}

const Covid19Certificate: React.FC<any> = () => {

    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [loading, setLoading] = useState<boolean>(false);
    const [alertMessage, setAlertMessage] = useState<string>('');
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [brandData, setBrandData] = useState<any[]>([])
    const [selectedBrand, setSelectedBrand] = useState<number>(0)
    const [locationId, setLocationId] = useState<number>(0)
    const printRef = useRef<any>(null)
    const tableRef = useRef<any>(null);
    const [addreqData, setaddreqData] = useState<any[]>([])
    const editor = useRef<any>(null);
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getMasterData()
    }, [])
    const getMasterData = () => {
        setLoading(true)
        AxiosLayout.get(`/General/GetMasterData?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                if (res.data.BrandList !== null) {
                    setBrandData(res.data.BrandList)
                    if (res.data.BrandList?.length !== 0) {
                        setSelectedBrand(res.data.BrandList[0]?.BrandId)
                        setLocationId(res.data.BrandList[0]?.LocationId)
                    }

                }

                setLoading(false)
            }
        })
    }


    const handleSelectBrand = (value: any) => {
        // setSelectedBrand(value)
        const desc = brandData.filter(i => i.BrandId === Number(value))
        setSelectedBrand(desc[0]?.BrandId)
        setLocationId(desc[0]?.LocationId)
    }
    const handleGetData = () => {
        if (selectedBrand == 0) {
            setErrorMessage("Please Select Brand...")
        }

        else {
            getEmpDetails()

        }
    }
    const getEmpDetails = () => {
        setLoading(true)
        const payload = {
            companyId: userId?.companyId,
            departmentId: 0,
            positionId: 0,
            employeeId: 0,
            userId: userId?.user,
            brandId: selectedBrand,
            locationId: locationId,
            projectId: 0,
            year: 0,
            reportType: 0,
            rotaMonth: true,
            rotaWeekNo: true,
            salaryTypeId: 0,
            basicNumber: 0,
            noofdays: 0
        }
        AxiosLayout.post("/EmployeeReport/GetCovid19certificate", payload).then((res: any) => {
            if (res?.status === 200) {
                if(res?.data?.Table){
                setaddreqData(res?.data?.Table)
                setLoading(false)
                }
                setLoading(false)
            }
            
        })
    }



    const config = {
        readonly: true,
        toolbarAdaptive: false,
        buttons: ['print'],
        height: 400,
        allowCommandsInReadOnly: ['selectall', 'preview', 'print']
    };
let htmlContent = '';

// First group by company
const groupedByCompany = addreqData?.reduce((acc: any, curr: any) => {
  const company = curr?.compname || 'Unknown Company';
  if (!acc[company]) acc[company] = [];
  acc[company].push(curr);
  return acc;
}, {});

// Sort company names
const sortedCompanies = Object.keys(groupedByCompany).sort((a, b) =>
  a.localeCompare(b)
);

sortedCompanies.forEach((companyName) => {
  const companyData = groupedByCompany[companyName];

  // Group by department inside the company
  const groupedByDepartment = companyData.reduce((acc: any, curr: any) => {
    const dept = curr?.Department || 'Unknown Department';
    if (!acc[dept]) acc[dept] = [];
    acc[dept].push(curr);
    return acc;
  }, {});

  const sortedDepartments = Object.keys(groupedByDepartment).sort((a, b) =>
    a.localeCompare(b)
  );

  // Start company block
  htmlContent += `
    <div class="katableee" style="padding: 0 !important;
    margin: 0 !important;width:25% !important;min-width:23% !important">
      <table width="100%" border="1" cellspacing="0" cellpadding="0" style="margin-bottom:0 !important">
        <tr>
          <td colspan="2" style="border:none !important; font-weight:bold !important; font-size: 18px;color:black !important" class="tdcolor">${companyName}</td>

        </tr>
      </table>
    </div>
  `;

  // Now loop through departments under that company
  sortedDepartments.forEach((dept) => {
    const deptData = groupedByDepartment[dept];

    htmlContent += `
      <div class="katableee" style="padding-top:0px !important;padding-bottom:0px !important;">
        <table width="100%" border="1" cellspacing="0" cellpadding="0">
          <tr>
            <td colspan="1" style="border:none !important; font-weight:bold !important; font-size: 12px;color:black !important"  class="tdcolor">Sub Dept: ${dept}</td>
          </tr>
          <tr><td style="border:none !important;"></td></tr>
          <tr>
            <th>EmpID</th>
            <th>Name</th>
            <th>Position</th>
            <th>Certificate (Y/N)</th>
          </tr>
          ${deptData
            .map(
              (emp: any) => `
            <tr>
              <td>${emp?.EmployeeId || ''}</td>
              <td>${emp?.Name || ''}</td>
              <td>${emp?.Position || ''}</td>
              <td>${emp?.Covid19 || ''}</td>
            </tr>
          `
            )
            .join('')}
        </table>
      </div>
    `;
  });
});

    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div className="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Employee Report</Breadcrumb.Item>
                            <Breadcrumb.Item active>Covid19 Certificate</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                </div>

                <div className='employee-container'>
                    <Row>
                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecSelect className={`md`}
                                objectNameKey="BrandName"
                                objectValueKey="BrandId"
                                data={[
                                    { BrandId: 0, BrandName: "Select Brand" },
                                    ...brandData?.map((i: any) => ({
                                        BrandId: i?.BrandId,
                                        BrandName: i?.Brand
                                    }))
                                ]}
                                value={selectedBrand}
                                onChange={(e) => handleSelectBrand(e.target.value)}
                            />
                        </Col>




                        <Col xs={12} sm={6} md={2} className="mt-2">
                            <YsecButton type='button' className={"w-100"} onClick={handleGetData}>Show</YsecButton>
                        </Col>

                    </Row>

                    <Row>
                        <Col xs={0} lg={2}></Col>
                        <Col xs={12} lg={8}>
                            <div className="mx-auto mt-2" >

                                {addreqData?.length !== 0 ?
                                    <>
                                        <JoditEditor
                                            ref={editor}
                                            value={`      
                                             <div >
                                             <div style="display: flex;  justify-items: end;">    
                               
                                <h5 style="width:50%;text-align:end" class="stafftitle">${userId?.company}</h5>
                                 <p  style="width:50%;text-align:end">
                                   Date: ${new Date().toISOString()?.split("T")[0]}  
                                    ${new Date().getHours()}:${new Date().getMinutes()}
                                </p>
                                </div>
                                <h5 style="text-align:center;font-weight:bold;margin-bottom:0px;" >Covid-19 Certificate Details</h5>
                                </div>            
                                
                            ${htmlContent}      
                                            `}
                                            config={config}

                                        />
                                    </>
                                    : <p className='p-3 bg-white'>No Data Found Here...</p>}



                            </div></Col>
                        <Col xs={0} lg={2}></Col>

                    </Row>

                </div>
            </React.Suspense>
        </div>
    )
}

export default Covid19Certificate;