import React from "react";
import "./Loader.scss"; 

function LoadingSpinner({ show = true }) {
  if (!show) return null;
  return (
    <div id="loading-bar-spinner">
      <div className="spinner-icon"></div>
    </div>
  );
}

export default LoadingSpinner;