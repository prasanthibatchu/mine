import React, { useEffect, useRef, useState } from "react";
import './Dashboard.scss';
import { Breadcrumb, Card, Col, Row } from "react-bootstrap";
import { DataType, Table } from 'ka-table';
import { CategoryScale, Chart, Legend, LinearScale, registerables, Tooltip } from "chart.js";
import AxiosLayout from "../../apis/axios";
import LoadingSpinner from "../Loader/Loader";



Chart.register(...registerables, LinearScale, CategoryScale, Tooltip, Legend);


const YsecTable = React.lazy(() => import("YsecitUtilityWeb/YsecTable"));


interface UserType {
    user: string;
    userName: string;
    companyId: number;
    company?: string;
}


const Dashboard: React.FC<any> = () => {
    const userString = localStorage.getItem('_user');
    const userId: UserType | null = userString ? JSON.parse(userString) as UserType : null;
    const [empData, setEmpData] = useState<any[]>([])
    const printRef = useRef<HTMLDivElement | any>(null);
    const tableRef = useRef<any>(null);
    const [loading, setLoading] = useState<boolean>(false);

    useEffect(() => {
        getGeneralData()
    }, []);

    const getGeneralData = () => {
setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployeesGeneralList?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res: any) => {
            if (res.status === 200) {
                const activeEmployees = res.data.filter(
                    (employee: any) => employee.Brand !== "" && employee.Department !== ""
                );
                setEmpData(activeEmployees); // Set filtered data
                // setEmpData(res.data)
                setLoading(false)
            }
        })


    }
    const staticColumns = [
        { id: 'EmployeeId', header: 'Employee ID', filter: true, size: 100 },
        { id: 'FullName', header: 'Name', filter: true, size: 100 },
        { id: 'IdNumber', header: 'Id Number', filter: true, size: 100 },
        { id: 'DOE', header: 'DOE', filter: true, size: 100 },
        { id: 'DOB', header: 'DOB', filter: true, size: 100 },
        { id: 'Phone', header: 'Phone', filter: true, size: 100 },
        { id: 'Country', header: 'Country', filter: true, size: 100 },
        { id: 'MaritalStatus', header: 'Marital Status', filter: true, size: 100 },
        { id: 'Brand', header: 'Brand', filter: true, size: 100 },
        { id: 'Department', header: 'Department', filter: true, size: 100 },
        { id: 'Position', header: 'Position', filter: true, size: 100 },
    ];




    const chartRef = useRef<HTMLDivElement | any>(null);

    const generateColors = (count: any) => {
        const colors = [];
        for (let i = 0; i < count; i++) {
            const hue = Math.floor((360 / count) * i); // Spread colors evenly
            const saturation = 70 + Math.random() * 30;
            const lightness = 50 + Math.random() * 20;
            colors.push(`hsl(${hue}, ${saturation}%, ${lightness}%)`);
        }
        return colors;
    };



    useEffect(() => {
        if (!empData || empData.length === 0) return;

        const ctx = chartRef.current.getContext("2d");

        // Calculate and sort position counts dynamically
        const getSortedPositionCounts = () => {
            const positionCounts = empData.reduce((acc: any, employee: any) => {
                const department = employee.Department || "Unknown";
                acc[department] = (acc[department] || 0) + 1;
                return acc;
            }, {});


            return Object.entries(positionCounts)
                // .sort((a, b) => b[1] - a[1]) 
                .reduce((acc: any, [key, value]: [key: any, value: any]) => {
                    acc.labels.push(key);
                    acc.data.push(value);
                    return acc;
                }, { labels: [], data: [] });
        };

        const { labels, data } = getSortedPositionCounts();
        const colors = generateColors(labels.length);

        const chartData = {
            labels,
            datasets: [
                {
                    label: "Employee Positions",
                    data,
                    backgroundColor: colors,
                },
            ],
        };


        const config: any = {
            type: "doughnut",
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: "top",
                        labels: {
                            font: {
                                size: 14,
                            },
                            color: "#333",
                        },
                    },
                    tooltip: {
                        callbacks: {
                            label: (context: any) => `${context.label}: ${context.raw}`,
                        },
                    },
                },
            },
        };

        const pieChart = new Chart(ctx, config);

        return () => {
            pieChart.destroy();
        };
    }, [empData]);


    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>

                <div className='header d-flex row flex-wrap'>
                    <div className="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">HRMS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
                            <Breadcrumb.Item active>Dashboard</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                </div>
                <div className="dashboard_container" ref={printRef}>
                    <Card>
                        <Card.Header>Employee Details</Card.Header>
                        <Card.Body className="p-0">
                            {empData?.length !== 0 &&
                                <div className='katable' >
                                    <YsecTable
                                        rowData={empData}
                                        columnDefs={staticColumns}
                                        filter={true}
                                        pagination={true}
                                        tableRef={tableRef}
                                        pageSize={20}
                                        dragColumnDisable={true}

                                    />
                                </div>}
                        </Card.Body>
                    </Card>
                    {empData?.length !== 0 &&
                        <Card className="mt-2">
                            <Card.Header>Employee Summary</Card.Header>
                            <Card.Body>
                                <Row>

                                    <Col xs={12} md={12}>
                                        <div className="piegrap" >
                                            <canvas ref={chartRef}></canvas>
                                        </div>
                                    </Col>
                                </Row>
                            </Card.Body>
                        </Card>}
                </div>
            </React.Suspense>
        </div>

    );
};

export default Dashboard;