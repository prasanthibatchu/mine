import React from "react";
import "./SamplePage.scss";
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecCountrySelect = React.lazy(() => import("Layout/YsecCountrySelect2"));
const YsecTimePicker = React.lazy(() => import("Layout/YsecTimePicker2"));
const YsecDropdown = React.lazy(() => import("Layout/YsecDropdown2"));




const SamplePage: React.ComponentType<any> = () => {
  const onChangeFun = (e:any) => {
    console.log(e.target?.value);
  };

  return (
    <div className="p-5">
      <h1>SamplePage HRMS</h1>{" "}
      <React.Suspense fallback={<>Loading...</>}>
        <div className="py-2">
          <YsecDropdown
            label="Ysec Dropdown"
            mandatory="true"
            className="test"
            wrapperClass=""
            id="testID"
            onChange={onChangeFun}
            data={[
              { id: 1, name: "name1" },
              { id: 2, name: "name2" },
              { id: 3, name: "name3" },
            ]}
            objectNameKey="name"
            objectValueKey="id"
            defaultSelectedValue="2"
          />
        </div>
        <div className="d-flex gap-3 py-4">
          <YsecDatePicker
            label=" Date Picker"
            mandatory="true"
            error="test message"
            id="testID"
            onChange={onChangeFun}
            value="12-12-2024"
            placeholder="placeholder"
            /*Ysec Date Picker options*/
            ysecType="tab"
            ysecFormat="D-MM-YYYY"
            ysecMinDate="10_D"
            ysecMaxDate="1_Y"
          />
        </div>
        <div className="d-flex gap-3 py-4">
          <YsecDatePicker
            label=" Date Picker"
            mandatory="true"
            error="test message"
            id="testID"
            onChange={onChangeFun}
            placeholder="placeholder"
            /*Ysec Date Picker options*/
            ysecType="combobox"
            ysecFormat="D/MM/YYYY"
            ysecMinDate="10_D"
            ysecMaxDate="11_D"
          />
        </div>
        <div className="py-2">
          <YsecCountrySelect
            label="Phone"
            mandatory="true"
            selection="code"
            error="test message"
            id="testID"
            placeholder="placeholder"
            activePhoneCode="1-268"
            defaultValue="999999999"
            onChange={onChangeFun}
          />
        </div>
        <div className="py-2">
          <YsecCountrySelect
            label="Country"
            mandatory="true"
            selection="country"
            error="test message"
            id="testID"
            placeholder="placeholder"
            activePhoneCode="1-268"
            defaultValue="999999999"
            onChange={onChangeFun}
          />
        </div>
        <div className="py-2">
          <YsecInput
            label="Input box"
            mandatory="true"
            error="test message"
            id="testID"
            onChange={onChangeFun}
            placeholder="placeholder"
          />
        </div>{" "}
        <div className="d-flex gap-3 py-4">
          <YsecTimePicker
            label=" Time Picker (12)"
            mandatory="true"
            error="test message"
            id="testID"
            onChange={onChangeFun}
            placeholder="placeholder"
            /*Ysec Date Picker options*/
            ysecFormat="12"
            value="12:30 AM"
          />
        </div>
        <div className="d-flex gap-3 py-4">
          <YsecTimePicker
            label=" Time Picker (24)"
            mandatory="true"
            error="test message"
            id="testID"
            onChange={onChangeFun}
            placeholder="placeholder"
            /*Ysec Date Picker options*/
            ysecFormat="24"
            value="18:20"
          />
        </div>
        <div className="py-2">
          {" "}
          <YsecSelect
            label="Input box"
            mandatory="true"
            error="test message"
            className="test"
            id="testID"
            onChange={onChangeFun}
            data={[
              { id: 1, name: "name1" },
              { id: 2, name: "name2" },
              { id: 3, name: "name3" },
            ]}
            objectNameKey="name"
            objectValueKey="id"
            defaultSelectedValue="2"
          />
        </div>{" "}
        <div className="py-2">
          {" "}
          <YsecTextarea
            label="Input box"
            mandatory="true"
            error="test message"
            className="test"
            id="testID"
            onChange={onChangeFun}
          />
        </div>
        <div className="d-flex gap-3 py-4">
          <YsecCheckbox
            label="Input box"
            mandatory="true"
            error="test message"
            className="test"
            id="testID"
            onChange={onChangeFun}
          />
          <YsecRadio
            label="Input box"
            name="checkbox"
            className="test"
            id="testID1"
            onChange={onChangeFun}
          />
          <YsecRadio
            label="Input box2"
            name="checkbox"
            className="test"
            id="testID2"
            onChange={onChangeFun}
          />
        </div>{" "}
      </React.Suspense>
    </div>
  );
};
export default SamplePage;
