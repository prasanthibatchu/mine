import React from "react";

const NotFound: React.ComponentType<any> = () => {
    return (   
         <h1>Not Found</h1>    
    );
}
 
export default NotFound;