import SampleSlice  from "../feature/SampleSlice";

const store =  { SampleSlice} 
export default store;