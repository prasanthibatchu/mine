 

  import {combineReducers, configureStore } from "@reduxjs/toolkit";
import HRMS_Store  from "./HRMS_Store";

const initStore = async () => {
 const UserDetailsSlice = {
  user: await import("Layout/UserDetailsSlice").then(
    (module:any) => module?.default?.reducer
  ),
};



  const MenuLayoutVisibilitySlice = {
    MenuLayoutVisibility: (await import("Layout/MenuLayoutVisibilitySlice")).default,
  };

  const Store = configureStore({ 
    reducer: combineReducers({
      ...HRMS_Store,
      ...UserDetailsSlice,
      ...MenuLayoutVisibilitySlice,      
    }),  
  });
  return Store;
};
export default initStore;