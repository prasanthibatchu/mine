
import { createRoot } from "react-dom/client";
import "./index.scss";
import { Provider } from "react-redux";
import SetAuth from "./SetAuth";
import initStore from "./redux/app/store";
import React from "react";


const App:React.ComponentType<any>  = () => {
  return <SetAuth />;
};
const container:any = document.getElementById("app");
const root = createRoot(container);
initStore().then((Store:any) => {
  root.render(
    <Provider store={Store}>
      <App />
    </Provider>
  );
});
