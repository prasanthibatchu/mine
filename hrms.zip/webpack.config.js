const path = require("path");
const fs = require("fs");
const HtmlWebPackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
const Dotenv = require("dotenv-webpack");
const { BundleAnalyzerPlugin } = require("webpack-bundle-analyzer");
const deps = require("./package.json").dependencies;

module.exports = (env = {}, argv = {}) => {
  const mode = argv.mode || "development";
  const envTarget = env.ENV || "development";
  const preferredEnvFile = path.resolve(__dirname, `.env.${envTarget}`);
  const fallbackEnvFile = path.resolve(__dirname, ".env");
  const envPath = fs.existsSync(preferredEnvFile)
    ? preferredEnvFile
    : fallbackEnvFile;

  require("dotenv").config({ path: envPath });
  console.log(`Loading environment from: ${envPath}`);
  console.log(`Using PUBLIC_PATH: ${process.env.PUBLIC_PATH}`);

  return {
    output: {
      publicPath: process.env.PUBLIC_PATH,
      clean: true,
    },
    experiments: {
      topLevelAwait: true,
    },
    optimization: {
      runtimeChunk: false,
    },
    devtool: mode === "production" ? "source-map" : "eval-source-map",
    resolve: {
      extensions: [".tsx", ".ts", ".jsx", ".js", ".json"],
    },
    devServer: {
      port: 9001,
      historyApiFallback: true,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
    },
    performance: {
      maxEntrypointSize: 512000,
      maxAssetSize: 512000,
    },
    module: {
      rules: [
        {
          test: /\.(ts|tsx|js|jsx)$/,
          exclude: /node_modules/,
          use: {
            loader: "babel-loader",
            options: {
              presets: [
                "@babel/preset-env",
                "@babel/preset-react",
                "@babel/preset-typescript",
              ],
            },
          },
        },
        {
          test: /\.(css|s[ac]ss)$/i,
          use: ["style-loader", "css-loader", "postcss-loader", "sass-loader"],
        },
        {
          test: /\.(png|svg|jpg)$/,
          type: "asset/resource",
        },
      ],
    },
    plugins: [
      new ModuleFederationPlugin({
        name: "HRMS",
        filename: "remoteEntry.js",
        remotes: {
          Layout: `Layout@${process.env.LAYOUT_URL || ""}`,
          YsecitUtilityWeb: "YsecitUtilityWeb@https://demo.ysecit.in:10510/remoteEntry.js",
        },
        exposes: {
          "./RouterHRMS": "./src/RouterHRMS.tsx",
          "./HRMS_Store": "./src/redux/app/HRMS_Store.ts",
        },
        shared: {
          ...deps,
          react: {
            singleton: true,
            requiredVersion: deps.react,
          },
          "react-dom": {
            singleton: true,
            requiredVersion: deps["react-dom"],
          },
          "react-router-dom": {
            singleton: true,
            requiredVersion: deps["react-router-dom"],
          },
          "react-redux": {
            singleton: true,
            requiredVersion: deps["react-redux"],
          },
          "@reduxjs/toolkit": {
            singleton: true,
            requiredVersion: deps["@reduxjs/toolkit"],
          },
          "react-toastify": {
            singleton: true,
            requiredVersion: deps["react-toastify"],
          }, "react-bootstrap": {
            singleton: true,
            requiredVersion: deps["react-bootstrap"],
          }
        },
      }),
      new HtmlWebPackPlugin({
        template: "./src/index.html",
      }),
      new Dotenv({
        path: envPath,
        systemvars: true,
      }),
      ...(env.ANALYZE ? [new BundleAnalyzerPlugin()] : []),
    ],
  };
};
