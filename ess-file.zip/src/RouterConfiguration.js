import React from "react";
import { Route, Routes } from "react-router-dom";
const RouterConfiguration = ({ RequireAuth, Layout, LayoutType }) => {
  const RouterESS= React.lazy(() => import("./RouterESS"));
  const NotFound = React.lazy(() => import("./pages/NotFound"));
  return (
    <Routes>
      <Route element={<RequireAuth />}>
        <Route path="/" element={<Layout LayoutType={LayoutType} />}>
        <Route
            path="/ess/:companyID/:productID/*"
            element={
              <React.Suspense fallback={<>Loading...</>}>
                <RouterESS/>
              </React.Suspense>
            }
          />    
            
        </Route>
      </Route>
    </Routes>
  );
};

export default RouterConfiguration;
