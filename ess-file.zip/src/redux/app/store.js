import {combineReducers, configureStore } from "@reduxjs/toolkit"; 
import ESS_Store from "./ESS_Store";
 const UserDetailsSlice = {
  user: await import("Layout/UserDetailsSlice").then(
    (module) => module?.default?.reducer
  ),
};

const MenuLayoutVisibilitySlice = {
  MenuLayoutVisibility: await import("Layout/MenuLayoutVisibilitySlice").then(
    (module) => module?.default
  ),
};
 



const initStore = async () => {
  const Store = configureStore({ 
    reducer: combineReducers({
      // counter: SampleSlice,  
       ...ESS_Store,
     ...UserDetailsSlice,
     ...MenuLayoutVisibilitySlice,       
    }),  
  });
  return Store;
  };
  export default  initStore;
