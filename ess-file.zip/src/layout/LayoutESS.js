import React, { useEffect }  from "react";
import "./LayoutESS.scss";

import { useNavigate, useParams } from "react-router-dom";
const LayoutESS = () => {
const Layout = React.lazy(() => import("Layout/Layout"));  
let { companyID, productID } = useParams();
const navigate = useNavigate();




 return (
    <React.Suspense fallback={<div>Loading...</div>}>
      <Layout
        productId_={productID}
        companyId_={companyID}
        LayoutType="layoutESS"      
      />
    </React.Suspense>
  );
};
export default LayoutESS;
