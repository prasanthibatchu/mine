import React, { useEffect, useState } from 'react'
import { Col, Modal, Row } from 'react-bootstrap'
import AxiosLayout from '../../apis/axios';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

const YsecMultipleSelect = React.lazy(() => import("Layout/YsecMultipleSelect2"))
export const ApplyMeeting = (props) => {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [data, setData] = useState({ meetingId: 0, subject: "", purpose: "", issues: "", act_items: "", notes: "", submitted_by: null, edited_by: null })
    const [attentees, setAttendees] = useState([])
    const [err, setErr] = useState(0)
    const [datee, setDatee] = useState("")
    const [selectedEmpIds, setSelectedEmpIds] = useState([]);
    useEffect(() => {
        if (props?.editData?.length !== 0) {
            const prevData=props?.editData[0]
            setData({
                meetingId: prevData?.MeetingId,
                subject:prevData?.Subject,
                purpose:prevData?.PurposeOfMeeting,
                issues:prevData?.OpenIssues,
                act_items:prevData?.ActionItems,
                notes:prevData?.Notes,
                submitted_by: prevData?.SubmittedBy,

                edited_by: prevData?.EditedBy
            })

    const formatDate = (dateStr) => {
      const date = new Date(dateStr);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0');
      const year = date.getFullYear();
      return `${day}/${month}/${year}`;
    };

    setDatee(formatDate(prevData?.Date));
            setSelectedEmpIds(props?.editAttendees?.map(i=>i.EmployeeId))
        }
    }, [])
    const handleChange = (e) => {
        setData({ ...data, [e.target.name]: e.target.value })
    }
    const handleDateChange = (e) => {
        setDatee(e.target.value)
    }
    // const handleAttendeeChange = (e) => {
    //     // Merge and deduplicate by empId
    //     const updatedAttendees = [...attentees, ...e];
    //     const uniqueAttendees = Array.from(
    //         new Map(updatedAttendees.map(item => [item.empId, item])).values()
    //     );

    //     setAttendees(uniqueAttendees);
    //     setSelectedEmpIds(uniqueAttendees.map(item => item.empId));
    // };
    const handleAttendeeChange = (selected) => {
    setAttendees(selected);
    setSelectedEmpIds(selected.map(item => item.empId));
};
    const handleSave = async (e) => {
        e.preventDefault()
        setErr(0)
        if (datee === "") {
            setErr(1)
        }
        else if (data.subject === "") {
            setErr(2)
        }
        else if (selectedEmpIds.length === 0) {
            setErr(3)
        }
        else if (data.purpose === "") {
            setErr(4)
        }
        else if (data.issues === "") {
            setErr(5)
        }
        else if (data.act_items === "") {
            setErr(6)
        }
        else if (data.notes === "") {
            setErr(7)
        }
        else if (data.submitted_by === null) {
            setErr(8)
        }
        else if (data.edited_by === null) {
            setErr(9)
        }
        else {
            const date2 = datee?.split("/")
            const formdata = {

                meetingId: data.meetingId,
                date: `${date2[2]}-${date2[1]}-${date2[0]}`,
                subject: data.subject,
                attendees: selectedEmpIds.toString(),
                purposeOfMeeting: data.purpose,
                openIssues: data.issues,
                actionItems: data.act_items,
                notes: data.notes,
                submittedBy: Number(data.submitted_by),
                editedBy: Number(data.edited_by),
                submitted: "",
                edited: "",
                userId: userId.user,

            }

            AxiosLayout.post("/Employee/InsertUpdateMeetingDetails", formdata).then(res => {
                if (res.data.Status === 1) {
                    setData({ subject: "", purpose: "", issues: "", act_items: "", notes: "", submitted_by: "", edited_by: "" })
                    setDatee("")
                    setAttendees([])
                    setSelectedEmpIds([])
                    props.handleOpen()
                    props.getMeetings()
                    props.getEmployees()
                }
            })
        }
    }
    const handleClear = () => {
        setData({ subject: "", purpose: "", issues: "", act_items: "", notes: "", submitted_by: "", edited_by: "" })
        setDatee("")
        setAttendees([])
        setSelectedEmpIds([])
        props.handleOpen()
    }



    return (
        <Modal
            {...props}
            size="xl"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header>

                <p className="modal-title" id="exampleModalLabel">Meeting Minutes</p>
                <button type="button" className="btn-close" onClick={props.handleOpen} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <Row>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecDatePicker
                            name="datee"
                            error="test message"
                            onChange={handleDateChange}
                            value={datee}
                            placeholder="YYYY-MM-DD"
                            ysecMinDate="1_D"
                            ysecMaxDate="1_Y"
                            ysecType="tab"
                            ysecFormat="YYYY-MM-DD"
                            wrapperClass
                            multipleSelect={false}
                            label="Date"
                            mandatory

                        />
                        {err === 1 && <label className='error'>Please Select Date...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecTextarea name="subject" value={data.subject} label="Subject" mandatory onChange={handleChange} />
                        {err === 2 && <label className='error'>Please Enter Subject...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>

                        <YsecMultipleSelect
                            className="md"
                            label="Attendees"
                            mandatory
                            objectNameKey="empName"
                            objectValueKey="empId"
                            data={props?.empData?.map(i => ({
                                empId: i.EmployeeId,
                                empName: i.Employee
                            })) || []}
                            value={selectedEmpIds}
                            // name="attentees"
                            onChange={handleAttendeeChange}
                        />

                        {err === 3 && <label className='error'>Please Select attendees...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecTextarea name="purpose" value={data.purpose} label="Purpose of Meeting" mandatory onChange={handleChange} />
                        {err === 4 && <label className='error'>Please Enter Purpose of meeting...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecTextarea name="issues" value={data.issues} label="Open Issues" mandatory onChange={handleChange} />
                        {err === 5 && <label className='error'>Please Enter Open issues...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecTextarea name="act_items" value={data.act_items} label="Action Items" mandatory onChange={handleChange} />
                        {err === 6 && <label className='error'>Please Enter Action Items...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecTextarea name="notes" value={data.notes} label="Notes" mandatory onChange={handleChange} />
                        {err === 7 && <label className='error'>Please Enter Notes...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecSelect 
                            objectNameKey="empName"
                            objectValueKey="empId"
                            data={[
                                { empId: "", empName: "Select" },
                                ...props?.empData.map(i => ({
                                    empId: i.EmployeeId,
                                    empName: i.Employee
                                }))
                            ]}
                            value={data.submitted_by}
                            name="submitted_by"
                            onChange={handleChange}
                            label="Submitted By"
                            mandatory
                            disabled={data.meetingId !==0}
                            className={`md ${data.meetingId !==0 && "disbledselect"}`}
                        />
                        {err === 8 && <label className='error'>Please Select Submitted By ...</label>}
                    </Col>
                    <Col xs={12} md={6} className='mt-1 mb-1'>
                        <YsecSelect className="md"
                            objectNameKey="empName"
                            objectValueKey="empId"
                            data={[
                                { empId: "", empName: "Select" },
                                ...props?.empData.map(i => ({
                                    empId: i.EmployeeId,
                                    empName: i.Employee
                                }))
                            ]}
                            value={data.edited_by}
                            name="edited_by"
                            onChange={handleChange}
                            label="Edited By"
                            mandatory
                        />
                        {err === 9 && <label className='error'>Please Select Edited By...</label>}
                    </Col>

                </Row>
                <div className='d-flex justify-content-center'>
                    <YsecButton type="button" className="m-1" onClick={handleSave}>Submit</YsecButton>
                    <YsecButton type="button" className="m-1" onClick={handleClear}>Clear</YsecButton>

                </div>
            </Modal.Body>
        </Modal>
    )
}
