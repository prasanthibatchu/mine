import './Meeting.scss'
import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AxiosLayout from '../../apis/axios';

import { DataType, Table, useTableInstance } from 'ka-table';

import { Breadcrumb, Modal } from 'react-bootstrap';
import { ApplyMeeting } from './ApplyMeeting';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
function Meeting() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [open, setOpen] = useState(false);
    const [alertMessage, setAlertMessage] = useState('');
    const [meetData, setMeetData] = useState([])
    const [empData, setEmpData] = useState([])
    const [AttData, setAttData] = useState([])
    const [searchText, setSearchText] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);
    const printRef = useRef();
    const [editData, setEditData] = useState([])
    const [editAttendees, setEditAttendees] = useState([])
    const handleOpen = () => setOpen(!open);

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage(''); // Clear the alert message after 5 seconds
            }, 1000);

            // Cleanup the timer on component unmount or when alertMessage changes
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);
    useEffect(() => {
        getMeetings()
        getEmployees()
    }, [])
    const getMeetings = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetMeetings?EmployeeId=${userId?.user}`).then(res => {
            if (res.status === 200) {
                if (res.data?.MeetingMinuteDetails !== null) {
                    setMeetData(res.data?.MeetingMinuteDetails)
                }
                if (res.data?.AttendeesDetails !== null) {
                    setAttData(res.data?.AttendeesDetails)
                }
                setLoading(false)
            }
        })
    }
    const getEmployees = () => {
        setLoading(true)
        AxiosLayout.get(`/Employee/GetEmployees?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then(res => {
            if (res.status === 200) {
                setEmpData(res.data)
                setLoading(false)
            }
        })
    }

    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const dataArray = meetData.map(
        (i, index) => ({
            date: i.Date,
            subject: i.Subject,
            attendees: i.Attendees,
            purpose: i.PurposeOfMeeting,
            issues: i.OpenIssues,
            action_items: i.ActionItems,
            notes: i.Notes,
            submitted_by: i.Submitted,
            edited_by: i.Edited,
            id: i.MeetingId,
        }),
    );
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);
    const EditAction = ({ dispatch, rowKeyValue }) => {
        return (<>
            <YsecFont className={`yf-pen  action-icon`}
                onClick={() => {

                    const data = meetData.filter(i => i.MeetingId == rowKeyValue);
                    const data2 = AttData.filter(j => j.MeetingId == rowKeyValue)
                    setEditData(data)
                    setEditAttendees(data2)
                    handleOpen()

                }}
            />
        </>)
    }

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Meeting Minutes</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };

    return (
        <div className="p-1">
            {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div class="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Meeting</Breadcrumb.Item>
                            <Breadcrumb.Item active>Meeting Minutes</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm btn leave ${open === false ? "btn-outline-primary" : "history"} `} onClick={handleOpen}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <ysecButton type="button" className={`sm  ${open === true ? "btn-outline-primary" : "history"}`} onClick={() => {
                            setSearchText("")
                            getMeetings()
                            getEmployees()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>

                </div>
                {open && (
                    <ApplyMeeting show={open} handleOpen={handleOpen} getEmployees={getEmployees} setAlertMessage={setAlertMessage} empData={empData} getMeetings={getMeetings} editData={editData} editAttendees={editAttendees}
                    />
                )}

                <div className='meetcontainer'>
                    <div class="d-flex flex-wrap row m-1 p-2 bg-white">
                        <div class="col-12 col-sm-12 p-1">
                            <YsecInput placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>

                    </div>
                    <div className='katable' ref={printRef}>
                        <Table
                            columns={[
                                { key: 'date', title: 'Date', dataType: DataType.String },
                                { key: 'subject', title: 'Subject', dataType: DataType.String },
                                { key: 'attendees', title: 'Attendees', dataType: DataType.String },
                                { key: 'purpose', title: 'Purpose of Meeting', dataType: DataType.String },
                                { key: 'issues', title: 'Open Issues', dataType: DataType.String },
                                { key: 'action_items', title: 'Action Items', dataType: DataType.String },
                                { key: 'notes', title: 'Notes', dataType: DataType.String },
                                { key: 'submitted_by', title: 'Submitted By', dataType: DataType.String },
                                { key: 'edited_by', title: 'Edited By', dataType: DataType.String },
                                { key: 'action', title: 'Edit', dataType: DataType.String },
                            ]}
                            data={dataArray}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {
                                            case 'action':
                                                return <EditAction {...props} />;

                                            default:
                                                return props.children;
                                        }

                                    },
                                },


                            }}
                        />
                    </div>
                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>
            </React.Suspense></div>
    )
}

export default Meeting