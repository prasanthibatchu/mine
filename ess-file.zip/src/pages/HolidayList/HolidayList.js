import React, { useEffect, useState } from 'react';
import './HolidayList.scss';
import AxiosLayout from '../../apis/axios';

import { Breadcrumb, Col, Row } from 'react-bootstrap';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

export default function HolidayList() {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(null);
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [holidayData, setHolidayData] = useState([]);
  const [holidaysByMonth, setHolidaysByMonth] = useState([]);
  const [viewType, setViewType] = useState("grid")
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const years = [...Array(3)].map((_, index) => {
    const year = new Date().getFullYear() - index;
    return { YearId: year.toString(), YearDescription: year.toString() };
  });
  const months = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  useEffect(() => {
    const timer = setTimeout(() => {
      getHolidaysList();
    }, 50);
    return () => clearTimeout(timer);
  }, []);

  const getHolidaysList = () => {
    AxiosLayout.get(`/Leave/GetGeneralHolidays?Year=${selectedYear}&CompanyId=${userId?.companyId}&userId=${userId.user}`).then((res) => {
      if (res.status === 200) {
        setHolidayData(res.data);

        const getDaysInMonth = (month, year) => {
          return new Array(31).fill('').map((_, i) => {
            const date = new Date(year, month, i + 1);
            return date.getMonth() === month ? date : null;
          }).filter(Boolean);
        };

        const updatedHolidaysByMonth = months.map((month, index) => {
          const monthHolidays = res.data.filter(holiday => {
            const holidayDate = new Date(holiday.HolidayDate);
            return holidayDate.getMonth() === index;
          });
          return { month, holidays: monthHolidays, days: getDaysInMonth(index, selectedYear) };
        });

        setHolidaysByMonth(updatedHolidaysByMonth);
      }
    });
  };
  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  const handleMonthClick = (month) => {
    setSelectedMonth(month);
  };

  const handleBackClick = () => {
    setSelectedMonth(null);
  };
  const handleViewType = (newValue) => {
    setViewType(newValue);
  };
  return (
    <div>
      <React.Suspense fallback={<>Loading...</>}>
        <div className='header'>
          <Breadcrumb>
            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
            <Breadcrumb.Item href="#">Reports</Breadcrumb.Item>
            <Breadcrumb.Item active>Holiday List</Breadcrumb.Item>
          </Breadcrumb>
        </div>
        <div className='containerr'>
          <div className='d-flex justify-content-end '>
            <YsecButton className={`m-1 ${viewType === "grid" && "btn-outline-primary"}`} onClick={() => handleViewType("list")}><YsecFont className="yf-list-bullets-points-bullet" /></YsecButton>
            <YsecButton className={`m-1 ${viewType === "list" && "btn-outline-primary"}`} onClick={() => handleViewType("grid")}><YsecFont className="yf-dots" /></YsecButton>

          </div>
          <div className={`d-flex align-items-center ${viewType === "grid"?"justify-content-center":"justify-content-start"} flex-wrap row m-1 p-1 bg-white`}>
            <div className="col-12 col-md-3 p-1">
              <YsecSelect
                className="md"
                objectNameKey="YearDescription"
                objectValueKey="YearId"
                data={years}
                onChange={(e) => setSelectedYear(e.target.value)}
              />
            </div>
            <div className="col-12 col-md-1 p-1">
              <YsecButton className="md w-100 submit-btn" onClick={getHolidaysList}>Submit</YsecButton>
            </div>
            {viewType === "grid" &&<>
            <div className="col-12 col-md-7 p-1 calandertxt">
              <p className='mb-0'>Holiday Calender <span>{selectedYear}</span></p>
            </div>
            <div className="col-12 col-md-1 p-1 holiday-icon">
              <YsecFont className="yf-dot"></YsecFont>
              <span className='txt'>Holiday</span>
            </div>
            </>}
          </div>
        </div>
        {viewType === "grid" ?
          <div className='calendar-body p-2 m-2'>
            {selectedMonth === null ? (
              <Row>
                {holidaysByMonth.map(({ month, holidays, days }) => (
                  <Col key={month} xs={12} md={4} lg={3} xl={3} className="p-2" onClick={() => handleMonthClick(month)}>
                    <div className="calendar-month bg-white p-2 h-100 text-center">
                      <h5>{month}</h5>
                      <div className="calendar-body d-flex flex-wrap">
                        {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((weekday, index) => (
                          <div key={index} className="calendar-day-header text_align_center">
                            <h6>{weekday}</h6>
                          </div>
                        ))}
                        {new Array(days[0].getDay()).fill(null).map((_, index) => (
                          <div key={index} className="calendar-day text_align_center"></div>
                        ))}
                        {days.map((day, index) => {
                          const holiday = holidays.find(holiday => new Date(holiday.HolidayDate).getDate() === day.getDate());
                          return (
                            <div key={index} className={holiday ? 'holiday text_align_center' : 'not_holiday text_align_center'}>
                              <span>{day.getDate()}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </Col>
                ))}
              </Row>
            ) : (
              <div className="calendar-month bg-white p-2 h-100 w-100 text-center">
                <Row>
                  <Col xs={1} onClick={handleBackClick}>
                    <YsecButton className="md back-btn" onClick={handleBackClick}><YsecFont className="yf-chevron-left" onClick={handleBackClick} />Back</YsecButton>
                  </Col>
                  <Col xs={11}>
                    <h5 className='text_align_center2'>{selectedMonth}</h5>
                  </Col>
                </Row>
                <div className="calendar-body d-flex flex-wrap">
                  {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((weekday, index) => (
                    <div key={index} className="calendar-day-header text_align_center">
                      <h6>{weekday}</h6>
                    </div>
                  ))}
                  {new Array(holidaysByMonth.find(({ month }) => month === selectedMonth).days[0].getDay()).fill(null).map((_, index) => (
                    <div key={index} className="calendar-day text_align_center"></div>
                  ))}
                  {holidaysByMonth.find(({ month }) => month === selectedMonth).days.map((day, index) => {
                    const holiday = holidaysByMonth.find(({ month }) => month === selectedMonth).holidays.find(holiday => new Date(holiday.HolidayDate).getDate() === day.getDate());
                    return (
                      <div key={index} className={holiday ? 'holiday text_align_center single_month' : 'not_holiday text_align_center single_month'}>
                        <span>{day.getDate()}</span>
                        <p className='holodaysize'>{holiday?.Holiday}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
          :
          <div className='tablecontainer'>
            <Row>
              <Col xs={12} lg={6}>
                <div className='katable'>
                  <table>
                    <tr>
                      <th>Holiday Date</th>
                      <th>Holiday</th>
                    </tr>
                    {holidayData?.length !== 0 && holidayData?.map((i,index) => (
                      <tr key={index}>
                        <td>{i?.HolidayDate}</td>
                        <td>{i?.Holiday}</td>
                      </tr>
                    ))}

                  </table>
                </div>
              </Col>
            </Row>
          </div>
        }
      </React.Suspense>
    </div>
  );
}