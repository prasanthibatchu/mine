import React from 'react';
import { Col, Modal, Row } from 'react-bootstrap';
import { DataType, Table, useTableInstance } from 'ka-table';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
export default function ViewAdvanceData(props) {
  const dataArray = props?.viewData?.map(
    (i, index) => ({
        salaryPeriod: i?.SalaryPeriod,
        amount: i?.Amount,
        paidAmount: i?.PaidAmount,
        balance: i?.Balance,
        id: index,
    }),
);
    
const lastItem = props?.viewData?.[props?.viewData.length - 1];

const totalsRow = lastItem ? {
    salaryPeriod: 'Total',
    amount: lastItem.SumOfAmount,
    paidAmount: lastItem.SumOfPaidAmount,
    balance: lastItem.SumOfBalance,
    id: dataArray.length,
    isTotal: true,
} : null;

const updatedDataArray = totalsRow ? [...dataArray, totalsRow] : dataArray;

  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header>

        <p className="modal-title" id="exampleModalLabel">PAYBACK SCHEDULES</p>
        <button type="button" className="btn-close" onClick={props.handleOpenViewData} aria-label="Close"></button>
      </Modal.Header>
      <Modal.Body>
      <div>
  <Row>
    <Col xs={12}  className='m-1'>
    <Row>
      <Col xs={3} className='heading_single_user'>Employee Id</Col>
      <Col xs={9} className='data_single_user'>{props?.singleData?.EmployeeId}</Col>
    </Row>
    </Col>
    <Col xs={12}  className='m-1'>
    <Row>
      <Col xs={3} className='heading_single_user'>Date</Col>
      <Col xs={9} className='data_single_user'>{props?.singleData?.Date}</Col>
    </Row>
    </Col>
    <Col xs={12}  className='m-1'>
    <Row>
      <Col xs={3} className='heading_single_user'>Amount</Col>
      <Col xs={9} className='data_single_user'>{props?.singleData?.Amount}</Col>
    </Row>
    </Col>
    <Col xs={12}  className='m-1'>
    <Row>
      <Col xs={3} className='heading_single_user'>Currency</Col>
      <Col xs={9} className='data_single_user'>{props?.singleData?.Currency}</Col>
    </Row>
    </Col>
    
  </Row>
</div>
        <div className='table'>
          <Table
            columns={[
              { key: 'salaryPeriod', title: 'Salary Period', dataType: DataType.String },
              { key: 'amount', title: 'Amount', dataType: DataType.String },
              { key: 'paidAmount', title: 'Paid Amount', dataType: DataType.String },
              { key: 'balance', title: 'Balance', dataType: DataType.String },
            ]}
            data={updatedDataArray}
            rowKeyField={'id'}
            noData={{
              text: 'No Data Found'
            }}
            childComponents={{
              dataRow: {
                  elementAttributes: ({ rowData }) => ({
                      className: rowData.isTotal ? 'total-row' : ''
                  })
                 
              }
          }}
            
          />
        </div>

      </Modal.Body>
      <Modal.Footer>


        <YsecButton type="button" className="cancel" onClick={props.handleOpenViewData}>Cancel</YsecButton>
      </Modal.Footer>

    </Modal>
  )
}
