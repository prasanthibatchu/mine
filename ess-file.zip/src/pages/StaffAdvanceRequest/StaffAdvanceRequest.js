import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Button, Col, Row, ToastContainer } from 'react-bootstrap';
import "./StaffAdvanceRequest.scss"
import { DataType, Table, useTableInstance } from 'ka-table';
import { ApplyAdvanceRequest } from './ApplyAdvanceRequest';
import AxiosLayout from '../../apis/axios';
import ViewAdvanceData from './ViewAdvanceData';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));


const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value === "Approved" && 'approved') || (value === "Rejected" && 'rejected') || (value === "Open" && "open") || (value === "Cancelled (Manager)" && 'cancelled') || (value === "Processed" && 'approved')}
        >
            {value}
        </div>
    );
};


function StaffAdvanceRequest() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [searchText, setSearchText] = useState('');
    const [advanceData, setAdvanceData] = useState([])
    const [loading, setLoading] = useState(false);
    const [open, setOpen] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);
    const [curData, setCurData] = useState([])
    const [error, setError] = useState(null);
    const [alertMessage, setAlertMessage] = useState('');
    const [successMsg, setSuccessMsg] = useState("")
    const [openViewData, setOpenViewData] = useState(false)
    const [viewData, setViewData] = useState([])
    const [singleData, setSingleData] = useState([])
    const [advhist,setAdvHist]=useState(false)
    const printRef = useRef();
    useEffect(() => {
        getAdvanceDetails()
        getCurrency()
    }, []);
    useEffect(() => {
        if (alertMessage !== "") {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);

    useEffect(() => {
        if (successMsg !== "") {
            const timer = setTimeout(() => {
                setSuccessMsg('');
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [successMsg]);
    const getAdvanceDetails = () => {

        setAdvHist(true);
        try {


            AxiosLayout.get(`/Advance/GetAdvanceDetailsByEmployeeId?CompanyId=${userId?.companyId}&EmployeeId=${userId?.user}`).then((response) => {
                if (response.status === 200) {
                    setAdvanceData(response?.data)
                    //  setAdvHist(true);
                }
            })

        } catch (err) {
            setError(err.message);
        } finally {
            setAdvHist(false);
        }
    }
    const getCurrency = async () => {
        setLoading(true);
        try {
            const response = await AxiosLayout.get(
                `/Advance/GetStaffAdvanceCurrency?CompanyId=${userId?.companyId}&TillId=1&UserId=${userId?.user}`
            );
            setCurData(response?.data);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const dataArray = advanceData?.map((i, index) => ({

        date: i?.Date,
        amount: i?.Amount,
        currency: i?.Currency,
        remark: i?.Remark,
        payBackCount: i?.PayBackCount,
        approvalStatus: i?.ApprovalStatusDescription,
        id: i?.AdvanceId,
    }),
    );

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);


    const handleOpen = () => setOpen(!open);
    const handleOpenViewData = () => setOpenViewData(!openViewData);

    const Allactions = ({ dispatch, rowKeyValue, approvalStatus }) => {
        const isDisabled = approvalStatus === "Open";
        return (
            <>
                <YsecFont
                    className={`yf-delete-circle-1 ${isDisabled ? 'deleteIcon' : 'no-action'}`}
                    onClick={() => {
                        if (isDisabled) {
                            const cancelRequestData = advanceData.filter(i => i.AdvanceId == rowKeyValue)
                            const date = cancelRequestData[0]?.Date;
                            cancelRequest(rowKeyValue, date)
                        };
                    }}
                />

            </>
        );
    };

    const PaybackView = ({ dispatch, rowKeyValue }) => {
        const data = advanceData.find(i => i.AdvanceId == rowKeyValue)
        return (
            <>
                <Button size="sm" variant="link" className='history' onClick={() => {
                    setSingleData(data)
                    viewAdvanceRequestById(rowKeyValue)
                }}>View</Button>
            </>
        )
    }
    const cancelRequest = (id, date) => {
        const data = {
            employeeId: userId?.user,
            advanceId: Number(id),
            isCancelled: 0,
            advdate: date,
        }
        AxiosLayout.post(`/Advance/CancelAdvanceRequest`, data).then((res) => {
            if (res.data.Status === 1) {
                getAdvanceDetails()
                setSuccessMsg(res.data.Message);
            }
            else {
                if (res.data.Message == null) {
                    setAlertMessage("Error");
                }
                else {
                    setAlertMessage(res.data.Message);
                }
            }
        })
    }
    const viewAdvanceRequestById = (id) => {

        AxiosLayout.get(`/Advance/GetEMIDetailsByAdvanceId?EmployeeId=${userId?.user}&AdvanceId=${Number(id)}&UserId=${userId?.user}`).then((res) => {
            if (res.status === 200) {
                setViewData(res.data)
                setOpenViewData(true)
            }

        }
        )
        // 
    }

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Staff Advance Request</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">PayRoll And Compensation</Breadcrumb.Item>
                            <Breadcrumb.Item active>Staff Advance Request</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm btn leave ${open === false ? "btn-outline-primary" : "history"} `} onClick={handleOpen}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <ysecButton type="button" className={`sm  ${open === true ? "btn-outline-primary" : "history"}`} onClick={() => {
                            setSearchText("")
                            getAdvanceDetails()
                            getCurrency()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>

                    </div>
                </div>
                {open && (
                    <ApplyAdvanceRequest show={open} handleOpen={handleOpen} open={open} setOpen={setOpen} curData={curData} getAdvanceDetails={getAdvanceDetails} setSuccessMsg={setSuccessMsg} />
                )}
                {openViewData && (
                    <ViewAdvanceData show={openViewData} handleOpenViewData={handleOpenViewData} openViewData={openViewData} viewData={viewData} singleData={singleData} />
                )}


                <div class="d-flex flex-wrap row m-1 p-2 bg-white">
                    <div class="col-12 col-sm-12">
                        <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                            setSearchText(event.target.value);
                        }} />
                    </div>

                </div>
                {alertMessage !== "" && (
                    <div className="alert alert-danger m-2" role="alert">
                        {alertMessage}
                    </div>
                )}
                {successMsg !== "" && (
                    <div className="alert alert-success m-2" role="success">
                        {successMsg}
                    </div>
                )}
                <div className='advanceRequestContainer'>
                    <div className='katable' ref={printRef}>
                           {advhist && <LoadingSpinner />}
                        <Table
                            columns={[
                                { key: 'date', title: 'Date', dataType: DataType.String },
                                { key: 'amount', title: 'Amount', dataType: DataType.String },
                                { key: 'currency', title: 'Currency', dataType: DataType.String },
                                { key: 'remark', title: 'Remark', dataType: DataType.String },
                                { key: 'payBackCount', title: 'Payback Count', dataType: DataType.String },
                                { key: ':action2', title: 'Payback Schedule', dataType: DataType.String },
                                { key: 'approvalStatus', title: 'Approval Status', dataType: DataType.String },
                                { key: ':action', title: 'Cancel Request', dataType: DataType.String },
                            ]}
                            data={paginatedData}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {
                                            case ':action':
                                                return <Allactions {...props} approvalStatus={props.rowData.approvalStatus} />;
                                            case ':action2':
                                                return <PaybackView {...props} />
                                            case 'approvalStatus':
                                                return <CustomCell  {...props} />

                                            default:
                                                return props.children;
                                        }

                                    },
                                },
                            }}
                        />
                    </div>
                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>
                <ToastContainer autoClose={2000} />
            </React.Suspense>

        </div>
    )
}

export default StaffAdvanceRequest;