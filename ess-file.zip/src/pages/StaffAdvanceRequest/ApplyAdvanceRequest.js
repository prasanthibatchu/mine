import React, { useEffect, useState } from 'react'
import { Modal, Col, Row } from 'react-bootstrap';
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import { toast, ToastContainer } from 'react-toastify';
import { date } from 'yup';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

export const ApplyAdvanceRequest = (props) => {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [user, setUser] = useState({
        amount: "",
        remark: "",
        payback_Count: ""
    })
    const [err, setErr] = useState(0)
    const [datee, setDatee] = useState("")
    const [loading, setLoading] = useState(false);
    const [currency, setCuurrency] = useState(null)
    const [paybackdata, setPaybackData] = useState([])
    const [paybackDataShow, setPayBackDataShow] = useState(false)
    const onChangeFun = (e) => {
        setUser({ ...user, [e.target.name]: e.target.value })
    }

    const [error, setError] = useState(null);
    const [alertMessage, setAlertMessage] = useState('');
    const onChangeDate = (e) => {
        setDatee(e.target.value)
    }
    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
    useEffect(() => {
        if (alertMessage !=="") {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);
    const handlePaybackData = async (e) => {

        e.preventDefault()

        setErr(0)
        if (datee === "") {
            setErr(1)
        }
        else if (user.amount === "") {
            setErr(3)
        }

        else if (user.payback_Count === "") {
            setErr(5)
        }
        else {
            const dateee = datee.split("/");
            const fromattedDate = dateee[1] + "-" + dateee[0] + "-" + dateee[2];
            const data = {
                employeeId: userId?.user,
                date: fromattedDate,
                amount: Number(user.amount),
                paybackCount: Number(user.payback_Count),
                companyId: userId?.companyId,
                UserId:userId?.user

            }

            await AxiosLayout.post("/Advance/GetEMIDetails", data).then((res) => {
                if (res.status === 200) {
                    setPaybackData(res?.data)
                    setPayBackDataShow(true)
                    props.setOpen(true)                    
                }
                else {
                    setAlertMessage(res.data.Message);

                }
            })
        }
    }

    const handleSave = async (e) => {
        e.preventDefault()
        setErr(0)
        if (datee === "") {
            setErr(1)
        }
        else if (currency === null) {
            setErr(2)
        }
        else if (user.amount === "") {
            setErr(3)
        }
        else if (user.remark === "") {
            setErr(4)
        }
        else if (user.payback_Count === "") {
            setErr(5)
        }
        else {
            const dateee = datee.split("/");
            const fromattedDate = dateee[1] + "-" + dateee[0] + "-" + dateee[2];
            const data = {
                employeeId: userId?.user,
                date: fromattedDate,
                amount: Number(user.amount),
                currencyId: Number(currency),
                paybackCount: Number(user.payback_Count),
                companyId: userId?.companyId,
                remark: user.remark,
                UserId:userId.user
            }

            await AxiosLayout.post("/Advance/SaveStaffAdvanceDetails", data).then((res) => {

                if (res.data.Status === 1) {
                    setUser({})
                    setDatee("")
                    setCuurrency(null)
                    props.getAdvanceDetails()
                    props.handleOpen()
                    props?.setSuccessMsg(res.data.Message)
                }
                else {
                    if(res.data.Message== null){
                        setAlertMessage("Error");
                    }
                    else{
                    setAlertMessage(res.data.Message);
                    }

                }
            })
        }
    }


    const dataArray = paybackdata?.map(
        (i, index) => ({
            salaryPeriod: i?.SalaryPeriod,
            amount: i?.Amount,
            paidAmount: i?.PaidAmount,
            balance: i?.Balance,
            id: index,
        }),
    );
    
const lastItem = paybackdata?.[paybackdata.length - 1];

const totalsRow = lastItem ? {
    salaryPeriod: '',
    amount: lastItem.SumOfAmount,
    paidAmount: lastItem.SumOfPaidAmount,
    balance: lastItem.SumOfBalance,
    id: dataArray.length,
    isTotal: true,
} : null;

const updatedDataArray = totalsRow ? [...dataArray, totalsRow] : dataArray;

    return (

        <Modal
            {...props}
            size="xl"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header>

                <p className="modal-title" id="exampleModalLabel">Staff Advance Request</p>
                <button type="button" className="btn-close" onClick={props.handleOpen} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <div className='form_container'>
                    <Row>
                        {alertMessage && (
                            <Col xs={12} className="alert alert-danger" role="alert">
                                {alertMessage}
                            </Col>
                        )}
                        <Col xs={12} lg={6}>
                            <Row className=' mb-3'>
                                <Col xs={4}><label>Employee Id</label></Col>
                                <Col xs={8}> <YsecInput value={userId?.user} disabled className="disabled_text" /></Col>
                            </Row>
                            <Row className=' mb-3'>
                                <Col xs={4}><label>Date</label></Col>
                                <Col xs={8}><YsecDatePicker
                                    // label="Select Date Range"
                                    mandatory="true"
                                    error="test message"
                                    onChange={onChangeDate}
                                    value={datee}
                                    placeholder="YYYY-MM-DD"
                                    ysecMinDate="1_D"
                                    ysecMaxDate="1_Y"
                                    ysecType="tab"
                                    ysecFormat="YYYY-MM-DD"
                                    wrapperClass
                                    multipleSelect={false}

                                />
                                    {err === 1 && <label className='error'>Select Date</label>}
                                </Col>
                            </Row>
                            <Row className=' mb-3'>
                                <Col xs={4}><label>Currency</label></Col>
                                <Col xs={8}>
                                    <YsecSelect className="md"
                                        objectNameKey="Currency"
                                        objectValueKey="CurrencyId"
                                        data={[
                                            { CurrencyId: "", Currency: "Select Currency" },
                                            ...props?.curData?.map(i => ({
                                                CurrencyId: i?.CurrencyId,
                                                Currency: i?.Currency
                                            }))
                                        ]}
                                        onChange={(e) => setCuurrency(e.target.value)}
                                    />
                                    {err === 2 && <label className='error'>Select Currency</label>}
                                </Col>
                            </Row>
                            <Row className=' mb-3'>
                                <Col xs={4}><label>Amount</label></Col>
                                <Col xs={8}> <YsecInput value={user.amount} name="amount" onChange={onChangeFun} />
                                    {err === 3 && <label className='error'>Enter Amount</label>}</Col>

                            </Row>
                            <Row className=' mb-3'>
                                <Col xs={4}><label>Remark</label></Col>
                                <Col xs={8}> <YsecInput value={user.remark} name="remark" onChange={onChangeFun} />
                                    {err === 4 && <label className='error'>Enter Remark</label>}</Col>

                            </Row>
                            <Row className=' mb-3'>
                                <Col xs={4}><label>Payback Count</label></Col>
                                <Col xs={8} className='d-flex'>
                                    <YsecInput value={user.payback_Count} type="number" name="payback_Count" onChange={onChangeFun} className="me-1 " />

                                    <YsecButton onClick={handlePaybackData} className="w-50 nowrapbtn" >Apply Payback</YsecButton>
                                </Col>
                                {err === 5 &&
                                    <>
                                        <Col xs={4}></Col>
                                        <Col xs={8}> <label className='error'>Enter Payback Count</label>
                                        </Col></>}

                            </Row>

                        </Col>
                        <Col xs={12} lg={6}>
                            {paybackDataShow === true &&
                                <div className='table'>
                                    <p className='head'>PAYBACK SCHEDULES</p>
                                    <Table
                                        columns={[
                                            { key: 'salaryPeriod', title: 'Salary Period', dataType: DataType.String },
                                            { key: 'amount', title: 'Amount', dataType: DataType.String },
                                            { key: 'paidAmount', title: 'Paid Amount', dataType: DataType.String },
                                            { key: 'balance', title: 'Balance', dataType: DataType.String },
                                        ]}
                                        // data={dataArray}
                                        data={updatedDataArray}
                                        rowKeyField={'id'}
                                        noData={{
                                            text: 'No Data Found'
                                        }}
                                        
                                        childComponents={{
                                            dataRow: {
                                                elementAttributes: ({ rowData }) => ({
                                                    className: rowData.isTotal ? 'total-row' : ''
                                                })
                                               
                                            }
                                        }}
                                    />

                                </div>
                            }
                        </Col>
                    </Row>
                </div>
                <ToastContainer autoClose={2000} />
            </Modal.Body>
            <Modal.Footer>
                <YsecButton type="button" className={paybackdata?.length === 0 ? "disbled_btn" : "confirm"} onClick={handleSave} disabled={paybackdata?.length === 0}>Save</YsecButton>

                <YsecButton type="button" className="cancel" onClick={props.handleOpen}>Cancel</YsecButton>
            </Modal.Footer>

        </Modal>
    )
}

