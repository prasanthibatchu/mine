import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb } from 'react-bootstrap';
import './PensionDetails.scss'
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
function PensionDetails() {
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [searchText, setSearchText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [data, setaData] = useState([])
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(20);
  const printRef = useRef();
  useEffect(() => {
    getData()
  }, [])
  const getData = () => {
    setLoading(true)
    AxiosLayout.get(`/Employee/GetPensionDetails?EmployeeId=${userId?.user}`).then(res => {
      if (res.status === 200) {
        if (res.data !== null) {
          setaData(res.data)
          setLoading(false)
        }

      }
    })
  }
  // if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  const dataArray = data?.map(
    (i, index) => ({
      desc: i.PensionName,
      deduct_month: i.DeductedMonth,
      goal_amt: i.GoalAmount,
      employer_share: i.EmployerShare,
      employee_share: i.EmployeeShare,
      employer_contribution: i.EmployerContribution,
      employee_contribution: i.EmployeeContribution,
      id: index,
    }),
  );
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = dataArray;
  const paginatedData = currentData?.slice(indexOfFirstItem, indexOfLastItem);
  const totalItems = dataArray?.length;

  const startRange = indexOfFirstItem + 1;
  const endRange = Math.min(indexOfLastItem, totalItems);
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);
  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Pension Details</title>');
    // Optional: Add your styles here, or link to your CSS file
    printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };
  return (
    <div className='p-1'>
      {loading === true && <LoadingSpinner show={loading} />}
      <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>

        <div className='header d-flex row flex-wrap'>
          <div class="col">
            <Breadcrumb  >
              <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
              <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
              <Breadcrumb.Item href="#">Payroll and Compensation</Breadcrumb.Item>
              <Breadcrumb.Item active>Pension Details</Breadcrumb.Item>
            </Breadcrumb>
          </div>

          <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

            <ysecButton type="button" className={`sm  history`} onClick={() => {
              setSearchText("")
              getData()
            }}>
              <YsecFont className="yf-clock" />
            </ysecButton>
            <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
              <YsecFont className="yf-printer-scan" />
            </YsecButton>
          </div>
        </div>

        <div className='containerr'>

          <div class="d-flex flex-wrap row m-1 p-2 bg-white">
            <div class="col-12 col-sm-12 p-1">
              <YsecInput placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                setSearchText(event.target.value);
              }} />
            </div>
          </div>
          <div className='katable' ref={printRef}>
            <p className='head'>Pension Deductions</p>
            <Table
              columns={[
                { key: 'desc', title: 'Pension Description', dataType: DataType.String },
                { key: 'deduct_month', title: 'Deducted Month', dataType: DataType.String },
                { key: 'goal_amt', title: 'Goal Amount', dataType: DataType.String },
                { key: 'employer_share', title: 'Employer Share(%)', dataType: DataType.String },
                { key: 'employee_share', title: 'Employee Share(%)', dataType: DataType.String },
                { key: 'employer_contribution', title: 'Employer Contribution', dataType: DataType.String },
                { key: 'employee_contribution', title: 'Employee Contribution', dataType: DataType.String },
              ]}
              data={paginatedData}
              rowKeyField={'id'}
              searchText={searchText}
              noData={{
                text: 'No Data Found'
              }}
            />
          </div>
          <div className='pagination'>
            <span className='pageselect'>
              <YsecSelect
                objectNameKey="pageDescription"
                objectValueKey="pageNumber"
                data={pageNumbers.map(number => ({
                  pageNumber: number,
                  pageDescription: `Page ${number.toString()}`
                }))}
                className="sm"
                onChange={(e) => {
                  const selectedPage = Number(e.target.value);
                  setCurrentPage(selectedPage);
                }}
              />
            </span>

            <span>{startRange}-{endRange} of {totalItems}</span>
            <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
              onClick={() => {
                if (currentPage > 1) {
                  setCurrentPage(prev => prev - 1);
                }
              }}
            />
            <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
              onClick={() => {
                if (currentPage < totalPages) {
                  setCurrentPage(prev => prev + 1);
                }
              }}
            />
          </div>
        </div>
      </React.Suspense>
    </div>
  )
}

export default PensionDetails