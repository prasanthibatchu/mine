
import React, { useEffect, useState } from 'react'
import { Breadcrumb, Card, CardBody, CardHeader, } from 'react-bootstrap';
import './Feeds.scss';
import AxiosLayout from '../../apis/axios';
import birthdayBanner from './images/banner_birthday.jpg';
import aniversaryBanner from './images/banner_aniversary.jpg';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faThumbsUp, faCommentDots } from '@fortawesome/free-solid-svg-icons';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

function Feeds() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [feedsData, setFeedsData] = useState([]);
    const [likeCount, setLikeCount] = useState(0);
    const [commentsCont, setCommentsCont] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [comments, setComments] = useState('');
    const [showEmoji, setShowEmoji] = useState({});
    const [expandComments, setExpandComments] = useState({});
    const [hoverBox, setHoverBox] = useState({});
    const emojiData = [
        { "iconid": 1, "icon": "😀" },
        { "iconid": 2, "icon": "😂" },
        { "iconid": 3, "icon": "😇" },
        { "iconid": 4, "icon": "😍" },
        { "iconid": 5, "icon": "😎" },
        { "iconid": 6, "icon": "😏" },
        { "iconid": 7, "icon": "😛" },
        { "iconid": 8, "icon": "😪" },
        { "iconid": 9, "icon": "😸" },
        { "iconid": 10, "icon": "🙃" },
        { "iconid": 11, "icon": "👍" },
        { "iconid": 12, "icon": "👊" },
        { "iconid": 13, "icon": "👋" },
        { "iconid": 14, "icon": "👌" },
        { "iconid": 15, "icon": "👏" },
        { "iconid": 16, "icon": "🙋" },
        { "iconid": 17, "icon": "🙏" },
        { "iconid": 18, "icon": "💪" },
        { "iconid": 19, "icon": "💝" },
        { "iconid": 20, "icon": "💖" },
        { "iconid": 21, "icon": "🧡" },
        { "iconid": 22, "icon": "💔" },
        { "iconid": 23, "icon": "🦋" },
        { "iconid": 24, "icon": "💐" },
        { "iconid": 25, "icon": "🎄" },
        { "iconid": 26, "icon": "🌷" },
        { "iconid": 27, "icon": "🌹" },
        { "iconid": 28, "icon": "🌻" },
        { "iconid": 29, "icon": "🍎" },
        { "iconid": 30, "icon": "🍓" },
        { "iconid": 31, "icon": "🍷" },
        { "iconid": 32, "icon": "🎁" },
        { "iconid": 33, "icon": "🎂" },
        { "iconid": 34, "icon": "🎉" },
        { "iconid": 35, "icon": "🎊" },
    ];

    useEffect(() => {
        getFeedsData();
    }, []);

    const getFeedsData = () => {
        setLoading(true);
        try {
            AxiosLayout.get(`/Feeds/GetFeeds?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
                if (res.status === 200) {
                    if(res.data){
                    const data = res?.data?.Table;
                    if(userId?.companyId==78){
                    const dataWithComments = data?.map((i) => ({
                        ...i,
                        comments: res.data.Table1.filter(c => c.NId === i.NId && c.Comment !==""),
                        likes:res.data.Table1.filter(c => c.NId === i.NId && c.IsLiked===true),
                        commentsExpanded: false
                    }));
                    setFeedsData(dataWithComments);
                }else{
                    setFeedsData(data)
                }
                }
                }
            });
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    const compressComment = (nid) => {
        setExpandComments((prev) => ({
            ...prev,
            [nid]: false,
        }));
        setFeedsData((prevFeedsData) =>
            prevFeedsData.map((feed) =>
                feed.NId === nid
                    ? {
                          ...feed,
                          comments: feed.comments,
                      }
                    : feed
            )
        );
    };

    const getCommentDetails = (nid) => {
        setLoading(true);
        try {
            AxiosLayout.get(`/Feeds/GetCommentDetails?UserId=${userId?.user}&NId=${nid}`).then((response) => {
                if (response.status === 200) {
                    setFeedsData((prevFeedsData) =>
                        prevFeedsData.map((feed) =>
                            feed.NId === nid
                                ? {
                                      ...feed,
                                    //   comments: response.data ,
                                    comments: response.data.filter((c) => c.Comment !== ""),
                                  }
                                : feed
                        )
                    );
                    setExpandComments((prev) => ({
                        ...prev,
                        [nid]: true,
                    }));
                }
            });
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const handelEmojis = (nid, type) => {
        setShowEmoji((prevState) => ({
            ...prevState,
            [`${nid}-${type}`]: !prevState[`${nid}-${type}`],
        }));
    };

    const handleEmojiClick = (emoji, nid, type) => {
        setComments((prevComments) => ({
            ...prevComments,
            [`${nid}-${type}`]: (prevComments[`${nid}-${type}`] || '') + emoji.icon,
        }));
        handelEmojis(nid, type);
    };

    const onChangeComment = (e, nid, type) => {
        const { value } = e.target;
        setComments((prevComments) => ({
            ...prevComments,
            [`${nid}-${type}`]: value,
        }));
    };

    const handleSendMessage = (e, nid, typeId, date) => {
        e.preventDefault();
        const data = {
            nId: nid,
            typeId: typeId,
            likes: comments[`${nid}-${typeId}`] === undefined ? true : false,
            comments: comments[`${nid}-${typeId}`] === undefined ? '' : comments[`${nid}-${typeId}`],
            userId: userId?.user,
        };
        AxiosLayout.post('/Feeds/SaveLikeAndComment', data).then((res) => {
            if (res.status === 200) {
                setComments('');
                getFeedsData();
            }
        });
    };
    const handleMouseEnter = (nid) => {
        setHoverBox((prev) => ({
            ...prev,
            [nid]: true,
        }));
    };

    const handleMouseLeave = (nid) => {
        setHoverBox((prev) => ({
            ...prev,
            [nid]: false,
        }));
    };
    const renderComments = (comments, nid) => {
        if (expandComments[nid]) {
            return comments.map((comment, index) => (
                <div key={index} className='d-flex row msg-list'>
                    <div className='d-flex col-10'>
                        <div className='d-flex'>
                            <Card.Img
                                src={`data:image/png;base64,${comment?.EmployeeImage}`}
                                className='empImgefile'
                                alt=""
                            />
                        </div>
                        <div className='name_msg'>
                            <span>
                                <b>{comment.FullName}</b>
                            </span>
                            <span>{comment.Comment}</span>
                        </div>
                    </div>
                    <div className='d-flex col-2 time'>{comment.CommentTime}</div>
                </div>
            ));
        } else {
            return comments.slice(0, 2).map((comment, index) => (
                <div key={index} className='d-flex row msg-list'>
                    <div className='d-flex col-10'>
                        <div className='d-flex'>
                            <Card.Img
                                src={`data:image/png;base64,${comment?.EmployeeImage}`}
                                className='empImgefile'
                                alt=""
                            />
                        </div>
                        <div className='name_msg'>
                            <span>
                                <b>{comment.FullName}</b>
                            </span>
                            <span>{comment.Comment}</span>
                        </div>
                    </div>
                    <div className='d-flex col-2 time'>{comment.CommentTime}</div>
                </div>
            ));
        }
    };

    return (
        <div>
            {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header'>
                    <Breadcrumb>
                        <Breadcrumb.Item href='#'>Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item href='#'>ESS</Breadcrumb.Item>
                        <Breadcrumb.Item href='#'>Feeds</Breadcrumb.Item>
                    </Breadcrumb>
                </div>

                <div className='containerr row d-flex justify-content-center'>
                    {feedsData?.length !== 0 &&
                        feedsData?.map((i) => (
                            <Card key={i?.NId} className={`m-2 p-2 col-12 card ${i.TypeId === 4 ? 'welcome' : 'cardimgg'}`}>
                                <CardHeader className='bg-white'>
                                    <div className='d-flex p-1 datebtn'>
                                        <YsecButton type="button">{i.Eventdate?.split("T")[0]}</YsecButton>
                                    </div>
                                </CardHeader>
                                <CardBody className='bg-white'>
                                    {i?.TypeId === 4 && (
                                        <div className='birthday-body'>
                                            <Card.Img variant='top' src={birthdayBanner} className='banner' />
                                            <div className='d-flex flexdata'>
                                                <div className='imageposition'>
                                                    <Card.Img src={`data:image/png;base64,${i.EmployeeImage}`} className='bg-white emp_img' />
                                                </div>
                                                <div className='emp_wishes'>
                                                    <h5>
                                                        {' '}
                                                        Happy Birthday <span className='textcolor'>{i.FullName}!!!</span>
                                                    </h5>
                                                    <p>
                                                        May <b>{i.FullName}</b> have a prosperous and successful birthday on {i.SchDate}.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    {i.TypeId === 5 && (
                                        <>
                                            <Card.Img variant='top' src={aniversaryBanner} className='anniversaryimg' />
                                            <div className='wish_img_position'>
                                                <div className='centered_img'>
                                                    <Card.Img src={`data:image/png;base64,${i.EmployeeImage}`} className='bg-white emp_img' />
                                                </div>
                                                <div className='emp_wishes_2'>
                                                    <h5 className='textcolor'>Congratulations {i.FullName}!</h5>
                                                    <h5 className='textcolor'>{i.Messge}</h5>

                                                    <p>
                                                        {' '}
                                                        YsecIT Wishing you a Happy <b>{i.Messge} </b>. Congrats on another year of hard work and
                                                        success Thank you for being an essential part of YsecIT's Success.
                                                    </p>
                                                </div>
                                            </div>
                                        </>
                                    )}
                                </CardBody>

                                {i.CommentEnabled === true && (
                                    <>
                                        <hr className='mt-0 mb-0' />
                                        <CardBody>
                                            <div className='d-flex s comments_icons'>
                                                <div className='=" d-flex col-10 '>
                                                    <div className='icons_text ' onClick={(e) => handleSendMessage(e, i.NId, i.TypeId, i.Eventdate?.split('T')[0])}>
                                                        <FontAwesomeIcon icon={faThumbsUp} />
                                                        <span> {i.LikeCount} Likes</span>
                                                    </div>
                                                    <div className='icons_text eye'>
                                                        <a className='link'>
                                                            <YsecFont className='yf-edit-view-eye'   onMouseEnter={() => handleMouseEnter(i.NId)}
                                                        onMouseLeave={() => handleMouseLeave(i.NId)}/>
                                                        </a>
                                                        
                                                        
                                                            <div className='hover-box' onMouseEnter={() => handleMouseEnter(i.NId)} onMouseLeave={() => handleMouseLeave(i.NId)}>
                                                              {i.likes?.map(l=>(
                                                                   <div >
                                                                   <img
                                                                      src={`data:image/png;base64,${l?.EmployeeImage}`}
                                                                       className='empImgefile'
                                                                       alt={""}
                                                                   />
                                                                   <span className='fullname'><b>{l.FullName}</b></span>
                                                               </div>
                                                              ))}
                                                            </div>
                                                       
                                                    </div>
                                                    <div className='icons_text2 '>
                                                        <FontAwesomeIcon icon={faCommentDots} />
                                                        <span> {i.CCount} Comments</span>
                                                    </div>
                                                </div>
                                                
                                                {i.comments.length > 2 && (
                                                <div className='col-2 d-flex justify-content-end'>
                                                    {expandComments[i.NId] ? (
                                                        <button onClick={() => compressComment(i.NId)} className='btnview'>View Less...</button>
                                                    ) : (
                                                        <button onClick={() => getCommentDetails(i.NId)} className='btnview'>View More...</button>
                                                    )}
                                                </div>)}
                                            </div>
                                        </CardBody>
                                        <Card.Body className='card2'>
                                            {i.CommentEnabled === true && (
                                                <>
                                                    {/* {i.comments.map((comment, index) => (
                                                        <div key={index} className='d-flex row msg-list'>
                                                            <div className='d-flex col-10'>
                                                                <div className='d-flex'>
                                                                    <Card.Img
                                                                        src={`data:image/png;base64,${comment?.EmployeeImage}`}
                                                                        className='empImgefile'
                                                                        alt=""
                                                                    />
                                                                </div>
                                                                <div className='name_msg'>
                                                                    <span>
                                                                        <b>{comment.FullName}</b>
                                                                    </span>
                                                                    <span>{comment.Comment}</span>
                                                                </div>
                                                            </div>
                                                            <div className='d-flex col-2 time'>{comment.CommentTime}</div>
                                                        </div>
                                                    ))} */}
                                                     {renderComments(i.comments, i.NId)}
                                                    {showEmoji[`${i.NId}-${i.TypeId}`] === true && (
                                                        <div className='emojicard'>
                                                            <div className='emoji-grid'>
                                                                {emojiData?.map((emoji) => (
                                                                    <span key={emoji.iconid} className='emoji-card-list' onClick={() => handleEmojiClick(emoji, i.NId, i.TypeId)}>
                                                                        {emoji.icon}
                                                                    </span>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    )}
                                                    <div className='inputfield'>
                                                        <button className='emojibtn' onClick={(e) => handelEmojis(i.NId, i.TypeId)}>
                                                            <svg xmlns='http://www.w3.org/2000/svg' width='16' height='16' fill='currentColor' className='bi bi-emoji-smile' viewBox='0 0 16 16'>
                                                                <path d='M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16' />
                                                                <path d='M4.285 9.567a.5.5 0 0 1 .683.183A3.5 3.5 0 0 0 8 11.5a3.5 3.5 0 0 0 3.032-1.75.5.5 0 1 1 .866.5A4.5 4.5 0 0 1 8 12.5a4.5 4.5 0 0 1-3.898-2.25.5.5 0 0 1 .183-.683M7 6.5C7 7.328 6.552 8 6 8s-1-.672-1-1.5S5.448 5 6 5s1 .672 1 1.5m4 0c0 .828-.448 1.5-1 1.5s-1-.672-1-1.5S9.448 5 10 5s1 .672 1 1.5' />
                                                            </svg>
                                                        </button>
                                                        <YsecInput
                                                            placeholder='Add a comment'
                                                            className='inputt'
                                                            name={'comment'}
                                                            value={comments[`${i.NId}-${i.TypeId}`] || ''}
                                                            onChange={(e) => onChangeComment(e, i.NId, i.TypeId)}
                                                        />
                                                        <button className='sendemail' onClick={(e) => handleSendMessage(e, i.NId, i.TypeId, i.Eventdate?.split('T')[0])}>
                                                            <YsecFont className='yf-send-email' />
                                                        </button>
                                                    </div>
                                                </>
                                            )}
                                        </Card.Body>
                                    </>
                                )}
                            </Card>
                        ))}
                </div>
            </React.Suspense>
        </div>
    );
}

export default Feeds;