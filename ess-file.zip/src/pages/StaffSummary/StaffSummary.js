import React, { useEffect, useRef, useState } from 'react'
import './StaffSummary.scss'
import { DataType, Table } from 'ka-table';
import { Breadcrumb } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';
import LoadingSpinner from '../Loader/Loader';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
export default function StaffSummary() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [selectMonth, setSelectMonthh] = useState('')
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(15);
    const [periodData, setPeriodData] = useState([])
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [staffData, setStaffData] = useState([])
    const [leaveTypes, setLeaveTypes] = useState([]);
    const [brandData, setBrandData] = useState([]);
    const [brandId, setBrandId] = useState(null);
    const printRef = useRef();
    const [errorMessage, setErrorMessage] = useState('');
    useEffect(() => {
        getLeavedata()
        peroidMonthData()
        getData()
    }, [])
    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    const getLeavedata = () => {
        setLoading(true)
        AxiosLayout.get(`/Leave/GetLeaveTypes?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
            setLeaveTypes(res.data);
            setLoading(false)
        });
    }
    const peroidMonthData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetSalaryPeriods?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
            if (res.status === 200) {
                setPeriodData(res.data)
                setLoading(false)
            }
        })

    }
    const getData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetBrands?CompanyId=${userId.companyId}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setBrandData(res.data);
                setLoading(false)
            }
        });
    };
    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
    const handleStaffData = () => {
        if (brandId === null) {
            setErrorMessage("Select Brand")
        }
        else if (selectMonth !== "") {
            setLoading(true)
            AxiosLayout.get(`/Report/GetStaffSummary?SalaryPeriod=${selectMonth}&EmployeeId=${userId.user}&CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then(res => {
                if (res.status === 200) {
                    setStaffData(res.data)
                    setLoading(false)
                }
            })
        }
    }

    const dataArray = staffData.map(
        (i, index) => ({
            employeeId: i.EmployeeId,
            date: i.AtnDate?.split(" ")[0],
            first_in: i.InTime,
            last_out: i.OutTime,
            work_time: i.WorkTime,
            break_time: i.BreakTime,
            status: i.Status,
            remarks: i.Remark,
            comments: i.Reason,
            id: index
        }),
    );

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const paginatedData = dataArray.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;
    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

    // const countStatuses = (data) => {
    //     const statusCounts = {
    //         P: 0,
    //         SL: 0,
    //         CL: 0,
    //         LOP: 0,
    //         A: 0,
    //         Other: 0
    //     };

    //     data.forEach(item => {
    //         if (statusCounts.hasOwnProperty(item.Status)) {
    //             statusCounts[item.Status]++;
    //         } else {
    //             statusCounts.Other++;
    //         }
    //     });

    //     return statusCounts;
    // };
    const countStatuses = (data) => {
        const statusCounts = {
            P: 0,
            SL: 0,
            CL: 0,
            LOP: 0,
            A: 0,
            Other: 0,

        };

        data.forEach(item => {
            if (item.Status === 'H') return;
            switch (item.Status) {
                case 'SL':
                    statusCounts.SL += 1;
                    break;
                case 'SLH':
                    statusCounts.SL += 0.5;
                    break;
                case 'CL':
                    statusCounts.CL += 1;
                    break;
                case 'CLH':
                    statusCounts.CL += 0.5;
                    break;
                case 'LOP':
                    statusCounts.LOP += 1;
                    break;
                case 'LOPH':
                    statusCounts.LOP += 0.5;
                    break;
                case 'P':
                    statusCounts.P += 1;
                    break;
                case 'A':
                    statusCounts.A += 1;
                    break;
                default:
                    statusCounts.Other += 1;
            }
        });

        return statusCounts;
    };
    const statusCounts = countStatuses(staffData);
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Staff Summary</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {errorMessage && (
                    <div class="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Reports</Breadcrumb.Item>
                            <Breadcrumb.Item active>Staff Summary</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={() => {
                            setPeriodData([])
                            setSelectMonthh("")
                            setBrandData([])
                            setBrandId(null)
                            getLeavedata()
                            peroidMonthData()
                            getData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='containerr'>
                    <div className="d-flex flex-wrap row m-1 p-2 bg-white">
                        <div className="col-12 col-md-4 col-lg-2 p-1">
                            <YsecSelect className="md"
                                objectNameKey="brandName"
                                objectValueKey="brandId"
                                data={[
                                    { brandId: "", brandName: "Select Brand" },
                                    ...brandData.map(i => ({
                                        brandId: i.BrandId,
                                        brandName: i.Brand
                                    }))
                                ]}
                                onChange={(e) => setBrandId(e.target.value)}
                            />
                        </div>
                        <div className="col-12 col-md-4 col-lg-3 p-1">
                            <YsecSelect
                                mandatory
                                className="select"
                                objectNameKey="PeriodDescription"
                                objectValueKey="SalaryPeriod"
                                data={[
                                    { SalaryPeriod: "", PeriodDescription: "Select Month" },
                                    ...periodData?.filter(j => j.BrandId == Number(brandId)).map(i => ({
                                        SalaryPeriod: i.SalaryPeriod,
                                        PeriodDescription: i.PeriodDescription
                                    }))
                                ]}
                                onChange={(e) => setSelectMonthh(e.target.value)}
                            />
                        </div>

                        <div className="col-12 col-md-4 col-lg-1 p-1">
                            <YsecButton className='btnn w-100' onClick={handleStaffData}>Submit</YsecButton>
                        </div>
                        <div className="col-12 col-sm-6 col-md-2 col-lg-1 p-1"><YsecButton className='btnn2 w-100 text-nowrap'>P : {statusCounts.P}</YsecButton></div>
                        <div className="col-12 col-sm-6 col-md-2 col-lg-1 p-1"><YsecButton className='btnn2 w-100 text-nowrap'>SL : {statusCounts.SL}</YsecButton></div>
                        <div className="col-12 col-sm-6 col-md-2 col-lg-1 p-1"><YsecButton className='btnn2 w-100 text-nowrap'>CL : {statusCounts.CL}</YsecButton></div>
                        <div className="col-12 col-sm-6 col-md-2 col-lg-1 p-1"><YsecButton className='btnn2 w-100 text-nowrap'>LOP : {statusCounts.LOP}</YsecButton></div>
                        <div className="col-12 col-sm-6 col-md-2 col-lg-1 p-1"><YsecButton className='btnn2 w-100 text-nowrap'>A : {statusCounts.A}</YsecButton></div>
                        <div className="col-12 col-sm-6 col-md-2 col-lg-1 p-1"><YsecButton className='btnn2 w-100 text-nowrap'>Other : {statusCounts.Other}</YsecButton></div>


                    </div>



                    <div className='katable' ref={printRef}>
                        <Table
                            columns={[
                                { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
                                { key: "date", title: "Date", dataType: DataType.String, },
                                { key: "first_in", title: "In Time", dataType: DataType.String, },
                                { key: "last_out", title: "Out Time", dataType: DataType.String, },
                                { key: "work_time", title: "Work Time", dataType: DataType.String, },
                                { key: "break_time", title: "Break Time", dataType: DataType.String, },
                                { key: "status", title: "Status", dataType: DataType.String, },
                                { key: "remarks", title: "Remarks", dataType: DataType.String, },
                                { key: "comments", title: "Comments", dataType: DataType.String, },
                            ]}
                            data={paginatedData}
                            rowKeyField={'id'}
                            noData={{
                                text: 'No Data Found'
                            }}

                        />
                    </div>
                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}
