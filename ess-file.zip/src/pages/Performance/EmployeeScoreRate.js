import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb, Col, Row } from 'react-bootstrap';
import './EmployeeScore.scss'
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import { EvalScoreRateInput, RemarkInput } from './CustomeInputs';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));

function EmployeeScoreRate() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [searchText, setSearchText] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);
    const [selectedMonth, setSelectedMonth] = useState("")
    const [selectedStaffGroup, setSelectedStaffGroup] = useState("")
    const [departments, setDepartments] = useState([])
    const [data, setData] = useState([])
    const [scores, setScores] = useState({})
    const [remarks, setRemarks] = useState({})
    const [selectedDepartmentName, setSelectedDepartmentName] = useState("");
    const [alertMessage, setAlertMessage] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
      const [loading, setLoading] = useState(false);
      const [error, setError] = useState(null);
    const printRef = useRef();
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);
    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getDeapartments()
    }, [])
    const getDeapartments = () => {
        setLoading(true)
        try {
            AxiosLayout.get(`/Performance/GetDepartments?CompanyId=${userId?.companyId}&UserId=${userId.user}`).then(res => {
                if (res.data) {
                    setDepartments(res.data)
                    setLoading(false)
                }
            })

        } catch (error) {
            console.error(error);
        }
    }

    
//   if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;


    const getData = () => {
        if (selectedMonth === "") {
            setErrorMessage("Select Month")
        }
        else if (selectedStaffGroup === "") {
            setErrorMessage("Select Department")
        }
        else {
            setLoading(true)
            try {
                const month = `${selectedMonth}-01`
                AxiosLayout.get(`/Performance/GetDeptPerformanceList?UserId=${userId.user}&DeptId=${selectedStaffGroup}&MonthDate=${month}`).then(res => {
                    if (res.data) {
                        setData(res.data)
                        const initialScores = {};
                        const initialRemarks = {};
                        res.data.forEach(item => {
                            initialScores[item.RowNo] = item.Score;
                            initialRemarks[item.RowNo] = item.Remarks;
                        });
                        setScores(initialScores);
                        setRemarks(initialRemarks);
                        setLoading(false)
                    }
                })

            } catch (error) {
                console.error(error);
            }
        }
    }
    const dataArray = data.map(
        (i, index) => ({
            no: i.RowNo,
            emp_id: i.EmployeeId,
            doe: i.DOE,
            staff_name: i.FullName,
            job_title: i.JobTitle,
            eval_score_rate: i.Score,
            remark: i.Remarks,
            performanceId: i.PerformanceId,
            isClosed: i.IsClosed,
            id: i.RowNo,
        }),
    );

    const onChangeFun = (e) => {
        const month = e.target.value
        // setSelectedMonth(`${month}-01`)
        setSelectedMonth(month)
    }
    const handleDepartmentChange = (e) => {
        const selectedGroupId = e.target.value;
        setSelectedStaffGroup(selectedGroupId);
        const selectedDepartment = departments.find(dept => dept.DepartmentID === Number(selectedGroupId));
        setSelectedDepartmentName(selectedDepartment ? selectedDepartment.DepartmentName : "");
    };
    const dataArrayy = [
        {
            id: 1,
            label: `${selectedDepartmentName}`

        },
        {
            id: 2,
            label: `Score entered by: ${userId?.userName}`,
        }
    ];
    const handleScoreChange = (no, value) => {
        setScores(prev => ({ ...prev, [no]: value }));
    };

    const handleRemarks = (no, value) => {
        setRemarks(prev => ({ ...prev, [no]: value }));
    };


    const handleSave = () => {

        for (let item of dataArray) {
            const score = scores[item.no] || item.eval_score_rate;
            // if (!item.eval_score_rate && !scores[item.no]) {
            if (!score) {
                setErrorMessage(`All Scores Fields are required to be filled`);
                return;
            }
            if (score < 1 || score > 100) {
                setErrorMessage(`Please enter score between 1 and 100`);
                return;
            }
        }
        const month = `${selectedMonth}-01`
        const scoreDetails = dataArray.map(item => ({
            performanceId: item.performanceId, // Assuming performanceId is part of item
            employeeId: item.emp_id,
            score: scores[item.no] || item.eval_score_rate,
            remarks: remarks[item.no] || item.remark
        }));
        const payload = {
            monthDate: month,
            deptId: selectedStaffGroup,
            userId: userId.user,
            scoreDetails: scoreDetails
        }
        AxiosLayout.post(`/Performance/UpdateDeptScoreRate`, payload).then(res => {
            if (res.data) {
                setAlertMessage(res.data.Message)
                setScores({})
                setRemarks({})
                setSelectedMonth("")
                setSelectedStaffGroup("")
                setData([])
                setSelectedDepartmentName("")
                setDepartments([])
                getDeapartments()
            }
        }).catch(err => {
            console.error(err);
            setErrorMessage(err.message);
        })
    }
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Employee Score Rate</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    const isSubmitDisabled = dataArray.some(item => item.isClosed === true);


    return (
        <div className="p-1">
           {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div class="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                {errorMessage && (
                    <div class="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Performance</Breadcrumb.Item>
                            <Breadcrumb.Item active>Employee Score Rate</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm ${data?.length!==0 ?"history":"btn-outline-primary"} `} onClick={getData}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <ysecButton type="button" className={`sm ${data?.length===0 ?"history":"btn-outline-primary"}`} onClick={() => {
                            setSelectedMonth("")
                            setSelectedDepartmentName("")
                            setDepartments([])
                            setScores({});
                            setRemarks({});
                            setData([])
                            setSearchText("")
                            setSelectedStaffGroup("")
                            getDeapartments()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='employee_container'>
                    <div class="d-flex flex-wrap row m-1 p-2 bg-white">

                        <div class="col-4 col-sm-2 col-lg-1 p-1">
                            <label>Select Month</label>
                        </div>
                        <div class="col-8 col-sm-4 col-lg-2 p-1">
                            <input type='month' className='w-100' placeholder="YYYY-MM" onChange={onChangeFun}
                                value={selectedMonth} />
                        </div>
                        <div class="col-12 col-sm-6 col-lg-3 p-1">
                            <YsecSelect className="md"
                                objectNameKey="groupName"
                                objectValueKey="groupId"
                                data={[
                                    { groupId: "", groupName: "Select" },
                                    ...departments.map(i => ({
                                        groupId: i.DepartmentID,
                                        groupName: i.DepartmentName
                                    }))

                                ]}
                                onChange={handleDepartmentChange}
                            />
                        </div>
                        <div class="col-12 col-sm-6 col-lg-2  p-1">
                            <YsecButton className='btnn w-100' onClick={() => {
                                setScores({})
                                setRemarks({})
                                setData([])
                                getData()
                            }}>Show</YsecButton>
                        </div>
                        <div class="col-12 col-sm-6 col-lg-4 p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>
                    </div>
                    <div className='katable' ref={printRef}>
                        <Table
                            columns={[
                                { key: "no", title: "No", dataType: DataType.String, },
                                { key: "emp_id", title: "Employee Id", dataType: DataType.String, },
                                { key: "doe", title: "DOE", dataType: DataType.String, },
                                { key: "staff_name", title: "Staff Name", dataType: DataType.String, },
                                { key: "job_title", title: "Job Title", dataType: DataType.String, },
                                { key: "eval_score_rate", title: "Evaluation Scoring Rate", dataType: DataType.String, },
                                { key: "remark", title: "Remarks", dataType: DataType.String, },
                            ]}
                            data={dataArray}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {
                                            case 'eval_score_rate':
                                                return <EvalScoreRateInput {...props} scores={scores} setScores={setScores} handleScoreChange={handleScoreChange} />
                                            case 'remark':
                                                return <RemarkInput  {...props} remarks={remarks} setRemarks={setRemarks} handleRemarks={handleRemarks} />
                                            default:
                                                return props.children;
                                        }

                                    },
                                },


                            }}
                        />
                    </div>
                    <div>
                        {selectedDepartmentName !== "" &&
                            <Row>
                                <Col xs={12} sm={3}>

                                    <div className='katable table2'>
                                        <Table
                                            columns={[
                                                {
                                                    key: 'label',
                                                    title: '',
                                                    dataType: DataType.String
                                                },
                                            ]}
                                            data={dataArrayy}
                                            rowKeyField={'id'}
                                            noData={{
                                                text: 'No Data Found'
                                            }}
                                        />
                                    </div>

                                </Col>
                                <Col xs={12} sm={7}>
                                </Col>
                                <Col xs={12} sm={2}>
                                    {/* <YsecButton className={isSubmitDisabled===true ? "disabled w-100":'btnn w-100'} onClick={handleSave} disabled={isSubmitDisabled===true}>Submit</YsecButton> */}
                                    <YsecButton className={'btnn w-100'} onClick={handleSave} >Submit</YsecButton>

                                </Col>
                            </Row>}
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}

export default EmployeeScoreRate;