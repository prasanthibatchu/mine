import React, { useState } from "react";
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
export const Empdesc = (props) => {
  const orderNo = props.rowKeyValue.orderno;
  const [localDesc, setLocalDesc] = useState(props.descriptions[orderNo] || props.rowKeyValue.empdesc);

  return (
    <YsecTextarea className="custom-inputt sm"
      name="desc"
      value={localDesc}
      onChange={(e) => setLocalDesc(e.target.value)}
      onBlur={() => props.handleDescriptionChange(orderNo, localDesc)}
    />
  );
};

export const EmpScore = (props) => {
  const orderNo = props.rowKeyValue.orderno;
  const [localScore, setLocalScore] = useState(props.scores[orderNo] || props.rowKeyValue.employeeScore);

  return (
    <YsecInput className={`${props?.scoreReq === false && "disbaledtxt"}`}
      type="number"
      name="score"
      value={localScore === "" ? 0 : localScore}
      onChange={(e) => setLocalScore(e.target.value)}
      onBlur={() => props.handleScoreChange(orderNo, localScore)}
       disabled={props?.scoreReq === false}
    />
  );
};

export const Mngdesc = (props) => {
  const orderNo = props.rowKeyValue.orderno;
  const [localDesc, setLocalDesc] = useState(props.descriptions[orderNo] || props.rowKeyValue.mngdesc);

  return (
    <YsecTextarea className={`sm ${props?.displayTypeID == 4 && "disbaledtxt"}`}
      name="desc"
      value={localDesc}
      onChange={(e) => setLocalDesc(e.target.value)}
      onBlur={() => props.handleDescriptionChange(orderNo, localDesc)}
      disabled={props?.displayTypeID===4}
    />
  );
};

export const MngScore = (props) => {
  const orderNo = props.rowKeyValue.orderno;
  const [localScore, setLocalScore] = useState(props.scores[orderNo] || props.rowKeyValue.mngScore);

  return (
    <YsecInput className={`${props?.scoreReq === false && "disbaledtxt"}`}
      type="number"
      name="score"
      value={(localScore === "") ? 0 : localScore}
      onChange={(e) => setLocalScore(e.target.value)}
      onBlur={() => props.handleScoreChange(orderNo, localScore)}
       disabled={props?.scoreReq === false}
    />
  );
};

export const EvalScoreRateInput = (props) => {
  const no = props.rowKeyValue;
  const [localScore, setLocalScore] = useState(props.scores[no] || props.rowKeyValue.eval_score_rate);
  return (
    <>
      <YsecInput placeholder="Enter Score" type="number" className="custom-inputt"
        name="score"
        value={localScore === "" ? 0 : localScore}
        onChange={(e) => setLocalScore(e.target.value)}
        onBlur={() => props.handleScoreChange(no, localScore)}
      />
    </>
  )
}
export const RemarkInput = (props) => {
  const no = props.rowKeyValue;
  const [localDesc, setLocalDesc] = useState(props.remarks[no] || props.rowKeyValue.remark);
  return (
    <>
      <YsecInput placeholder="Remarks" type="text" className="custom-inputt"
        name="score"
        value={localDesc}
        onChange={(e) => setLocalDesc(e.target.value)}
        onBlur={() => props.handleRemarks(no, localDesc)}
      />
    </>
  )
}