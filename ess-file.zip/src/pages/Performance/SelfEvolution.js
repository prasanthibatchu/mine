import React, { useState, useEffect, useRef } from 'react';
import './EmployeeScore.scss';
import { Breadcrumb } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';
import { DataType, Table } from 'ka-table';
import Modal from 'react-bootstrap/Modal';
import { Empdesc, EmpScore } from './CustomeInputs';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

function SelfEvolution() {
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [alertMessage, setAlertMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [errorMessage2, setErrorMessage2] = useState('');
  const printRef = useRef();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [err, setErr] = useState(0)
  const [selfData, setSelfData] = useState([])
  const [evalData, setEvalData] = useState([])
  const [descriptions, setDescriptions] = useState({});
  const [scores, setScores] = useState({});
  const [openModel, setOpenModel] = useState(false)
  useEffect(() => {
    if (alertMessage) {
      const timer = setTimeout(() => {
        setAlertMessage('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [alertMessage]);
  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => {
        setErrorMessage('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);
  useEffect(() => {
    if (errorMessage2) {
      const timer = setTimeout(() => {
        setErrorMessage2('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage2]);
  useEffect(() => { getData() }, [])
  const getData = () => {
    setLoading(true)
    AxiosLayout.get(`/Performance/GetEvaluation?EmpId=${userId.user}`).then(res => {
      if (res.status === 200) {

        setSelfData(res?.data?.Table[0])
        setEvalData(res?.data?.Table1)

        setLoading(false)


      }
    });

  }
  if (error) return <p>Error: {error}</p>;

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Self Evaluation</title>');
    printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };
  const dataArray = evalData?.map((i, index) => ({
    orderno: i.OrderNo,
    evalid: i.EvaluationID,
    description: i.Description,
    maxScore: i.MaxScore,
    empdesc: i.EmployeeDes,
    employeeScore: i.EmployeeScore == null ? 0 : i.EmployeeScore,
    scoreReq: i.ScoreRequired,
    id: i.OrderNo
  }));
  const handleOpenModel = () => {
    setOpenModel(!openModel)
  }
  const handleDescriptionChange = (orderNo, value) => {
    setDescriptions(prev => ({ ...prev, [orderNo]: value }));
  };

  const handleScoreChange = (orderNo, value) => {
    setScores(prev => ({ ...prev, [orderNo]: value }));
  };

  const handleSaveDraft = () => {
    setLoading(true)
    for (let item of dataArray) {

      const latestScore = scores[item.orderno] !== undefined ? scores[item.orderno] : item.employeeScore;
      if (item.maxScore > 0) {
        if (
          latestScore === undefined ||
          latestScore === "" ||
          Number(latestScore) < 1 ||
          Number(latestScore) > Number(item.maxScore)
        ) {
          setErrorMessage2(`Please enter score between 1 and ${item.maxScore} for SL No ${item.orderno}`);
          setLoading(false);
          window.scrollTo(0, 0);
          return;
        }
      }
    }
    const scoreDetails = dataArray?.map(item => ({
      orderNo: item.orderno,
      score: scores[item.orderno] || item.employeeScore,
      remarks: descriptions[item.orderno] !== undefined ? descriptions[item.orderno] : (item.empdesc || '')
    }));

    const payload = {
      entryType: 0,
      evaluationID: selfData?.EvaluationID,
      scoreDetails: scoreDetails,
      UserId: userId.user
    };

    AxiosLayout.post("/Performance/UpdateSelfScoreDraft", payload).then(res => {
      if (res.data.Status === 1) {

        setDescriptions({})
        setScores({})
        setAlertMessage(res.data.Message)
        getData()
        setLoading(false)
        window.scrollTo(0, 0);
      }
      else {
        setErrorMessage(res.data.Message)
        setLoading(false)
        window.scrollTo(0, 0);
      }
    })
  };
  const handleSave = (e) => {
    e.preventDefault()
    setErr(0)

    for (let item of dataArray) {
      const latestDesc = descriptions[item.orderno] !== undefined
        ? descriptions[item.orderno]
        : item.empdesc;
      const latestScore = scores[item.orderno] !== undefined
        ? scores[item.orderno]
        : item.employeeScore;
      if (!latestDesc || latestDesc.trim() === "") {
        setErrorMessage2(`Please enter Your Review for all points (${item.orderno}).`);
        // setOpenModel(false);
        window.scrollTo(0, 0);
        return;
      }
      else if (item?.scoreReq === true) {
        if (!latestDesc || latestDesc.trim().length < 10) {
          setErrorMessage2(`Please enter a clear Review for all points.`);
          // setOpenModel(false);
          window.scrollTo(0, 0);
          return;
        }
      }
      else {
        if (!latestDesc || latestDesc.trim().length < 1) {
          setErrorMessage(`'Please enter a clear Review for all points.`);
          // setOpenModel(false);
          window.scrollTo(0, 0);
          return;
        }
      }

      // if (!latestDesc || latestDesc.trim() === "") {
      //   setErrorMessage(`All Descriptions are required`);
      //   setOpenModel(false);
      //   return;
      // }
      if (latestScore === undefined || latestScore === null || latestScore === "") {
        setErrorMessage(`Score is required for SL No ${item.orderno}`);
        // setOpenModel(false);
        window.scrollTo(0, 0);
        return;
      }
      if (item.maxScore > 0) {
        if (
          latestScore === undefined ||
          latestScore === "" ||
          Number(latestScore) < 1 ||
          Number(latestScore) > Number(item.maxScore)
        ) {
          setErrorMessage2(`Please enter score between 1 and ${item.maxScore} for SL No ${item.orderno}`);
          setLoading(false);
          // setOpenModel(false);
          window.scrollTo(0, 0);
          return;
        }
      }
    }
    setOpenModel(true);

  };
  const handleSave2 = () => {
    const scoreDetails = dataArray.map(item => ({
      orderNo: Number(item.orderno),
      score: scores[item.orderno] !== undefined ? Number(scores[item.orderno]) : Number(item.employeeScore),
      remarks: descriptions[item.orderno] !== undefined ? descriptions[item.orderno] : item.empdesc,
    }));

    const payload = {
      entryType: 0,
      evaluationID: selfData?.EvaluationID,
      scoreDetails: scoreDetails,
      UserId: userId.user
    };

    AxiosLayout.post("/Performance/SaveSelfEvaluation", payload).then(res => {
      if (res.data.Status === 1) {
        setDescriptions({});
        setScores({});
        setSelfData([])
        setEvalData([])
        getData();
        setAlertMessage(res.data.Message);
        setOpenModel(false);
        window.scrollTo(0, 0);
      } else {
        setErrorMessage(res.data.Message);
        window.scrollTo(0, 0);
      }
    });
  }
  return (
    <div>
      {loading === true && <LoadingSpinner show={loading} />}
      <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
        {alertMessage && (
          <div class="alert alert-success" role="alert">
            {alertMessage}
          </div>
        )}
        {errorMessage && (
          <div class="alert alert-danger" role="alert">
            {errorMessage}
          </div>
        )}
        <div className='header d-flex row flex-wrap'>
          <div class="col">
            <Breadcrumb>
              <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
              <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
              <Breadcrumb.Item href="#">Performance</Breadcrumb.Item>
              <Breadcrumb.Item active>Self Evaluation</Breadcrumb.Item>
            </Breadcrumb>
          </div>
          <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
            <ysecButton type="button" className={`sm history`} >
              <YsecFont className="yf-clock" />
            </ysecButton>
            <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
              <YsecFont className="yf-printer-scan" />
            </YsecButton>
          </div>
        </div>
        {evalData?.length !== 0 ?
          <div className='employee_container'>

            <div className='katable eveltable'>
              <table className="even-table">
                <tr className='boldcell'>
                  <td>
                    <div className="cell-flex">
                      <label>Employee:</label>
                      <span>{selfData?.EmployeeID}-{selfData?.FullName}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Last Date to Submit:</label>
                      <span>{selfData?.CutOffDate}</span>
                    </div>
                  </td>
                </tr>
                <tr className='boldcell'>
                  <td>
                    <div className="cell-flex">
                      <label>Date of Join:</label>
                      <span>{selfData?.DateofJoin}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Designation:</label>
                      <span>{selfData?.Designation}</span>
                    </div>
                  </td>
                </tr>
                <tr className='boldcell'>
                  <td>
                    <div className="cell-flex">
                      <label>Reporting Manager:</label>
                      <span>{selfData?.ReportingManager}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Evaluated By:</label>
                      <span>{selfData?.EvaluatedBy}</span>
                    </div>
                  </td>
                </tr>
                <tr className='boldcell'>
                  <td>
                    <div className="cell-flex">
                      <label>Appraisal Period:</label>
                      <span>{selfData?.AppraisalPeriod}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Location:</label>
                      <span>{selfData?.Location}</span>
                    </div>
                  </td>
                </tr>
                <tr className='boldcell'>
                  <td>
                    <div className="cell-flex">
                      <label>Attendance Summary:</label>
                      <span></span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label></label>
                      <span></span>
                    </div>
                  </td>
                </tr>
                <tr className='boldcell'>
                  <td>
                    <div className="cell-flex">
                      <label>Review Start Date:</label>
                      <span>{selfData?.ReviewStartDate}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Review End Date:</label>
                      <span>{selfData?.ReviewEndDate}</span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="cell-flex">
                      <label>Total Days:</label>
                      <span>{selfData?.totalDays}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Leave Days:</label>
                      <span>{selfData?.LeaveDays}</span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="cell-flex">
                      <label>Total Working Days:</label>
                      <span>{selfData?.TotalDays}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Leave Hrs:</label>
                      <span>{selfData?.LeaveHrs}</span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="cell-flex">
                      <label>Expected Working Hrs:</label>
                      <span>{selfData?.ExpectedWorkingHrs}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Holidays:</label>
                      <span>{selfData?.Holidays}</span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="cell-flex">
                      <label>Days Worked:</label>
                      <span>{selfData?.DaysWorked}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label>Break Hrs:</label>
                      <span>{selfData?.BreakHrs}</span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="cell-flex">
                      <label>Worked Hrs:</label>
                      <span>{selfData?.WorkedHrs}</span>
                    </div>
                  </td>
                  <td>
                    <div className="cell-flex">
                      <label></label>
                      <span></span>
                    </div>
                  </td>
                </tr>
              </table>
            </div>

            <div>
              <p><b><i>Plese ensure that the details below are completed within the review period, from the start to the end date.</i></b></p>
            </div>

            <div className='katable eveltable'>
              {errorMessage2 && (
                <div class="alert alert-danger" role="alert">
                  {errorMessage2}
                </div>
              )}
              <Table
                columns={[
                  { key: "orderno", title: "No", dataType: DataType.String },
                  { key: "description", title: "Description", dataType: DataType.String },
                  { key: "maxScore", title: "Max Score", dataType: DataType.String },
                  { key: "empdesc", title: "My Review", dataType: DataType.String },
                  { key: "employeeScore", title: "My Score", dataType: DataType.String },
                ]}
                data={dataArray}
                rowKeyField={'id'}
                noData={{
                  text: 'No Data Found'
                }}
                childComponents={{
                  cellText: {
                    content: (props) => {
                      switch (props.column.key) {
                        case 'empdesc':
                          return <Empdesc rowKeyValue={props.rowData} handleDescriptionChange={handleDescriptionChange} descriptions={descriptions} />;
                        case 'employeeScore':
                          return <EmpScore rowKeyValue={props.rowData} handleScoreChange={handleScoreChange} scores={scores} scoreReq={props.rowData.scoreReq} />;
                        default:
                          return props.children;
                      }
                    },
                  },
                }}
              />
            </div>


            {dataArray?.length > 0 && (
              <div className="d-flex flex-wrap align-items-center justify-content-end row m-1 p-2 bg-white">

                <div className="col-12 col-md-2 p-1">
                  <YsecButton className='btnn w-100 text-nowrap' onClick={handleSaveDraft}>Save as Draft</YsecButton>
                </div>
                <div className="col-12 col-md-2 p-1">
                  <YsecButton className='btnn w-100' onClick={handleSave}>Submit</YsecButton>
                </div>
              </div>
            )}
          </div> :
          <>
            <div className='d-flex justify-content-center'>
              <div class="alert alert-danger evalumsg" role="alert">
                No Self-performance evaluation process initiated for you now.
              </div>
            </div>
          </>}

        {openModel && (
          <Modal
            show={openModel}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
          >
            <Modal.Header>
              <button type="button" className="btn-close" onClick={handleOpenModel} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
              <h6 className='deleteleave'>This is the final submission. Once submitted cannot be reverted back. Are you sure to submit?</h6>
            </Modal.Body>
            <Modal.Footer>
              <YsecButton type="button" onClick={handleOpenModel} className='cancel'>Cancel</YsecButton>
              <YsecButton type="button" className="confirm" onClick={handleSave2}>Confirm</YsecButton>
            </Modal.Footer>
          </Modal>
        )}
      </React.Suspense>
    </div>
  );
}

export default SelfEvolution;