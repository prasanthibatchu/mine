import React, { useState, useEffect, useRef } from 'react';
import './EmployeeScore.scss';
import { Breadcrumb, Col, Row } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';
import { DataType, Table } from 'ka-table';
import Modal from 'react-bootstrap/Modal';
import { Mngdesc, MngScore } from './CustomeInputs';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

function MemberEvolution() {
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [memberData, setMemberData] = useState([])
  const [evalData, setEvalData] = useState([])
  const [autherData, setAutherData] = useState([])
  const [searchText, setSearchText] = useState('');
  const [descriptions, setDescriptions] = useState({});
  const [scores, setScores] = useState({});
  const [alertMessage, setAlertMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [openModel, setOpenModel] = useState(false)
  const [enterInput, setEnterInput] = useState("")
  const [empData, setEmpData] = useState([])
  const [empId, setEmpId] = useState(null)
  const [auther, setAuther] = useState(null)
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const printRef = useRef();
  const [err, setErr] = useState(0)
  useEffect(() => {
    getEmpData()

  }, []);

  useEffect(() => {
    if (alertMessage) {
      const timer = setTimeout(() => {
        setAlertMessage('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [alertMessage]);
  useEffect(() => {
    if (errorMessage) {
      const timer = setTimeout(() => {
        setErrorMessage('');
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [errorMessage]);
  const getEmpData = () => {
    setLoading(true)
    AxiosLayout.get(`/Performance/GetMembers?ManagerId=${userId.user}`).then(res => {
      if (res.status === 200) {
        setEmpData(res.data)
        setLoading(false)
      }
    })
  }
  useEffect(() => { if (empId !== null) { getData(); } }, [empId])
  useEffect(() => {
    setDescriptions({});
    setScores({});
    setMemberData([])
    setAutherData([])
    setEvalData([])
  }, [empId]);
  const getData = () => {
    setLoading(true)

    if (empId === null || empId == "") {
      setErrorMessage("Please select Employee")
      setMemberData([])
      setAutherData([])
      setEvalData([])
      setEmpData([])
      setEmpId(null)
      getEmpData()
      setLoading(false)
      window.scrollTo(0, 0);
      return;
    }

    AxiosLayout.get(`/Performance/GetMemberEvaluation?EmpId=${empId}&UserId=${userId.user}`).then(res => {
      if (res.status === 200) {

        setMemberData(res?.data?.Table[0])
        setEvalData(res?.data?.Table1)
        setAutherData(res?.data?.Table2)
        setLoading(false)
      }
    });
  };


  // if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  const handleOpenModel = () => {
    setOpenModel(!openModel)
  }

  const dataArray = evalData?.map((i, index) => ({

    orderno: i.OrderNo,
    employeeId: i.EmployeeID,
    evalid: i.EvaluationID,
    cutoffdate: i.CuttOffDate,
    description: i.Description,
    maxScore: i.MaxScore,
    qType: i.QType,
    status: i.StatusID,
    empdesc: i.EmployeeDes,
    employeeScore: i.EmployeeScore,
    employeeInputs: i.EmployeeInputs,
    mngdesc: i.ManagerDes,
    mngScore: i.ManagerScore == null ? 0 : i.ManagerScore,
    scoreReq: i.ScoreRequired,
    displayTypeID: i.DisplayTypeID,
    id: i.OrderNo
  }));

  const handleDescriptionChange = (orderNo, value) => {
    setDescriptions(prev => ({ ...prev, [orderNo]: value }));
  };

  const handleScoreChange = (orderNo, value) => {
    setScores(prev => ({ ...prev, [orderNo]: value }));
  };



  const handleSaveDraft = () => {
    if (empId === null || empId === "") {
      setErrorMessage("Please select Employee")
      window.scrollTo(0, 0);
      return;
    }
    const scoreDetails = dataArray?.map(item => ({
      orderNo: item.orderno,
      score: scores[item.orderno] || item.mngScore,
      remarks: descriptions[item.orderno] !== undefined ? descriptions[item.orderno] : (item.mngdesc || '')
    }));

    const payload = {
      entryType: 0,
      evaluationID: memberData?.EvaluationID,
      scoreDetails: scoreDetails,
      UserId: userId.user
    };
    AxiosLayout.post("/Performance/UpdateMemberScoreDraft", payload).then(res => {
      if (res.data.Status === 1) {
        setDescriptions({})
        setScores({})
        setAlertMessage(res.data.Message)
        getData()
        window.scrollTo(0, 0);
      }
      else {
        setErrorMessage(res.data.Message)
        window.scrollTo(0, 0);
      }
    })
  };
//   const handleSave = (e) => {
//     e.preventDefault()
//     setErr(0)
//     for (let item of dataArray) {
//       // Only validate if not DisplayTypeID 4 (input is enabled)
//       if (item.displayTypeID !== 4) {
//         // If ScoreRequired is true, description must be entered and at least 10 characters
//         const desc = descriptions[item.orderno] !== undefined ? descriptions[item.orderno] : item.mngdesc;
//         if (item.scoreReq) {
//           if (!desc) {
//             setErrorMessage(`Please enter Your Comments for all points (${item.orderno}).`);
//             window.scrollTo(0, 0);
//             return;
//           } else if (!desc || desc.trim().length < 10) {
//             setErrorMessage(`Please enter a clear Comments for all points ( ${item.orderno}).`);
//             window.scrollTo(0, 0);
//             return;
//           }
//         }
//       }
//       if (item.scoreReq && item.maxScore > 0) {
//         const latestScore = scores[item.orderno] !== undefined ? scores[item.orderno] : item.mngScore;
//         if (
//           latestScore === undefined ||
//           latestScore === "" ||
//           Number(latestScore) < 1 ||
//           Number(latestScore) > Number(item.maxScore)
//         ) {
//           setErrorMessage(`Please enter score between 1 and ${item.maxScore} for SL No ${item.orderno}`);
//           window.scrollTo(0, 0);
//           return;
//         }
//       }
// setOpenModel(true);
//     }
//     // for (let item of dataArray) {
//     //   if (!item.mngdesc && !descriptions[item.orderno]) {
//     //     setErrorMessage(`Please enter Your Comments for all points.`);
//     //     setOpenModel(false);
//     //     return;
//     //   }
//     //   else if(item.mngdesc?.length<10){
//     //      setErrorMessage(`Please enter a clear Comments for all points.`);
//     //     setOpenModel(false);
//     //     return;
//     //   }
//     //   if (!item.mngScore && !scores[item.orderno]) {
//     //     setErrorMessage(`All Scores are required`);
//     //     setOpenModel(false);
//     //     return;
//     //   }
//     // }

  
//   }
const handleSave = (e) => {
  e.preventDefault();
  setErr(0);

  for (let item of dataArray) {
    if (item.displayTypeID !== 4) {
      const desc = descriptions[item.orderno] !== undefined ? descriptions[item.orderno] : item.mngdesc;
      if (item.scoreReq) {
        if (!desc) {
          setErrorMessage(`Please enter Your Comments for all points (${item.orderno}).`);
          window.scrollTo(0, 0);
          return;
        } else if (desc.trim().length < 10) {
          setErrorMessage(`Please enter a clear Comments for all points (${item.orderno}).`);
          window.scrollTo(0, 0);
          return;
        }
      }
    }

    if (item.scoreReq && item.maxScore > 0) {
      const latestScore = scores[item.orderno] !== undefined ? scores[item.orderno] : item.mngScore;
      if (
        latestScore === undefined ||
        latestScore === "" ||
        Number(latestScore) < 1 ||
        Number(latestScore) > Number(item.maxScore)
      ) {
        setErrorMessage(`Please enter score between 1 and ${item.maxScore} for SL No ${item.orderno}`);
        window.scrollTo(0, 0);
        return;
      }
    }
  }

  setOpenModel(true);
};

  const handleSave2=()=>{
      const scoreDetails = dataArray?.map(item => ({
      orderNo: item.orderno,
      score: scores[item.orderno] || item.mngScore || 0,
      remarks: descriptions[item.orderno] || item.mngdesc || ''
    }));

    const payload = {
      entryType: 0,
      evaluationID: memberData?.EvaluationID,
      scoreDetails: scoreDetails,
      UserId: userId.user
    };

    AxiosLayout.post("/Performance/SaveMemberEvaluation", payload).then(res => {
      if (res.data.Status === 1) {
        setEnterInput("")
        setDescriptions({})
        setScores({})
        setEmpId(null)
        setAuther(null)
        setAlertMessage(res.data.Message)
        // setEmpId(null)
        // getEmpData()
        getData()
        setOpenModel(false);
        window.scrollTo(0, 0);
      }
      else {
        setErrorMessage(res.data.Message)
      }
    })
  }
  const handleAuther = () => {
    if (auther == "" || auther == null) {
      setErrorMessage("Select Autherized Member")
      return
    }
    const payload = {
      evaluationID: memberData?.EvaluationID,
      authorizedBy: userId.user,
      evaluatorID: Number(auther)
    }

    AxiosLayout.post(`/Performance/AuthorizeEvaluation`, payload).then(res => {
      if (res.data.Status === 1) {
        setEnterInput("")
        setDescriptions({})
        setScores({})
        setEmpId(null)
        setAuther(null)
        setAlertMessage(res.data.Message)
        getData()
        window.scrollTo(0, 0);
      }
      else {
        setErrorMessage(res.data.Message)
        window.scrollTo(0, 0);
      }

    })
  }
  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Member Evaluation</title>');
    // Optional: Add your styles here, or link to your CSS file
    printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };
  return (
    <div>
      {loading === true && <LoadingSpinner show={loading} />}
      <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
        {alertMessage && (
          <div class="alert alert-success" role="alert">
            {alertMessage}
          </div>
        )}
        {errorMessage && (
          <div class="alert alert-danger" role="alert">
            {errorMessage}
          </div>
        )}
        <div className='header d-flex row flex-wrap'>
          <div class="col">
            <Breadcrumb>
              <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
              <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
              <Breadcrumb.Item href="#">Performance</Breadcrumb.Item>
              <Breadcrumb.Item active>Member Evaluation</Breadcrumb.Item>
            </Breadcrumb>
          </div>
          <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

            <ysecButton type="button" className={`sm history`} onClick={() => {

              getEmpData()
            }}>
              <YsecFont className="yf-clock" />
            </ysecButton>
            <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
              <YsecFont className="yf-printer-scan" />
            </YsecButton>
          </div>
        </div>
        <div className='employee_container'>

          <Row className="m-1 p-2 bg-white">
            <Col xs={12} sm={3} className="p-1">

              <YsecSelect className="md"
                objectNameKey="EmpName"
                objectValueKey="EmpId"
                label="Employee"
                data={[
                  { EmpId: "", EmpName: "Select" },
                  ...empData?.map(i => ({
                    EmpId: i.EmployeeId,
                    EmpName: i.FullName
                  }))
                ]}
                onChange={(e) => {

                  setEmpId(e.target.value)
                }}
              />
            </Col>
            {memberData?.ManagerID === userId.user && <>
              {(autherData?.length !== 0 && memberData?.AuthStats == "0") && (
                <Col xs={12} sm={7} className="p-1 d-flex align-items-center">

                  <div className='w-50'>
                    <YsecSelect className="md flex-grow-1"
                      label="Authorized to"
                      objectNameKey="EmpName"
                      objectValueKey="EmpId"
                      data={[
                        { EmpId: "", EmpName: "Select" },
                        ...autherData?.map(i => ({
                          EmpId: i.EmployeeId,
                          EmpName: i.FullName
                        }))
                      ]}
                      onChange={(e) => setAuther(e.target.value)}
                    /></div>
                  <YsecButton className="ms-2 w-25 mt-4" onClick={handleAuther}>Authorize</YsecButton>
                </Col>
              )}</>}
            <Col xs={12}>
              <b> Last Date to Submit: {memberData?.CutOffDate}</b>
            </Col>
          </Row>
          {empData?.length !== 0?<>
          {(empData?.length !== 0 && empId !== null) &&
            <div >

              <div className='katable eveltable'>
                <table className="even-table">

                  <tr>
                    <td>
                      <div className="cell-flex">
                        <label>Date of Join:</label>
                        <span>{memberData?.DateofJoin}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Designation:</label>
                        <span>{memberData?.Designation}</span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="cell-flex">
                        <label>Reporting Manager:</label>
                        <span>{memberData?.ReportingManager}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Evaluated By:</label>
                        <span>{memberData?.EvaluatedBy}</span>
                      </div>
                    </td>
                  </tr>
                  <tr className='boldcell'>
                    <td>
                      <div className="cell-flex">
                        <label>Appraisal Period:</label>
                        <span>{memberData?.AppraisalPeriod}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Location:</label>
                        <span>{memberData?.Location}</span>
                      </div>
                    </td>
                  </tr>
                  <tr className='boldcell'>
                    <td>
                      <div className="cell-flex">
                        <label>Attendance Summary:</label>
                        <span></span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label></label>
                        <span></span>
                      </div>
                    </td>
                  </tr>
                  <tr className='boldcell'>
                    <td>
                      <div className="cell-flex">
                        <label>Review Start Date:</label>
                        <span>{memberData?.ReviewStartDate}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Review End Date:</label>
                        <span>{memberData?.ReviewEndDate}</span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="cell-flex">
                        <label>Total Days:</label>
                        <span>{memberData?.totalDays}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Leave Days:</label>
                        <span>{memberData?.LeaveDays}</span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="cell-flex">
                        <label>Total Working Days:</label>
                        <span>{memberData?.TotalDays}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Leave Hrs:</label>
                        <span>{memberData?.LeaveHrs}</span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="cell-flex">
                        <label>Expected Working Hrs:</label>
                        <span>{memberData?.ExpectedWorkingHrs}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Holidays:</label>
                        <span>{memberData?.Holidays}</span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="cell-flex">
                        <label>Days Worked:</label>
                        <span>{memberData?.DaysWorked}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label>Break Hrs:</label>
                        <span>{memberData?.BreakHrs}</span>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td>
                      <div className="cell-flex">
                        <label>Worked Hrs:</label>
                        <span>{memberData?.WorkedHrs}</span>
                      </div>
                    </td>
                    <td>
                      <div className="cell-flex">
                        <label></label>
                        <span></span>
                      </div>
                    </td>
                  </tr>
                </table>
              </div>

              <div>
                <p><b><i>Plese ensure that the details below are completed within the review period, from the start to the end date.</i></b></p>
              </div>

              <div className='katable eveltable'>
                {memberData?.ManagerID === userId.user && <>
                  {memberData?.AuthStats !== "0" && <div class="alert alert-success" role="alert">
                    {memberData?.AuthStats}
                  </div>}</>}
                <Table
                  columns={[
                    { key: "orderno", title: "No", dataType: DataType.String, width: "5%" },
                    { key: "description", title: "Description", dataType: DataType.String, width: "15%" },
                    { key: "maxScore", title: "Max Score", dataType: DataType.String, width: "5%" },
                    { key: "empdesc", title: "Employee's Comments", dataType: DataType.String, width: "20%" },
                    { key: "employeeScore", title: "Employee's Score", dataType: DataType.String, width: "5%" },
                    { key: "mngdesc", title: "PL's Comments", dataType: DataType.String, width: "25%" },
                    { key: "mngScore", title: "PL's Score", dataType: DataType.String, width: "10%" },
                  ]}
                  data={dataArray}
                  rowKeyField={'id'}
                  noData={{
                    text: 'No Data Found'
                  }}
                  childComponents={{
                    cellText: {
                      content: (props) => {
                        switch (props.column.key) {
                          case 'mngdesc':
                            return <Mngdesc rowKeyValue={props.rowData} handleDescriptionChange={handleDescriptionChange} descriptions={descriptions} displayTypeID={props?.rowData?.displayTypeID} />;
                          case 'mngScore':
                            return <MngScore rowKeyValue={props.rowData} handleScoreChange={handleScoreChange} scores={scores} scoreReq={props.rowData.scoreReq} />;
                          default:
                            return props.children;
                        }
                      },
                    },
                  }}
                />
              </div>


              {dataArray?.length > 0 && (
                <div className="d-flex flex-wrap align-items-center justify-content-end row m-1 p-2 bg-white">

                  <div className="col-12 col-md-2 p-1">
                    <YsecButton className='btnn w-100 text-nowrap' onClick={handleSaveDraft}>Save as Draft</YsecButton>
                  </div>
                  <div className="col-12 col-md-2 p-1">
                    <YsecButton className='btnn w-100' onClick={handleSave}>Submit</YsecButton>
                  </div>
                </div>
              )}
            </div>}
            </>
           :
          <>
            <div className='d-flex justify-content-center mt-5'>
            <div class="alert alert-danger evalumsg" role="alert">
              No Members to Evaluate now.
            </div>
            </div>
          </>} 
        </div>

        {openModel && (
          <Modal
            show={openModel}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            centered
          >
            <Modal.Header>

              <button type="button" className="btn-close" onClick={handleOpenModel} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
              <h6 className='deleteleave'>This is the final submission. Once submitted cannot be reverted back. Are you sure to submit?</h6>
            </Modal.Body>
            <Modal.Footer>

              <YsecButton type="button" onClick={handleOpenModel} className='cancel'>Cancel</YsecButton>

              <YsecButton type="button" className="confirm" onClick={handleSave2}>Confirm</YsecButton>

            </Modal.Footer>

          </Modal>
        )}
      </React.Suspense>

    </div>
  )
}
export default MemberEvolution