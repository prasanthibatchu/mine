import React, { useEffect, useRef, useState } from "react";
import { Breadcrumb, Col, Row } from "react-bootstrap";
import { DataType, Table } from "ka-table";
import AxiosLayout from "../../apis/axios";
import "./EmployeeScore.scss";
import { CSVLink } from 'react-csv';
import LoadingSpinner from "../Loader/Loader";
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

function MonthEvalReport() {
    const userId = JSON.parse(localStorage.getItem("_user"));
    const [departments, setDepartments] = useState([]);
    const [selectedDepartment, setSelectedDepartment] = useState("");
    const [selectedFromMonth, setSelectedFromMonth] = useState("");
    const [selectedToMonth, setSelectedToMonth] = useState("");
    const [allTablesData, setAllTablesData] = useState([]);
    const [selectedDepartmentName, setSelectedDepartmentName] = useState("");
    const [searchText, setSearchText] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const printRef = useRef();
    const [errorMessage, setErrorMessage] = useState('');
    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getDepts()
    }, []);
    const getDepts = () => {
        setLoading(true)
        AxiosLayout.get(`/Performance/GetDepartments?CompanyId=${userId?.companyId}&UserId=${userId.user}`).then((res) => {
            if (res.data) setDepartments(res.data);
            setLoading(false)
        });
    }

    const getData = () => {
        if (selectedDepartment === "") {
            setErrorMessage("Select Department")
        }
        else if (selectedFromMonth === "") {
            setErrorMessage("Select From Month")
        }
        else if (selectedToMonth === "") {
            setErrorMessage("Select To Month")
        }
        else {
            const frommonth = `${selectedFromMonth}-01`;
            const tomonth = `${selectedToMonth}-01`;
            setLoading(true)
            AxiosLayout.get(
                `/Performance/GetDeptScoreReport?DeptId=${selectedDepartment}&FromMonth=${frommonth}&ToMonth=${tomonth}&Userid=${userId.user}`).then((res) => {
                    if (res.data) {
                        const dataa = [...res.data.Table1].sort((a, b) => new Date(a.MonthDate) - new Date(b.MonthDate));

                        // Grouping data by MonthDate
                        const groupedData = res.data.Table.map((meta) => ({
                            month: new Date(meta.MonthDate).toLocaleString("default", { month: "long", year: "numeric" }),
                            createdBy: meta.CreatedBy,
                            createdDate: new Date(meta.CreatedDate).toLocaleString(),
                            evaluations: dataa.filter((i) => i.MonthDate === meta.MonthDate),
                        }));

                        setAllTablesData(groupedData);
                        setLoading(false)
                    }
                });
        }
    };

    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const columns = [
        { key: 'MonthDate', title: 'Month', dataType: DataType.String, visible: false, },
        { key: "RowNo", title: "No", dataType: DataType.String, width: 80, },
        { key: "EmployeeId", title: "Employee Id", dataType: DataType.String, width: 80, },
        { key: "DOE", title: "DOE", dataType: DataType.String, width: 80, },
        { key: "FullName", title: "Staff Name", dataType: DataType.String, width: 80, },
        { key: "JobTitle", title: "Job Title", dataType: DataType.String, width: 80, },
        { key: "Score", title: "Evaluation Score (%)", dataType: DataType.String, width: 80, },
        { key: "Remarks", title: "Additional Remarks (explanatory)", dataType: DataType.String, width: 80, },
        { key: "LeaveRemarks", title: "HR Leave Remarks", dataType: DataType.String, width: 80, },
        { key: "WLRemarks", title: "HR Warning Letter Remarks", dataType: DataType.String, width: 80, },
        { key: "LMRemarks", title: "HR Late Minute Remarks", dataType: DataType.String, width: 80, },
        { key: "OtherRemarks", title: "HR Other Remarks", dataType: DataType.String, width: 80, },
        { key: "CreatedDate", title: "Submit Date", dataType: DataType.String, visible: false },
        { key: "CreatedBy", title: "Submit By", dataType: DataType.String, visible: false },

    ]
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Monthly Evaluation Output Report</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {errorMessage && (
                    <div class="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className="header d-flex row flex-wrap">
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Performance</Breadcrumb.Item>
                            <Breadcrumb.Item active>Monthly Evaluation Output Report</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm history`}>
                            <YsecFont className="yf-clock" onClick={() => {
                                setSelectedDepartment("")
                                setSelectedDepartmentName("")
                                setSelectedFromMonth("")
                                setSelectedToMonth("")
                                setSearchText("")
                                setAllTablesData([])
                                getDepts()
                            }} />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className="member_container">
                    <Row className="m-1 p-2 bg-white">
                        <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                            <YsecSelect
                                objectNameKey="groupName"
                                objectValueKey="groupId"
                                data={[
                                    { groupId: "", groupName: "Select" },
                                    ...departments.map((i) => ({
                                        groupId: i.DepartmentID,
                                        groupName: i.DepartmentName,
                                    })),
                                ]}
                                onChange={(e) => {
                                    const selectedGroupId = e.target.value;
                                    setSelectedDepartment(selectedGroupId);
                                    const selectedDept = departments.find((dept) => dept.DepartmentID === Number(selectedGroupId));
                                    setSelectedDepartmentName(selectedDept ? selectedDept.DepartmentName : "");
                                }}
                            />
                        </Col>
                        <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                            <Row>
                                <Col xs={4}>
                                    <label className="text-nowrap">From Month:&nbsp;</label>
                                </Col>
                                <Col xs={8}>
                                    <input
                                        type="month"
                                        placeholder="YYYY-MM"
                                        onChange={(e) => setSelectedFromMonth(e.target.value)}
                                        value={selectedFromMonth}
                                        className="w-100"
                                    />
                                </Col>
                            </Row>
                        </Col>
                        <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                            <Row>
                                <Col xs={4}>
                                    <label className="text-nowrap">To Month:&nbsp;</label>
                                </Col>
                                <Col xs={8}>
                                    <input
                                        type="month"
                                        placeholder="YYYY-MM"
                                        onChange={(e) => setSelectedToMonth(e.target.value)}
                                        value={selectedToMonth}
                                        className="w-100"
                                    />
                                </Col>
                            </Row>
                        </Col>
                        <Col xs={12} sm={6} lg={1} className="mt-1 mb-1">
                            <YsecButton className="btnn w-100" onClick={getData}>
                                Submit
                            </YsecButton>
                        </Col>
                        <Col xs={12} sm={6} lg={1} className=' mt-1 mb-1 csv'>

                            <CSVLink className="btnn csvbtn w-100"
                                data={allTablesData.flatMap(group => group.evaluations)}
                                headers={columns.map(c => ({ label: c.title, key: c.key }))}
                                filename='MonthlyEvaluationReport.csv'
                                enclosingCharacter={''}
                                separator={';'}>
                                Export
                            </CSVLink>
                            {/* <YsecButton className='btnn w-100' onClick={() => exportClick()}>Export</YsecButton> */}
                        </Col>
                        <Col xs={12} sm={6} lg={2} className=' mt-1 mb-1'>
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} /></Col>
                    </Row>


                    <div id="printable-table" className="katable" ref={printRef}>
                        {allTablesData.length > 0 && (
                            <div className="tablebody">
                                <Table columns={columns} data={[]} rowKeyField={"RowNo"} />
                            </div>
                        )}
                        {allTablesData.map((group, index) => (
                            <div key={index}>
                                <span className="table-month">
                                    {selectedDepartmentName} - {group.month}
                                </span>

                                <div className="table3">
                                    <Table columns={columns} data={group.evaluations} rowKeyField={"RowNo"} searchText={searchText}
                                        noData={{
                                            text: 'No Data Found'
                                        }} />
                                </div>
                                <div>
                                    <p className="tab-footer">{selectedDepartmentName}</p>
                                    <p className="tab-footer">Score entered by:{group.createdBy}</p>
                                    <p className="tab-footer">Submitted on:{group.createdDate}</p>


                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </React.Suspense>
        </div>
    );
}

export default MonthEvalReport;
