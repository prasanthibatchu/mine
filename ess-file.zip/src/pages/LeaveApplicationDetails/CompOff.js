import React, { useEffect, useState } from 'react'
import AxiosLayout from '../../apis/axios'
import './leaveApplication.scss';
import { Breadcrumb, Col, Modal, Row } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import LoadingSpinner from '../Loader/Loader';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

function CompOff(props) {
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [holidayList, setHolidayList] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  // const [alertMessage, setAlertMessage] = useState('At least 8 hours work time required to apply compoff');
  const [alertMessage, setAlertMessage] = useState('');
  const today = new Date();
  const currentDate = today.toISOString().split('T')[0];
  const [fromDate, setFromDate] = useState("")
  const [toDate, setToDate] = useState("")
  const [workedTime, setWorkedTime] = useState("")
  const [days, setDays] = useState("")
  const [desc, setDesc] = useState("")
  const [err, setErr] = useState(0)
  const history = useNavigate()


  useEffect(() => {
    if (fromDate !== "" && toDate !== "") {

      AxiosLayout.get(`/ComboOff/GetWorkTime?EmployeeId=${userId?.user}&Fromdate=${fromDate?.split("/")[2] + "-" + fromDate?.split("/")[1] + "-" + fromDate?.split("/")[0]}&ToDate=${toDate?.split("/")[2] + "-" + toDate?.split("/")[1] + "-" + toDate?.split("/")[0]}`).then((res) => {
        if (res.status === 200) {
          setWorkedTime(res.data.Table[0]?.WorkTime)
          setDays(res.data?.Table[0]?.Days)
           
        }
      })
    }
  }, [fromDate, toDate])
  if (error) return <p>Error: {error}</p>;


  const handleClear = () => {
    setFromDate("")
    setToDate("")
    setWorkedTime("")
    setDays("")
    setDesc("")
    props.handleOpen()
  }
  function parseTimeToMinutes(timeString) {
  if (!timeString) return 0;
  const [hours, minutes] = timeString.split(':').map(Number);
  return (hours * 60) + (minutes || 0);
}

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErr(0)
    if (fromDate === "") {

      setErr(1)
    }
    else if (toDate === "") {
      setErr(2)
    }
    else if (desc === "") {
      setErr(3)
    }
    else if (!workedTime || workedTime.trim() === "") {
    setAlertMessage('Work time is required to apply compoff');
  }
   else if (parseTimeToMinutes(workedTime) <= 479) {
    setAlertMessage('At least 8 hours work time required to apply compoff');
  }
   else if (Number(days) < 1) {
  setAlertMessage('At least one Day to apply compoff')
}
    else {

      const data = {
        comboId: 0,
        employeeId: userId?.user,
        employeeName: userId?.userName,
        leaveTypeId: 115,
        leaveType: "COF",
        applyDate: currentDate,
        fromDate: fromDate?.split("/")[2] + "-" + fromDate?.split("/")[1] + "-" + fromDate?.split("/")[0],
        toDate: toDate?.split("/")[2] + "-" + toDate?.split("/")[1] + "-" + toDate?.split("/")[0],
        hours: Number(workedTime?.split(":")[0])+"."+Number(workedTime?.split(":")[1]),
        timeDesc:workedTime,
        remarks: desc,
        days: Number(days),
        halfDayType: 0,
        approvalStatus: "Open",
        status: true,
        editable: true
      }
      await AxiosLayout.post("/ComboOff/ApplyComboOff", data).then((res) => {
        if (res.data.Status === 1) {
          setFromDate("")
          setToDate("")
          setWorkedTime("")
          setDays("")
          setDesc("")
          props?.getData()
          props.handleOpen()
        }
      })
    }
  }
  return (
    <Modal
      {...props}
      size="xl"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header>

        <p className="modal-title" id="exampleModalLabel">Apply Compoff</p>
        <button type="button" className="btn-close" onClick={props.handleOpen} aria-label="Close"></button>
      </Modal.Header>
      <Modal.Body>


        <div className='container bg-white p-3 '>

          {alertMessage && (
            <div className="alert alert-danger" role="alert">
              {alertMessage}
            </div>
          )}

          <Row>

            <Col xs={12} md={6}>
              <YsecDatePicker
                name="fromDate"
                error="test message"
                onChange={(e) => setFromDate(e.target.value)}
                value={fromDate}
                placeholder="YYYY-MM-DD"
                ysecMinDate="100_Y"
                ysecMaxDate="0_D"
                ysecType="tab"
                ysecFormat="YYYY-MM-DD"
                wrapperClass
                multipleSelect={false}
                label="From Date"
                mandatory
              />
              {err === 1 && <label className='error'>Please Select From Date...</label>}
            </Col>
            <Col xs={12} md={6}>
              <YsecDatePicker
                name="toDate"
                error="test message"
                onChange={(e) => setToDate(e.target.value)}
                value={toDate}
                placeholder="YYYY-MM-DD"
                ysecMinDate="100_Y"
                ysecMaxDate="0_D"
                ysecType="tab"
                ysecFormat="YYYY-MM-DD"
                wrapperClass
                multipleSelect={false}
                label="To Date"
                mandatory
              />
              {err === 2 && <label className='error'>Please To From Date...</label>}
            </Col>
            <Col xs={6}>
              <YsecInput name="workedTime" value={workedTime} label="Worked Time" disabled className="inputstyle" />
            </Col>
            <Col xs={6}>
              <YsecInput name="days" value={days} label="Days" disabled className="inputstyle" />
            </Col>
            <Col xs={12}>
              <YsecTextarea name="desc" value={desc} label="Description" onChange={(e) => setDesc(e.target.value)} mandatory />
              {err === 3 && <label className='error'>Please Enter Description...</label>}
            </Col>
          </Row>
        </div>
      </Modal.Body>
      <Modal.Footer>

        <YsecButton type="button" onClick={handleClear} className="cancel">Cancel</YsecButton>


        <YsecButton type="button" onClick={handleSubmit}>Submit</YsecButton>
      </Modal.Footer>
    </Modal>
  )
}

export default CompOff