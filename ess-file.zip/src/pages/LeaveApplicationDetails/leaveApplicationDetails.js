import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AxiosLayout from '../../apis/axios';
// import { setLeaveDetails } from '../../redux/feature/LeaveApplcationSlice';
import './leaveApplication.scss';
import { DataType, Table, useTableInstance } from 'ka-table';
import ApplyLeave from './ApplyLeave';
import Modal from 'react-bootstrap/Modal';
import { Breadcrumb } from 'react-bootstrap';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value?.split(" ")[0] === "Rejected" && 'rejected') || (value?.split(" ")[0] === "Open" && "open") || value?.split(" ")[0] === "Cancelled" && "cancelled" || value?.split(" ")[0] === "Approved" && 'approved' || value?.split(" ")[0] === "InProgress" && "open"}
        >
            {value}
        </div>
    );
};

function LeaveApplicationDetails() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [open, setOpen] = useState(false);
    const [leaveTypes, setLeaveTypes] = useState([]);
    // const [selectedLeaveTypeId, setSelectedLeaveTypeId] = useState(null);
    const [selectedLeaveTypeId, setSelectedLeaveTypeId] = useState("");

    const [leaveDetails, setLeaveDetails] = useState([])
    const [reason, setReason] = useState('');
    const [searchText, setSearchText] = useState('');
    const [openDeletLeave, setOpenDeletLeave] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20); // Default items per page
    const [leaveId, setLeaveId] = useState('')
    const [alertMessage, setAlertMessage] = useState('');
    const printRef = useRef();

    const handleOpen = () => setOpen(!open);
    const handleOpenDeleteLeave = () => setOpenDeletLeave(!openDeletLeave);
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage(''); // Clear the alert message after 5 seconds
            }, 1000);

            // Cleanup the timer on component unmount or when alertMessage changes
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);
    useEffect(() => {
        const timer = setTimeout(() => {
            getLeaveTyypes()
            fetchLeaveDetails()
        }, 100);
        return () => clearTimeout(timer);
    }, []);

    const getLeaveTyypes = () => {


        AxiosLayout.get(`/Leave/GetLeaveTypes?CompanyId=${userId?.companyId}&UserId=${userId?.user}`
        ).then((res) => {
            setLeaveTypes(res.data);
        });
    }
    const fetchLeaveDetails = async () => {
        setLoading(true);
        try {
            const response = await AxiosLayout.get(
                `/Leave/GetEmployeeLeaves?EmpId=${userId?.user}&CompanyId=${userId?.companyId}`
            );

            setLeaveDetails(response?.data)
            setLoading(false);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };
    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;



    const dataArray = leaveDetails.map(leave => ({
        employeeId: leave.EmployeeId,
        emp_name: leave.EmployeeName,
        leave_type: leave.LeaveTypeDesc,
        apply_date: leave.ApplyDate,
        from_date: leave.FromDate,
        to_date: leave.ToDate,
        hours: leave.Hours,
        days: leave.Days,
        reason: leave.Reason,
        remark: leave.Remark,
        leaveTypeId: leave.LeaveTypeId,
        status: leave.ApprovalStatus,
        id: leave.LeaveId
    }));

    const Allactions = ({ dispatch, rowKeyValue, approvalStatus }) => {
        const isDisabled = approvalStatus === "Open";
        return (
            <>
                <YsecFont className={`yf-delete-bin-2 ${isDisabled ? 'action-icon' : 'no-action'}`} onClick={() => {
                    if (isDisabled) {
                        const deleteData = leaveDetails.filter(i => i.LeaveId == rowKeyValue);
                        setLeaveId(deleteData[0].LeaveId);
                        setReason(deleteData[0].Reason);
                        handleOpenDeleteLeave()
                    };
                }} />

            </>
        );
    };


    const filteredData = dataArray.filter((item) => {
        const searchLower = searchText.toLowerCase();

        const matchesLeaveType = selectedLeaveTypeId === "" || item.leaveTypeId === Number(selectedLeaveTypeId);

        const matchesSearchText = (
            item.employeeId.toString().toLowerCase().includes(searchLower) ||
            item.emp_name.toLowerCase().includes(searchLower) ||
            item.leave_type.toLowerCase().includes(searchLower) ||
            item.apply_date.toLowerCase().includes(searchLower) ||
            item.from_date.toLowerCase().includes(searchLower) ||
            item.to_date.toLowerCase().includes(searchLower) ||
            item.hours.toString().toLowerCase().includes(searchLower) ||
            item.days.toString().toLowerCase().includes(searchLower) ||
            item.remark.toLowerCase().includes(searchLower) ||
            item.status.toLowerCase().includes(searchLower) ||
            item.reason.toLowerCase().includes(searchLower)
        );

        return matchesLeaveType && matchesSearchText;
    });
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = filteredData;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = filteredData.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);


    const handleCancelLeave = async (e) => {
        e.preventDefault();

        const data = {

            "leaveId": Number(leaveId),
            "employeeId": userId?.user,
            "acceptedBy": userId?.user,
            "companyId": userId?.companyId,
            "statusId": 7,
            "reason": reason,
            UserId: userId.user
        };
        await AxiosLayout.post(`/Leave/CancelLeave`, data).then((res) => {
            if (res.data.Status === 1) {
                setAlertMessage(res.data.Message)
                handleOpenDeleteLeave();
                setSearchText("")
                fetchLeaveDetails()
            } else {

                handleOpenDeleteLeave();


            }
        });
    }
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Leave Applications</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div class="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Leave Application Details</Breadcrumb.Item>
                            <Breadcrumb.Item active>Leave Applications</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm btn leave ${open === false ? "btn-outline-primary" : "history"} `} onClick={handleOpen}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <ysecButton type="button" className={`sm  ${open === true ? "btn-outline-primary" : "history"}`} onClick={() => {
                            setLeaveTypes([])
                            setSelectedLeaveTypeId("")
                            setSearchText("")
                            fetchLeaveDetails()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>

                </div>

                {open && (
                    <ApplyLeave show={open} handleOpen={handleOpen} fetchLeaveDetails={fetchLeaveDetails} setAlertMessage={setAlertMessage} setLoading={setLoading}/>
                )}
                <div className='leavecontainerr'>
                    <div class="d-flex flex-wrap row m-1 p-2 bg-white">
                        <div class="col-12 col-sm-6 col-md-8 p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>
                        <div class="col-12 col-sm-6 col-md-4  p-1">
                            <YsecSelect className="md"
                                objectNameKey="LeaveDescription"
                                objectValueKey="LeaveTypeId"
                                data={[
                                    { LeaveTypeId: "", LeaveDescription: "Select Leave Type" },
                                    ...leaveTypes.map(leave => ({
                                        LeaveTypeId: leave.LeaveTypeId,
                                        LeaveDescription: leave.LeaveDescription
                                    }))
                                ]}
                                value={selectedLeaveTypeId}
                                onChange={(e) => setSelectedLeaveTypeId(e.target.value)}
                            />
                        </div>
                    </div>
                    <div className='katable' ref={printRef}>
                        <table >
                            <tr>
                                <th>Employee Id</th>
                                <th>Employee Name</th>
                                <th>Leave Type</th>
                                <th>Applied Date</th>
                                <th>From Date</th>
                                <th>To Date</th>
                                <th>Hours</th>
                                <th>Days</th>
                                <th>Remarks</th>
                                <th>Approval Status</th>
                                <th>Reason</th>
                                <th>Action</th>
                            </tr>

                            {paginatedData?.length > 0 ? <>{paginatedData.map((item, index) => (
                                <tr key={index}>
                                    <td>{item.employeeId}</td>
                                    <td>{item.emp_name}</td>
                                    <td>{item.leave_type}</td>
                                    <td>{item.apply_date}</td>
                                    <td>{item.from_date}</td>
                                    <td>{item.to_date}</td>
                                    <td>{item.hours}</td>
                                    <td>{item.days}</td>
                                    <td>{item.remark}</td>
                                    <td><CustomCell value={item.status} /></td>
                                    <td>{item.reason}</td>
                                    <td><Allactions rowKeyValue={item.id} approvalStatus={item.status} /></td>
                                </tr>
                            ))}</>

                                : <tr><td colSpan={12} className='text-center'>No Data Found</td></tr>}

                        </table>
                    </div>

                  

                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>

                {openDeletLeave && (
                    <Modal
                        show={openDeletLeave}
                        size="md"
                        aria-labelledby="contained-modal-title-vcenter"
                        centered
                    >
                        <Modal.Header>
                            <p className="modal-title" id="exampleModalLabel">Cancel Leave</p>
                            <button type="button" className="btn-close" onClick={handleOpenDeleteLeave} aria-label="Close"></button>
                        </Modal.Header>
                        <Modal.Body>
                            <h6 className='deleteleave'>Please confirm the selected leave details will be delete!!!</h6>
                        </Modal.Body>
                        <Modal.Footer>
                            {/* <span className='cancel'> */}
                            <YsecButton type="button" onClick={handleOpenDeleteLeave} className='cancel'>Cancel</YsecButton>
                            {/* </span> */}

                            <YsecButton type="button" className="btn-danger confirm" onClick={handleCancelLeave}>Confirm</YsecButton>

                        </Modal.Footer>

                    </Modal>
                )}



            </React.Suspense>
        </div>
    );
};

export default LeaveApplicationDetails;