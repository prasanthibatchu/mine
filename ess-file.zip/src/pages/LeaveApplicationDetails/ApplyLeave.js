import React, { useEffect, useState } from 'react'
import Modal from 'react-bootstrap/Modal';
import Button from 'react-bootstrap/Button';
import AxiosLayout from '../../apis/axios';
import { DataType, Table, useTableInstance } from 'ka-table';
import { toast, ToastContainer } from 'react-toastify';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const ApplyLeave = (props) => {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [selectedLeaveTypeId, setSelectedLeaveTypeId] = useState(null);
    const [leaveBalance, setLeaveBalance] = useState([]);
    const [holidayList, setHolidayList] = useState([]);
    const today = new Date();
    const currentDate = today.toISOString().split('T')[0];
    const [leaveTypes, setLeaveTypes] = useState([]);
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState('');
    const [workingDays, setWorkingDays] = useState(0);
    const [selectedValue, setSelectedValue] = useState('');
    const [curLeaveBlnce, setCurLeaveBlnce] = useState([]);
    const [reason, setReason] = useState('');
    const [hours, setHours] = useState(0);
    const [err, setErr] = useState(0)
    const [alertMessage, setAlertMessage] = useState('');
    
    useEffect(() => {
        props?.setLoading(true)
        AxiosLayout.get(`/Leave/GetLeaveTypes?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
            setLeaveTypes(res.data);
        });
        AxiosLayout.get(`/Leave/GetLeaveBalance?CompanyId=${userId?.companyId}&EmployeeId=${userId?.user}`).then((res) => {
            setCurLeaveBlnce(res.data.Table);
            setLeaveBalance(res.data.Table1);
            setHolidayList(res.data.Table2);
        });
        props?.setLoading(false)
    }, []);

useEffect(()=>{
    if(selectedLeaveTypeId !==null){
    setFromDate(currentDate)
    setToDate(currentDate)
    calculateWorkingDays(currentDate,currentDate)
    }
},[selectedLeaveTypeId])

    const onChangeFun = (e) => {
        const dateRange = e.target.value;

        if (dateRange) {
            const dates = dateRange.split(' to ');
            if (dates.length === 2) {
                const startDate = dates[0].trim();
                const endDate = dates[1].trim();
                const formattedStartDate = startDate.split('/').reverse().join('-');
                const formattedEndDate = endDate.split('/').reverse().join('-');
                setFromDate(formattedStartDate);
                setToDate(formattedEndDate);
                calculateWorkingDays(formattedStartDate, formattedEndDate);
            } else {
                console.error('Invalid date range format. Please use "DD/MM/YYYY to DD/MM/YYYY".');
            }
        }
    };

    const onChangeSelectedRadioFun = (e) => {
        setSelectedValue(e.target.value);
        const calculatedHours = e.target.value * 8;
        setHours(calculatedHours);
    };

    const calculateWorkingDays = (formattedStartDate, formattedEndDate) => {
        const start = new Date(formattedStartDate);
        const end = new Date(formattedEndDate);
        let totalWorkingDays = 0;
        if (start > end) return;

        for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
            const dayOfWeek = date.getDay();
            const formattedDate = date.toISOString().split('T')[0];

            if (dayOfWeek === 0 || dayOfWeek === 6) continue;

            const isHoliday = holidayList?.some(holiday => holiday?.HolidayDate === formattedDate);
            if (isHoliday) continue;

            totalWorkingDays++;
        }
        setWorkingDays(totalWorkingDays);
        setSelectedValue(totalWorkingDays.toString())
        const calculatedHours = totalWorkingDays * 8;
        setHours(calculatedHours);

    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        setErr(0)
        if (selectedLeaveTypeId === null) {
            setErr(1)
        }
        else if (fromDate === "") {
            setErr(2)
        }
        else if (toDate === "") {
            setErr(2)
        }
        else if (selectedValue === "") {
            setErr(3)
        } else if (reason === "") {
            setErr(4)
        } else {
            const data = {
                "leaveId": 0,
                "employeeId": userId?.user,
                "leaveTypeId": selectedLeaveTypeId,
                "applyDate": currentDate,
                "fromDate": fromDate,
                "toDate": toDate,
                "days": selectedValue,
                "hours": hours,
                "remark": reason,
                "isActive": true,
                "employeeName": "string",
                "leaveTypeDesc": "string",
                "approvalStatus": "string",
                "approvedDate": "2024-11-20T08:16:01.869Z",
                "companyId": userId?.companyId,
                "file": "string",
                "reason": ""
            };
            await AxiosLayout.post(`/Leave/ApplyLeaves`, data).then((res) => {
                if (res.data.Status === 1) {
                    setSelectedLeaveTypeId(null);
                    setSelectedValue('');
                    setReason('');

                    props.handleOpen();
                    props.fetchLeaveDetails()
                    props.setAlertMessage(res.data.Message)
                } else {
                    setAlertMessage(res.data.Message);

                }
            });
        }
    };

    const leaveBalanceArray = leaveBalance.map((i) => ({
        Description: i.Description,
        BalanceLeave: i.BalanceLeave,
        EligbleDays: i.EligbleDays,
        ApprovalPending: i.ApprovalPending,
    }));

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage(''); // Clear the alert message after 5 seconds
            }, 1000);

            // Cleanup the timer on component unmount or when alertMessage changes
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);
    return (
        <Modal
            {...props}
            size="xl"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header>
           
                <p className="modal-title" id="exampleModalLabel">Leave Application Details</p>
                <button type="button" className="btn-close" onClick={props.handleOpen} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <p className='leaveblnce'>Current Leave Balance : {curLeaveBlnce[0]?.currentLeaveBalance}</p>
                {userId?.companyId==78 &&
                <div className='table'>
                    {leaveBalance.length !== 0 && <Table
                        columns={[
                            { key: "Description", title: "Description", dataType: DataType.String },
                            { key: "BalanceLeave", title: "Balance leave", dataType: DataType.String },
                            { key: "EligbleDays", title: "Eligible Days", dataType: DataType.String },
                            { key: "ApprovalPending", title: "Approval Pending", dataType: DataType.String },
                        ]}
                        data={leaveBalanceArray}
                        rowKeyField='id'
                        childComponents={{
                            cellText: {
                                content: (props) => { },
                            },
                        }}
                    />}
                </div>}
                <h6 className={`${userId?.companyId !==78 && 'mt-5 p-0'}`}>Apply Leaves</h6>
                <hr />
                <div className="applyleaves">
                {alertMessage && (
                <div className="alert alert-danger" role="alert">
                    {alertMessage}
                </div>
            )}


                    <div className='fieds'>
                        <YsecSelect label="Leave Type" mandatory
                            className="select"
                            objectNameKey="LeaveDescription"
                            objectValueKey="LeaveTypeId"
                            data={[
                                { LeaveTypeId: "", LeaveDescription: "Select Leave Type" },
                                ...leaveTypes.map(leave => ({
                                    LeaveTypeId: leave.LeaveTypeId,
                                    LeaveDescription: leave.LeaveDescription
                                }))
                            ]}
                            onChange={(e) => setSelectedLeaveTypeId(e.target.value)}
                        />
                    </div>
                    {err === 1 && <label className='error'>Please Select Leave...</label>}
                    <div className='datePickandradio fieds'>
                        <div className='datepick'>
                            {Number(selectedLeaveTypeId)===113 &&
                            <YsecDatePicker
                                label="Select Date Range"
                                mandatory="true"
                                error="test message"
                                onChange={onChangeFun}
                                value={fromDate === "" ? "" : [fromDate, toDate]}
                                placeholder="YYYY-MM-DD"
                                ysecMinDate="1_D"
                                ysecMaxDate= "0_D"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-DD"
                                wrapperClass
                                multipleSelect={true}

                            />}
                             {Number(selectedLeaveTypeId)!==113 &&<YsecDatePicker
                            label="Select Date Range"
                            mandatory="true"
                            error="test message"
                            onChange={onChangeFun}
                            value={fromDate === "" ? "" : [fromDate, toDate]}
                            placeholder="YYYY-MM-DD"
                            ysecMinDate="1_D"
                            ysecMaxDate="1_Y"
                            ysecType="tab"
                            ysecFormat="YYYY-MM-DD"
                            wrapperClass
                            multipleSelect={true}

                        />} 
                        </div>

                        <div>
                            <div>
                                <label className='labelofday'>No. of Days:</label>
                            </div>
                            {(fromDate !== "" && toDate !== "") &&
                                <>
                                    <div className='radio'>
                                        <YsecRadio
                                            label={workingDays?.toString()}
                                            name="leaveValue"
                                            id="leaveValue1"
                                            value={workingDays?.toString()}
                                            checked={selectedValue === workingDays?.toString()}
                                            onChange={onChangeSelectedRadioFun}
                                        />
                                        <YsecRadio
                                            label={(workingDays - 0.5)?.toString()}
                                            name="leaveValue"
                                            id="leaveValue2"
                                            value={(workingDays - 0.5)?.toString()}
                                            checked={selectedValue === (workingDays - 0.5)?.toString()}
                                            onChange={onChangeSelectedRadioFun}
                                        />
                                    </div>
                                    {err === 3 && <label className='error'>Please Select Number of days...</label>}
                                </>}
                        </div>
                    </div>
                    {err === 2 && <label className='error'>Please Select From - To Date...</label>}


                    <div className='fieds'>
                        <YsecTextarea label="Description"
                            mandatory="true"
                            error="test message"
                            className="lg"
                            id="testID"
                            name="reason"
                            value={reason}
                            onChange={(e) => setReason(e.target.value)}
                            placeholder="Enter Reason"
                        />
                        {err === 4 && <label className='error'>Please Enter Reason...</label>}

                    </div>
                </div>
                <ToastContainer autoClose={2000} />
            </Modal.Body>
            <Modal.Footer>
                {/* <span className='cancel'> */}
                    <YsecButton type="button"  onClick={props.handleOpen} className="cancel">Cancel</YsecButton>
                {/* </span> */}

                <YsecButton type="button"  onClick={handleSubmit}>Submit</YsecButton>

            </Modal.Footer>

        </Modal>
    )
}
export default ApplyLeave;

