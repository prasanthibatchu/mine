import React, { useEffect, useRef, useState } from 'react'
import './AdvanceApprovals.scss'
import { Breadcrumb, Button, Modal, Overlay, Tooltip } from 'react-bootstrap';
import { DataType, Table, } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import ViewAdvanceData from '../StaffAdvanceRequest/ViewAdvanceData';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox"))


function AdvanceApprovals() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [searchText, setSearchText] = useState('');
    const [selectedRows, setSelectedRows] = useState(new Set());
    const [currentRowKey, setCurrentRowKey] = useState(null);
    const [currentType, setCurrentType] = useState(null);
    const [openViewData, setOpenViewData] = useState(false)
    const [viewData, setViewData] = useState([])
    const [bulApproveModel, setBulkApproveModel] = useState(false)
    const [bulkCancelModel, setBulkCancelModel] = useState(false)
    const [bulkType, setBulkType] = useState("")
    const [approveData, setApproveData] = useState([])
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);
    const [singleData, setSingleData] = useState([])
    const printRef = useRef();
    const handleBulkApproveModel = () => {
        setBulkApproveModel(!bulApproveModel)
    }
    const handleBulkCancelModel = () => {
        setBulkCancelModel(!bulkCancelModel)
    }
    const handleOpenViewData = () => setOpenViewData(!openViewData);
    useEffect(() => {
        getApprovalsData()
    }, [])
    const getApprovalsData = () => {
        setLoading(true);
        try {


            AxiosLayout.get(`/Advance/GetAllAdvanceApprovalDetails?EmployeeId=${userId?.user}&CompanyId=${userId?.companyId}`).then((response) => {
                if (response.status === 200) {
                    setApproveData(response?.data)
                }
            })

        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    }

    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const dataArray = approveData?.map(
        (i, index) => ({
            EmployeeId: i?.EmployeeId,
            FullName: i?.FullName,
            Currency: i?.Currency,
            Date: i?.Date,
            Amount: i?.Amount,
            Remark: i?.Remark,
            PaybackCount: i?.PaybackCount,

            id: i.AdvanceId,
        }),
    );
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

    const handleCheckboxChange = (rowKeyValue) => {
        const newSelectedRows = new Set(selectedRows);
        if (newSelectedRows.has(rowKeyValue)) {
            newSelectedRows.delete(rowKeyValue);
        } else {
            newSelectedRows.add(rowKeyValue);
        }
        setSelectedRows(newSelectedRows);
    };
    const SelectCheck = ({ rowKeyValue, selectedRows, onCheckboxChange }) => {
        const isChecked = selectedRows.has(rowKeyValue);
        return (
            <>
                <YsecCheckbox checked={isChecked}
                    onChange={() => onCheckboxChange(rowKeyValue)} />

            </>
        )
    }


    const ViewAction = ({ dispatch, rowKeyValue }) => {
        const data = approveData.find(i => i.AdvanceId == rowKeyValue)

        return (
            <>
                <Button size="sm" variant="link" className='history'
                    onClick={() => {
                        const empId = data?.EmployeeId
                        setSingleData(data)
                        viewAdvanceRequestById(empId, rowKeyValue)
                    }}
                >View</Button>
            </>
        )
    }
    const viewAdvanceRequestById = (empId, id) => {

        AxiosLayout.get(`/Advance/GetEMIDetailsByAdvanceId?EmployeeId=${empId}&AdvanceId=${Number(id)}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setViewData(res.data)
                setOpenViewData(true)
            }

        }
        )
        // 
    }


    const handleBulkApproveSubmit = async () => {
        const selectedRequests = Array.from(selectedRows).map(rowKeyValue => {
            const data = approveData.find(leave => leave.AdvanceId === rowKeyValue);
            return {
                leaveId: data?.AdvanceId,
                employeeId: data?.EmployeeId
            };
        });

        const data = {
            advanceIds: selectedRequests,
            userId: userId?.user,
            companyId: userId?.companyId,
        }
        await AxiosLayout.post(`/Advance/BulkAdvanceApproval`, data).then((res) => {
            getApprovalsData()
            handleBulkApproveModel();
        });



    };


    const Approveaction = ({ rowKey, currentRowKey, currentType, setCurrentRowKey, setCurrentType, type }) => {
        const show = rowKey === currentRowKey && type === currentType;
        const tooltipRef = useRef(null); // Create a ref for the tooltip
        const [appReason, setAppReason] = useState("")
        const handleOpenTooltp = () => {
            if (show) {
                setCurrentRowKey(null);
                setCurrentType(null);
            } else {
                setCurrentRowKey(rowKey);
                setCurrentType(type);

            }

        }

        const data = approveData.filter(i => i.AdvanceId == rowKey);
        const leaveId = data[0]?.AdvanceId;
        const empIds = data[0]?.EmployeeId;


        return (
            <span ref={tooltipRef} className='d-flex justify-content-center'>
                <YsecButton className="sm approve" onClick={handleOpenTooltp}>
                    Approve
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${leaveId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                    <textarea name='appReason'
                                        value={appReason}
                                        onChange={(e) => setAppReason(e.target.value)}
                                        rows="3"
                                        placeholder="Remarks (Optional)"
                                    />
                                    <div className='apbtn'>
                                        <YsecButton className="sm approve" onClick={async () => {
                                            const data = {
                                                userId: userId?.user,
                                                advanceId: Number(leaveId),
                                                employeeId: Number(empIds),
                                                companyId: userId?.companyId,
                                                reason: appReason
                                            };
                                            await AxiosLayout.post(`/Advance/ApproveAdvanceApproval`, data).then((res) => {
                                                if (res.data.Status === 1) {
                                                    getApprovalsData()
                                                    setCurrentRowKey(null);
                                                    setCurrentType(null);
                                                } else {
                                                    // alert('error')
                                                    setCurrentRowKey(null);
                                                    setCurrentType(null);
                                                }
                                            });
                                        }}>Approve</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    };
    const Cancelaction = ({ rowKey, currentRowKey, currentType, setCurrentRowKey, setCurrentType, type }) => {
        const show = rowKey === currentRowKey && type === currentType;
        const tooltipRef = useRef(null); // Create a ref for the tooltip
        const [cancelReason, setCancelReason] = useState("")
        const [err, setErr] = useState(0)
        const handleOpenTooltp = () => {

            if (show) {
                setCurrentRowKey(null);
                setCurrentType(null);
            } else {
                setCurrentRowKey(rowKey);
                setCurrentType(type);
            }
        }

        const approveDataa = approveData.filter(i => i.AdvanceId == rowKey);
        const leaveId = approveDataa[0]?.AdvanceId;
        const empIds = approveDataa[0]?.EmployeeId;


        return (
            <span ref={tooltipRef} className='d-flex justify-content-center'>


                <YsecButton className="sm cancel" onClick={handleOpenTooltp}>
                    Cancel
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${leaveId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                    <textarea name='cancelReason'
                                        value={cancelReason}
                                        onChange={(e) => setCancelReason(e.target.value)}
                                        rows="3"
                                        placeholder="Reason"
                                    />
                                    {err === 1 && <div><label className='error'>Please Enter Reason...</label></div>}
                                    <div className='apbtn'>
                                        <YsecButton className="sm cancel" onClick={async () => {
                                            setErr(0)
                                            if (cancelReason === "") {
                                                setErr(1)
                                            }
                                            else {
                                                const cancelData = {

                                                    userId: userId?.user,
                                                    advanceId: Number(leaveId),
                                                    employeeId: Number(empIds),
                                                    companyId: userId?.companyId,
                                                    reason: cancelReason
                                                };

                                                await AxiosLayout.post('/Advance/CancelAdvanceApproval', cancelData).then((res) => {
                                                    if (res.data.Status === 1) {

                                                        getApprovalsData()
                                                        setCurrentRowKey(null);
                                                        setCurrentType(null);
                                                    } else {
                                                        // alert('error')
                                                        setCurrentRowKey(null);
                                                        setCurrentType(null);


                                                    }
                                                });

                                            }
                                        }}>Submit</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    };

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Advance Approval</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Approval</Breadcrumb.Item>
                            <Breadcrumb.Item active>Advance Approval</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={() => {
                            setSearchText("")
                            getApprovalsData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='advnace_container'>
                    {openViewData && (
                        <ViewAdvanceData show={openViewData} handleOpenViewData={handleOpenViewData} openViewData={openViewData} viewData={viewData} singleData={singleData} />
                    )}

                    <div class="d-flex flex-wrap  row m-1 p-2 bg-white">

                        <div class="col-12 col-md-12  p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>

                    </div>

                    <div className='katable' ref={printRef}>
                        {/* <div className='d-flex  justify-content-end'>
                            <YsecButton className="sm bulkcancel m-1" onClick={() => {
                                setBulkType("cancel")
                                handleBulkApproveModel()
                            }}>Bulk Cancel</YsecButton>
                            <YsecButton className="sm bulkbtn m-1" onClick={() => {
                                setBulkType("approve")
                                handleBulkApproveModel()
                            }}>Bulk Approve</YsecButton>

                        </div> */}
                        <Table
                            columns={[
                                { key: 'EmployeeId', title: 'Employee Id', dataType: DataType.String },
                                { key: 'FullName', title: 'Full Name', dataType: DataType.String },
                                { key: 'Currency', title: 'Currency', dataType: DataType.String },
                                { key: 'Date', title: 'Date', dataType: DataType.String },
                                { key: 'Amount', title: 'Amount', dataType: DataType.String },
                                { key: 'Remark', title: 'Remark', dataType: DataType.String },
                                { key: 'PaybackCount', title: 'Payback Count', dataType: DataType.String },
                                { key: ':action1', title: 'Payback Schedule', dataType: DataType.String },

                                { key: ':action3', title: 'Approve', dataType: DataType.String },
                                { key: ':action4', title: 'Cancel', dataType: DataType.String },
                                // { key: ':action3', title: 'Select', dataType: DataType.String }, //checkbox

                            ]}
                            data={paginatedData}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {

                                        switch (props.column.key) {
                                            case ':action1':
                                                return <ViewAction {...props}
                                                />

                                            case ':action3':
                                                return <Approveaction {...props}
                                                    type={props.column.key}
                                                    rowKey={props.rowKeyValue}
                                                    currentRowKey={currentRowKey}
                                                    currentType={currentType}
                                                    setCurrentRowKey={setCurrentRowKey}
                                                    setCurrentType={setCurrentType}
                                                // activeRowKey={activeRowKey} setActiveRowKey={setActiveRowKey} 

                                                />
                                            case ':action4':
                                                return <Cancelaction {...props}
                                                    {...props}
                                                    type={props.column.key}
                                                    rowKey={props.rowKeyValue}
                                                    currentRowKey={currentRowKey}
                                                    currentType={currentType}
                                                    setCurrentRowKey={setCurrentRowKey}
                                                    setCurrentType={setCurrentType}
                                                // activeRowKey2={activeRowKey2} setActiveRowKey2={setActiveRowKey2}
                                                />
                                            // case ':action3':
                                            //     return <SelectCheck {...props} selectedRows={selectedRows} onCheckboxChange={handleCheckboxChange} />
                                            default:
                                                return props.children;
                                        }

                                    },
                                },


                            }}
                        />
                    </div>
                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>

                {bulApproveModel === true && <Modal
                    show={bulApproveModel}
                    size="md"
                    aria-labelledby="contained-modal-title-vcenter"
                    centered
                >
                    <Modal.Header>
                        <p className="modal-title" id="exampleModalLabel">Bulk {bulkType === "approve" ? "Approve" : "Cancel"}</p>
                        <button type="button" className="btn-close" onClick={handleBulkApproveModel} aria-label="Close"></button>
                    </Modal.Header>
                    <Modal.Body>
                        <h6 className='deleteleave'>Please confirm the selected payback schedules will be bulk {bulkType === "approve" ? "approve" : "cancel"}!!!</h6>
                    </Modal.Body>
                    <Modal.Footer>
                        <span className='cancel'>
                            <YsecButton type="button" onClick={handleBulkApproveModel}>{bulkType === "approve" ? "Cancel" : "Close"}</YsecButton>
                        </span>
                        {bulkType === "approve" ?
                            <YsecButton type="button" className="btn-success" onClick={handleBulkApproveSubmit}>Approve</YsecButton>
                            :
                            <YsecButton type="button" className="btn-danger">Submit</YsecButton>
                        }
                    </Modal.Footer>

                </Modal>}


            </React.Suspense>
        </div>
    )
}

export default AdvanceApprovals;
