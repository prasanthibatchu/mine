import React, { useEffect, useRef, useState } from 'react'
import '../LeaveApprovalHistory/LeaveApprovalHistory.scss'
import { Breadcrumb } from 'react-bootstrap'
import AxiosLayout from '../../apis/axios';

import { DataType, Table, useTableInstance } from 'ka-table';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));



const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value === "Approved" && 'approved') || (value === "Rejected" && 'rejected') || (value === "Open" && "open") || (value === "Cancelled (Manager)" && 'cancelled') || (value === "Processed" && 'approved')}
        >
            {value}
        </div>
    );
};
function AdvanceApprovalHistory() {
    const [searchText, setSearchText] = useState('');
    const [approvalHistoryData, setApprovalHistoryData] = useState([])
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const printRef = useRef();
    useEffect(() => {
        getData()
    }, []);
    const getData = () => {
        setLoading(true)
        AxiosLayout.get(`/Advance/GetAdvanceHistory?EmployeeId=${userId?.user}&CompanyId=${userId?.companyId}`).then((res) => {
            setApprovalHistoryData(res.data);
            setLoading(false)
        });
    }
    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
    const dataArray = approvalHistoryData?.map(
        (i, index) => ({
            EmployeeId: i?.EmployeeId,
            FullName: i?.FullName,
            Currency: i?.Currency,
            Date: i?.Date,
            Amount: i?.Amount,
            Remark: i?.Remark,
            PaybackCount: i?.PaybackCount,
            status: i?.ApprovalStatus,
            id: i.AdvanceId,
        }),
    );


    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Advance Approval History</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className='p-1'>
             {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Approval</Breadcrumb.Item>
                            <Breadcrumb.Item active>Advance Approval History</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={() => {
                            setSearchText("")
                            getData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='leavecontainerr'>
                    <div class="d-flex flex-wrap row m-1 p-2 bg-white">

                        <div class="col-12 col-sm-12 p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>

                        <div className='katable' ref={printRef}>
                            <Table
                                columns={[
                                    { key: 'EmployeeId', title: 'Employee Id', dataType: DataType.String },
                                    { key: 'FullName', title: 'Full Name', dataType: DataType.String },
                                    { key: 'Currency', title: 'Currency', dataType: DataType.String },
                                    { key: 'Date', title: 'Date', dataType: DataType.String },
                                    { key: 'Amount', title: 'Amount', dataType: DataType.String },
                                    { key: 'Remark', title: 'Remark', dataType: DataType.String },
                                    { key: 'PaybackCount', title: 'Payback Count', dataType: DataType.String },

                                    { key: "status", title: "Approval Status", dataType: DataType.String, },

                                ]}
                                data={paginatedData}
                                rowKeyField={'id'}
                                searchText={searchText}
                                noData={{
                                    text: 'No Data Found'
                                }}
                                childComponents={{
                                    cellText: {
                                        content: (props) => {
                                            switch (props.column.key) {
                                                case 'status':
                                                    return <CustomCell  {...props} />
                                                default:
                                                    return props.children;
                                            }

                                        },
                                    },


                                }}


                            />
                        </div>

                        <div className='pagination'>
                            <span className='pageselect'>
                                <YsecSelect
                                    objectNameKey="pageDescription"
                                    objectValueKey="pageNumber"
                                    data={pageNumbers.map(number => ({
                                        pageNumber: number,
                                        pageDescription: `Page ${number.toString()}`
                                    }))}
                                    className="sm"
                                    onChange={(e) => {
                                        const selectedPage = Number(e.target.value);
                                        setCurrentPage(selectedPage);
                                    }}
                                />
                            </span>

                            <span>{startRange}-{endRange} of {totalItems}</span>
                            <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                                onClick={() => {
                                    if (currentPage > 1) {
                                        setCurrentPage(prev => prev - 1);
                                    }
                                }}
                            />
                            <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                                onClick={() => {
                                    if (currentPage < totalPages) {
                                        setCurrentPage(prev => prev + 1);
                                    }
                                }}
                            />
                        </div>
                    </div>
                </div>

            </React.Suspense>
        </div>
    )
}

export default AdvanceApprovalHistory