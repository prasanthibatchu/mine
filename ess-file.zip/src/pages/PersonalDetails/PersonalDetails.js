import React, { useEffect, useRef, useState } from 'react';
import './PersonalDetails.scss'
import AxiosLayout from '../../apis/axios';
import { Breadcrumb, Card, Col, Container, Row } from 'react-bootstrap';
import LoadingSpinner from '../Loader/Loader';


const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));

const PersonalDetails = () => {

    const userId = JSON.parse(localStorage.getItem('_user'))
    const [loading, setLoading] = useState(false);
    const [employee, setEmployee] = useState([])
    const printRef = useRef();
    useEffect(() => {
        getData()
    }, []);
    const getData = async () => {
        setLoading(true);
        await AxiosLayout.get(`/Employee/GetEmployeeDetails?UserId=${userId?.user}`).then((res) => {
            setEmployee(res.data);
            setLoading(false);
        });
    }



    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Personal Details</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div>
            {loading === true ? <LoadingSpinner show={loading} />:
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Personal Information</Breadcrumb.Item>
                            <Breadcrumb.Item active>Personal Details</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={getData}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div ref={printRef}>
                    <Row className='cards d-flex'>
                        <Col xs={12} md={9}>
                            <Row className='d-flex'>
                                <Col xs={12} md={12} className="card-spacing">
                                    <Card className="h-100">
                                        <Card.Header as="h5">Personal Information</Card.Header>
                                        <Card.Body>

                                            <Card.Text>
                                                <Row>
                                                    <Col xs={4}>Employee Id</Col>
                                                    <Col xs={8}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.EmployeeId}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Name</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Title} {employee[0]?.FullName}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Blood Group</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.BloodGroup}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Gender</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Gender}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Religion</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Religion}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Date Of Birth</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.DateOfBirth?.split(" ")[0]}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Father / husband</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Guardian}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Marital Status</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.MaritalStatus}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Nationality</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Nationality}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={4}>Govt. ID</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.IdNumber}</span></Col>
                                                </Row>
                                            </Card.Text>

                                        </Card.Body>
                                    </Card>
                                </Col>


                                <Col xs={12} md={6} className="card-spacing" >
                                    <Card className="h-100">
                                        <Card.Header as="h5">Address Details</Card.Header>
                                        <Card.Body>

                                            <Card.Text>
                                                <Row>
                                                    <Col xs={4}>Address</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Address}</span></Col>
                                                </Row>

                                                <Row>
                                                    <Col xs={4}>City / Town</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.City}</span></Col>
                                                </Row>
                                                {/* <Row>
                                            <Col xs={4}>State / Province</Col>
                                            <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Address}</span></Col>
                                        </Row> */}
                                                <Row>
                                                    <Col xs={4}>Country</Col>
                                                    <Col xs={7}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Country}</span></Col>
                                                </Row>

                                            </Card.Text>

                                        </Card.Body>
                                    </Card>
                                </Col>
                                <Col xs={12} md={6} className="card-spacing">
                                    <Card className="h-100">
                                        <Card.Header as="h5">Contact Details</Card.Header>
                                        <Card.Body>
                                            <Card.Text>
                                                <Row>
                                                    <Col xs={6}>Phone Number</Col>
                                                    <Col xs={6}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Mobile}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={6}>Emergency Contact Number</Col>
                                                    <Col xs={6}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.EmergencyContact}</span></Col>
                                                </Row>
                                                <Row>
                                                    <Col xs={6}>Email</Col>
                                                    <Col xs={6}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Email}</span></Col>
                                                </Row>
                                                {/* <Row>
                                            <Col xs={6}>Personal Email</Col>
                                            <Col xs={6}><span className='divider'>:</span><span className='empdetail'>{employee[0]?.Email}</span></Col>
                                        </Row> */}

                                            </Card.Text>

                                        </Card.Body>
                                    </Card>
                                </Col>
                            </Row>
                        </Col>
                        <Col xs={12} md={3} className="card-spacing">
                            <Card className="h-100">
                                <Card.Img variant="top" src={employee[0]?.StrEmpImg} alt={employee[0]?.FullName} />
                                <Card.Body>
                                    <Card.Text>
                                        <h6 className='name'>{employee[0]?.Title} {employee[0]?.FullName}</h6>
                                        <p className='department'>{employee[0]?.Department}</p>
                                        <p className='designation'>{employee[0]?.Position}</p>


                                    </Card.Text>

                                </Card.Body>
                            </Card>

                        </Col>
                    </Row>
                </div>

            </React.Suspense>}
        </div>


    )
};

export default PersonalDetails;


