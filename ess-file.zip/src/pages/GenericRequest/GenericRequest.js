import React, { useEffect, useRef, useState } from 'react'
import './GenericRequest.scss'
import { DataType, Table } from 'ka-table';
import NewRequest from './NewRequest';
import { Breadcrumb } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));


const CustomCell = ({ column, rowKeyValue, value }) => {

  return (
    <div>
      {column.key === 'RequestId' && <div className='requestId'>{value}</div>}
    </div>
  );
};

const GenericRequest = () => {
  const [search, setSearch] = useState('')
  const [open, setOpen] = useState(false);
  const [req_history, setReqHistory] = useState([])
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [closeData, setClosedData] = useState([])
  const [OpenData, setOpendData] = useState([])
  const [searchText, setSearchText] = useState('');
  const handleOpen = () => setOpen(!open);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);
  const [alertMessage, setAlertMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const printRef = useRef();
  useEffect(() => { getData() }, []);
  useEffect(() => {
    if (alertMessage) {
      const timer = setTimeout(() => {
        setAlertMessage(''); // Clear the alert message after 5 seconds
      }, 1000);

      // Cleanup the timer on component unmount or when alertMessage changes
      return () => clearTimeout(timer);
    }
  }, [alertMessage]);
  const getData = () => {
    setLoading(true)
    AxiosLayout.get(`/Request/GetEmployeeRequestDetails?EmployeeID=${userId?.user}`).then((res) => {
      setReqHistory(res.data);
      const dataa = res.data
      setClosedData(dataa.filter(request => request.Status === "Close"))

      setOpendData(dataa.filter(request => request.Status !== "Close"))
      setLoading(false)
    });


  }


  // if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;

  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentData = closeData;
  const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
  const totalItems = closeData.length;

  const startRange = indexOfFirstItem + 1;
  const endRange = Math.min(indexOfLastItem, totalItems);
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);
  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Generic Requests</title>');
    // Optional: Add your styles here, or link to your CSS file
    printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };

  return (
    <div className='p-1'>
      {loading === true && <LoadingSpinner show={loading} />}
      <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
        {alertMessage && (
          <div class="alert alert-success" role="alert">
            {alertMessage}
          </div>
        )}
        <div className='header d-flex row flex-wrap'>
          <div class="col">
            <Breadcrumb  >
              <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
              <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
              <Breadcrumb.Item active>Generic Request</Breadcrumb.Item>
            </Breadcrumb>
          </div>
          <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
            <YsecButton type="button" className={`sm btn leave ${open === false ? "btn-outline-primary" : "history"} `} onClick={handleOpen}>
              <YsecFont className='yf-plus-add' />
            </YsecButton>
            <ysecButton type="button" className={`sm  ${open === true ? "btn-outline-primary" : "history"}`} onClick={() => {
              setSearchText("")
              getData()
            }}>
              <YsecFont className="yf-clock" />
            </ysecButton>
            <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
              <YsecFont className="yf-printer-scan" />
            </YsecButton>
          </div>

        </div>

        <div className='containerr'>

          <div class="d-flex flex-wrap row m-1 p-2 bg-white">
            <div class="col-12 col-sm-12 p-1">
              <YsecInput placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                setSearchText(event.target.value);
              }} />
            </div>
            {/* <div class="col-12 col-sm-1  p-1">
              <YsecButton className='btnn w-100'>Submit</YsecButton>
            </div> */}
          </div>
          <div ref={printRef}>
            <div className='displaydata'>
              <div className='heading'>
                <p>New Requests</p>
              </div>
              <div className='box'>
                {OpenData.length !== 0 ? <div className='katable'>
                  <Table
                    columns={[
                      { key: "RequestId", title: "Request Id", dataType: DataType.String, },
                      { key: "FullName", title: "Employee", dataType: DataType.String, },
                      { key: "Message", title: "Request", dataType: DataType.String, },
                      { key: "RequestDate", title: "Date", dataType: DataType.String, },
                      { key: "RequestTime", title: "Time", dataType: DataType.String, },
                      { key: "FeedBack", title: "Feedback", dataType: DataType.String, },
                      { key: "RequestType", title: "Request Type", dataType: DataType.String, },
                      { key: "ApprovedBy", title: "Approved By", dataType: DataType.String, },
                      { key: "ApprovedDate", title: "Approved Date", dataType: DataType.String, },
                      { key: "Status", title: "Status", dataType: DataType.String, },

                    ]}
                    data={OpenData}
                    rowKeyField={'id'}
                    searchText={searchText}
                    noData={{
                      text: 'No Data Found'
                    }}
                    childComponents={{
                      cellText: {
                        content: (props) => {

                          switch (props.column.key) {
                            case 'RequestId': {
                              return <CustomCell {...props} RequestId={props.rowData.RequestId} />;
                            }
                            case 'FullName': {

                              return (
                                <div>
                                  {props.rowData.FullName} - {props.rowData.EmployeeId}
                                </div>
                              );
                            }

                            default:
                              return <div >{props.rowData[props.column.key]}</div>;
                          }
                        },
                      },
                    }}
                  />
                </div> : <p>No Requests to display</p>}

              </div>
            </div>
            {paginatedData.length !== 0 &&
              <div className='displaydata'>
                <div className='heading'>
                  <p>Closed Requests</p>
                </div>

                <div className='katable'>
                  <Table
                    columns={[
                      { key: "RequestId", title: "Request Id", dataType: DataType.String, },
                      { key: "FullName", title: "Employee", dataType: DataType.String, },
                      { key: "Message", title: "Request", dataType: DataType.String, },
                      { key: "RequestDate", title: "Date", dataType: DataType.String, },
                      { key: "FeedBack", title: "Feedback", dataType: DataType.String, },
                      { key: "RequestType", title: "Request Type", dataType: DataType.String, },
                      { key: "ClosedBy", title: "Closed By", dataType: DataType.String, },
                      { key: "ClosedDate", title: "Closed Date", dataType: DataType.String, },
                      { key: "ClosedTime", title: "Time", dataType: DataType.String, },
                      { key: "Status", title: "Status", dataType: DataType.String, },

                    ]}
                    data={paginatedData}
                    rowKeyField={'id'}
                    searchText={searchText}
                    noData={{
                      text: 'No Data Found'
                    }}
                    childComponents={{
                      cellText: {
                        content: (props) => {

                          switch (props.column.key) {
                            case 'RequestId': {
                              return <CustomCell {...props} RequestId={props.rowData.RequestId} />;
                            }
                            case 'FullName': {

                              return (
                                <div>
                                  {props.rowData.FullName} - {props.rowData.EmployeeId}
                                </div>
                              );
                            }

                            default:
                              return <div >{props.rowData[props.column.key]}</div>;
                          }
                        },
                      },
                    }}
                  />
                </div>
                <div className='pagination'>
                  <span className='pageselect'>
                    <YsecSelect
                      objectNameKey="pageDescription"
                      objectValueKey="pageNumber"
                      data={pageNumbers.map(number => ({
                        pageNumber: number,
                        pageDescription: `Page ${number.toString()}`
                      }))}
                      className="sm"
                      onChange={(e) => {
                        const selectedPage = Number(e.target.value);
                        setCurrentPage(selectedPage);
                      }}
                    />
                  </span>

                  <span>{startRange}-{endRange} of {totalItems}</span>
                  <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                    onClick={() => {
                      if (currentPage > 1) {
                        setCurrentPage(prev => prev - 1);
                      }
                    }}
                  />
                  <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                    onClick={() => {
                      if (currentPage < totalPages) {
                        setCurrentPage(prev => prev + 1);
                      }
                    }}
                  />
                </div>

              </div>
            }
          </div>
        </div>
        {open && <NewRequest show={open} handleOpen={handleOpen} getData={getData} setAlertMessage={setAlertMessage} />}
      </React.Suspense>

    </div>
  )
}
export default GenericRequest;
