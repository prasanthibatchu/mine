import React, { useEffect, useState } from 'react'
import { Modal } from 'react-bootstrap'
import AxiosLayout from '../../apis/axios';
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));

export default function NewRequest(props) {
    const userId = JSON.parse(localStorage.getItem('_user'));

    const [request, setRequest] = useState('')
    const [err, setErr] = useState(0)
    const [alertMessage, setAlertMessage] = useState('');
    const handleSubmit = async (e) => {
        e.preventDefault()
        setErr(0)
        if (request === "") {
            setErr(1)
        }
        else {
            const data = {
                "requestId": 0,
                "employeeId": userId?.user,
                "message": request
            };
            await AxiosLayout.post(`/Request/SaveRequest`, data).then((res) => {
                if (res.data.Status === 1) {
                    props.handleOpen()
                    props.getData()
                    props.setAlertMessage(res.data.Message)
                } else {
                    setAlertMessage(res.data.Message);
                }
            });

        }
    }

    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage(''); // Clear the alert message after 5 seconds
            }, 1000);

            // Cleanup the timer on component unmount or when alertMessage changes
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);
    return (
        <Modal   {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered>
            <Modal.Header>
                <p className="modal-title" id="exampleModalLabel">New Request</p>
                <button type="button" className="btn-close" onClick={props.handleOpen} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                {alertMessage && (
                    <div className="alert alert-danger" role="alert">
                        {alertMessage}
                    </div>
                )}
                <YsecTextarea label="Request"
                    mandatory="true"
                    error="test message"
                    className="test"
                    id="testID"
                    name="request"
                    value={request}
                    onChange={(e) => setRequest(e.target.value)}
                    placeholder="Enter Request Description"
                />
                {err === 1 && <label className='error'>Please Enter Request...</label>}
            </Modal.Body>
            <Modal.Footer>

                {/* <span className='cancel'> */}
                    <YsecButton type="button" className="lg cancel" onClick={props.handleOpen} >Cancel</YsecButton>
                {/* </span> */}

                <YsecButton type="button" className="lg" onClick={handleSubmit}>Submit</YsecButton>

            </Modal.Footer>
        </Modal>
    )
}
