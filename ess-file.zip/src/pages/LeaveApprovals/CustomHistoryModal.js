import React, { useEffect, useState } from 'react'
import './LeaveApproval.scss'
import { DataType, Table, useTableInstance } from 'ka-table';
import { Button, Col, Modal, Row } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));

export const LeaveHistoryModal = (props) => {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [leaveHistoryData, setLeaveHistoryData] = useState([])
    const [loading, setLoading] = useState(false);
    const [currentPage2, setCurrentPage2] = useState(1);
    const [itemsPerPage2, setItemsPerPage2] = useState(10);
const [leaveBlance,setLeaveBlnace]=useState("")
    useEffect(() => {
        setLoading(true);
        AxiosLayout.get(`/Leave/GetLeaveHistory?EmployeeId=${props.EmployeeId}&CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
            setLeaveBlnace(res.data.CurrenctLeaveBalance)
            setLeaveHistoryData(res.data.leaveHistories)
            setLoading(false);
        });
    }, []);
    const leave_history = leaveHistoryData?.map(
        (i, index) => ({
            leave_type: i.LeaveType,
            applied_date: i.AppliedDate,
            from_date: i.FromDate,
            to_date: i.ToDate,
            hours: i.Hours,
            days: i.Days,
            description: i.Remarks,
            status: i.ApprovalStatus,
            id: index
        }
        ),
    );

    // Count the number of leaves for each type
    const leaveCounts =  leaveHistoryData?.reduce((acc, i) => {
        const leaveType = i?.LeaveType; // Normalize to lowercase for consistency
        if (acc[leaveType]) {
            acc[leaveType] += 1; // Increment count if leave type already exists
        } else {
            acc[leaveType] = 1; // Initialize count if leave type is new
        }
        return acc;
    }, {});

    const slCount = leaveCounts['SL'] || 0; // Count for SL
    const clCount = leaveCounts['CL'] || 0; // Count for CL
    const cofCount = leaveCounts['COF'] || 0; // Count for COF
    const lopCount = leaveCounts['LOP'] || 0; // Count for LOP


    const total_leaves = Array(1).fill(undefined).map(
        (_, index) => ({
            sl: slCount,
            cl: clCount,
            cof: cofCount,
            lop: lopCount,
            id: index
        }),
    );
    const totalPages2 = Math.ceil(leave_history.length / itemsPerPage2);

    // Get current items to display
    const startIndex = (currentPage2 - 1) * itemsPerPage2;
    const currentItems = leave_history.slice(startIndex, startIndex + itemsPerPage2);

    



    // ==============

    const indexOfLastItem = currentPage2 * itemsPerPage2;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage2;
    const currentData = leave_history;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = leave_history.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage2);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

    return (

        <Modal {...props} size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered>
            <Modal.Header>
                <p className="modal-title" id="exampleModalLabel"> Leave History </p>
                <button type="button" className="btn-close" onClick={props.handleOpenLeaveHistory} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
            <p className='leaveblnce'>Current Leave balance : {leaveBlance}</p>
                <div className='katable'>
                    <Row>
                        <Col><b>Employee Id: {props.EmployeeId}</b></Col>
                        <Col><b>Employee: {props.empName}</b></Col>
                    </Row>
                    <div>
                        <Table
                            columns={[
                                { key: "leave_type", title: "Leave Type", dataType: DataType.String, },
                                { key: "applied_date", title: "Applied date", dataType: DataType.String, },
                                { key: "from_date", title: "From Date", dataType: DataType.String, },
                                { key: "to_date", title: "To Date", dataType: DataType.String, },
                                { key: "hours", title: "Hours", dataType: DataType.String, },
                                { key: "days", title: "Days", dataType: DataType.String, },
                                { key: "description", title: "Description", dataType: DataType.String, },
                                { key: "status", title: "Approval Status", dataType: DataType.String, },
                            ]}
                            data={paginatedData}
                            rowKeyField={'id'}
                            noData={{
                                text: 'No Data Found'
                            }}
                        />
                    </div>
                    <div className='pagination'>



                        <YsecButton className={currentPage2 !== 1 ? "pagebtn" : "disabled"} onClick={() => setCurrentPage2(prev => Math.max(prev - 1, 1))}
                            disabled={currentPage2 === 1}
                        >Prev</YsecButton>
                        <YsecButton>{currentPage2}/{totalPages2} </YsecButton>
                        <YsecButton className={currentPage2 !== totalPages2 ? "pagebtn" : "disabled"}
                            onClick={() => setCurrentPage2(prev => Math.min(prev + 1, totalPages2))}
                            disabled={currentPage2 === totalPages2}

                        >Next</YsecButton>
                    </div>
                    {userId?.companyId===78 &&
                    <div>
                        <Table
                            columns={[
                                { key: "sl", title: "SL", dataType: DataType.String, },
                                { key: "cl", title: "CL", dataType: DataType.String, },
                                { key: "cof", title: "COF", dataType: DataType.String, },
                                { key: "lop", title: "LOP", dataType: DataType.String, },
                            ]}
                            data={total_leaves}
                            rowKeyField={'id'}
                            noData={{
                                text: 'No Data Found'
                            }}
                        />
                    </div>}
                </div>
            </Modal.Body>
            <Modal.Footer>
                <YsecButton type='button' onClick={props.handleOpenLeaveHistory}>Close</YsecButton>

            </Modal.Footer>
        </Modal>
    )
}


export const LogHistoryModal = (props) => {
    const [logHistorydata, setLogHistoryData] = useState([])
    const [loading, setLoading] = useState(false);
    const userId = JSON.parse(localStorage.getItem('_user'));
    useEffect(() => {
        setLoading(true);
        AxiosLayout.get(`/Leave/GetLeaveLogs?LeaveId=${props.selectedRowId}&UserId=${userId?.user}`).then((res) => {
            setLogHistoryData(res.data)
            setLoading(false);
        });
    }, []);


    const log_history = logHistorydata?.map(
        (i, index) => ({
            employeeId: i.EmployeeId,
            transaction_type: i.TransactionType,
            changed_by: i.ChangedBy,
            change_date: i.ChangeDate?.split(" ")[0],
            details: i.Details,
            id: index
        }),
    );
    return (

        <Modal {...props} size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered>
            <Modal.Header>
                <p className="modal-title" id="exampleModalLabel"> Log History </p>
                <button type="button" className="btn-close" onClick={props.handleOpenLogHistory} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                
                <div className='katable'>
                    <Table
                        columns={[
                            { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
                            { key: "transaction_type", title: "Transaction Type", dataType: DataType.String, },
                            { key: "changed_by", title: "Changed By", dataType: DataType.String, },
                            { key: "change_date", title: "Change Date", dataType: DataType.String, },
                            { key: "details", title: "Deatils", dataType: DataType.String, },
                        ]}
                        data={log_history}
                        rowKeyField={'id'}
                        noData={{
                            text: 'No Data Found'
                        }}
                    />
                </div>
            </Modal.Body>
            <Modal.Footer>
                <YsecButton  type='button' onClick={props.handleOpenLogHistory}>Close</YsecButton>

            </Modal.Footer>
        </Modal>
    )
}
