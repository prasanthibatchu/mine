import React, { useEffect, useRef, useState } from 'react'
import './LeaveApproval.scss'
import { Breadcrumb, Button, Col, Modal, Overlay, Row, Tooltip } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import { LeaveHistoryModal, LogHistoryModal } from './CustomHistoryModal';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox"))
const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value?.split(" ")[0] === "Rejected" && 'rejected') || (value?.split(" ")[0] === "Open" && "open") || value?.split(" ")[0] === "Cancelled" && "cancelled" || value?.split(" ")[0] === "Approved" && 'approved' || value?.split(" ")[0] === "InProgress" && "open" || value?.split(" ")[0] === "Processed" && "open"}
        >
            {value}
        </div>
    );
};

function CompOffApprovals() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const today = new Date();
    const currentDate = today.toISOString().split('T')[0];
    const [searchText, setSearchText] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(15);
    const [err, setErr] = useState(0)
    const [data, setData] = useState([])
    const printRef = useRef();
    useEffect(() => {
        getData()
    }, []);

    const getData = () => {
        setLoading(true)
        AxiosLayout.get(`/ComboOff/GetComboOffApprovals?UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setData(res.data)
                setLoading(false)
            }
        })
    }


    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Leave Approvals</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    // const sampleItem = {
    //     employeeId: "1686",
    //     emp_name: "Sample User",
    //     leave_type: "Test Leave",
    //     apply_date: "2025-06-11",
    //     from_date: "2025-06-12",
    //     to_date: "2025-06-12",
    //     hours: 8,
    //     days: 1,
    //     remark: "This is a sample entry",
    //     leaveTypeId: 0,
    //     status: "Open",
    //     id: 223
    // };
    // const dataArray = [
    //     ...data.map(i => ({
    //         employeeId: i.EmployeeId,
    //         emp_name: i.EmployeeName,
    //         leave_type: i.LeaveType,
    //         apply_date: i.ApplyDate,
    //         from_date: i.FromDate,
    //         to_date: i.ToDate,
    //         hours: i.Hours,
    //         days: i.Days,
    //         remark: i.Remarks,
    //         leaveTypeId: i.LeaveTypeId,
    //         status: i.ApprovalStatus,
    //         id: i.ComboId
    //     })),
    //     sampleItem // sample at the end, or put at the start if you prefer
    // ];
    const dataArray = data.map(i => ({
        employeeId: i.EmployeeId,
        emp_name: i.EmployeeName,
        leave_type: i.LeaveType,
        apply_date: i.ApplyDate,
        from_date: i.FromDate,
        to_date: i.ToDate,
        hours: i.Hours,
        days: i.Days,
        remark: i.Remarks,
        leaveTypeId: i.LeaveTypeId,
        status: i.ApprovalStatus,
        id: i.ComboId
    }));
    const filteredData = dataArray.filter((item) => {
        const searchLower = searchText.toLowerCase();

        const matchesSearchText = (
            item.employeeId.toString().toLowerCase().includes(searchLower) ||
            item.emp_name.toLowerCase().includes(searchLower) ||
            item.leave_type.toLowerCase().includes(searchLower) ||
            item.apply_date.toLowerCase().includes(searchLower) ||
            item.from_date.toLowerCase().includes(searchLower) ||
            item.to_date.toLowerCase().includes(searchLower) ||
            item.hours.toString().toLowerCase().includes(searchLower) ||
            item.days.toString().toLowerCase().includes(searchLower) ||
            item.remark.toLowerCase().includes(searchLower) ||
            item.status.toLowerCase().includes(searchLower)
        );

        return matchesSearchText;
    });
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = filteredData;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = filteredData.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);


    const [currentRowKey, setCurrentRowKey] = useState(null);
    const [currentAction, setCurrentAction] = useState({ rowKey: null, action: null });
    const ApproveAction = ({ rowKey, currentRowKey, setCurrentRowKey, }) => {
        const show = rowKey === currentRowKey && currentAction.action === "approve";
        const tooltipRef = useRef(null); // Create a ref for the tooltip
        const [appReason, setAppReason] = useState("")
        const handleOpenTooltp = () => {
   
            if (show) {
                setCurrentRowKey(null);
                setCurrentAction({ rowKey: null, action: null });
            } else {
                setCurrentRowKey(rowKey);
                setCurrentAction({ rowKey, action: "approve" });
            }

        }

        const filData = data.filter(i => i.ComboId == Number(rowKey));
        const reqId = filData[0]?.ComboId;
        const empiId = filData[0]?.EmployeeId

        return (
            <span ref={tooltipRef}>
                <YsecButton className="sm approve" onClick={handleOpenTooltp}>
                    Approve
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${reqId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                   
                                    <textarea name='appReason'
                                        value={appReason}
                                        onChange={(e) => setAppReason(e.target.value)}
                                        rows="3"
                                        placeholder="Remarks (Optional)"
                                    />
                                    <div className='apbtn'>
                                        <YsecButton className="sm approve" onClick={async () => {
                                            const data = {
                                                comboId: Number(rowKey),
                                                employeeId: Number(empiId),
                                                acceptedBy: userId.user,
                                                reason: appReason
                                            }
                                                
                                            await AxiosLayout.post(`/ComboOff/ApproveComboOff`, data).then((res) => {
                                                if (res.data.Status === 1) {
                                                    getData()
                                                    setCurrentRowKey(null);
                                                    setCurrentAction({ rowKey: null, action: null });
                                                } else {
                                                    // alert('error')
                                                    setCurrentRowKey(null);
                                                    setCurrentAction({ rowKey: null, action: null });
                                                }
                                            });
                                        }}>Approve</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    };
    const DeleteAction = ({ rowKey, currentRowKey, setCurrentRowKey, }) => {
        const show = rowKey === currentRowKey && currentAction.action === "cancel";
        const tooltipRef = useRef(null); // Create a ref for the tooltip
        const [cancelReason, setCancelReason] = useState("")
        const handleOpenTooltp = () => {
            if (show) {
                setCurrentRowKey(null);
                setCurrentAction({ rowKey: null, action: null });
            } else {
                setCurrentRowKey(rowKey);
                setCurrentAction({ rowKey, action: "cancel" });
            }

        }

        const filData = data.filter(i => i.ComboId == Number(rowKey));
        const reqId = filData[0]?.ComboId;
        const empiId = filData[0]?.EmployeeId

        return (
            <span ref={tooltipRef}>
                <YsecButton className="sm cancel" onClick={handleOpenTooltp}>
                    Cancel
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${reqId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                    <textarea name='cancelReason'
                                        value={cancelReason}
                                        onChange={(e) => setCancelReason(e.target.value)}
                                        rows="3"
                                        placeholder="Remarks"
                                    />
                                     {err === 1 && <div><label className='error'>Please Enter Reason...</label></div>}
                                    <div className='apbtn'>
                                        <YsecButton className="sm approve" onClick={async () => {
                                             if (cancelReason === "") {
                                                setErr(1)
                                            }
                                            else {
                                            const data = {
                                                comboId: Number(rowKey),
                                                employeeId: Number(empiId),
                                                acceptedBy: userId.user,
                                                reason: cancelReason
                                            }
                                                
                                            await AxiosLayout.post(`/ComboOff/CancelComboOff`, data).then((res) => {
                                                if (res.data.Status === 1) {
                                                    getData()
                                                    setCurrentRowKey(null);
                                                    setCurrentAction({ rowKey: null, action: null });
                                                } else {
                                                    // alert('error')
                                                    setCurrentRowKey(null);
                                                    setCurrentAction({ rowKey: null, action: null });
                                                }
                                            });
                                        }
                                        }}>Cacel</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    
    }
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Approval</Breadcrumb.Item>
                            <Breadcrumb.Item active>Compoff Approval</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={() => {
                            setSearchText("")
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='leavecontainerr'>
                    <div class="d-flex flex-wrap  row m-1 p-2 bg-white">

                        <div class="col-12 col-sm-6 col-md-8 p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>
                    </div>

                    <div className='katable' ref={printRef}>
                         <Table
                                                    columns={[
                                                        { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
                                                        { key: "emp_name", title: "Employee Name", dataType: DataType.String, },
                                                        { key: "leave_type", title: "Leave Type", dataType: DataType.String, },
                                                        { key: "apply_date", title: "Applied Date", dataType: DataType.String, },
                                                        { key: "from_date", title: "From Date", dataType: DataType.String, },
                                                        { key: "to_date", title: "To Date", dataType: DataType.String, },
                                                        { key: "hours", title: "Hours", dataType: DataType.String, },
                                                        { key: "days", title: "Days", dataType: DataType.String, },
                                                        { key: "remark", title: "Description", dataType: DataType.String, },
                                                        
                        
                                                        { key: ':action3', title: 'Approve Action', width: 70, },
                                                        { key: ':action4', title: 'Cancel Action', width: 70, },
                                                        
                        
                                                    ]}
                                                    data={paginatedData}
                                                    rowKeyField={'id'}
                                                    searchText={searchText}
                                                    noData={{
                                                        text: 'No Data Found'
                                                    }}
                                                    childComponents={{
                                                        cellText: {
                                                            content: (props) => {
                        
                                                                switch (props.column.key) {
                                                                    case ':action3':
                                                                        return <ApproveAction {...props}
                                                                            rowKeyValue={props.rowKeyValue} rowKey={props.rowKeyValue}  currentRowKey={currentRowKey} setCurrentRowKey={setCurrentRowKey} currentAction={currentAction} setCurrentAction={setCurrentAction}
                                                                       
                        
                                                                        />
                                                                    case ':action4':
                                                                        return <DeleteAction {...props}
                                                                            {...props}
                                                                            rowKeyValue={props.rowKeyValue} rowKey={props.rowKeyValue} currentRowKey={currentRowKey} setCurrentRowKey={setCurrentRowKey} currentAction={currentAction} setCurrentAction={setCurrentAction} />
                                                                       
                                                                  
                                                                    
                                                                }
                        
                                                            },
                                                        },
                        
                        
                                                    }}
                        
                                                />
                       
                    </div>



                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>



            </React.Suspense>
        </div>
    )
}
export default CompOffApprovals;

