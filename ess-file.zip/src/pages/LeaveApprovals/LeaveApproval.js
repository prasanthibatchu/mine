import React, { useEffect, useRef, useState } from 'react'
import './LeaveApproval.scss'
import { Breadcrumb, Button, Col, Modal, Overlay, Row, Tooltip } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import { LeaveHistoryModal, LogHistoryModal } from './CustomHistoryModal';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox"))

function LeaveApproval() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [leaveTypes, setLeaveTypes] = useState([]);
    const [selectedLeaveTypeId, setSelectedLeaveTypeId] = useState(null);
    const [curLeaveBlnce, setCurLeaveBlnce] = useState([]);
    const [leaveBalance, setLeaveBalance] = useState([]);
    const [holidayList, setHolidayList] = useState([]);
    const today = new Date();
    const currentDate = today.toISOString().split('T')[0];
    const [leaves, setLeaves] = useState([])
    const dispatch = useDispatch();
    const [searchText, setSearchText] = useState('');
    const [openDeletLeave, setOpenDeletLeave] = useState(false);
    const [openApproveLeave, setOpenApproveLeave] = useState(false);
    const [openHoldLeave, setOpenHoldLeave] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(15); // Default items per page
    const [leaveId, setLeaveId] = useState('')
    const [empIds, setEmpIds] = useState('')
    const [openLogHistory, setOpenLogHistory] = useState(false)
    const [openLeaveHistory, setOpenLeavegHistory] = useState(false)
    const [empName, setEmpName] = useState('')
    const [currentPage2, setCurrentPage2] = useState(1);
    const [itemsPerPage2, setItemsPerPage2] = useState(5); // Default items per page
    const [selectedRows, setSelectedRows] = useState(new Set());
    const [selectEmpId, setSelectEmpId] = useState('')
    const [bulApproveModel, setBulkApproveModel] = useState(false)
    const [selectedRowId, setSelectedRowId] = useState("")
    const [bulkinput, setBulkInput] = useState("")
    const [err, setErr] = useState(0)
    const printRef = useRef();
    useEffect(() => {
        fetchLeaveDetails()
        getLeaveTypes()
    }, []);

 
const getLeaveTypes=()=>{
     AxiosLayout.get(`/Leave/GetLeaveTypes?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
            setLeaveTypes(res.data);
        });
}

    const dataArray = leaves.map(leave => ({
        employeeId: leave.EmployeeId,
        emp_name: leave.EmployeeName,
        leave_type: leave.LeaveTypeDesc,
        apply_date: leave.ApplyDate,
        from_date: leave.FromDate,
        to_date: leave.ToDate,
        hours: leave.Hours,
        days: leave.Days,
        remark: leave.Remark,
        eligible_days: leave.EligibleDays,
        id: leave.LeaveId
    }));

    const filteredDataArray = dataArray.filter(leave => {
        const leaveTypeMatch = leaveTypes.filter(type => type.LeaveTypeId == selectedLeaveTypeId);
        const leaveDescription = leaveTypeMatch.length > 0 ? leaveTypeMatch[0].LeaveDescription : null;
        const matchesLeaveType = selectedLeaveTypeId === "" || leave.leave_type === leaveDescription;

        const matchesSearchText = searchText === '' ||
            Object.values(leave).some(value =>
                String(value).toLowerCase().includes(searchText.toLowerCase())
            );

        return matchesLeaveType && matchesSearchText;
    });

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = selectedLeaveTypeId === null ? dataArray : filteredDataArray;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = selectedLeaveTypeId === null ? dataArray.length : filteredDataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);
    const fetchLeaveDetails = async () => {
        setLoading(true);
        AxiosLayout.get(`/Leave/GetLeavesForApproval?ManagerId=${userId?.user}&CompanyId=${userId?.companyId}`).then((res) => {
            setLeaves(res?.data);
            setLoading(false);
        });

    };


    const handleOpenApproveLeave = () => setOpenApproveLeave(!openApproveLeave);
    const handleOpenDeleteLeave = () => setOpenDeletLeave(!openDeletLeave);
    const handleOpenHoldLeave = () => setOpenHoldLeave(!openHoldLeave);
    const handleOpenLogHistory = () => setOpenLogHistory(!openLogHistory);
    const handleOpenLeaveHistory = () => setOpenLeavegHistory(!openLeaveHistory);
    const handleBulkApproveModel = () => {
        setBulkApproveModel(!bulApproveModel)
    }


    const LeaveHistory = ({ rowKeyValue }) => {
        return (
            <>
                <Button size="sm" variant="link" className='history' onClick={() => {
                    const histData = leaves.filter(i => i.LeaveId == rowKeyValue);
                    setEmpIds(histData[0]?.EmployeeId)
                    setEmpName(histData[0]?.EmployeeName)
                    handleOpenLeaveHistory()
                }}>History</Button>

                {openLeaveHistory && <LeaveHistoryModal show={openLeaveHistory} open={openLeaveHistory} handleOpenLeaveHistory={handleOpenLeaveHistory} EmployeeId={empIds} empName={empName} />}
            </>
        )
    }



    const LogDetails = ({ rowKeyValue }) => {
        return (
            <>
                <Button size="sm" variant="link" className='history' onClick={() => {
                    setSelectedRowId(rowKeyValue)
                    handleOpenLogHistory()
                }}>Log Details</Button>
                {openLogHistory && <LogHistoryModal show={openLogHistory} open={openLogHistory} handleOpenLogHistory={handleOpenLogHistory} leaveId={rowKeyValue} selectedRowId={selectedRowId} />}
            </>
        )
    }
    const handleCheckboxChange = (rowKeyValue) => {
        const newSelectedRows = new Set(selectedRows);
        if (newSelectedRows.has(rowKeyValue)) {
            newSelectedRows.delete(rowKeyValue);
        } else {
            newSelectedRows.add(rowKeyValue);
        }
        setSelectedRows(newSelectedRows);
    };
    const SelectCheck = ({ rowKeyValue, selectedRows, onCheckboxChange }) => {
        const isChecked = selectedRows.has(rowKeyValue);
        return (
            <>
                <YsecCheckbox checked={isChecked}
                    onChange={() => onCheckboxChange(rowKeyValue)} />

            </>
        )
    }

    const handleBulkApproveSubmit = async () => {
        const selectedLeaves = Array.from(selectedRows).map(rowKeyValue => {
            const leaveData = leaves.find(leave => leave.LeaveId === rowKeyValue);
            return {
                LeaveId: leaveData?.LeaveId,
                EmployeeId: leaveData?.EmployeeId
            };
        });


        setErr(0)
        if (bulkinput === "") {
            setErr(1)
        }
        else {
            const data = {
                leaveIds: selectedLeaves,
                acceptedBy: userId?.user,
                companyId: userId?.companyId,
                reason: bulkinput
            }
            AxiosLayout.post(`/Leave/BulkLeaveApprove`, data).then((res) => {
                fetchLeaveDetails()
                handleBulkApproveModel();
            });

        }
    };


    const [currentRowKey, setCurrentRowKey] = useState(null);
    const [currentType, setCurrentType] = useState(null);



    const Approveaction = ({ rowKey, currentRowKey, currentType, setCurrentRowKey, setCurrentType, type }) => {
        const show = rowKey === currentRowKey && type === currentType;
        const tooltipRef = useRef(null); // Create a ref for the tooltip
        const [appReason, setAppReason] = useState("")
        const handleOpenTooltp = () => {
            if (show) {
                setCurrentRowKey(null);
                setCurrentType(null);
            } else {
                setCurrentRowKey(rowKey);
                setCurrentType(type);

            }

        }

        const approveData = leaves.filter(i => i.LeaveId == rowKey);
        const leaveId = approveData[0]?.LeaveId;
        const empIds = approveData[0]?.EmployeeId;


        return (
            <span ref={tooltipRef}>
                <YsecButton className="sm approve" onClick={handleOpenTooltp}>
                    Approve
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${leaveId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                    <textarea name='appReason'
                                        value={appReason}
                                        onChange={(e) => setAppReason(e.target.value)}
                                        rows="3"
                                        placeholder="Remarks (Optional)"
                                    />
                                    <div className='apbtn'>
                                        <YsecButton className="sm approve" onClick={async () => {
                                            const data = {
                                                "leaveId": leaveId,
                                                "employeeId": empIds,
                                                "acceptedBy": userId?.user,
                                                "companyId": userId?.companyId,
                                                "reason": appReason,
                                            };
                                            await AxiosLayout.post(`/Leave/ApproveLeave`, data).then((res) => {
                                                if (res.data.Status === 1) {
                                                    fetchLeaveDetails()
                                                    setCurrentRowKey(null);
                                                    setCurrentType(null);
                                                } else {
                                                    // alert('error')
                                                    setCurrentRowKey(null);
                                                    setCurrentType(null);
                                                }
                                            });
                                        }}>Approve</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    };
    const Cancelaction = ({ rowKey, currentRowKey, currentType, setCurrentRowKey, setCurrentType, type }) => {
        const show = rowKey === currentRowKey && type === currentType;
        const tooltipRef = useRef(null); // Create a ref for the tooltip
        const [cancelReason, setCancelReason] = useState("")
        const [err, setErr] = useState(0)
        const handleOpenTooltp = () => {

            if (show) {
                setCurrentRowKey(null);
                setCurrentType(null);
            } else {
                setCurrentRowKey(rowKey);
                setCurrentType(type);
            }
        }

        const approveData = leaves.filter(i => i.LeaveId == rowKey);
        const leaveId = approveData[0]?.LeaveId;
        const empIds = approveData[0]?.EmployeeId;


        return (
            <span ref={tooltipRef}>


                <YsecButton className="sm cancel" onClick={handleOpenTooltp}>
                    Cancel
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${leaveId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                    <textarea name='cancelReason'
                                        value={cancelReason}
                                        onChange={(e) => setCancelReason(e.target.value)}
                                        rows="3"
                                        placeholder="Reason"
                                    />
                                    {err === 1 && <div><label className='error'>Please Enter Reason...</label></div>}
                                    <div className='apbtn'>
                                        <YsecButton className="sm cancel" onClick={async () => {
                                            setErr(0)
                                            if (cancelReason === "") {
                                                setErr(1)
                                            }
                                            else {
                                                const cancelData = {

                                                    "leaveId": leaveId,
                                                    "employeeId": empIds,
                                                    "companyId": userId?.companyId,
                                                    "statusId": 6,
                                                    "acceptedBy": userId?.user,
                                                    "reason": cancelReason
                                                };
                                                await AxiosLayout.post('/Leave/CancelLeave', cancelData).then((res) => {
                                                    if (res.data.Status === 1) {

                                                        fetchLeaveDetails()
                                                        setCurrentRowKey(null);
                                                        setCurrentType(null);
                                                    } else {
                                                        // alert('error')
                                                        setCurrentRowKey(null);
                                                        setCurrentType(null);


                                                    }
                                                });

                                            }
                                        }}>Submit</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    };
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Leave Approvals</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Approval</Breadcrumb.Item>
                            <Breadcrumb.Item active>Leave Approval</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={()=>{
                            setSearchText("")
                            setSelectedRows(new Set())
                            setLeaveTypes([])
                            setSelectedLeaveTypeId(null)
                            getLeaveTypes()
                            fetchLeaveDetails()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='leavecontainerr'>
                    <div class="d-flex flex-wrap  row m-1 p-2 bg-white">

                        <div class="col-12 col-sm-6 col-md-8 p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>

                        <div class="col-12 col-sm-6 col-md-4  p-1">
                            <YsecSelect className="md"
                                objectNameKey="LeaveDescription"
                                objectValueKey="LeaveTypeId"
                                data={[
                                    { LeaveTypeId: "", LeaveDescription: "Select Leave Type" },
                                    ...leaveTypes.map(leave => ({
                                        LeaveTypeId: leave.LeaveTypeId,
                                        LeaveDescription: leave.LeaveDescription
                                    }))
                                ]}
                                onChange={(e) => setSelectedLeaveTypeId(e.target.value)}
                            />
                        </div>
                    </div>

                    <div className='katable'  ref={printRef}>
                        <div className='bulkbtn'>
                            <YsecButton className="sm" onClick={handleBulkApproveModel}>Bulk Approve</YsecButton>
                        </div>

                        <Table
                            columns={[
                                { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
                                { key: "emp_name", title: "Employee Name", dataType: DataType.String, },
                                { key: "leave_type", title: "Leave Type", dataType: DataType.String, },
                                { key: "apply_date", title: "Applied Date", dataType: DataType.String, },
                                { key: "from_date", title: "From Date", dataType: DataType.String, },
                                { key: "to_date", title: "To Date", dataType: DataType.String, },
                                { key: "hours", title: "Hours", dataType: DataType.String, },
                                { key: "days", title: "Days", dataType: DataType.String, },
                                { key: "remark", title: "Description", dataType: DataType.String, },
                                { key: ":action1", title: "Leave History", dataType: DataType.String, },
                                { key: ":action2", title: "Log Details", dataType: DataType.String, },

                                { key: ':action3', title: '', width: 70, },
                                { key: ':action4', title: '', width: 70, },
                                { key: ':action6', title: 'Select', width: 70, },
                                // { key: ':action7', title: 'test1', width: 70, },
                                // { key: ':action8', title: 'test2', width: 70, },
                                { key: "eligible_days", title: "Eligible Days", dataType: DataType.String, },

                            ]}
                            data={paginatedData}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {

                                        switch (props.column.key) {
                                            case ':action3':
                                                return <Approveaction {...props}
                                                    type={props.column.key}
                                                    rowKey={props.rowKeyValue}
                                                    currentRowKey={currentRowKey}
                                                    currentType={currentType}
                                                    setCurrentRowKey={setCurrentRowKey}
                                                    setCurrentType={setCurrentType}
                                                // activeRowKey={activeRowKey} setActiveRowKey={setActiveRowKey} 

                                                />
                                            case ':action4':
                                                return <Cancelaction {...props}
                                                    {...props}
                                                    type={props.column.key}
                                                    rowKey={props.rowKeyValue}
                                                    currentRowKey={currentRowKey}
                                                    currentType={currentType}
                                                    setCurrentRowKey={setCurrentRowKey}
                                                    setCurrentType={setCurrentType}
                                                // activeRowKey2={activeRowKey2} setActiveRowKey2={setActiveRowKey2}
                                                />
                                            // case ':action5':
                                            //     return <OnHold {...props} />
                                            case ':action6':
                                                return <SelectCheck {...props} selectedRows={selectedRows} onCheckboxChange={handleCheckboxChange} />
                                            case ':action1':
                                                return <LeaveHistory {...props} />
                                            case ':action2':
                                                return <LogDetails {...props} />
                                            // case ':action7':
                                            //         return (
                                            //           <Test1
                                            //             {...props}
                                            //             type={props.column.key}
                                            //             rowKey={props.rowKeyValue}
                                            //             currentRowKey={currentRowKey}
                                            //             currentType={currentType}
                                            //             setCurrentRowKey={setCurrentRowKey}
                                            //             setCurrentType={setCurrentType}
                                            //           />
                                            //         );
                                            // case ':action8':
                                            //         return (
                                            //           <Test2
                                            //             {...props}
                                            //             type={props.column.key}
                                            //             rowKey={props.rowKeyValue}
                                            //             currentRowKey={currentRowKey}
                                            //             currentType={currentType}
                                            //             setCurrentRowKey={setCurrentRowKey}
                                            //             setCurrentType={setCurrentType}
                                            //           />
                                            //         );

                                        }

                                    },
                                },


                            }}

                        />
                    </div>

                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>


                {bulApproveModel && (
                    <Modal
                        show={bulApproveModel}
                        size="md"
                        aria-labelledby="contained-modal-title-vcenter"
                        centered
                    >
                        <Modal.Header>
                            <p className="modal-title" id="exampleModalLabel">Bulk Approve</p>
                            <button type="button" className="btn-close" onClick={handleBulkApproveModel} aria-label="Close"></button>
                        </Modal.Header>
                        <Modal.Body>
                            <h6 className='deleteleave'>Please confirm the selected leave details will be bulk approve!!!</h6>
                            <YsecInput className="md" placeholder="Reason" type="text" label="Reason" mandatory value={bulkinput} onChange={(event) => {
                                setBulkInput(event.target.value);
                            }} />
                            {err === 1 && <label className='error'>Please Enter Reason...</label>}
                        </Modal.Body>
                        <Modal.Footer>
                            {/* <span className='cancel'> */}
                            <YsecButton type="button" className='cancel' onClick={handleBulkApproveModel}>Cancel</YsecButton>
                            {/* </span> */}

                            <YsecButton type="button" className="btn-success" onClick={handleBulkApproveSubmit}>Approve</YsecButton>

                        </Modal.Footer>

                    </Modal>
                )}
            </React.Suspense>
        </div>
    )
}
export default LeaveApproval;

