import React, { useEffect, useRef, useState } from "react";
import { Breadcrumb, Col, Row } from "react-bootstrap";
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from "../../apis/axios";
import "./Reports.scss";
import { CSVLink } from 'react-csv';
import { PunchCountHistory } from "../MyAttendance/punchCountHistory";
import LoadingSpinner from "../Loader/Loader";
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));

const CustomCell = ({ column, rowKeyValue, value, getPunchDeatails, rowData, status }) => {

    const [showModal, setShowModal] = useState(false);
    const timeThreshold = timeToMinutes("9:00");
    const workTimeThreshold = timeToMinutes("7:40");
    const currentTime = timeToMinutes(value);

    return (
        <div>
            {column.key === 'total_time' && <div className={((currentTime < timeThreshold  )? "time" : "")}>{value}</div>}
            {column.key === 'actual_time' && <div className={((currentTime < workTimeThreshold )? "time" : "")}>{value}</div>}
            {column.key === 'punch_count' && (
                <div className={value > 1 ? "count" : ""}>
                    {value > 1 ? (
                        <p onClick={() => getPunchDeatails(rowData)}>
                            {value % 2 === 0 ? value : `Incorrect Punch - ${value}`}
                        </p>
                    ) : value % 2 === 0 ? value : `Incorrect Punch - ${value}`}
                </div>
            )}



        </div>
    );
};
const timeToMinutes = (time) => {
    if (typeof time !== 'string' || !time.includes(':')) {
        console.error('Invalid time format:', time);
        return 0;
    }
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
};
function Attendance_Report() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [searchText, setSearchText] = useState('');
    const [brandData, setBrandData] = useState([]);
    const [brandId, setBrandId] = useState(null);
    const [empData, setEmpData] = useState([]);
    const [empId, setEmpId] = useState(null);
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [reportData, setReportData] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [punchData, setPunchData] = useState([])
  const [selectedEmp, setselectedEmp] = useState("")
   const [loading, setLoading] = useState(false);
      const [error, setError] = useState(null);
  const printRef = useRef();
    const handleShow = () => setShowModal(!showModal);
    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);

    useEffect(() => { getData() }, []);

    const getData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetBrands?CompanyId=${userId.companyId}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setBrandData(res.data);
                setLoading(false)
            }
        });
    };

    useEffect(() => {
        if (brandId !== null) { getEmpData(); }
    }, [brandId]);

    const getEmpData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetActiveEmployee?CompanyId=${userId.companyId}&BrandId=${brandId}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setEmpData(res.data);
                setLoading(false)
            }
        });
    };

    const onChangeFun = (e) => {
        const dateRange = e.target.value;
        if (dateRange) {
            const dates = dateRange.split(' to ');
            if (dates.length === 2) {
                const startDate = dates[0].trim();
                const endDate = dates[1].trim();
                const formattedStartDate = startDate.split('/').reverse().join('-');
                const formattedEndDate = endDate.split('/').reverse().join('-');
                setFromDate(formattedStartDate);
                setToDate(formattedEndDate);
            } else {
                console.error('Invalid date range format. Please use "DD/MM/YYYY to DD/MM/YYYY".');
            }
        }
    };

    const getAttendanceReportData = async (e) => {
        e.preventDefault();
        if (brandId === null) {
            setErrorMessage("Select Brand");
        } else if (empId === null) {
            setErrorMessage("Select Employee");
        } else if (fromDate === "") {
            setErrorMessage("Select From Date");
        } else if (toDate === "") {
            setErrorMessage("Select To Date");
        } else {
            setLoading(true)
            const data = {
                leadview: brandId,
                employeeId: empId,
                fromDate: fromDate,
                toDate: toDate,
                UserId:userId?.user
            };
            AxiosLayout.post("/Report/AttendanceReportDetails", data).then((res) => {
                if (res.status === 200) {
                    setReportData(res.data);
                    setLoading(false)
                }
            });
        }
    };
    if (error) return <p>Error: {error}</p>;

    const dataArray = reportData?.map(
        (i, index) => ({
            employee_id: i.EmployeeId,
            emp_name: i.FullName,
            date: i.Date?.split(" ")[0],
            first_in: i.IN1,
            total_3: i.Total3,
            last_out: i.LastOut,
            total_time: i.TotalTime,
            actual_time: i.ActualTime?.split("@")[0],
            break_time: i.ActualTime?.split("@")[1],
            punch_count: i.PunchCount,
            id: index,
        }),
    );

    const columns = [
        { key: 'employee_id', title: 'Employee Id', dataType: DataType.String },
        { key: 'emp_name', title: 'Name', dataType: DataType.String },
        { key: 'date', title: 'Date', dataType: DataType.String },
        { key: 'first_in', title: 'First IN', dataType: DataType.String },
        { key: 'last_out', title: 'Last Out', dataType: DataType.String },
        { key: 'total_time', title: 'Total Time', dataType: DataType.String },
        { key: 'actual_time', title: 'Actual Time', dataType: DataType.String },
        { key: 'break_time', title: 'Break Time', dataType: DataType.String },
        { key: 'punch_count', title: 'Punch Count', dataType: DataType.String },
    ];
    const getPunchDeatails = async (data) => {
        setLoading(true)
        const datee = data?.date
        const year = datee?.split("-")[2]
        const month = datee?.split("-")[1]
        const day = datee?.split("-")[0]
        const formattedDate = `${year}-${month}-${day}`;
        await AxiosLayout.get(`/Report/GetPunchingDetails?AtnDate=${formattedDate}&EmployeeId=${data?.employee_id}&UserId=${userId?.user}`).then((res) => {
            setPunchData(res?.data);
            setselectedEmp(data?.emp_name)
            setShowModal(true)
            setLoading(false)
        });
    }
    const handlePrint = () => {
  const printContents = printRef.current.innerHTML;
  const printWindow = window.open('', '', 'height=600,width=800');
  printWindow.document.write('<html><head><title>Attendance Report</title>');
  // Optional: Add your styles here, or link to your CSS file
  printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
  printWindow.document.write('</head><body >');
  printWindow.document.write(printContents);
  printWindow.document.write('</body></html>');
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
};
    return (
        <div className="p-1">
           {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {errorMessage && (
                    <div className="alert alert-danger" role="alert">
                        {errorMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
          <div class="col">
                    <Breadcrumb>
                        <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                        <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                        <Breadcrumb.Item href="#">Reports</Breadcrumb.Item>
                        <Breadcrumb.Item active>Attendance Details</Breadcrumb.Item>
                    </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        
                        <ysecButton type="button" className={`sm history`} onClick={()=>{
                            setBrandData([])
                            setEmpData([])
                            setBrandId(null)
                            setFromDate("")
                            setToDate("")
                            setEmpId(null)
                            setReportData([])
                            setPunchData([])
                            setSearchText("")
                           getData()
                           }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>                        
                    </div>
                </div>
                {showModal && (
                    <PunchCountHistory show={showModal} handleShow={handleShow} punchData={punchData} selectedEmp={selectedEmp} />
                )}
                <div className="report_contaainer" ref={printRef}>
                    <Row className="m-1 p-2 bg-white">
                        <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                            <YsecSelect className="md"
                                objectNameKey="brandName"
                                objectValueKey="brandId"
                                data={[
                                    { brandId: "", brandName: "Select Brand" },
                                    ...brandData.map(i => ({
                                        brandId: i.BrandId,
                                        brandName: i.Brand
                                    }))
                                ]}
                                onChange={(e) => setBrandId(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                            <YsecSelect className="md"
                                objectNameKey="employee_name"
                                objectValueKey="employeeId"
                                data={[
                                    { employeeId: "", employee_name: "Select Employee" },
                                    ...empData.map(i => ({
                                        employeeId: i.EmployeeId,
                                        employee_name: i.FullName
                                    }))
                                ]}
                                onChange={(e) => setEmpId(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                            <YsecDatePicker
                                mandatory="true"
                                error="test message"
                                onChange={onChangeFun}
                                value={fromDate === "" ? "" : [fromDate, toDate]}
                                placeholder="Select From-To Date"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-DD"
                                wrapperClass
                                multipleSelect={true}
                            />
                        </Col>
                        <Col xs={12} sm={6} lg={1} className="mt-1 mb-1">
                            <YsecButton className="btnn w-100" onClick={getAttendanceReportData} >
                                Submit
                            </YsecButton>
                        </Col>
                        <Col xs={12} sm={6} lg={1} className='mt-1 mb-1 csv'>
                            <CSVLink
                                className="btnn csvbtn w-100"
                                data={dataArray}
                                headers={columns.map(c => ({ label: c.title, key: c.key }))}
                                filename='AttendanceReport.csv'
                                enclosingCharacter={''}
                                separator={';'}
                            >
                                Export
                            </CSVLink>
                        </Col>
                        <Col xs={12} sm={6} lg={2} className=' mt-1 mb-1'>
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </Col>
                    </Row>
                    <div className="katable" >
                        <Table
                            columns={columns}
                            data={dataArray}
                            rowKeyField={'id'}
                            // columnResizing={true}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {
                                            case 'total_time': {
                                                return <CustomCell {...props} total_time={props?.rowData?.total_time} status={props?.rowData?.status} />;
                                            }

                                            case 'actual_time': {
                                                return <CustomCell {...props} actual_time={props?.rowData?.actual_time} status={props?.rowData?.status} />;
                                            }
                                            case 'punch_count': {
                                                return <CustomCell {...props} punch_count={props?.rowData?.punch_count} getPunchDeatails={getPunchDeatails} rowData={props?.rowData} status={props?.rowData?.status} />;
                                            }

                                            default:
                                                return <div >{props?.rowData[props?.column?.key]}</div>;
                                        }
                                    },
                                },
                            }}
                        />
                    </div>
                </div>
            </React.Suspense>
        </div>
    );
}

export default Attendance_Report;