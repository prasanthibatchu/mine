
import React, { useEffect, useRef, useState } from 'react'
import './Reports.scss'
import { Breadcrumb, Col, Row } from 'react-bootstrap';
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import { CSVLink } from 'react-csv';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value?.split(" ")[0] === "Rejected" && 'rejected') || (value?.split(" ")[0] === "Open" && "open") || value?.split(" ")[0] === "Cancelled" && "cancelled" || value?.split(" ")[0] === "Approved" && 'approved' || value?.split(" ")[0] === "InProgress" && "open"}
        >
            {value}
        </div>
    );
};
function LeaveDetailsApprovals() {
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState('');
    const [searchText, setSearchText] = useState('');
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [leaveDetails, setLeaveDetails] = useState([])
    const [leaveTypes, setLeaveTypes] = useState([]);
    const printRef = useRef();
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [brandData, setBrandData] = useState([]);
    const [brandId, setBrandId] = useState(null);
    const [empData, setEmpData] = useState([]);
    const [empId, setEmpId] = useState(null);
    useEffect(() => {
        getData()
        getBrandData()
    }, []);
    const getData = () => {
        setLoading(true)
        AxiosLayout.get(`/Leave/GetLeaveTypes?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
            setLeaveTypes(res.data);
            setLoading(false)
        });
    }
    const getBrandData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetBrands?CompanyId=${userId.companyId}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setBrandData(res.data);
                setLoading(false)
            }
        });
    };

    useEffect(() => {
        if (brandId !== null) { getEmpData(); }
    }, [brandId]);

    const getEmpData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetActiveEmployee?CompanyId=${userId.companyId}&BrandId=${brandId}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setEmpData(res.data);
                setLoading(false)
            }
        });
    };
    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
    const onChangeFun = (e) => {
        const dateRange = e.target.value;

        if (dateRange) {
            const dates = dateRange.split(' to ');
            if (dates.length === 2) {
                const startDate = dates[0].trim();
                const endDate = dates[1].trim();
                const formattedStartDate = startDate.split('/').reverse().join('-');
                const formattedEndDate = endDate.split('/').reverse().join('-');
                setFromDate(formattedStartDate);
                setToDate(formattedEndDate);

            } else {
                console.error('Invalid date range format. Please use "DD/MM/YYYY to DD/MM/YYYY".');
            }
        }
    };

    const handleLeaveData = () => {
        setLoading(true)
        const data = {
            employeeId: Number(empId),
            fromDate: fromDate,
            toDate: toDate,
            companyId: userId?.companyId,
            userId: userId?.user,
            brandId: Number(brandId)
        }
        AxiosLayout.post('/Report/GetLeaveApprovalReport', data).then((res) => {
            if (res.status === 200) {
                if (res.data !== null) {
                    setLeaveDetails(res?.data?.Table)
                    setLoading(false)
                }
            }
        })
    }

    const dataArray = leaveDetails?.map((leave, index) => ({
        employeeId: leave.EmployeeId,
        emp_name: leave.FullName,
        leave_type: leave.LeaveType,
        apply_date: leave.ApplyDate,
        from_date: leave.FromDate,
        to_date: leave.ToDate,
        hours: leave.Hours,
        days: leave.Days,
        remark: leave.Remark,
        desc: leave.Reason,
        status: leave.AprStatus,
        manager: leave.Manager,
        approve_by: leave.ApprovedBy,
        cancel_by: leave.CancelledBy,
        id: index
    }));

    const columns = [
        { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
        { key: "emp_name", title: "Name", dataType: DataType.String, },
        { key: "leave_type", title: "Leave Type", dataType: DataType.String, },
        { key: "apply_date", title: "Apply Date", dataType: DataType.String, },
        { key: "from_date", title: "From Date", dataType: DataType.String, },
        { key: "to_date", title: "To Date", dataType: DataType.String, },
        { key: "days", title: "Days", dataType: DataType.String, }, { key: "hours", title: "Hours", dataType: DataType.String, },
        { key: "hours", title: "Hours", dataType: DataType.String, },
        { key: "desc", title: "Description", dataType: DataType.String, },
        { key: "status", title: "Status", dataType: DataType.String, },
        { key: "manager", title: "Manager", dataType: DataType.String, },
        { key: "approve_by", title: "Approved By", dataType: DataType.String, },
        { key: "cancel_by", title: "Cancelled By", dataType: DataType.String, },
        { key: "remark", title: "Remarks", dataType: DataType.String, },


    ]
    const targetLeaveTypeIds = [113, 114, 123];

    const leaveCounts = {
        SL: 0,
        CL: 0,
        LOP: 0,
        Others: 0
    };


    leaveDetails.forEach(leave => {
        if (targetLeaveTypeIds.includes(leave.LeaveTypeId)) {
            if (leave.LeaveTypeId === 113) {
                leaveCounts.SL += 1;
            } else if (leave.LeaveTypeId === 114) {
                leaveCounts.CL += 1;
            } else if (leave.LeaveTypeId === 123) {
                leaveCounts.LOP += 1;
            }
        } else {
            leaveCounts.Others += 1;
        }
    });

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Leave Details All</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };


    return (
        <div>
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Reports</Breadcrumb.Item>
                            <Breadcrumb.Item active>Leave Approval All</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm history`} onClick={() => {
                            setLeaveDetails([])
                            setFromDate("")
                            setToDate("")
                            setSearchText("")
                            setBrandData([])
                            setEmpData([])
                            setBrandId(null)
                            setEmpId(null)
                            getData()
                            // handleLeaveData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='report_contaainer'>
                    <Row className="m-1 p-2 bg-white">
                        <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                            <YsecSelect className="md"
                                objectNameKey="brandName"
                                objectValueKey="brandId"
                                data={[
                                    { brandId: "", brandName: "Select Brand" },
                                    ...brandData.map(i => ({
                                        brandId: i.BrandId,
                                        brandName: i.Brand
                                    }))
                                ]}
                                onChange={(e) => setBrandId(e.target.value)}
                            />
                        </Col>
                        <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                            <YsecSelect className="md"
                                objectNameKey="employee_name"
                                objectValueKey="employeeId"
                                data={[
                                    { employeeId: "", employee_name: "Select Employee" },
                                    ...empData.map(i => ({
                                        employeeId: i.EmployeeId,
                                        employee_name: i.FullName
                                    }))
                                ]}
                                onChange={(e) => setEmpId(e.target.value)}
                            />
                        </Col>
                        <Col className='gap-1 mt-1 mb-1' xs={12} sm={6} lg={2} >
                            <YsecDatePicker
                                mandatory="true"
                                error="test message"
                                onChange={onChangeFun}
                                value={fromDate === "" ? "" : [fromDate, toDate]}
                                placeholder="Select Date Range"
                                ysecMinDate="1000_Y"
                                ysecMaxDate="1000_Y"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-DD"
                                wrapperClass
                                multipleSelect={true}
                            />
                        </Col>

                        <Col className='gap-1 mt-1 mb-1' xs={12} sm={6} lg={2} >
                            <YsecButton className="btnn w-100" onClick={handleLeaveData}>Submit</YsecButton>
                        </Col>


                        <Col xs={12} sm={6} lg={2} className='gap-1 mt-1 mb-1 csv'>
                            <CSVLink
                                className="btnn csvbtn w-100"
                                data={dataArray}
                                headers={columns.map(c => ({ label: c.title, key: c.key }))}
                                filename='Leave_Approval_All.csv'
                                enclosingCharacter={''}
                                separator={';'}
                            >
                                Export
                            </CSVLink>
                        </Col>



                        <Col xs={12} sm={6} lg={2} className='gap-1 mt-1 mb-1' >
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </Col>
                    </Row>

                    <div className='katable' ref={printRef}>
                        <Table
                            columns={columns}
                            data={dataArray}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {

                                            case 'status':
                                                return <CustomCell  {...props} />
                                            default:
                                                return props.children;
                                        }

                                    },
                                },


                            }}
                        />
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}

export default LeaveDetailsApprovals;