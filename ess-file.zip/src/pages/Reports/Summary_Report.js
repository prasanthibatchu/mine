
import React, { useEffect, useRef, useState } from "react";
import { Breadcrumb, Col, Row } from "react-bootstrap";
import { DataType, Table } from "ka-table";
import AxiosLayout from "../../apis/axios";
import "./Reports.scss";
import { CSVLink } from 'react-csv';
import LoadingSpinner from "../Loader/Loader";
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));


function Summary_Report() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [searchText, setSearchText] = useState('');
    const [brandData, setBrandData] = useState([])
    const [brandId, setBrandId] = useState(null)
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState("")
    const [errorMessage, setErrorMessage] = useState('');
    const [checkBtn, setCheckBtn] = useState(1)
    const [sumData, setSumData] = useState([])
    const [selectMonth, setSelectMonthh] = useState('')
    const [periodData, setPeriodData] = useState([])
    const [empData, setEmpData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [monthreportData, setGetMonthReportData] = useState([])
    const [empId, setEmpId] = useState(null);
    const [attendanceSumData, setAttendanceSumData] = useState([])
    const [attendanceSumTableData, setAttendanceSumTableData] = useState([])
    const printRef = useRef();
    useEffect(() => {
        if (errorMessage) {
            const timer = setTimeout(() => {
                setErrorMessage('');
            }, 1000);
            return () => clearTimeout(timer);
        }
    }, [errorMessage]);
    useEffect(() => {
        getData()
        peroidMonthData()
    }, [])
    const getData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetBrands?CompanyId=${userId.companyId}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setBrandData(res.data)
                setLoading(false)
            }
        })
    }

    const peroidMonthData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetSalaryPeriods?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
            if (res.status === 200) {
                setPeriodData(res.data)
                setLoading(false)
            }
        })

    }

    useEffect(() => {
        if (brandId !== null) { getEmpData(); }
    }, [brandId]);
    const getEmpData = () => {
        setLoading(true)
        AxiosLayout.get(`/Report/GetActiveEmployee?CompanyId=${userId.companyId}&BrandId=${brandId}&UserId=${userId.user}`).then((res) => {
            if (res.status === 200) {
                setEmpData(res.data);
                setLoading(false)
            }
        });
    };


    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const onChangeFun = (e) => {
        const dateRange = e.target.value;
        setFromDate(dateRange);
    };


    const getSummaryData = () => {
setLoading(true)
        const today = new Date();
        const currentDate = today.toISOString().split('T')[0];
        AxiosLayout.get(`/Report/GetDailySummary?sDate=${currentDate}&BrandId=${brandId}&UserId=${userId?.user}`).then((res) => {
            if (res.status === 200) {
                setSumData(res.data)
                setLoading(false)
            }
        })

    }
    const dataArray = sumData.map(
        (i, index) => ({
            employee_id: i.EmployeeId,
            emp_name: i.FullName,
            position: i.Position,
            date: i.AtnDate?.split("T")[0],
            in_time: i.InTime,
            out_time: i.OutTime,
            work_time: i.WorkTime,
            break_time: i.BreakTime,
            total_time: i.TotalTime,
            status: i.Status,

            id: index,
        }),
    );
    const columns = [
        { key: 'employee_id', title: 'Employee Id', dataType: DataType.String },
        { key: 'emp_name', title: 'Name', dataType: DataType.String },
        { key: 'position', title: 'Position', dataType: DataType.String },
        { key: 'date', title: 'Date', dataType: DataType.String },
        { key: 'in_time', title: 'In Time', dataType: DataType.String },
        { key: 'out_time', title: 'Out Time', dataType: DataType.String },
        { key: 'work_time', title: 'Work Time', dataType: DataType.String },
        { key: 'break_time', title: 'Break Time', dataType: DataType.String },
        { key: 'total_time', title: 'Total Time', dataType: DataType.String },
        { key: 'status', title: 'Status', dataType: DataType.String },
    ]
    const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const getEveryEmpData = async () => {
        for (const employee of empData) {
            await delay(1000);
            getMonthReport(employee.EmployeeId);
        }
    };

    const getMonthReport = (employeeid) => {
        AxiosLayout.get(`/Report/GetMonthlySummary?EmpIds=${employeeid}&Salaryperiod=${selectMonth}&UserId=${userId?.user}`).then(res => {
            setGetMonthReportData(prevData => [...prevData, ...res.data]);
        })

    }

    const getColumns = (data) => {
        if (!data || data.length === 0) return [];
        const keys = Object.keys(data[0]);
        return keys
    };

    const headers = getColumns(monthreportData);
    const onChangeFunDates = (e) => {
        const dateRange = e.target.value;

        if (dateRange) {
            const dates = dateRange.split(' to ');
            if (dates.length === 2) {
                const startDate = dates[0].trim();
                const endDate = dates[1].trim();
                const formattedStartDate = startDate.split('/').reverse().join('-');
                const formattedEndDate = endDate.split('/').reverse().join('-');
                setFromDate(formattedStartDate);
                setToDate(formattedEndDate);

            } else {
                console.error('Invalid date range format. Please use "DD/MM/YYYY to DD/MM/YYYY".');
            }
        }
    };
    const getAttendanceSummary = async (e) => {
        e.preventDefault();
        if (brandId === null) {
            setErrorMessage("Select Brand");
        } else if (empId === null) {
            setErrorMessage("Select Employee");
        } else if (fromDate === "") {
            setErrorMessage("Select From Date");
        } else if (toDate === "") {
            setErrorMessage("Select To Date");
        } else {
            setLoading(true)
            const data = {
                leadview: brandId,
                employeeId: empId,
                fromDate: fromDate,
                toDate: toDate,
                UserId: userId?.user
            };
            AxiosLayout.post("/Report/GetAttendanceSummaryPeriodwise", data).then((res) => {
                if (res.status === 200) {
                    setAttendanceSumTableData(res.data.Table)
                    setAttendanceSumData(res.data.Table1);
                    setLoading(false)
                }
            });
        }
    }
    const dataArraytableSumData = attendanceSumTableData.map(
        (i, index) => ({
            startdate: i.StartDate,
            enddate: i.EndDate,
            totaldays: i.TotalDays,
            total_working_days: i.TotalWorkingDays,
            holidays: i.Holidays,
            expecting_hrs: i.ExpectedWorkingHrs,
            id: index,
        }),
    );
    const columnsSumData = [
        { key: 'startdate', title: 'Start Date', dataType: DataType.String },
        { key: 'enddate', title: 'End Date', dataType: DataType.String },
        { key: 'totaldays', title: 'Total Days', dataType: DataType.String },
        { key: 'total_working_days', title: 'Total Working Days', dataType: DataType.String },
        { key: 'holidays', title: 'Holidays', dataType: DataType.String },
        { key: 'expecting_hrs', title: 'Expecting Hours', dataType: DataType.String }
    ]
    const dataArraytableSumDataa = attendanceSumData.map(
        (i, index) => ({
            employeeId: i.EmployeeId,
            fullname: i.Fullname,
            date_of_employment: i.date_of_employment,
            worked_days: i.TotalWorkingDays,
            worked_hrs: i.worked_hrs,
            break_hrs: i.break_hrs,
            leave_hrs: i.leave_hrs,
            leave_days: i.leave_days,
            id: index,
        }),
    );

    const columnsSumDataa = [
        { key: 'employeeId', title: 'Employee Id', dataType: DataType.String },
        { key: 'fullname', title: 'Full Name', dataType: DataType.String },
        { key: 'date_of_employment', title: 'Date of Employment', dataType: DataType.String },
        { key: 'worked_days', title: 'Days Worked', dataType: DataType.String },
        { key: 'worked_hrs', title: 'Worked Hours', dataType: DataType.String },
        { key: 'break_hrs', title: 'Break Hours', dataType: DataType.String },
        { key: 'leave_hrs', title: 'Leave Hours', dataType: DataType.String },
        { key: 'leave_days', title: 'Leave Days', dataType: DataType.String },

    ]

    const csvData = [

        columnsSumData.map(col => col.title),

        ...dataArraytableSumData.map(item => [
            item.startdate,
            item.enddate,
            item.totaldays,
            item.total_working_days,
            item.holidays,
            item.expecting_hrs,
        ]),
        [],
        columnsSumDataa.map(col => col.title),

        ...dataArraytableSumDataa.map(item => [
            item.employeeId,
            item.fullname,
            item.date_of_employment,
            item.worked_days,
            item.worked_hrs,
            item.break_hrs,
            item.leave_hrs,
            item.leave_days,
        ]),
    ];

    // CSV file name
    const csvReport = {
        filename: 'Attendance_Monthly_Summary.csv',
        headers: [],
        data: csvData,
    };
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Summary Report</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
           {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className="header d-flex row flex-wrap">
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Reports</Breadcrumb.Item>
                            <Breadcrumb.Item active>Summary</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <ysecButton type="button" className={`sm history`} onClick={() => {
                            setFromDate("")
                            setToDate("")
                            setSearchText("")
                            setBrandData([])
                            setBrandId(null)
                            setSumData([])
                            setSelectMonthh('')
                            setPeriodData([])
                            setEmpData([])
                            setGetMonthReportData([])
                            setEmpId(null)
                            setAttendanceSumData([])
                            setAttendanceSumTableData([])
                            getData()
                            peroidMonthData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>

                <div className="d-flex justify-content-sm-end justify-content-center m-1 gap-1 flex-wrap">
                    <YsecRadio
                        label="Daily"
                        name="checkBtn"
                        id="btn1"
                        value={1}
                        checked={checkBtn == 1}
                        onChange={(e) => {
                            setFromDate("")
                            setCheckBtn(e.target.value)
                        }}
                    />
                    <YsecRadio
                        label="Monthly"
                        name="checkBtn"
                        id="btn2"
                        value={2}
                        checked={checkBtn == 2}
                        onChange={(e) => setCheckBtn(e.target.value)}
                    />
                    <YsecRadio
                        label="Attendance Monthly Summary"
                        name="checkBtn"
                        id="btn3"
                        value={3}
                        checked={checkBtn == 3}
                        onChange={(e) => {
                            setFromDate("")
                            setCheckBtn(e.target.value)
                        }}
                    />
                </div>

                <div className="report_contaainer" ref={printRef}>
                    {checkBtn == 1 && <>
                        <Row className="m-1 p-2 bg-white">
                            <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                                <YsecSelect className="md"
                                    objectNameKey="brandName"
                                    objectValueKey="brandId"
                                    data={[
                                        { brandId: "", brandName: "Select Brand" },
                                        ...brandData.map(i => ({
                                            brandId: i.BrandId,
                                            brandName: i.Brand
                                        }))

                                    ]}
                                    onChange={(e) => setBrandId(e.target.value)}
                                />
                            </Col>

                            <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                                <YsecDatePicker
                                    // label="Select From-To Date"
                                    mandatory="true"
                                    error="test message"
                                    onChange={onChangeFun}
                                    // value={fromDate === "" ? "" : [fromDate, toDate]}
                                    value={fromDate}
                                    placeholder="Select Date"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y"
                                    ysecType="tab"
                                    ysecFormat="YYYY-MM-DD"
                                    wrapperClass
                                    multipleSelect={false}

                                />
                            </Col>
                            <Col xs={12} sm={6} lg={1} className="mt-1 mb-1">
                                <YsecButton className="btnn w-100" onClick={getSummaryData}>
                                    Submit
                                </YsecButton>
                            </Col>
                            {/* <Col xs={12} sm={6} lg={1} className=' mt-1 mb-1 csv'> */}
                            <Col xs={12} sm={6} lg={1} className=' mt-1 mb-1 '>

                                <CSVLink
                                    className="btnn csvbtn w-100"
                                    data={dataArray}
                                    headers={columns.map(c => ({ label: c.title, key: c.key }))}
                                    filename='SummaryReport.csv'
                                    enclosingCharacter={''}
                                    separator={';'}
                                >
                                    Export
                                </CSVLink>

                            </Col>
                            <Col xs={12} sm={6} lg={2} className=' mt-1 mb-1'>
                                <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                    setSearchText(event.target.value);
                                }} /></Col>

                        </Row>

                        <div className="katable">
                            <Table

                                columns={columns}
                                data={dataArray}
                                rowKeyField={'id'}
                                searchText={searchText}
                                noData={{
                                    text: 'No Data Found'
                                }}
                            />
                        </div>
                    </>}

                    {checkBtn == 2 && <>
                        <Row className="m-1 p-2 bg-white">
                            <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                                <YsecSelect className="md"
                                    objectNameKey="brandName"
                                    objectValueKey="brandId"
                                    data={[
                                        { brandId: "", brandName: "Select Brand" },
                                        ...brandData.map(i => ({
                                            brandId: i.BrandId,
                                            brandName: i.Brand
                                        }))

                                    ]}
                                    onChange={(e) => setBrandId(e.target.value)}
                                />
                            </Col>

                            <Col xs={12} sm={6} lg={3} className="mt-1 mb-1">
                                <YsecSelect className="md"
                                    objectNameKey="PeriodDescription"
                                    objectValueKey="SalaryPeriod"
                                    data={[
                                        { SalaryPeriod: "", PeriodDescription: "Sarlary Period" },
                                        ...periodData.map(i => ({
                                            SalaryPeriod: i.SalaryPeriod,
                                            PeriodDescription: i.PeriodDescription
                                        }))

                                    ]}
                                    onChange={(e) => setSelectMonthh(e.target.value)}
                                />
                            </Col>

                            <Col xs={12} sm={6} lg={1} className="mt-1 mb-1">
                                <YsecButton className="btnn w-100" onClick={() => {
                                    setGetMonthReportData([])
                                    getEveryEmpData()
                                }}>
                                    Submit
                                </YsecButton>
                            </Col>
                            <Col xs={12} sm={6} lg={1} className=' mt-1 mb-1 csv'>
                                {/* <Col xs={12} md={6} lg={1} className=' mt-1 mb-1 '> */}


                                <CSVLink
                                    className="btnn csvbtn w-100"
                                    data={monthreportData}
                                    headers={headers}
                                    filename='MonthSummaryReport.csv'
                                    enclosingCharacter={''}
                                    separator={';'}
                                >
                                    Export
                                </CSVLink>

                            </Col>
                            <Col xs={12} sm={6} lg={2} className=' mt-1 mb-1'>
                                <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                    setSearchText(event.target.value);
                                }} /></Col>

                        </Row>

                        <div className="katable">

                            {monthreportData?.length !== 0 && <table>
                                <thead>
                                    <tr className="monthheader">
                                        {headers.map((header) => (
                                            <th key={header} >
                                                {header}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {monthreportData.map((item, index) => (
                                        <tr key={index}>
                                            {headers.map((header) => (
                                                <td key={header} className="monthbodydata">
                                                    {item[header]}
                                                </td>
                                            ))}
                                        </tr>
                                    ))}
                                </tbody>
                            </table>}
                        </div>
                    </>}

                    {checkBtn == 3 && <>
                        <Row className="m-1 p-2 bg-white">
                            <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                                <YsecSelect className="md"
                                    objectNameKey="brandName"
                                    objectValueKey="brandId"
                                    data={[
                                        { brandId: "", brandName: "Select Brand" },
                                        ...brandData.map(i => ({
                                            brandId: i.BrandId,
                                            brandName: i.Brand
                                        }))

                                    ]}
                                    onChange={(e) => setBrandId(e.target.value)}
                                />
                            </Col>

                            <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                                <YsecDatePicker
                                    // label="Select From-To Date"
                                    mandatory="true"
                                    error="test message"
                                    onChange={onChangeFunDates}
                                    value={fromDate === "" ? "" : [fromDate, toDate]}

                                    placeholder="Select From - To Date"
                                    ysecMinDate="1000_Y"
                                    ysecMaxDate="1000_Y"
                                    ysecType="tab"
                                    ysecFormat="YYYY-MM-DD"
                                    wrapperClass
                                    multipleSelect={true}

                                />
                            </Col>
                            <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                                <YsecSelect className="md"
                                    objectNameKey="employee_name"
                                    objectValueKey="employeeId"
                                    data={[
                                        { employeeId: "", employee_name: "Select Employee" },
                                        ...empData.map(i => ({
                                            employeeId: i.EmployeeId,
                                            employee_name: i.FullName
                                        }))
                                    ]}
                                    onChange={(e) => setEmpId(e.target.value)}
                                />
                            </Col>
                            <Col xs={12} sm={6} lg={2} className="mt-1 mb-1">
                                <YsecButton className="btnn w-100" onClick={getAttendanceSummary}>
                                    Submit
                                </YsecButton>
                            </Col>
                            <Col xs={12} sm={6} lg={1} className=' mt-1 mb-1 csv'>
                                {/* <Col xs={12} sm={6} lg={1} className=' mt-1 mb-1 '> */}

                                <CSVLink
                                    className="btnn csvbtn w-100"
                                    {...csvReport}

                                    enclosingCharacter={''}
                                    separator={';'}
                                >
                                    Export
                                </CSVLink>
                            </Col>
                            <Col xs={12} sm={6} lg={3} className=' mt-1 mb-1'>
                                <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                    setSearchText(event.target.value);
                                }} /></Col>

                        </Row>

                        <div className="katable">
                            <Table

                                columns={columnsSumData}
                                data={dataArraytableSumData}
                                rowKeyField={'id'}
                                searchText={searchText}
                                noData={{
                                    text: 'No Data Found'
                                }}
                            />

                        </div>
                        <div className="katable">
                            <Table

                                columns={columnsSumDataa}
                                data={dataArraytableSumDataa}
                                rowKeyField={'id'}
                                searchText={searchText}
                                noData={{
                                    text: 'No Data Found'
                                }}
                            />
                        </div>
                    </>}
                </div>
            </React.Suspense>
        </div>
    )
}

export default Summary_Report;

