import React, { useEffect, useState } from 'react'
import { Col, Modal, Row } from 'react-bootstrap'
import AxiosLayout from '../../apis/axios';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
function ApplyLetter(props) {
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [err, setErr] = useState(0)
  const [alertMessage, setAlertMessage] = useState('');
  const [letterTypes, setLetterTypes] = useState([]);
  const [req_date, setReqDate] = useState("")
  const [selectedLetterTypeId, setSelectedLetterTypeId] = useState("");
  const [reason, setReason] = useState("")
  const [selectCompany, setSelectCompany] = useState("")
  const [companyData, setCompanyData] = useState([])
  const [comp_desc, setCompDesc] = useState("")
  const [address, setAddress] = useState("")

  const today = new Date();
  const currentDate = today.toISOString().split('T')[0];
  useEffect(() => {
    AxiosLayout.get(`/Letter/GetLetterType?UserId=${userId?.user}`).then((res) => {
      setLetterTypes(res.data?.LetterTypes);
      setCompanyData(res.data?.Company)
    });

  }, []);
  const handleSubmit = async (e) => {
    e.preventDefault();
    setErr(0)
    if (req_date === "") {
      setErr(1)
    }
    else if (selectedLetterTypeId === "") {
      setErr(2)
    }
    else if (reason === "") {
      setErr(3)
    }
    else if (Number(selectedLetterTypeId) === 1 && selectCompany === "") {
      setErr(4)
    }
    else if (Number(selectedLetterTypeId) === 2 && comp_desc === "") {
      setErr(5)
    }
    else if (Number(selectedLetterTypeId) === 2 && address === "") {
      setErr(6)
    }
    else {
      const data = {
        requestID: 0,
        employeeID: userId?.user,
        employee: userId?.userName,
        letterTypeID: Number(selectedLetterTypeId),
        letterType: "",
        applyDate: currentDate,
        institutionID: Number(selectCompany),
        institution: "",
        requestReason: reason,
        companyName: comp_desc,
        companyAddress: address,
        statusID: 1,
        status: "",
        locationID: 0,
        hierarchyID: userId?.companyId
      }
      AxiosLayout.post("/Letter/SaveLetterRequest", data).then(res => {
        if (res.data.Status === 1) {
          props.handleOpen()
          setSelectCompany("")
          setCompDesc("")
          setAddress("")
          setSelectedLetterTypeId("")
          setReason("")
          setReqDate("")
          props?.getLetterData()
        }
      })
    }
  }
  return (
    <Modal
      {...props}
      size="xl"
      aria-labelledby="contained-modal-title-vcenter"
      centered
    >
      <Modal.Header>
        <p className="modal-title" id="exampleModalLabel">Apply Letter</p>
        <button type="button" className="btn-close" onClick={props.handleOpen} aria-label="Close"></button>
      </Modal.Header>

      <Modal.Body>
        <Row>
          <Col xs={12} md={6}>
            <YsecDatePicker
              name="req_date"
              error="test message"
              onChange={(e) => setReqDate(e.target.value)}
              value={req_date}
              placeholder="YYYY-MM-DD"
              ysecMinDate="1_D"
              ysecMaxDate="1_Y"
              ysecType="tab"
              ysecFormat="YYYY-MM-DD"
              wrapperClass
              multipleSelect={false}
              label="Requested Date"
              mandatory

            />
            {err === 1 && <label className='error'>Please Select Requested Date...</label>}
          </Col>
          <Col xs={12} md={6}>
            <YsecSelect label="Letter Type" mandatory
              className="select"
              objectNameKey="LetterDescription"
              objectValueKey="LetterTypeId"
              data={[
                { LetterTypeId: "", LetterDescription: "Select Letter Type" },
                ...letterTypes.map(i => ({
                  LetterTypeId: i.ID,
                  LetterDescription: i.LetterType
                }))
              ]}
              onChange={(e) => {
                setSelectCompany("")
                setCompDesc("")
                setAddress("")
                setSelectedLetterTypeId(e.target.value)
              }}
            />
            {err === 2 && <label className='error'>Please Select Leave Type...</label>}
          </Col>
          <Col xs={12} md={6}>
            <YsecTextarea label="Reason" name="reason" value={reason} onChange={(e) => setReason(e.target.value)} mandatory />
            {err === 3 && <label className='error'>Please Enter Reason...</label>}
          </Col>
          {Number(selectedLetterTypeId) === 1 && <Col xs={12} md={6}>
            <YsecSelect label="To" mandatory
              className="select"
              objectNameKey="copmanyName"
              objectValueKey="Id"
              data={[
                { Id: "", copmanyName: "Select" },
                ...companyData.map(i => ({
                  Id: i.ID,
                  copmanyName: i.Company
                }))
              ]}
              onChange={(e) => setSelectCompany(e.target.value)}
            />
            {err === 4 && <label className='error'>Please Select To Employee...</label>}
          </Col>}
          {Number(selectedLetterTypeId) === 2 && <>
            <Col xs={12} md={6}>
              <YsecTextarea label="Company" name="comp_desc" value={comp_desc} onChange={(e) => setCompDesc(e.target.value)} mandatory />
              {err === 5 && <label className='error'>Please Enter Company...</label>}
            </Col>
            <Col xs={12} md={6}>
              <YsecTextarea label="Address" name="address" value={address} onChange={(e) => setAddress(e.target.value)} mandatory />
              {err === 6 && <label className='error'>Please Enter Address...</label>}
            </Col></>}
        </Row>

      </Modal.Body>

      <Modal.Footer>
        <YsecButton type="button" onClick={props.handleOpen} className="cancel">Cancel</YsecButton>
        <YsecButton type="button" onClick={handleSubmit}>Submit</YsecButton>
      </Modal.Footer>

    </Modal>
  )
}

export default ApplyLetter