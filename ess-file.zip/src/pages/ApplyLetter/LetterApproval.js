import React, { useEffect, useRef, useState } from 'react'
import "./ApplyLetter.scss"
import { Breadcrumb, Button, Modal, Overlay, Tooltip } from 'react-bootstrap';
import { DataType, Table, } from 'ka-table';
import AxiosLayout from '../../apis/axios';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox"))


function LetterApproval() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [searchText, setSearchText] = useState('');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);
    const printRef = useRef();
    const [letterData, setLetterData] = useState([])

    useEffect(() => {
        getData();
    }, []);
    const getData = async () => {
        await AxiosLayout.get(`/Letter/GetLetterRequest?EmployeeId=${userId.user}&IsManager=1`).then((res) => {
            setLetterData(res.data)
        });
    }
    if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Advance Approval</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };

    const dataArray = letterData.map(i => ({
        employeeId: i.EmployeeID,
        emp_name: i.Employee,
        letter_type: i.LetterType,
        apply_date: i.ApplyDate,
        institution: i.Institution,
        reason: i.RequestReason,
        companyname: i.CompanyName,
        address: i.CompanyAddress,
        status: i.Status,
        id: i.RequestID
    }));
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

    const [currentRowKey, setCurrentRowKey] = useState(null);
    const [currentAction, setCurrentAction] = useState({ rowKey: null, action: null });
    const ApproveAction = ({ rowKey, currentRowKey, setCurrentRowKey, }) => {
        const show = rowKey === currentRowKey && currentAction.action === "approve";
        const tooltipRef = useRef(null); // Create a ref for the tooltip
        const [appReason, setAppReason] = useState("")
        const handleOpenTooltp = () => {
            if (show) {
                setCurrentRowKey(null);
                setCurrentAction({ rowKey: null, action: null });
            } else {
                setCurrentRowKey(rowKey);
                setCurrentAction({ rowKey, action: "approve" });
            }

        }

        const filData = letterData.filter(i => i.RequestID == Number(rowKey));
        const reqId = filData[0]?.RequestID;


        return (
            <span ref={tooltipRef}>
                <YsecButton className="sm approve" onClick={handleOpenTooltp}>
                    Approve
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${reqId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                    <p>Are you sure you want to approve?</p>
                                    <div className='apbtn'>
                                        <YsecButton className="sm approve mb-2" onClick={async () => {
                                            const data = {
                                                requestId: Number(rowKey),
                                                statusId: 3,
                                                accepted: filData[0].EmployeeID,
                                                userId: userId.user
                                            }
                                            await AxiosLayout.post("/Letter/CancelLetterRequest", data).then(res => {
                                                if (res.data.Status === 1) {
                                                    getData()
                                                    setCurrentRowKey(null);
                                                } else {
                                                    // alert('error')
                                                    setCurrentRowKey(null);
                                                }
                                            });
                                        }}>Approve</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    };
    const DeleteAction = ({ rowKey, currentRowKey, setCurrentRowKey, }) => {
        const show = rowKey === currentRowKey && currentAction.action === "cancel";
        const tooltipRef = useRef(null);
        const handleOpenTooltp = () => {
            if (show) {
                setCurrentRowKey(null);
                setCurrentAction({ rowKey: null, action: null });
            } else {
                setCurrentRowKey(rowKey);
                setCurrentAction({ rowKey, action: "cancel" });
            }

        }

        const filData = letterData.filter(i => i.RequestID == Number(rowKey));
        const reqId = filData[0]?.RequestID;


        return (
            <span ref={tooltipRef}>
                <YsecButton className="sm cancell" onClick={handleOpenTooltp}>
                    Cancel
                </YsecButton>
                <Overlay
                    target={tooltipRef.current}
                    show={show}
                    placement="bottom"
                >
                    {(props) => (
                        <Tooltip id={`tooltip-approve-${reqId}`} {...props}>
                            <div className='toolform'>
                                <div className='toolform-container'>
                                    <p>Are you sure you want to Cancel?</p>
                                    <div className='apbtn'>
                                        <YsecButton className="sm cancell mb-2" onClick={async () => {
                                            const data = {
                                                requestId: Number(rowKey),
                                                statusId: 2,
                                                accepted: filData[0].EmployeeID,
                                                userId: userId.user
                                            }
                                            await AxiosLayout.post("/Letter/CancelLetterRequest", data).then(res => {
                                                if (res.data.Status === 1) {
                                                    getData()
                                                    setCurrentRowKey(null);
                                                } else {
                                                    // alert('error')
                                                    setCurrentRowKey(null);
                                                }
                                            });
                                        }}>Cancel</YsecButton>
                                    </div>
                                </div>
                            </div>
                        </Tooltip>
                    )}
                </Overlay>
            </span>
        );
    };
    return (
        <div className="p-1">
            <React.Suspense fallback={<>Loading...</>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Approval</Breadcrumb.Item>
                            <Breadcrumb.Item active>Letter Approval</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={() => {
                            setSearchText("")
                            setLetterData([])
                            getData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                <div className='lettercontainer'>


                    <div class="d-flex flex-wrap row m-1 p-2 bg-white">
                        <div class="col-12 col-sm-12 p-1">
                            <YsecInput placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>

                    </div>
                    <div className='katable' ref={printRef}>
                        <Table
                            columns={[
                                { key: 'employeeId', title: 'Employee ID', dataType: DataType.String },
                                { key: 'letter_type', title: 'Letter Type', dataType: DataType.String },
                                { key: 'apply_date', title: 'Apply Date', dataType: DataType.String },
                                { key: 'institution', title: 'Institution', dataType: DataType.String },
                                { key: 'reason', title: 'Request Reason', dataType: DataType.String },
                                { key: 'companyname', title: 'Company Name', dataType: DataType.String },
                                { key: 'address', title: 'Company Address', dataType: DataType.String },
                                { key: 'status', title: 'Status', dataType: DataType.String },
                                { key: 'action', title: 'Approve', dataType: DataType.String },
                                { key: 'action2', title: 'Cancel', dataType: DataType.String },



                            ]}
                            data={paginatedData}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {
                                            case 'action2':
                                                return <DeleteAction {...props} rowKey={props.rowKeyValue}
                                                    currentRowKey={currentRowKey} setCurrentRowKey={setCurrentRowKey} currentAction={currentAction} setCurrentAction={setCurrentAction} />;
                                            case 'action':
                                                return <ApproveAction  {...props} rowKey={props.rowKeyValue}
                                                    currentRowKey={currentRowKey} setCurrentRowKey={setCurrentRowKey} currentAction={currentAction} setCurrentAction={setCurrentAction} />
                                            default:
                                                return props.children;
                                        }

                                    },
                                },


                            }}
                        />
                    </div>
                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>



            </React.Suspense>
        </div>
    )
}

export default LetterApproval