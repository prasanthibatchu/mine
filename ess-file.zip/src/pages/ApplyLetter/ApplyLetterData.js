import './ApplyLetter.scss'
import React, { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AxiosLayout from '../../apis/axios';

import { DataType, Table, useTableInstance } from 'ka-table';

import { Breadcrumb, Modal } from 'react-bootstrap';
import ApplyLetter from './ApplyLetter';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value?.split(" ")[0] === "Rejected" && 'rejected') || (value?.split(" ")[0] === "Open" && "open") || value?.split(" ")[0] === "Cancelled" && "cancelled" || value?.split(" ")[0] === "Approved" && 'approved' || value?.split(" ")[0] === "InProgress" && "open" || value?.split(" ")[0] === "Verified" && 'approved'}
        >
            {value}
        </div>
    );
};
function ApplyLetterData() {

    const userId = JSON.parse(localStorage.getItem('_user'));
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [open, setOpen] = useState(false);
    const [leaveTypes, setLeaveTypes] = useState([]);
    const [searchText, setSearchText] = useState('');
    const [openDeletLeave, setOpenDeletLeave] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(20);
    const [alertMessage, setAlertMessage] = useState('');
    const [letterData, setLetterData] = useState([])
    const handleOpen = () => setOpen(!open);
    const handleOpenDeleteLeave = () => setOpenDeletLeave(!openDeletLeave);
    const [selectReqId, setSelectReqId] = useState(null)
    const printRef = useRef();
    useEffect(() => {
        if (alertMessage) {
            const timer = setTimeout(() => {
                setAlertMessage(''); // Clear the alert message after 5 seconds
            }, 1000);

            // Cleanup the timer on component unmount or when alertMessage changes
            return () => clearTimeout(timer);
        }
    }, [alertMessage]);
    useEffect(() => {
        getLetterData()
    }, [])
    const getLetterData = () => {
        setLoading(true)
        AxiosLayout.get(`/Letter/GetLetterRequest?EmployeeId=${userId.user}&IsManager=0`).then((res) => {
            if (res.status === 200) {
                setLetterData(res.data)
                setLoading(false)
            }
        })
    }
    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;



    const dataArray = letterData.map(i => ({
        employeeId: i.EmployeeID,
        emp_name: i.Employee,
        letter_type: i.LetterType,
        apply_date: i.ApplyDate,
        institution: i.Institution,
        reason: i.RequestReason,
        companyname: i.CompanyName,
        address: i.CompanyAddress,
        status: i.Status,
        id: i.RequestID
    }));


    const DeleteAction = ({ dispatch, rowKeyValue, approvalStatus }) => {
        const isDisabled = approvalStatus === "Open";
        return (<>
            <YsecFont className={`yf-delete-bin-2 ${isDisabled ? 'action-icon' : 'no-action'}`}
                onClick={() => {
                    if (isDisabled) {
                        const deleteData = letterData.filter(i => i.RequestID == rowKeyValue);
                        setSelectReqId(deleteData[0]?.RequestID)
                        handleOpenDeleteLeave()
                    };
                }}
            />
        </>)
    }
    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);

    const handleCancelLeave = async (e) => {
        e.preventDefault();
        const data = {
            requestId: selectReqId,
            statusId: 2,
            accepted: userId.user,
            userId: userId.user
        }
        AxiosLayout.post("/Letter/CancelLetterRequest", data).then(res => {
            if (res.data.Status === 1) {
                handleOpenDeleteLeave()
                getLetterData()
            }
        })
    }
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Letter Details</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                {alertMessage && (
                    <div class="alert alert-success" role="alert">
                        {alertMessage}
                    </div>
                )}
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Leave Application Details</Breadcrumb.Item>
                            <Breadcrumb.Item active>Letter Details</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>
                        <YsecButton type="button" className={`sm btn leave ${open === false ? "btn-outline-primary" : "history"} `} onClick={handleOpen}>
                            <YsecFont className='yf-plus-add' />
                        </YsecButton>
                        <ysecButton type="button" className={`sm  ${open === true ? "btn-outline-primary" : "history"}`} onClick={() => {
                            setSearchText("")
                            getLetterData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>

                    </div>

                </div>

                {open && (
                    <ApplyLetter show={open} handleOpen={handleOpen} setAlertMessage={setAlertMessage} getLetterData={getLetterData} />

                )}
                <div className='lettercontainer'>


                    <div class="d-flex flex-wrap row m-1 p-2 bg-white">
                        <div class="col-12 col-sm-12 p-1">
                            <YsecInput placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>

                    </div>
                    <div className='katable' ref={printRef}>
                        <Table
                            columns={[
                                { key: 'employeeId', title: 'Employee ID', dataType: DataType.String },
                                { key: 'letter_type', title: 'Letter Type', dataType: DataType.String },
                                { key: 'apply_date', title: 'Apply Date', dataType: DataType.String },
                                { key: 'institution', title: 'Institution', dataType: DataType.String },
                                { key: 'reason', title: 'Request Reason', dataType: DataType.String },
                                { key: 'companyname', title: 'Company Name', dataType: DataType.String },
                                { key: 'address', title: 'Company Address', dataType: DataType.String },
                                { key: 'status', title: 'Status', dataType: DataType.String },
                                { key: 'action', title: 'Action', dataType: DataType.String },


                            ]}
                            data={paginatedData}
                            rowKeyField={'id'}
                            searchText={searchText}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {
                                            case 'action':
                                                return <DeleteAction {...props} approvalStatus={props.rowData.status} />;
                                            case 'status':
                                                return <CustomCell  {...props} />
                                            default:
                                                return props.children;
                                        }

                                    },
                                },


                            }}
                        />
                    </div>
                    <div className='pagination'>
                        <span className='pageselect'>
                            <YsecSelect
                                objectNameKey="pageDescription"
                                objectValueKey="pageNumber"
                                data={pageNumbers.map(number => ({
                                    pageNumber: number,
                                    pageDescription: `Page ${number.toString()}`
                                }))}
                                className="sm"
                                onChange={(e) => {
                                    const selectedPage = Number(e.target.value);
                                    setCurrentPage(selectedPage);
                                }}
                            />
                        </span>

                        <span>{startRange}-{endRange} of {totalItems}</span>
                        <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage > 1) {
                                    setCurrentPage(prev => prev - 1);
                                }
                            }}
                        />
                        <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                            onClick={() => {
                                if (currentPage < totalPages) {
                                    setCurrentPage(prev => prev + 1);
                                }
                            }}
                        />
                    </div>
                </div>
                {openDeletLeave && (
                    <Modal
                        show={openDeletLeave}
                        size="md"
                        aria-labelledby="contained-modal-title-vcenter"
                        centered
                    >
                        <Modal.Header>
                            <p className="modal-title" id="exampleModalLabel">Cancel Letter</p>
                            <button type="button" className="btn-close" onClick={handleOpenDeleteLeave} aria-label="Close"></button>
                        </Modal.Header>
                        <Modal.Body>
                            <h6 className='deleteleave'>Please confirm the selected Letter details will be delete!!!</h6>
                        </Modal.Body>
                        <Modal.Footer>
                            <YsecButton type="button" onClick={handleOpenDeleteLeave} className='cancel'>Cancel</YsecButton>

                            <YsecButton type="button" className="btn-danger confirm" onClick={handleCancelLeave}>Confirm</YsecButton>

                        </Modal.Footer>

                    </Modal>
                )}
            </React.Suspense>
        </div>
    );
};

export default ApplyLetterData