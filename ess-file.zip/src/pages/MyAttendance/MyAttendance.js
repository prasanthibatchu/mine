import React, { useEffect, useRef, useState } from 'react'
import './Myattendance.scss'
import { Breadcrumb, Col, Row } from 'react-bootstrap'
import { DataType, Table, useTableInstance } from 'ka-table';
import { PunchCountHistory } from './punchCountHistory';
import AxiosLayout from '../../apis/axios';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

const CustomCell = ({ column, rowKeyValue, value, getPunchDeatails, rowData, status, userid }) => {

    const [showModal, setShowModal] = useState(false);
    const timeThreshold = timeToMinutes("9:00");
    const workTimeThreshold = timeToMinutes("7:40");
    const currentTime = timeToMinutes(value);

    return (
        <div>


            {column.key === 'total_time' && <div className={((currentTime < timeThreshold && status === 'P') ? "time" : "")}>{value}</div>}
            {column.key === 'work_time' && <div className={((currentTime < workTimeThreshold && status === 'P') ? "time" : "")}>{value}</div>}
            {column.key === 'punch_count' && (
                <div className={value > 1 ? (Number(userid) == 78 && "count") : ""}>
                    {value > 1 ? (
                        <p onClick={() => { if (Number(userid) == 78) { getPunchDeatails(rowData) } }}>
                            {value % 2 === 0 ? value : `Incorrect Punch - ${value}`}
                        </p>
                    ) : value % 2 === 0 ? value : `Incorrect Punch - ${value}`}
                </div>
            )}



        </div>
    );
};
const timeToMinutes = (time) => {
    if (typeof time !== 'string' || !time.includes(':')) {
        console.error('Invalid time format:', time);
        return 0;
    }
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
};

// const timeToMinutes = (time) => {
//     const [hours, minutes] = time?.split(':').map(Number);
//     return hours * 60 + minutes;
// };
const MyAttendance = () => {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [selectEmpId, setSelectEmpId] = useState('')
    const [search, setSearch] = useState('')
    const today = new Date();
    const currentDate = today?.toISOString()?.split('T')[0];
    const [fromDate, setFromDate] = useState(currentDate);
    const [toDate, setToDate] = useState(currentDate);
    const [att_data, setAtt_data] = useState([])
    const [teamMembers, setTeamMembers] = useState([])
    const [punchData, setPunchData] = useState([])
    const [showModal, setShowModal] = useState(false);
    const [selectedEmp, setselectedEmp] = useState("")
    const handleShow = () => setShowModal(!showModal);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const printRef = useRef();
    let isMounted = true;
    useEffect(() => {

        getTeamMembers();
        getAttData();

        return () => {
            isMounted = false;
        };
    }, []);

    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
    const getTeamMembers = async () => {
        const res = await AxiosLayout.get(`/Leave/GetTeamMembers?ManagerId=${userId?.user}&CompanyId=${userId?.companyId}`);
        if (isMounted) {
            setTeamMembers(res.data);
        }
    };

    const getAttData = async () => {
        setLoading(true)
        const td = teamMembers.find((i) => i.EmployeeId === userId.user)

        const data = {
            // leadview: teamMembers?.length < 2 ?  0 : 1,
            leadview: teamMembers?.length < 2
                ? (selectEmpId == userId.user ? 0 : 0)
                : (td?.Name === "All" ? 1 : 0),
            employeeId: selectEmpId !== "" ? Number(selectEmpId) : userId.user,
            fromDate: fromDate,
            toDate: toDate,
            userId: userId.user,
        };
        const res = await AxiosLayout.post("/Report/GetAttendanceDetails", data);
        if (isMounted && res.status === 200) {
            setAtt_data(res.data);
            setLoading(false)
        }
    };
    const getAttData2 = async (from, to) => {
         setLoading(true)
        const td = teamMembers.find((i) => i.EmployeeId === userId.user)

        const data = {
            // leadview: teamMembers?.length < 2 ?  0 : 1,
            leadview: teamMembers?.length < 2
                ? (selectEmpId == userId.user ? 0 : 0)
                : (td?.Name === "All" ? 1 : 0),
            employeeId: selectEmpId !== "" ? Number(selectEmpId) : userId.user,
            fromDate: from,
            toDate: to,
            userId: userId.user,
        };
        const res = await AxiosLayout.post("/Report/GetAttendanceDetails", data);
        if (isMounted && res.status === 200) {
            setAtt_data(res.data);
             setLoading(false)
        }
    };
    const getPunchDeatails = async (data) => {
        setLoading(true)
        const datee = data?.date
        const year = datee?.split("-")[2]
        const month = datee?.split("-")[1]
        const day = datee?.split("-")[0]
        const formattedDate = `${year}-${month}-${day}`;
        await AxiosLayout.get(`/Report/GetPunchingDetails?AtnDate=${formattedDate}&EmployeeId=${data?.employeeId}&UserId=${userId?.user}`).then((res) => {
            setPunchData(res?.data);
            setselectedEmp(data?.emp_name)
            setShowModal(true)
            setLoading(false)
        });
    }


    const dataArray = att_data.map((i, index) => {

        return {
            employeeId: i.EmployeeId,
            emp_name: i.FullName,
            date: i.Date?.split(" ")[0],
            first_in: i.IN1,
            last_out: i.LastOut,
            total_time: i.TotalTime,
            work_time: i.ActualTime.split('@')[0],
            break_time: i.ActualTime.split('@')[1],
            punch_count: i.PunchCount,
            status: i.Status,
            id: index
        }
    });

    const onChangeFun = (e) => {
        const dateRange = e.target.value;

        if (dateRange) {
            const dates = dateRange?.split(' to ');
            if (dates.length === 2) {
                const startDate = dates[0].trim();
                const endDate = dates[1].trim();
                const formattedStartDate = startDate?.split('/').reverse().join('-');
                const formattedEndDate = endDate?.split('/').reverse().join('-');
                setFromDate(formattedStartDate);
                setToDate(formattedEndDate);

            } else {
                console.error('Invalid date range format. Please use "DD/MM/YYYY to DD/MM/YYYY".');
            }
        }
    };

    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Attendance Details</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    const sortedTeamMembers = [
  // First, the matching element
  ...teamMembers?.filter(leave => leave.EmployeeId === userId?.user),
  // Then, all others (excluding the matching one to avoid duplicates)
  ...teamMembers?.filter(leave => leave.EmployeeId !== userId?.user)
];
    return (
        <div className="p-1">
            {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">Personal Information</Breadcrumb.Item>
                            <Breadcrumb.Item active>My Attendance</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>
                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm history`} onClick={async () => {
                            setFromDate(currentDate)
                            setToDate(currentDate)
                            setTeamMembers([])
                            setSearch("")
                            setSelectEmpId("")
                            getTeamMembers();
                            await getAttData2(currentDate, currentDate);
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>
                {showModal && (
                    <PunchCountHistory show={showModal} handleShow={handleShow} punchData={punchData} selectedEmp={selectedEmp} />
                )}
                <div className='containerr'>
                    <div class="d-flex  flex-wrap   row m-1 p-2 bg-white">
                        <div class=" col-12 col-md-2 p-1">
                            <YsecSelect className="md"
                                objectNameKey="Name"
                                objectValueKey="EmployeeId"
                                // data={[
                                //     { EmployeeId: userId?.user, Name: "" },
                                //     ...teamMembers.map(leave => ({
                                //         EmployeeId: leave.EmployeeId,
                                //         Name: leave.Name
                                //     }))
                                // ]}
                                 data={sortedTeamMembers.map(leave => ({
                                        EmployeeId: leave.EmployeeId,
                                        Name: leave.Name
                                    }))
                                }
                                onChange={(e) => setSelectEmpId(e.target.value)}
                            />
                        </div>
                        <div class="col-12 col-md-3  p-1">
                            <YsecDatePicker
                                className="md"
                                mandatory="true"
                                error="test message"
                                onChange={onChangeFun}
                                value={fromDate === "" ? "" : [fromDate, toDate]}
                                placeholder="From - To Date"
                                ysecMinDate="36500_D"
                                ysecMaxDate="0_D"
                                ysecType="tab"
                                ysecFormat="YYYY-MM-DD"
                                wrapperClass
                                multipleSelect={true}

                            />
                        </div>
                        <div class="col-12 col-md-1  p-1">
                            <YsecButton className="md w-100 btnn" onClick={getAttData}>Show</YsecButton>
                        </div>
                        <div class="col-12 col-md-6  p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={search} onChange={(event) => {
                                setSearch(event.target.value);
                            }} />
                        </div>

                    </div>


                    <div className='katable' ref={printRef}>
                        <Table
                            columns={[
                                { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
                                { key: "emp_name", title: "Employee Name", dataType: DataType.String, },
                                { key: "date", title: "Date", dataType: DataType.String, },
                                { key: "first_in", title: "First IN", dataType: DataType.String, },
                                { key: "last_out", title: "Last Punch", dataType: DataType.String, },
                                { key: "total_time", title: "Total Time", dataType: DataType.String, },
                                { key: "work_time", title: "Work Time", dataType: DataType.String, visible: userId?.companyId === 78 },
                                { key: "break_time", title: "Break Time", dataType: DataType.String, visible: userId?.companyId === 78 },
                                { key: "punch_count", title: "Punch Count", dataType: DataType.String, },
                                { key: "status", title: "Status", dataType: DataType.String, },

                            ]}
                            data={dataArray}
                            rowKeyField={'id'}
                            searchText={search}
                            noData={{
                                text: 'No Data Found'
                            }}
                            childComponents={{
                                cellText: {
                                    content: (props) => {
                                        switch (props.column.key) {
                                            case 'total_time': {
                                                return <CustomCell {...props} total_time={props?.rowData?.total_time} status={props?.rowData?.status} />;
                                            }

                                            case 'work_time': {
                                                return <CustomCell {...props} work_time={props?.rowData?.work_time} status={props?.rowData?.status} />;
                                            }
                                            case 'punch_count': {
                                                return <CustomCell {...props} punch_count={props?.rowData?.punch_count} getPunchDeatails={getPunchDeatails} rowData={props?.rowData} status={props?.rowData?.status} userid={userId?.companyId} />;
                                            }

                                            default:
                                                return <div >{props?.rowData[props?.column?.key]}</div>;
                                        }
                                    },
                                },
                            }}
                        />
                    </div>
                </div>


            </React.Suspense>
        </div>
    )
}
export default MyAttendance
