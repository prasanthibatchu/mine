import React, { useState } from 'react'
import { Button, Modal } from 'react-bootstrap'
import './Myattendance.scss'
import { DataType, Table, useTableInstance } from 'ka-table';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));


export const PunchCountHistory = (props) => {

    const [attendanceTime, setAttendanceTime] = useState(props?.punchData?.AttendanceTotalTime)
    const dataArray = props?.punchData?.PunchingDetails?.map((i, index) => ({
        entryExit: i.EntryExit,
        punching: i.Punching,
        workTime: i.WorkTime,
        breakTime: i.BreakTime,
        id: index
    }));
    return (

        <Modal
            {...props}
            size="lg"
            aria-labelledby="contained-modal-title-vcenter"
            centered
        >
            <Modal.Header>

                <p className="modal-title" id="exampleModalLabel">Punching Details ({props.selectedEmp} {attendanceTime.Date?.split(" ")[0]})</p>
                <button type="button" className="btn-close" onClick={props.handleShow} aria-label="Close"></button>
            </Modal.Header>
            <Modal.Body>
                <div className='katable'>
                    <Table
                        columns={[
                            { key: "entryExit", title: "Entry Exit", dataType: DataType.String, },
                            { key: "punching", title: "Punching", dataType: DataType.String, },
                            { key: "workTime", title: "Work Time", dataType: DataType.String, },
                            { key: "breakTime", title: "Break Time", dataType: DataType.String, },


                        ]}
                        data={dataArray}
                        rowKeyField={'id'}
                        // searchText={search}
                        noData={{
                            text: 'No Data Found'
                        }}
                    // childComponents={{
                    //     cellText: {
                    //         content: (props) => {

                    //             switch (props.column.key) {
                    //                 case 'toatal_time': {
                    //                     return <CustomCell {...props} toatal_time={props.rowData.toatal_time} />;
                    //                 }


                    //                 default:
                    //                     return <div >{props.rowData[props.column.key]}</div>;
                    //             }
                    //         },
                    //     },
                    // }}
                    />
                </div>
                <div className='punching'>
                    <span className='emptydata'></span>
                    <span className='worktime'>{attendanceTime?.TotalWorkTime}</span>
                    <span className="totaltime">{attendanceTime?.TotalBreakTime}</span>

                </div>
            </Modal.Body>
            <Modal.Footer>
                <YsecButton variant="secondary" onClick={props.handleShow}>
                    Close
                </YsecButton>
            </Modal.Footer>
        </Modal>
    )
}
