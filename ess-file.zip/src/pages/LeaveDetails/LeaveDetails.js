import React, { useEffect, useRef, useState } from 'react'
import './LeaveDetails.scss'
import { Breadcrumb, Col, Row } from 'react-bootstrap';
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import LoadingSpinner from '../Loader/Loader';

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
function LeaveDetails() {
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [searchText, setSearchText] = useState('');
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [leaveDetails, setLeaveDetails] = useState([])
  const [leaveTypes, setLeaveTypes] = useState([]);
  const printRef = useRef();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  useEffect(() => {
    getData()
  }, []);
  const getData = () => {
    setLoading(true)
    AxiosLayout.get(`/Leave/GetLeaveTypes?CompanyId=${userId?.companyId}&UserId=${userId?.user}`).then((res) => {
      setLeaveTypes(res.data);
      setLoading(false)
    });
  }
  // if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  const onChangeFun = (e) => {
    const dateRange = e.target.value;

    if (dateRange) {
      const dates = dateRange.split(' to ');
      if (dates.length === 2) {
        const startDate = dates[0].trim();
        const endDate = dates[1].trim();
        const formattedStartDate = startDate.split('/').reverse().join('-');
        const formattedEndDate = endDate.split('/').reverse().join('-');
        setFromDate(formattedStartDate);
        setToDate(formattedEndDate);

      } else {
        console.error('Invalid date range format. Please use "DD/MM/YYYY to DD/MM/YYYY".');
      }
    }
  };

  const handleLeaveData = () => {
    setLoading(true)
    const data = {
      employeeId: userId?.user,
      startDate: fromDate,
      endDate: toDate,
      companyId: userId?.companyId,
      userId: userId?.user
    }
    AxiosLayout.post('/Leave/LeaveReport', data).then((res) => {
      if (res.status === 200) {
        setLeaveDetails(res.data)
        setLoading(false)
      }
    })
  }

  const dataArray = leaveDetails.map((leave, index) => ({
    employeeId: leave.EmployeeId,
    emp_name: leave.FullName,
    leave_type: leave.LeaveType,
    apply_date: leave.ApplyDate,
    from_date: leave.FromDate,
    to_date: leave.ToDate,
    hours: leave.Hours,
    days: leave.Days,
    remark: leave.Remark,
    id: index
  }));


  const targetLeaveTypeIds = [113, 114, 123];

  const leaveCounts = {
    SL: 0,
    CL: 0,
    LOP: 0,
    Others: 0
  };



  leaveDetails.forEach(leave => {
  const days = Number(leave.Days) || 0;
  if (targetLeaveTypeIds.includes(leave.LeaveTypeId)) {
    if (leave.LeaveTypeId === 113) {
      leaveCounts.SL += days;
    } else if (leave.LeaveTypeId === 114) {
      leaveCounts.CL += days;
    } else if (leave.LeaveTypeId === 123) {
      leaveCounts.LOP += days;
    }
  } else {
    leaveCounts.Others += days;
  }
});

  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Leave Details</title>');
    // Optional: Add your styles here, or link to your CSS file
    printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };


  return (
    <div>
 {loading===true&& <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
        <div className='header d-flex row flex-wrap'>
          <div class="col">
            <Breadcrumb>
              <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
              <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
              <Breadcrumb.Item href="#">Reports</Breadcrumb.Item>
              <Breadcrumb.Item active>Leave Details</Breadcrumb.Item>
            </Breadcrumb>
          </div>
          <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

            <ysecButton type="button" className={`sm history`} onClick={() => {
              setLeaveDetails([])
              setFromDate("")
              setToDate("")
              setSearchText("")
              getData()
              // handleLeaveData()
            }}>
              <YsecFont className="yf-clock" />
            </ysecButton>
            <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
              <YsecFont className="yf-printer-scan" />
            </YsecButton>
          </div>
        </div>
        <div className='leave-details-container'>
          <Row className="m-1 p-2 bg-white">

            <Col className='gap-1 mt-1 mb-1' xs={12} md={10} lg={3} >
              <YsecDatePicker
                mandatory="true"
                error="test message"
                onChange={onChangeFun}
                value={fromDate === "" ? "" : [fromDate, toDate]}
                placeholder="Select Date Range"
                ysecMinDate="1000_Y"
                ysecMaxDate="1000_Y"
                ysecType="tab"
                ysecFormat="YYYY-MM-DD"
                wrapperClass
                multipleSelect={true}
              />
            </Col>

            <Col className='gap-1 mt-1 mb-1' xs={12} md={2} lg={1} >
              <YsecButton className="btnn w-100" onClick={handleLeaveData}>Submit</YsecButton>
            </Col>


            <Col xs={12} md={12} lg={5}>
              <Row>
                <Col xs={12} sm={4} md={3} className='gap-1 mt-1 mb-1'>
                  <YsecButton className="w-100 text-nowrap cursor_text">SL - {leaveCounts?.SL}</YsecButton>
                </Col>
                <Col xs={12} sm={4} md={3} className='gap-1 mt-1 mb-1'>
                  <YsecButton className="w-100 text-nowrap cursor_text">CL - {leaveCounts?.CL}</YsecButton>
                </Col>
                <Col xs={12} sm={4} md={3} className='gap-1 mt-1 mb-1'>
                  <YsecButton className="w-100 text-nowrap cursor_text">LOP - {leaveCounts?.LOP}</YsecButton>
                </Col>
                <Col xs={12} sm={4} md={3} className='gap-1 mt-1 mb-1'>
                  <YsecButton className="w-100 text-nowrap cursor_text">OTHER - {leaveCounts?.Others}</YsecButton>
                </Col>
              </Row>




            </Col>

            <Col xs={12} md={12} lg={3} className='gap-1 mt-1 mb-1' >
              <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                setSearchText(event.target.value);
              }} />
            </Col>
          </Row>

          <div className='katable' ref={printRef}>
            <Table
              columns={[
                { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
                { key: "emp_name", title: "Name", dataType: DataType.String, },
                { key: "leave_type", title: "Leave Type", dataType: DataType.String, },
                { key: "apply_date", title: "Apply Date", dataType: DataType.String, },
                { key: "from_date", title: "From Date", dataType: DataType.String, },
                { key: "to_date", title: "To Date", dataType: DataType.String, },
                { key: "days", title: "Days", dataType: DataType.String, }, { key: "hours", title: "Hours", dataType: DataType.String, },
                { key: "hours", title: "Hours", dataType: DataType.String, },
                { key: "remark", title: "Remarks", dataType: DataType.String, },
              ]}
              data={dataArray}
              rowKeyField={'id'}
              searchText={searchText}
              noData={{
                text: 'No Data Found'
              }}
            />
          </div>
        </div>
      </React.Suspense>
    </div>
  )
}
export default LeaveDetails;