import React, { useEffect, useRef, useState } from 'react';
import AxiosLayout from '../../apis/axios';
import './LeaveApprovalHistory.scss';

import { DataType, Table, useTableInstance } from 'ka-table';
import Modal from 'react-bootstrap/Modal';
import { Breadcrumb, Button } from 'react-bootstrap';
import { LogHistoryModal } from '../LeaveApprovals/CustomHistoryModal';
import LoadingSpinner from '../Loader/Loader';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));




const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value?.split(" ")[0] === "Approved" && 'approved') || (value?.split(" ")[0] === "Rejected" && 'rejected') || (value?.split(" ")[0] === "Open" && "open") || value?.split(" ")[0] === "Cancelled" && "cancelled" || value?.split(" ")[0] === "InProgress" && "open"}
        >
            {value}
        </div>
    );
};



function LeaveApprovalHistory() {
    const [searchText, setSearchText] = useState('');
    const [leaveDetails, setLeaveDetails] = useState([])
    const [openLogHistory, setOpenLogHistory] = useState(false)
    const [teamMembers, setTeamMembers] = useState([])
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [selectTeamMember, setSelectTeamMember] = useState(0);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const handleOpenLogHistory = () => setOpenLogHistory(!openLogHistory);
    const [selectedRowId, setSelectedRowId] = useState("")
const [loadingHistory, setLoadingHistory] = useState(false);
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(15); // Default items per page
    const printRef = useRef();
    useEffect(() => {
        getTeamData()
    }, []);
    const getTeamData = async () => {
        setLoading(true)

        await AxiosLayout.get(`/Leave/GetTeamMembers?ManagerId=${userId?.user}&CompanyId=${userId?.companyId}`).then((res) => {
            setTeamMembers(res.data);
            setLoading(false);
        });

    }
    // if (loading) return <p>Loading...</p>;
    if (error) return <p>Error: {error}</p>;
 
    useEffect(() => {
        
        getApproveLeaveHistory()
    }, [selectTeamMember])

    const getApproveLeaveHistory = async() => {
        setLoadingHistory(true)
       await AxiosLayout.get(`/Leave/GetApproveLeaveHistory?EmpId=${selectTeamMember}&ManagerId=${userId?.user}&CompanyId=${userId?.companyId}`).then((res) => {
            setLeaveDetails(res.data)
            setLoadingHistory(false)
        })
    }

   const dataArray = leaveDetails?.map(leave => ({
        employeeId: leave.EmployeeId,
        emp_name: leave.FullName,
        leave_type: leave.LeaveType,
        apply_date: leave.ApplyDate,
        from_date: leave.FromDate,
        to_date: leave.ToDate,
        hours: leave.Hours,
        days: leave.Days,

        remark: leave.Remark,

        status: leave.ApprovalStatus,
        id: leave.LeaveId
    }));

    const indexOfLastItem = currentPage * itemsPerPage;
    const indexOfFirstItem = indexOfLastItem - itemsPerPage;
    const currentData = dataArray;
    const paginatedData = currentData.slice(indexOfFirstItem, indexOfLastItem);
    const totalItems = dataArray.length;

    const startRange = indexOfFirstItem + 1;
    const endRange = Math.min(indexOfLastItem, totalItems);
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const pageNumbers = Array.from({ length: totalPages }, (_, index) => index + 1);




    const LogDetails = ({ rowKeyValue }) => {
        return (
            <>
                <Button size="sm" variant="link" className='history' onClick={() => {
                    setSelectedRowId(rowKeyValue)
                    handleOpenLogHistory()
                }}>Log Details</Button>
                {openLogHistory && <LogHistoryModal show={openLogHistory} open={openLogHistory} handleOpenLogHistory={handleOpenLogHistory} leaveId={rowKeyValue} selectedRowId={selectedRowId} />}
            </>
        )
    }
    const handlePrint = () => {
        const printContents = printRef.current.innerHTML;
        const printWindow = window.open('', '', 'height=600,width=800');
        printWindow.document.write('<html><head><title>Leave Application History</title>');
        // Optional: Add your styles here, or link to your CSS file
        printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
        printWindow.document.write('</head><body >');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    };
    return (
        <div className="p-1">
            {loading === true && <LoadingSpinner show={loading} />}
            <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
                <div className='header d-flex row flex-wrap'>
                    <div class="col">
                        <Breadcrumb>
                            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
                            <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
                            <Breadcrumb.Item active>Leave Application History</Breadcrumb.Item>
                        </Breadcrumb>
                    </div>

                    <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

                        <ysecButton type="button" className={`sm  history`} onClick={() => {
                            setSelectTeamMember(0)
                            setTeamMembers([])
                            setSearchText("")
                            getTeamData()
                        }}>
                            <YsecFont className="yf-clock" />
                        </ysecButton>
                        <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
                            <YsecFont className="yf-printer-scan" />
                        </YsecButton>
                    </div>
                </div>

                <div className='leavecontainerr'>
                    <div class="d-flex flex-wrap row m-1 p-2 bg-white">
                        <div class="col-12 col-sm-6 col-md-4  p-1">

                            <YsecSelect className="md"
                                objectNameKey="Name"
                                objectValueKey="EmployeeId"
                                data={[
                                    { EmployeeId: 0, Name: "Select All" },
                                    ...teamMembers.map(leave => ({
                                        EmployeeId: leave.EmployeeId,
                                        Name: leave.Name
                                    }))
                                ]}
                                onChange={(e) => setSelectTeamMember(e.target.value)}
                            />
                        </div>
                        <div class="col-12 col-sm-6 col-md-8 p-1">
                            <YsecInput className="md" placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                                setSearchText(event.target.value);
                            }} />
                        </div>

                        <div className='katable' ref={printRef}>
                             {loadingHistory && <LoadingSpinner />}
                            <Table
                                columns={[
                                    { key: "employeeId", title: "Employee Id", dataType: DataType.String, },
                                    { key: "emp_name", title: "Employee Name", dataType: DataType.String, },
                                    { key: "leave_type", title: "Leave Type", dataType: DataType.String, },
                                    { key: "apply_date", title: "Applied Date", dataType: DataType.String, },
                                    { key: "from_date", title: "From Date", dataType: DataType.String, },
                                    { key: "to_date", title: "To Date", dataType: DataType.String, },
                                    { key: "hours", title: "Hours", dataType: DataType.String, },
                                    { key: "days", title: "Days", dataType: DataType.String, },
                                    { key: "remark", title: "Description", dataType: DataType.String, },

                                    { key: "status", title: "Approval Status", dataType: DataType.String, },
                                    { key: ":action", title: "Log Details", dataType: DataType.String, },
                                ]}
                                data={paginatedData}
                                rowKeyField={'id'}
                                searchText={searchText}
                                noData={{
                                    text: 'No Data Found'
                                }}
                                childComponents={{
                                    cellText: {
                                        content: (props) => {
                                            switch (props.column.key) {
                                                case ':action':
                                                    return <LogDetails {...props} />
                                                case 'status':
                                                    return <CustomCell  {...props} />
                                                default:
                                                    return props.children;
                                            }

                                        },
                                    },


                                }}


                            />
                        </div>

                        <div className='pagination'>
                            <span className='pageselect'>
                                <YsecSelect
                                    objectNameKey="pageDescription"
                                    objectValueKey="pageNumber"
                                    data={pageNumbers.map(number => ({
                                        pageNumber: number,
                                        pageDescription: `Page ${number.toString()}`
                                    }))}
                                    className="sm"
                                    onChange={(e) => {
                                        const selectedPage = Number(e.target.value);
                                        setCurrentPage(selectedPage);
                                    }}
                                />
                            </span>

                            <span>{startRange}-{endRange} of {totalItems}</span>
                            <YsecFont className={`yf-chevron-left ${totalItems === 0 || currentPage === 1 ? 'disabled' : ''}`}
                                onClick={() => {
                                    if (currentPage > 1) {
                                        setCurrentPage(prev => prev - 1);
                                    }
                                }}
                            />
                            <YsecFont className={`yf-chevron-right ${totalItems === 0 || currentPage >= totalPages ? 'disabled' : ''}`}
                                onClick={() => {
                                    if (currentPage < totalPages) {
                                        setCurrentPage(prev => prev + 1);
                                    }
                                }}
                            />
                        </div>
                    </div>
                </div>
            </React.Suspense>
        </div>
    )
}
export default LeaveApprovalHistory;