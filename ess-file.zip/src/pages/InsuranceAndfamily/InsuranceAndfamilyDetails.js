import React, { useEffect, useRef, useState } from 'react'
import { Breadcrumb } from 'react-bootstrap';
import './insurance.scss'
import { DataType, Table, useTableInstance } from 'ka-table';
import AxiosLayout from '../../apis/axios';
import LoadingSpinner from '../Loader/Loader';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
function InsuranceAndfamilyDetails() {
  const userId = JSON.parse(localStorage.getItem('_user'));
  const [searchText, setSearchText] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [empIns, setEmpIns] = useState([])
  const [familyIns, setFamilyIns] = useState([])
  const printRef = useRef();
  useEffect(() => {
    getData()
  }, [])
  const getData = () => {
    setLoading(true)
    AxiosLayout.get(`/Employee/GetInsAndFamilyDetails?EmployeeId=${userId?.user}`).then(res => {
      if (res.status === 200) {
        if (res.data.EmpIns !== null) {
          setEmpIns(res.data.EmpIns)
        }
        if (res.data.Family !== null) {
          setFamilyIns(res.data?.Family)
        }
        setLoading(false)
      }
    })
  }
  // if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error}</p>;
  const dataArray = empIns?.map(
    (i, index) => ({
      employee: i.Employee,
      copany_name: i.CompanyName,
      ins_amt: i.InsuranceAmount,
      currency: i.Currency,
      start_date: i.StartDate,
      end_date: i.EndDate,
      id: index,
    }),
  );

  const dataArray2 = familyIns.map(
    (i, index) => ({
      fullName: i.FullName,
      relation: i.Relation,
      married_name: i.MarriedName,
      dob: i.DateOfBirth,
      marital_status: i.MaritalStatus,
      id_num: i.IDNumber,
      address: i.Address,
      district: i.District,
      country: i.Country,
      id: index,
    }),
  );
  const handlePrint = () => {
    const printContents = printRef.current.innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    printWindow.document.write('<html><head><title>Insurance And Family Details</title>');
    // Optional: Add your styles here, or link to your CSS file
    printWindow.document.write('<style>table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ccc; padding: 8px; }</style>');
    printWindow.document.write('</head><body >');
    printWindow.document.write(printContents);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
    printWindow.close();
  };
  return (
    <div className='p-1'>
      {loading === true && <LoadingSpinner show={loading} />}
      <React.Suspense fallback={<><LoadingSpinner show={loading} /></>}>
        <div className='header d-flex row flex-wrap'>
          <div class="col">
            <Breadcrumb  >
              <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
              <Breadcrumb.Item href="#">ESS</Breadcrumb.Item>
              <Breadcrumb.Item href="#">Personal Information</Breadcrumb.Item>
              <Breadcrumb.Item active>Insurance And family</Breadcrumb.Item>
            </Breadcrumb>
          </div>
          <div className='col d-flex justify-content-end align-items-center m-1 gap-1'>

            <ysecButton type="button" className={`sm history`} onClick={() => {
              setSearchText("")
              getData()
            }}>
              <YsecFont className="yf-clock" />
            </ysecButton>
            <YsecButton type="button" className="sm btn-outline-primary" onClick={handlePrint}>
              <YsecFont className="yf-printer-scan" />
            </YsecButton>
          </div>
        </div>

        <div className='containerr'>

          <div class="d-flex flex-wrap row m-1 p-2 bg-white">
            <div class="col-12 col-sm-12 p-1">
              <YsecInput placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
                setSearchText(event.target.value);
              }} />
            </div>
          </div>
          <div ref={printRef}>
            <div className='katable'>
              <p className='head'>Insurance Details</p>
              <Table
                columns={[
                  { key: 'employee', title: 'Employee', dataType: DataType.String },
                  { key: 'copany_name', title: 'Company Name', dataType: DataType.String },
                  { key: 'ins_amt', title: 'Insurance Amount', dataType: DataType.String },
                  { key: 'currency', title: 'Currency', dataType: DataType.String },
                  { key: 'start_date', title: 'Start Date', dataType: DataType.String },
                  { key: 'end_date', title: 'End Date', dataType: DataType.String },
                ]}
                data={dataArray}
                rowKeyField={'id'}
                searchText={searchText}
                noData={{
                  text: 'No Data Found'
                }}
              />
            </div>
            <div className='katable'>
              <p className='head'>Family Members</p>
              <Table
                columns={[
                  { key: 'fullName', title: 'Full Name', dataType: DataType.String },
                  { key: 'relation', title: 'Relation', dataType: DataType.String },
                  { key: 'married_name', title: 'Married Name', dataType: DataType.String },
                  { key: 'dob', title: 'Date of Birth', dataType: DataType.String },
                  { key: 'marital_status', title: 'Marital Status', dataType: DataType.String },
                  { key: 'id_num', title: 'ID Number', dataType: DataType.String },
                  { key: 'address', title: 'Address', dataType: DataType.String },
                  { key: 'district', title: 'District', dataType: DataType.String },
                  { key: 'country', title: 'Country', dataType: DataType.String },
                ]}
                data={dataArray2}
                rowKeyField={'id'}
                searchText={searchText}
                noData={{
                  text: 'No Data Found'
                }}
              />
            </div>
          </div>
        </div>
      </React.Suspense>
    </div>
  )
}

export default InsuranceAndfamilyDetails