import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Route, Routes, useParams } from "react-router-dom";
import AxiosLayout from "./apis/axios";

const SamplePage = React.lazy(() => import("./pages/samplePage/SamplePage"));
const NotFound = React.lazy(() => import("./pages/NotFound"));
const PersonalDetails = React.lazy(() => import("./pages/PersonalDetails/PersonalDetails"));
const LeaveApplicationDetails = React.lazy(() => import('./pages/LeaveApplicationDetails/leaveApplicationDetails'))
const LeaveApproval = React.lazy(() => import('./pages/LeaveApprovals/LeaveApproval'))
const GenericRequest = React.lazy(() => import('./pages/GenericRequest/GenericRequest'))
const LeaveApprovalHistory = React.lazy(() => import('./pages/LeaveApprovalHistory/LeaveApprovalHistory'))
const StaffAdvanceRequest = React.lazy(() => import('./pages/StaffAdvanceRequest/StaffAdvanceRequest'))
const AdvanceApprovals = React.lazy(() => import('./pages/AdvanceApprovals/AdvanceApprovals'))
const AdvanceApprovalHistory = React.lazy(() => import('./pages/AdvanceApprovalHistory/AdvanceApprovalHistory'))
const Attendance = React.lazy(() => import('./pages/MyAttendance/MyAttendance'))
const LeaveDetails = React.lazy(() => import('./pages/LeaveDetails/LeaveDetails'))
const Feeds = React.lazy(() => import('./pages/Feeds/Feeds'))
const Dashboard = React.lazy(() => import('./pages/Dashboard/Dashboard'))
const StaffSummary = React.lazy(() => import('./pages/StaffSummary/StaffSummary'))
const HolidayList = React.lazy(() => import('./pages/HolidayList/HolidayList'))
const EmployeeScoreRate = React.lazy(() => import('./pages/Performance/EmployeeScoreRate'))
const MontEvalOutputReport = React.lazy(() => import('./pages/Performance/MonthEvalReport'))
const SelfEvolution = React.lazy(() => import('./pages/Performance/SelfEvolution'))
const MemberEvolution = React.lazy(() => import('./pages/Performance/MemberEvolution'))
const AttendenceReport = React.lazy(() => import('./pages/Reports/Attendance_Report'))
const SummaryReport = React.lazy(() => import('./pages/Reports/Summary_Report'))
const ApplyLetter=React.lazy(()=>import('./pages/ApplyLetter/ApplyLetterData'))
const Meeting=React.lazy(()=>import("./pages/Meeting/Meeting"))
const InsuranceAndfamilyDetails=React.lazy(()=>import("./pages/InsuranceAndfamily/InsuranceAndfamilyDetails"))
const PensionDetails=React.lazy(()=>import("./pages/PensionDetails/PensionDetails"))
const LetterApproval=React.lazy(()=>import("./pages/ApplyLetter/LetterApproval"))
const CompOff=React.lazy(()=>import("./pages/LeaveApplicationDetails/CompOffData"))
const StaffSummaryAll= React.lazy(() => import('./pages/StaffSummary/StaffSummaryAll'))
const LeaveDetailsAll = React.lazy(() => import('./pages/LeaveDetails/LeaveDetailsAll'))
const LeaveDetailsApprovals=React.lazy(()=>import('./pages/Reports/LeaveDetailsApprovals'))
const CompOffApprovals=React.lazy(()=>import("./pages/LeaveApprovals/CompOffApprovals"))
const RouterESS = () => {
  const EncryptFun = (ID) => {
    return ID ? btoa(ID) : null;
  };
  const { user } = useSelector((state) => state.user);
  AxiosLayout.defaults.baseURL = user?.apiUrls?.apiURL; 

  // AxiosLayout.defaults.baseURL = 'https://demo.ysecit.in:10497/YESSAPI'

  let { productID } = useParams();
  useEffect(() => {
    const fetchToken = async () => {
      if (user?.apiUrls?.apiURL) {
        try {
          // const res = await AxiosLayout.get(user?.apiUrls?.apiURL + `Login/GenerateToken?UserId=${user.user}`);
          const res = await AxiosLayout.get(`Login/GenerateToken?UserId=${user.user}`);
         
          if (res.status === 200) {
            // AxiosLayout.defaults.headers.common = { 'ESSAuthorization': `${res.data}` }
            AxiosLayout.defaults.headers.common['ESSAuthorization'] = res.data;
          }
        } catch (error) {
          console.error("Error generating token:", error);
        }
      }
    };

    fetchToken();
  }, [user]);
  return (
    EncryptFun(user?.apiUrls?.productId) == productID && <Routes>
      {/* <Route
        index
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <SamplePage />
          </React.Suspense>
        }
      /> */}

      <Route
        index
        element={
          <React.Suspense fallback={<>Loading...</>}>

            <Dashboard />

          </React.Suspense>
        }
      />
      <Route
        path="not-found"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <NotFound />
          </React.Suspense>
        }
      />
      <Route
        path="personal-details"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <PersonalDetails />
          </React.Suspense>
        }
      />
      <Route
        path="leave-applications"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <LeaveApplicationDetails />
          </React.Suspense>
        }
      />
      <Route
        path="leave-approval"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <LeaveApproval />
          </React.Suspense>
        }
      />
      <Route
        path="generic-request"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <GenericRequest />
          </React.Suspense>
        }
      />
      <Route
        path="leave-approval-history"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <LeaveApprovalHistory />
          </React.Suspense>
        }
      />
      <Route
        path="staff-advance"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <StaffAdvanceRequest />
          </React.Suspense>
        }
      />
      <Route
        path="advance-approval"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <AdvanceApprovals />
          </React.Suspense>
        }
      />
      <Route
        path="advance-approval-history"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <AdvanceApprovalHistory />
          </React.Suspense>
        }
      />
      <Route
        path="my-attendance"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <Attendance />
          </React.Suspense>
        }
      />
      <Route
        path="leave-details"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <LeaveDetails />
          </React.Suspense>
        }
      />
      <Route
        path="feeds"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <Feeds />
          </React.Suspense>
        }
      />
      <Route
        path="staff-summary"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <StaffSummary />
          </React.Suspense>
        }
      />
      <Route
        path="holiday-list"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <HolidayList />
          </React.Suspense>
        }
      />

      <Route
        path="employee-score-rate"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <EmployeeScoreRate />
          </React.Suspense>
        }
      />
      <Route
        path="monthly-evaluation-report"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <MontEvalOutputReport />
          </React.Suspense>
        }
      />
      <Route
        path="self-evaluation"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <SelfEvolution />
          </React.Suspense>
        }
      />
      <Route
        path="member-evaluation"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <MemberEvolution />
          </React.Suspense>
        }
      />
      <Route
        path="attendance-report"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <AttendenceReport />
          </React.Suspense>
        }
      />
      <Route
        path="summary-report"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <SummaryReport />
          </React.Suspense>
        }
      />
      <Route
        path="apply-letter"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <ApplyLetter />
          </React.Suspense>
        }
      />
      <Route
        path="meeting-minutes"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <Meeting />
          </React.Suspense>
        }
      />
      <Route
        path="insurance-and-family"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <InsuranceAndfamilyDetails />
          </React.Suspense>
        }
      />
      <Route
        path="pension-details"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <PensionDetails />
          </React.Suspense>
        }
      />
            <Route
        path="letter-approval"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <LetterApproval />
          </React.Suspense>
        }
      />
   <Route
        path="comp-off"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <CompOff />
          </React.Suspense>
        }
      />
   <Route
        path="staff-summary-all"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <StaffSummaryAll />
          </React.Suspense>
        }
      />
      <Route
        path="leave-details-all"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <LeaveDetailsAll />
          </React.Suspense>
        }
      />
      <Route
        path="leave-approval-details"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <LeaveDetailsApprovals />
          </React.Suspense>
        }
      />
       <Route
        path="comp-off-approval"
        element={
          <React.Suspense fallback={<div>Loading...</div>}>
            <CompOffApprovals />
          </React.Suspense>
        }
      />
    </Routes>
  );
};

export default RouterESS;
