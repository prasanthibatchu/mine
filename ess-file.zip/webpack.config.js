const HtmlWebPackPlugin = require("html-webpack-plugin");
const ModuleFederationPlugin = require("webpack/lib/container/ModuleFederationPlugin");
// const Dotenv = require('dotenv-webpack');
const deps = require("./package.json").dependencies;
const path = require('path');
module.exports = (_, argv) => ({
  output: {
    // publicPath: "http://localhost:9013/", 

    publicPath: "https://demo.ysecit.in:10497/",
    filename: '[name].[contenthash].js',
    path: path.resolve(__dirname, 'dist'),   
    clean: true 
  },
  resolve: {
    extensions: [".tsx", ".ts", ".jsx", ".js", ".json"],
  },

  devServer: {
    port: 9013,
    historyApiFallback: true,
  },

  module: {
    rules: [
      {
        test: /\.m?js/,
        type: "javascript/auto",
        resolve: {
          fullySpecified: false,
        },
      },
      {
        test: /\.(css|s[ac]ss)$/i,
        use: ["style-loader", "css-loader", "postcss-loader"],
      },
      {
        test: /\.(ts|tsx|js|jsx)$/,
        exclude: /node_modules/,
        use: {
          loader: "babel-loader",
        },
      },
      {
        test: /\.(png|svg|jpg)$/,
        type: "asset/resource",
      },
      {
        test: /\.svg$/,
        use: ["@svgr/webpack", "url-loader"],
      },
    ],
  },  

  plugins: [
    new ModuleFederationPlugin({
      name: "ESS",
      filename: "remoteEntry.js",
      remotes: { Layout: "Layout@https://gp.ysecit.in:10488/remoteEntry.js" },
      exposes: {
        "./RouterESS": "./src/RouterESS.js",
        './ESS_Store':"./src/redux/app/ESS_Store.js"
      },
      shared: {
       ...deps,
        react: {
        singleton: true,
        requiredVersion: deps.react,
        },
        "react-dom": {
        singleton: true,
        requiredVersion: deps["react-dom"],
        },
        "react-router-dom": {
        singleton: true,
        requiredVersion: deps["react-router-dom"],
        },
        "react-redux": {
        singleton: true,
        requiredVersion: deps["react-redux"],
        },
        "@reduxjs/toolkit": {
        singleton: true,
        requiredVersion: deps["@reduxjs/toolkit"],
        },
        "react-toastify": {
        singleton: true,
        requiredVersion: deps["react-toastify"],
        },
      },
    }),
    new HtmlWebPackPlugin({
      template: "./src/index.html",
    }),
    // new Dotenv()
  ],
});
