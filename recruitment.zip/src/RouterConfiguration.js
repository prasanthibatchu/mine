import React from "react";
import { Route, Routes } from "react-router-dom";
const RouterConfiguration = ({ RequireAuth, Layout, LayoutType }) => {
  const RouterRecruitment= React.lazy(() => import("./RouterRecruitment"));
  const NotFound = React.lazy(() => import("./pages/NotFound"));
  return (
    <Routes>
      <Route element={<RequireAuth />}>
        <Route path="/" element={<Layout LayoutType={LayoutType} />}>
        <Route
            path="/recruitment/:companyID/:productID/*"
            element={
              <React.Suspense fallback={<>Loading...</>}>
                <RouterRecruitment/>
              </React.Suspense>
            }
          />    
            
        </Route>
      </Route>
    </Routes>
  );
};

export default RouterConfiguration;
