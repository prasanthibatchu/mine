import React from "react";
import { createRoot } from "react-dom/client";
import "./index.scss";
import { Provider } from "react-redux";
import SetAuth from "./SetAuth";
import initStore from "./redux/app/store";

const App = () => {
  return <SetAuth />;
};
const container = document.getElementById("app");
const root = createRoot(container);
initStore().then((Store) => {
  root.render(
    <Provider store={Store}>
      <App />
    </Provider>
  );
});
