import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Route, Routes, useParams } from "react-router-dom";
import AxiosLayout from "./apis/axios";
const SamplePage = React.lazy(() => import("./pages/samplePage/SamplePage"));
const NotFound = React.lazy(() => import("./pages/NotFound"));
const Dashboard = React.lazy(() => import('./pages/Dashboard/Dashboard'))
const JobOpenings=React.lazy(()=>import("./pages/Home/JobOpenings"))
const Screening=React.lazy(()=>import("./pages/Home/Screening"))

const RouterRecruitment = () => {
  const [loading, setLoading] = useState(true);
  const EncryptFun = (ID) => {
    return ID ? btoa(ID) : null;
  };
  const { user } = useSelector((state) => state.user);
  // AxiosLayout.defaults.baseURL = user?.apiUrls?.apiURL; 

  AxiosLayout.defaults.baseURL = 'https://demo.ysecit.in:10497/RecruitmentAPI'

  let { productID } = useParams();
   useEffect(() => {
    const fetchToken = async () => {
      if (user.user !== "") {
        try {
          const res = await AxiosLayout.get(`Login/GenerateToken?UserId=${user.user}`);
          if (res.status === 200) {
            AxiosLayout.defaults.headers.common['RECAuthorization'] = res.data;
          }
        } catch (error) {
          console.error("Error generating token:", error);
        } finally {
          setLoading(false); // Ensure loading is set to false after fetching token
        }
      } else {
        setLoading(false); // Handle case where user is empty
      }
    };

    fetchToken();
  }, [user]);

  if (loading) {
    return <div>Loading...</div>; // Show a loading state while fetching the token
  }
//   useEffect(() => {
//     const fetchToken = async () => {
//       if (user.user !== "") {
//         try {
//           // const res = await AxiosLayout.get(user?.apiUrls?.apiURL + `Login/GenerateToken?UserId=${user.user}`);
//           const res = await AxiosLayout.get(`Login/GenerateToken?UserId=${user.user}`);
         
//           if (res.status === 200) {
// localStorage.setItem("rec",res.data)
//             AxiosLayout.defaults.headers.common['RECAuthorization'] = res.data;
//           }
//         } catch (error) {
//           console.error("Error generating token:", error);
//         }
//       }
//     };

//     fetchToken();
//   }, [user]);
//   console.log(productID,EncryptFun(user?.apiUrls?.productId) )
// debugger;
  return (
    EncryptFun(user?.apiUrls?.productId) !== productID && 
    <Routes>


      <Route
        index
        element={
          <React.Suspense fallback={<>Loading...</>}>
           

            <Dashboard />

          </React.Suspense>
        }
      />
      <Route
        path="not-found"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <NotFound />
          </React.Suspense>
        }
      />
       <Route
        path="job-openings"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <JobOpenings />
          </React.Suspense>
        }
      />
       <Route
        path="screeining"
        element={
          <React.Suspense fallback={<>Loading...</>}>
            <Screening />
          </React.Suspense>
        }
      />

    </Routes>
  );
};

export default RouterRecruitment;
