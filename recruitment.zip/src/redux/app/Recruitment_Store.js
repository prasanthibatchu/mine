import counter  from "../feature/SampleSlice";

const store =  {counter} 
export default store;