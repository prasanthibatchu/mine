import RouterConfiguration from "./RouterConfiguration";
import { useDispatch } from "react-redux";
import { useEffect } from "react";
import { BrowserRouter } from "react-router-dom";
import RequireAuth from "./RequireAuth";
import LayoutRecruitment from "./layout/LayoutRecruitment";
const getUser = () => {
  let _user = localStorage.getItem("_user");
  if (_user) _user = JSON.parse(_user);
  else _user = null;
  return _user;
};
const SetAuth = () => {
  const dispatch = useDispatch();
  let userDispatch = async () => {
    let _user = getUser();
    const updateUserDetails = await import("Layout/UserDetailsSlice").then(
      (module) => module?.updateUserDetails
    );
    if (_user) {
      dispatch(updateUserDetails(_user));
    }
  };
  useEffect(() => {
    userDispatch();
    return;
  }, []);
  return (
    <BrowserRouter>
      <RouterConfiguration RequireAuth={RequireAuth} Layout={LayoutRecruitment} />
    </BrowserRouter>
  );
};

export default SetAuth;
