
 
export const BASE_URL_IMAGE = '';
const axios_ = {
    AxiosLayout: await import("Layout/AxiosLayout").then(
      (module) => module?.default
    ),
  };
export default axios_.AxiosLayout;



