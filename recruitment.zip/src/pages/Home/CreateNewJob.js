import React, { useRef, useState } from 'react'
import { Col, Form, ProgressBar, Row } from 'react-bootstrap';


const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
  const YsecCheckbox = React.lazy(() => import("Layout/YsecCheckbox2"));

export const CreateNewJob = (props) => {
    const [files, setFiles] = useState([]);
    const [over, setOver] = useState(false);
    const [jobId, setJobId] = useState(68)
    const [data, setData] = useState({ title: "", job_type: "", experience_level: "", close_date: "", status: 1, qualification_level: "", description: "", skills: "" })
      const [publishInPortal, setPublishInPortal] = useState(false); 
    const [internalPosting, setInternalPosting] = useState(false); 
    const [selectedJob,setSelectedJob]=useState("")
    const inputRef = useRef(null);
    const MAX_FILES = 89;
    // Handle file selection
    const handleFileChange = (e) => {
        const selectedFiles = Array.from(e.target.files);
        setFiles((prevFiles) => [...prevFiles, ...selectedFiles].slice(0, MAX_FILES));
    };

    // Handle file drop
    const handleDrop = (e) => {
        e.preventDefault();
        const droppedFiles = Array.from(e.dataTransfer.files);
        setFiles((prevFiles) => [...prevFiles, ...droppedFiles].slice(0, MAX_FILES));
        setOver(false);
    };

    // Remove a specific file
    const handleRemoveFile = (index) => {
        const newFiles = [...files];
        newFiles.splice(index, 1);
        setFiles(newFiles);
    };

    // Calculate progress percentage
    const calculateProgress = () => {
        return Math.min((files.length / MAX_FILES) * 100, 100);
    };
    const handleChange = (e) => {
        setData({ ...data, [e.target.name]: e.target.value })
    }
    return (
        <div className='p-3'>
            <React.Suspense fallback={<>Loading...</>}>
            <h5>
                <YsecFont className="yf-job jobicon" /> Create New Job
            </h5>
            <Row className='mt-4 mb-4'>
                <Col xs={12} md={3} className='mb-2'>
                <YsecInput name="selectedJob" value={selectedJob} />
                </Col>
                <Col xs={12} md={2} className='mb-2'>
                <YsecButton>View JD</YsecButton>
                </Col>
            </Row>
                <Row>
                    <Col xs={12} md={6}>
                        <div>
                            <p
                                onClick={() => inputRef.current.click()}
                                onDrop={handleDrop}
                                onDragOver={(e) => {
                                    e.preventDefault();
                                    setOver(true);
                                }}
                                onDragLeave={(e) => {
                                    e.preventDefault();
                                    setOver(false);
                                }}
                                className={`${over ? 'blue_border p-2' : 'normal_border p-2'}`}
                            >
                                <div><YsecFont className={`yf-upload-cloud pe-1 cloudicon`} /></div>
                                Drag & Drop or Click to choose files
                            </p>
                            <input
                                type="file"
                                hidden
                                ref={inputRef}
                                multiple
                                onChange={handleFileChange}
                            />
                        </div>
                    </Col>
                    <Col xs={12} md={6}>
                        <div className="filesdata bg-white p-2">
                            {files.length > 0 && (
                                <>
                                    {files.map((file, index) => (
                                        <Row key={file.name + index} className="">
                                            <Col xs={9} className="mb-1">
                                                {file.name}
                                            </Col>
                                            <Col xs={2} className="mb-1 d-flex">
                                            <YsecFont className="yf-edit-view-eye pe-2" />

                                                <YsecFont className="yf-delete-bin-2 deletebin" onClick={(e) => {
                                                    e.stopPropagation();
                                                    handleRemoveFile(index);
                                                }} />
                                                <div className="ps-2">
                                                <YsecCheckbox />
</div>
                                            </Col>
                                        </Row>
                                    ))}
                                </>
                            )}
                        </div>
                        <Row className='pt-2'>
                            <Col xs={12} sm={9}>
                                <ProgressBar variant="success" now={calculateProgress()} />
                            </Col>
                            <Col xs={12} sm={3}>
                                {files.length}/{MAX_FILES} UPLOADED
                            </Col>
                        </Row>

                    </Col>
                </Row>

                <Row>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput name={"jobId"} value={jobId} mandatory label="Job Id(auto generate)" disabled />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecInput name={"title"} value={data.title} mandatory label="Job Title" onChange={handleChange} />
                    </Col>
                    <Col xs={12} md={6} lg={3}>

                        <YsecSelect label="Job Type" mandatory name="job_type"
                            className="select"
                            objectNameKey="jobdesc"
                            objectValueKey="jobtypeid"
                            data={[
                                { jobtypeid: "", jobdesc: "Select Leave Type" },
                                { jobtypeid: "", jobdesc: "Select L" },
                            ]}
                            onChange={handleChange}
                        />
                    </Col>
                    <Col xs={12} md={6} lg={3}>

                        <YsecSelect label="Experience level" mandatory name="experience_level"
                            className="select"
                            objectNameKey="expdesc"
                            objectValueKey="expid"
                            data={[
                                { expid: "", expdesc: "Select Leave Type" },
                                { expid: "", expdesc: "Select L" },
                            ]}
                            onChange={handleChange}
                        />
                    </Col>
                    <Col xs={12} md={6} lg={3}>
                        <YsecDatePicker name="close_date"
                            value={data?.close_date}
                            className="md"
                            placeholderText="Select Date"
                            label="Closing Date"
                            mandatory="true"
                            error="test message"
                            onChange={handleChange}
                            placeholder="placeholder"
                            ysecType="tab"
                            ysecFormat="D-MM-YYYY"
                            ysecMinDate="10_D"
                            ysecMaxDate="1000_Y" />
                    </Col>
                    <Col xs={12} md={6} lg={3}>

                        <YsecSelect label="Status" name="status"
                            className="select"
                            objectNameKey="statusdesc"
                            objectValueKey="status_id"
                            data={[
                                { status_id: 1, statusdesc: "Active" },
                                { status_id: 2, statusdesc: "InActive" },
                            ]}
                            onChange={handleChange}
                        />
                    </Col>
                    <Col xs={12} md={6} lg={3}>

                        <YsecSelect label="Qualification Level" name="qualification_level"
                            className="select"
                            objectNameKey="Qual_desc"
                            objectValueKey="qual_id"
                            data={[
                                { qual_id: 1, Qual_desc: "Active" },
                                { qual_id: 2, Qual_desc: "InActive" },
                            ]}
                            onChange={handleChange}
                        />
                    </Col>
                    <Col xs={12} md={6} lg={6}>
                        <YsecTextarea label="Description" mandatory name="description" value={data.description} onChange={handleChange} />
                    </Col>
                    <Col xs={12} md={6} lg={6}>
                        <YsecTextarea label="Skills" mandatory name="skills" value={data.skills} onChange={handleChange} />
                    </Col>
                    <Col xs={12} lg={3} className='mt-3'>
                        <Form.Check
                            type="switch"
                            id="publish-switch"
                            label="To Publish in Company Portal"
                            checked={publishInPortal}
                            onChange={(e) => setPublishInPortal(e.target.checked)}
                        />
                    </Col>
                    <Col xs={12} lg={4} className='mt-3'>
                        <Form.Check
                            type="switch"
                            id="internal-posting-switch"
                            label="Internal Posting by Mails"
                            checked={internalPosting}
                            onChange={(e) => setInternalPosting(e.target.checked)}
                        />
                    </Col>
                </Row>
                <div className='d-flex'>
                    <YsecButton className="d-flex text-nowrap m-2 save">Save & Publish</YsecButton>
                    <YsecButton className="m-2 save">Save</YsecButton>
                    <YsecButton className="m-2 cancel" type="button" onClick={props?.handleCreate}>Cancel</YsecButton>
                </div>


            </React.Suspense>
        </div>
    )
}
