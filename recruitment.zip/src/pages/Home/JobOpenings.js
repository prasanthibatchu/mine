import React, { useEffect, useState } from 'react'
import './Home.scss'
import { Breadcrumb, Col, Row } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';
import { DataType, Table } from 'ka-table';
import { UploadNewCV } from './UploadNewCV';
import { CreateNewJob } from './CreateNewJob';
import { ViewResumeData } from './ViewResumeData';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));

const CustomCell = ({ column, rowKeyValue, value }) => {

    return (
        <div
            className={(value?.split(" ")[0] === "Rejected" && 'rejected') || (value?.split(" ")[0] === "Open" && "open") || value?.split(" ")[0] === "Cancelled" && "cancelled" || value?.split(" ")[0] === "Approved" && 'approved' || value?.split(" ")[0] === "InProgress" && "inprogress" || value?.split(" ")[0] === "Closed" && "cancelled"}
        >
            {value}
        </div>
    );
};




function JobOpenings() {
    const userId = JSON.parse(localStorage.getItem('_user'));
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [showUpload, setShowUpload] = useState(false);
    const [selectedJobId, setSelectedJobId] = useState(null)
    const [createnew,setCreateNew]=useState(false)
    const [jobData,setJobData]=useState([])
    const [selectJobData,setSelectedJobData]=useState([])
    const [viewResume,setViewResume]=useState(false)
    const handleUpload = () => {
        setShowUpload(!showUpload);
    };
    const handleCreate=()=>{
        setCreateNew(!createnew)
    }
    const handleViewResume=()=>{
        setViewResume(!viewResume)
    }
    useEffect(() => {
        // AxiosLayout.get( AxiosLayout.get(`/JobOpening/GetJobOpenCommonData?CompanyId=${userId?.companyId}`
        AxiosLayout.get(`/JobOpening/GetJobOpening?CompanyId=${69}`

        ).then((res) => {
            if(res.status===200){
                setJobData(res.data)
            }
        })
    }, [])
    const dataArray =jobData.map(
        (i, index) => ({
            job_code: i.JobId,
            title: i.JobTitle,
            experience: i.ExperienceLevel,
            qualification: i.QualificationLevel,
            skills:i.Skills,
            description: i.Description,
            resume: i.ResumeCount+'resume',
            status: i.JobStatus,
            close_date: i.ClosingDate?.split("T")[0],
            id: i.JobId,
        }),
    );

    const UploadResume = ({ rowKeyValue, status }) => {


        return (<div className='d-flex align-items-center justify-content-center'>
            <YsecButton type="button" disabled={status === "Closed"} className={`${status === "Closed" && "closebtn"}`} onClick={() => {
                const data=jobData.filter(i=>i.JobId===Number(rowKeyValue))                
                setSelectedJobData(data)
                setSelectedJobId(rowKeyValue)
                handleUpload()
            }}><YsecFont className={`yf-upload-cloud pe-1 `} />Upload CV</YsecButton>
        </div>)

    }
    const ViewResume = ({ rowKeyValue, resume }) => {
    return (
        <div onClick={()=>{
            const data=jobData.filter(i=>i.JobId===Number(rowKeyValue))                
                setSelectedJobData(data)
            handleViewResume()}} className='viewresume'>
            {resume}
        </div>
    )
}
    return (
        <div className="p-1">
            <React.Suspense fallback={<>Loading...</>}>
                {/* {alertMessage && (
                        <div class="alert alert-success" role="alert">
                            {alertMessage}
                        </div>
                    )} */}
                <div className='header'>
                    <Breadcrumb>
                        <Breadcrumb.Item href="#">Recruitment</Breadcrumb.Item>
                        <Breadcrumb.Item href="#">Home</Breadcrumb.Item>
                        <Breadcrumb.Item active>Job Openings</Breadcrumb.Item>
                    </Breadcrumb>
                </div>
                {createnew===true?<><CreateNewJob handleCreate={handleCreate}/></>:<>
                {viewResume===true? <ViewResumeData  selectJobData={selectJobData}/>:<>
                {showUpload === true ? <UploadNewCV selectedJobId={selectedJobId} handleUpload={handleUpload} selectJobData={selectJobData}/> :
                    <div className='mt-3 home-container p-3'>
                        <Row>
                            <Col xs={12} md={6} className='d-flex opening'>
                                <YsecFont className="yf-job jobicon" /><h6>Job Opening</h6>
                            </Col>
                            <Col xs={12} md={6} className='d-flex justify-content-end' >
                                <YsecButton type="button" onClick={handleCreate}>Create New Job</YsecButton>
                            </Col>
                        </Row>
                        <div className='katable'>
                            <Table
                                columns={[
                                    { key: 'job_code', title: 'Job Code', dataType: DataType.String },
                                    { key: 'title', title: 'Job Title', dataType: DataType.String },
                                    { key: 'experience', title: 'Experience', dataType: DataType.String },
                                    { key: 'qualification', title: 'Qualification', dataType: DataType.String },
                                    { key: 'skills', title: 'Skills', dataType: DataType.String },
                                    { key: 'description', title: 'Description', dataType: DataType.String },
                                    { key: 'resume', title: 'Resume / CV', dataType: DataType.String },
                                    { key: 'status', title: 'Status', dataType: DataType.String },
                                    { key: 'upload_resume', title: 'Upload Resume/CV', dataType: DataType.String },
                                    { key: 'close_date', title: 'Closing Date', dataType: DataType.String },
                                ]}
                                data={dataArray}
                                rowKeyField={'id'}
                                // oddEvenRows={true}
                                noData={{
                                    text: 'No Data Found'
                                }}
                                childComponents={{
                                    cellText: {
                                        content: (props) => {
                                            switch (props.column.key) {
                                                case 'resume':
                                                    return <ViewResume {...props} resume={props.rowData.resume} />;
                                                case 'status':
                                                    return <CustomCell  {...props} />
                                                case 'upload_resume':
                                                    return <UploadResume {...props} status={props.rowData.status}  />;
                                                default:
                                                    return props.children;
                                            }

                                        },
                                    },


                                }}
                            />
                        </div>

                    </div>
                }</>}
                </>}

            </React.Suspense>
        </div>
    )
}

export default JobOpenings