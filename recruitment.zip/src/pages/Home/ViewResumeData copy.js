// // import React, { useEffect, useState } from 'react'
// // import { Col, Row } from 'react-bootstrap'
// // import AxiosLayout from '../../apis/axios'
// // import Mammoth from 'mammoth';
// // const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
// // const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
// // const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
// // const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
// // const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
// // const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
// // const YsecFont = React.lazy(() => import("Layout/YsecFont"));
// // export const ViewResumeData = (props) => {
// //     const [resumedata, setResumeData] = useState([])
// //     const [selectedFilePath, setSelectedFilePath] = useState(null);
// //     const [fileContent, setFileContent] = useState(null);
// //     useEffect(() => { getJobData() }, [])
// //     const getJobData = () => {
// //         AxiosLayout.get(`/JobOpening/GetUploadedResumes?JobId=${Number(props?.selectJobData[0]?.JobId)}&CompanyId=${69}`).then(res => {
// //             if (res.status === 200) {
// //                 setResumeData(res.data)
// //             }
// //         })
// //     }

// //        const handleFileClick = (filePath) => {
// //         setSelectedFilePath(filePath); // Always set the file path when clicked
// //     };
// //     return (
// //         <div className='p-3'>
// //             <React.Suspense fallback={<>Loading...</>}>
// //                 <h5>Resumes's / {resumedata?.JobTitle}</h5>
// //                 <div className='katable2'>
// //                     <table>
// //                         <tr>
// //                             <td><h6>Skills</h6>
// //                                 <div>{resumedata?.Skills}</div></td>

// //                             <td>
// //                                 <div>Experience Required</div>
// //                                 <div>{resumedata?.ExperienceLevel}</div>
// //                             </td>

// //                             <td><div>Job Type</div>
// //                                 <div>{resumedata?.JobTitle}</div></td>
// //                             <td>
// //                                 <div>Closing Date</div>
// //                                 <div>{resumedata?.ClosingDate}</div>
// //                             </td>
// //                         </tr>
// //                     </table></div>
// //                 <h6>Description</h6>
// //                 <p dangerouslySetInnerHTML={{ __html: resumedata.JobDescription }} />
// //                 <Row>
// //                     <Col xs={12} md={6}>
// //                         <div className='katable2'>
// //                             <table>
// //                                 <thead>
// //                                     <tr>
// //                                         <th>Column Item</th>
// //                                         <th>Status</th>
// //                                     </tr>
// //                                 </thead>
// //                                 <tbody>
// //                                     {resumedata?.JobFiles?.map((i) => (
// //                                         <tr key={i.ApplicationId}>
// //                                             <td key={i.FilePath}><p onClick={() => handleFileClick(i.FilePath)}>{i.FileName}</p></td>
// //                                             <td className='d-flex'>
// //                                                 <YsecRadio
// //                                                     label={"Open"}
// //                                                     value={i?.FileStatus === 0}
// //                                                     checked={i.FileStatus === 0}
// //                                                 />
// //                                                 <YsecRadio
// //                                                     label={"Yes"}
// //                                                     value={i?.FileStatus === 1}
// //                                                     checked={i.FileStatus === 1}
// //                                                 />
// //                                                 <YsecRadio
// //                                                     label={"No"}
// //                                                     value={i?.FileStatus === 2}
// //                                                     checked={i.FileStatus === 2}
// //                                                 />

// //                                             </td>
// //                                         </tr>
// //                                     ))}
// //                                 </tbody>
// //                             </table>
// //                         </div>
// //                     </Col>
// //                     <Col xs={12} md={6}>
// //                         {selectedFilePath && (
// //                             <div>
// //                                 {selectedFilePath.endsWith('.pdf')? (
// //                                     // Embed PDF in an iframe
// //                                     <iframe
// //                                         src={selectedFilePath}
// //                                         title="PDF Viewer"
// //                                         style={{ width: "100%", height: "500px" }}
// //                                     ></iframe>
// //                                 ):<>{selectedFilePath?.endsWith('.docx') && (
// //                                 // Display DOCX content
// //                                 <div style={{ whiteSpace: "pre-wrap", border: "1px solid #ccc", padding: "10px" }}>
// //                                     <iframe src={selectedFilePath} title='Doc Viewer' />
// //                                 </div>
// //                             )}</>}
// //                             </div>)}
                       
// //                     </Col>
// //                 </Row>
// //             </React.Suspense>
// //         </div>
// //     )
// // }


// import React, { useEffect, useState } from 'react';
// import { Col, Row } from 'react-bootstrap';
// import AxiosLayout from '../../apis/axios';
// import Mammoth from 'mammoth';

// const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));

// export const ViewResumeData = (props) => {
//     const [resumedata, setResumeData] = useState([]);
//     const [selectedFilePath, setSelectedFilePath] = useState(null);
//     const [fileContent, setFileContent] = useState(null); // State for extracted file content

//     useEffect(() => {
//         getJobData();
//     }, []);

//     const getJobData = () => {
//         AxiosLayout.get(`/JobOpening/GetUploadedResumes?JobId=${Number(props?.selectJobData[0]?.JobId)}&CompanyId=${69}`).then(res => {
//             if (res.status === 200) {
//                 setResumeData(res.data);
//             }
//         });
//     };
// const handleFileClick = async (filePath) => {
//     setSelectedFilePath(filePath);

//     if (filePath.endsWith('.docx')) {
//         try {
//             const response = await fetch(filePath);

//             if (!response.ok) {
//                 throw new Error(`HTTP error! status: ${response.status}`);
//             }

//             const fileBlob = await response.blob();
//             const arrayBuffer = await fileBlob.arrayBuffer();

//             // Extract text from the .docx file using Mammoth.js
//             Mammoth.extractRawText({ arrayBuffer })
//                 .then((result) => setFileContent(result.value))
//                 .catch((err) => {
//                     console.error("Error parsing DOCX file:", err);
//                     setFileContent(
//                         "Could not display content. Please download the file and view it locally."
//                     );
//                 });
//         } catch (error) {
//             console.error("Error fetching DOCX file:", error);
//             setFileContent(
//                 <p>
//                     Unable to fetch the file. You can <a href={filePath} target="_blank">download it here</a>.
//                 </p>
//             );
//         }
//     } else if (filePath.endsWith('.pdf')) {
//         setFileContent(`${filePath}#toolbar=0`);
//     } else {
//         setFileContent("Preview not available for this file type.");
//     }
// };
    

//     return (
//         <div className='p-3'>
//             <React.Suspense fallback={<>Loading...</>}>
//                 <h5>Resumes's / {resumedata?.JobTitle}</h5>
//                 <div className='katable2'>
//                     <table>
//                         <tr>
//                             <td><h6>Skills</h6>
//                                 <div>{resumedata?.Skills}</div></td>

//                             <td>
//                                 <div>Experience Required</div>
//                                 <div>{resumedata?.ExperienceLevel}</div>
//                             </td>

//                             <td><div>Job Type</div>
//                                 <div>{resumedata?.JobTitle}</div></td>
//                             <td>
//                                 <div>Closing Date</div>
//                                 <div>{resumedata?.ClosingDate}</div>
//                             </td>
//                         </tr>
//                     </table>
//                 </div>
//                 <h6>Description</h6>
//                 <p dangerouslySetInnerHTML={{ __html: resumedata.JobDescription }} />
//                 <Row>
//                     <Col xs={12} md={6}>
//                         <div className='katable2'>
//                             <table>
//                                 <thead>
//                                     <tr>
//                                         <th>Column Item</th>
//                                         <th>Status</th>
//                                     </tr>
//                                 </thead>
//                                 <tbody>
//                                     {resumedata?.JobFiles?.map((i) => (
//                                         <tr key={i.ApplicationId}>
//                                             <td key={i.FilePath}>
//                                                 <p
//                                                     style={{
//                                                         color: "blue",
//                                                         textDecoration: "underline",
//                                                         cursor: "pointer"
//                                                     }}
//                                                     onClick={() => handleFileClick(i.FilePath)}
//                                                 >
//                                                     {i.FileName}
//                                                 </p>
//                                             </td>
//                                             <td className='d-flex'>
//                                                 <YsecRadio
//                                                     label={"Open"}
//                                                     value={i?.FileStatus === 0}
//                                                     checked={i.FileStatus === 0}
//                                                 />
//                                                 <YsecRadio
//                                                     label={"Yes"}
//                                                     value={i?.FileStatus === 1}
//                                                     checked={i.FileStatus === 1}
//                                                 />
//                                                 <YsecRadio
//                                                     label={"No"}
//                                                     value={i?.FileStatus === 2}
//                                                     checked={i.FileStatus === 2}
//                                                 />
//                                             </td>
//                                         </tr>
//                                     ))}
//                                 </tbody>
//                             </table>
//                         </div>
//                     </Col>
//                     <Col xs={12} md={6}>
//                         {selectedFilePath && (
//                             <div>
//                                 {selectedFilePath.endsWith('.pdf') ? (
//                                     // Embed PDF with toolbar hidden
//                                     <iframe
//                                         src={fileContent}
//                                         title="PDF Viewer"
//                                         style={{ width: "100%", height: "500px" }}
//                                     ></iframe>
//                                 ) : selectedFilePath.endsWith('.docx') ? (
//                                     // Display extracted DOCX content
//                                     <div style={{ whiteSpace: "pre-wrap", border: "1px solid #ccc", padding: "10px" }}>
//                                         {fileContent || "Loading..."}
//                                     </div>
//                                 ) : (
//                                     // Handle other unsupported file types
//                                     <p>{fileContent}</p>
//                                 )}
//                             </div>
//                         )}
//                     </Col>
//                 </Row>
//             </React.Suspense>
//         </div>
//     );
// };

import React, { useEffect, useState } from 'react';
import { Col, Row } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';
import DocViewer, { DocViewerRenderers } from "react-doc-viewer";

const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));

export const ViewResumeData = (props) => {
    const [resumedata, setResumeData] = useState([]);
    const [selectedFilePath, setSelectedFilePath] = useState(null);

    useEffect(() => {
        getJobData();
    }, []);

    const getJobData = () => {
        AxiosLayout.get(`/JobOpening/GetUploadedResumes?JobId=${Number(props?.selectJobData[0]?.JobId)}&CompanyId=${69}`).then(res => {
            if (res.status === 200) {
                setResumeData(res.data);
            }
        });
    };

    const handleFileClick = (filePath) => {
        setSelectedFilePath(filePath); // Set the selected file path
    };

    const renderFileViewer = () => {
        if (!selectedFilePath) {
            return <p>Select a file to view its content.</p>;
        }

        if (selectedFilePath.endsWith('.pdf')) {
            return (
                <div>
                    <iframe
                        src={`${selectedFilePath}#toolbar=0`}
                        title="PDF Viewer"
                        style={{ width: "100%", height: "500px", border: "1px solid #ccc" }}
                    ></iframe>
                </div>
            );
        }

        if (selectedFilePath.endsWith('.docx')) {
            return (
                <div>
                    <h6>DOCX File Viewer</h6>
                    <DocViewer
                        documents={[{ uri: selectedFilePath }]} // Provide the file URI
                        pluginRenderers={DocViewerRenderers} // Use default renderers
                        style={{ width: "100%", height: "500px", border: "1px solid #ccc" }}
                    />
                </div>
            );
        }

        return (
            <p>
                Unsupported file format. You can <a href={selectedFilePath} target="_blank" rel="noopener noreferrer">download the file here</a>.
            </p>
        );
    };

    return (
        <div className='p-3'>
            <React.Suspense fallback={<>Loading...</>}>
                <h5>Resumes's / {resumedata?.JobTitle}</h5>
                <div className='katable2'>
                    <table>
                        <tr>
                            <td><h6>Skills</h6>
                                <div>{resumedata?.Skills}</div></td>

                            <td>
                                <div>Experience Required</div>
                                <div>{resumedata?.ExperienceLevel}</div>
                            </td>

                            <td><div>Job Type</div>
                                <div>{resumedata?.JobTitle}</div></td>
                            <td>
                                <div>Closing Date</div>
                                <div>{resumedata?.ClosingDate}</div>
                            </td>
                        </tr>
                    </table>
                </div>
                <h6>Description</h6>
                <p dangerouslySetInnerHTML={{ __html: resumedata.JobDescription }} />
                <Row>
                    <Col xs={12} md={6}>
                        <div className='katable2'>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Column Item</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {resumedata?.JobFiles?.map((i) => (
                                        <tr key={i.ApplicationId}>
                                            <td key={i.FilePath}>
                                                <p
                                                   
                                                    onClick={() => handleFileClick(i.FilePath)}
                                                >
                                                    {i.FileName}
                                                </p>
                                            </td>
                                            <td className='d-flex'>
                                                <YsecRadio
                                                    label={"Open"}
                                                    value={i?.FileStatus === 0}
                                                    checked={i.FileStatus === 0}
                                                />
                                                <YsecRadio
                                                    label={"Yes"}
                                                    value={i?.FileStatus === 1}
                                                    checked={i.FileStatus === 1}
                                                />
                                                <YsecRadio
                                                    label={"No"}
                                                    value={i?.FileStatus === 2}
                                                    checked={i.FileStatus === 2}
                                                />
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Col>
                    <Col xs={12} md={6}>
                        {renderFileViewer()}
                    </Col>
                </Row>
            </React.Suspense>
        </div>
    );
};