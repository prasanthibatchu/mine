import React, { useEffect, useState } from 'react';
import { Col, Modal, Row } from 'react-bootstrap';
import AxiosLayout from '../../apis/axios';
import Mammoth from 'mammoth';
import './Home.scss'

const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
export const ViewResumeData = (props) => {
    const [resumedata, setResumeData] = useState([]);
    const [selectedFilePath, setSelectedFilePath] = useState(null);
    const [fileContent, setFileContent] = useState(null);
    const [open, setOpen] = useState(false)
    const [remarks, setRemarks] = useState("")
const [filestatus, setFileStatus] = useState({});
    useEffect(() => {
        getJobData();
    }, []);

    const getJobData = () => {
        AxiosLayout.get(`/JobOpening/GetUploadedResumes?JobId=${Number(props?.selectJobData[0]?.JobId)}&CompanyId=${69}`).then(res => {
            if (res.status === 200) {
                setResumeData(res.data);
            }
        });
    };
    const handleFileClick = async (filePath) => {
        setSelectedFilePath(filePath);

        if (filePath.endsWith('.docx')) {
            try {
                const response = await fetch(filePath);

                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }

                const fileBlob = await response.blob();
                const arrayBuffer = await fileBlob.arrayBuffer();

                // Extract text from the .docx file using Mammoth.js
                Mammoth.extractRawText({ arrayBuffer })
                    .then((result) => setFileContent(result.value))
                    .catch((err) => {
                        console.error("Error parsing DOCX file:", err);
                        setFileContent(
                            "Could not display content. Please download the file and view it locally."
                        );
                    });
            } catch (error) {
                console.error("Error fetching DOCX file:", error);
                setFileContent(
                    <p>
                        Unable to fetch the file. You can <a href={filePath} target="_blank">download it here</a>.
                    </p>
                );
            }
        } else if (filePath.endsWith('.pdf')) {
            setFileContent(`${filePath}#toolbar=0`);
        } else {
            setFileContent("Preview not available for this file type.");
        }
    };

    const handleOpen = () => {
        setOpen(!open)
    }
 // Function to handle radio button change
const handleRadioChange = (applicationId, newValue) => {
    setFileStatus((prevState) => ({
        ...prevState,
        [applicationId]: newValue,
    }));
};
const handleSave=()=>{
    
}
    return (
        <div className='p-3'>
            <React.Suspense fallback={<>Loading...</>}>
                <Row>
                    <Col xs={12} md={8} lg={9} className='d-flex opening'>
                        <YsecFont className="yf-job jobicon" /><h6>Resumes'(s) / {resumedata?.JobTitle}</h6>
                    </Col>
                    <Col xs={12} md={4} lg={3} className='d-flex justify-content-md-end justify-content-start'>
                        <YsecButton className="ms-1 me-1 text-nowrap outlinedbtn" type="button" onClick={handleOpen}>View JD</YsecButton>
                        <YsecButton className="ms-1 me-1">Screening</YsecButton>
                    </Col>
                </Row>

                <div className='katable2'>
                    <table>
                        <tr>
                            <td><p className='subtitle'>Skills</p>
                                <div>{resumedata?.Skills}</div></td>

                            <td>
                                <p className='subtitle'>Experience Required</p>
                                <div>{resumedata?.ExperienceLevel}</div>
                            </td>

                            <td><p className='subtitle'>Job Type</p>
                                <div>{resumedata?.JobTitle}</div></td>
                            <td>
                                <p className='subtitle'>Closing Date</p>
                                <div className='dangertxt'>{resumedata?.ClosingDate}</div>
                            </td>
                        </tr>
                    </table>
                </div>
                <p className='subtitle'>Description</p>
                <p dangerouslySetInnerHTML={{ __html: resumedata.JobDescription }} />
                <Row>
                    <Col xs={12} md={6}>
                        <div className='katable2'>
                            <table>
                                <thead>
                                    <tr>
                                        <th>Column Item</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {resumedata?.JobFiles?.map((i) => (
                                        <tr key={i.ApplicationId}>
                                            <td key={i.FilePath}>
                                                <p className={`${selectedFilePath === i.FilePath && "selectedfile"}`}
                                                    onClick={() => handleFileClick(i.FilePath)}
                                                >
                                                    {i.FileName}
                                                </p>
                                            </td>
                                            <td className='d-flex'>
                                                 <YsecRadio
                    label={"Open"}
                    value={0}
                    checked={filestatus[i.ApplicationId] === 0}
                    onChange={() => handleRadioChange(i.ApplicationId, 0)}
                />
                <YsecRadio
                    label={"Yes"}
                    value={1}
                    checked={filestatus[i.ApplicationId] === 1}
                    onChange={() => handleRadioChange(i.ApplicationId, 1)}
                />
                <YsecRadio
                    label={"No"}
                    value={2}
                    checked={filestatus[i.ApplicationId] === 2}
                    onChange={() => handleRadioChange(i.ApplicationId, 2)}
                />
                                                {/* <YsecRadio
                                                    label={"Open"}
                                                    value={i?.FileStatus === 0}
                                                    checked={i.FileStatus === 0}
                                                />
                                                <YsecRadio
                                                    label={"Yes"}
                                                    value={i?.FileStatus === 1}
                                                    checked={i.FileStatus === 1}
                                                />
                                                <YsecRadio
                                                    label={"No"}
                                                    value={i?.FileStatus === 2}
                                                    checked={i.FileStatus === 2}
                                                /> */}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </Col>
                    <Col xs={12} md={6}>

                        {selectedFilePath && (
                            <div>
                                <>
                                    {selectedFilePath.endsWith('.pdf') ? (
                                        // Embed PDF with toolbar hidden
                                        <iframe
                                            src={fileContent}
                                            title="PDF Viewer"
                                            style={{ width: "100%", height: "500px" }}
                                        ></iframe>
                                    ) : selectedFilePath.endsWith('.docx') ? (
                                        // Display extracted DOCX content
                                        <div style={{ whiteSpace: "pre-wrap", border: "1px solid #ccc", padding: "10px" }}>
                                            {fileContent || "Loading..."}
                                        </div>
                                    ) : (

                                        <></>
                                    )}</>
                                <div>
                                    <YsecTextarea name="remarks" value={remarks} label="Remarks / Notes" mandatory onChange={(e) => setRemarks(e.target.value)} className="mt-3" />
                                    <div className='d-flex mt-2 justify-content-end'>
                                        <YsecButton className="cancel p-2 m-1">Cancel</YsecButton>
                                        <YsecButton className=" p-2 m-1">Submit</YsecButton>
                                    </div>

                                </div>
                            </div>
                        )}
                    </Col>
                </Row>
                {open === true &&
                    <Modal
                        show={open}
                        size="lg"
                        aria-labelledby="contained-modal-title-vcenter"
                        centered
                    >
                        <Modal.Header>
                            <p className="modal-title" id="exampleModalLabel">View Job</p>
                            <button type="button" className="btn-close" onClick={handleOpen} aria-label="Close"></button>
                        </Modal.Header>
                        <Modal.Body>
                            {/* <p dangerouslySetInnerHTML={{ __html: resumedata.JobDescription }} /> */}
                            <div
                                style={{
                                    maxHeight: "500px",
                                    overflowY: "auto",
                                    padding: "10px",
                                    border: "1px dashed #ccc",
                                    borderRadius: "5px",
                                    backgroundColor: "#f9f9f9",
                                }}
                                dangerouslySetInnerHTML={{ __html: resumedata.JobDescription }}
                            />
                        </Modal.Body>


                        <Modal.Footer className="d-flex justify-content-between align-items-center">
                            <p className="mb-0">{resumedata?.JobTitle}</p>
                            <YsecButton type="button" onClick={handleOpen}>OK</YsecButton>

                        </Modal.Footer>

                    </Modal>}
            </React.Suspense>
        </div>
    );
};