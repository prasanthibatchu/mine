
import React, { useRef, useState } from 'react';
import { Col, ProgressBar, Row } from 'react-bootstrap';
import Mammoth from 'mammoth';

const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));

export const UploadNewCV = (props) => {
    const [files, setFiles] = useState([]);
    const [over, setOver] = useState(false);
     const [selectedFile, setSelectedFile] = useState(null); 
      const [selectedFileContent, setSelectedFileContent] = useState(null);
    const inputRef = useRef(null);
    const MAX_FILES = 89; // Maximum number of files

    // Handle file selection
    const handleFileChange = (e) => {
        const selectedFiles = Array.from(e.target.files);
        setFiles((prevFiles) => [...prevFiles, ...selectedFiles].slice(0, MAX_FILES));
    };

    // Handle file drop
    const handleDrop = (e) => {
        e.preventDefault();
        const droppedFiles = Array.from(e.dataTransfer.files);
        setFiles((prevFiles) => [...prevFiles, ...droppedFiles].slice(0, MAX_FILES));
        setOver(false);
    };

    // Remove a specific file
    const handleRemoveFile = (index) => {
        const newFiles = [...files];
        newFiles.splice(index, 1);
        setFiles(newFiles);
    };

    // Calculate progress percentage
    const calculateProgress = () => {
        return Math.min((files.length / MAX_FILES) * 100, 100);
    };
 const handleFilePreview = async (file) => {
        if (file.type === "application/vnd.openxmlformats-officedocument.wordprocessingml.document") {
            try {
                const arrayBuffer = await file.arrayBuffer();
                const result = await Mammoth.extractRawText({ arrayBuffer });
                setSelectedFileContent(result.value); // Set extracted plain text
            } catch (error) {
                console.error("Error extracting text from .docx file:", error);
                setSelectedFileContent("Error: Unable to preview this .docx file.");
            }
        } else if (file.type === "application/pdf") {
            const fileURL = URL.createObjectURL(file); // Create a blob URL for PDF preview
            setSelectedFileContent(
                <iframe
                    src={fileURL}
                    title="PDF Preview"
                    style={{ width: "100%", height: "300px" }}
                ></iframe>
            );
        } else {
            setSelectedFileContent("Unsupported file format.");
        }
    };


    return (
        <div className='p-3'>
            <h5><YsecFont className="yf-job jobicon" /> {props?.selectJobData[0]?.JobTitle} Resume's</h5>
            <Row className='mb-3'>
                <Col xs={12} md={6} className="borderr">
                <h6>Skills</h6>   
                <div>{props?.selectJobData[0]?.Skills}</div>
                </Col>
                <Col xs={12} md={2} className="borderr">
                <div>Experience Required</div>
                <div>{props?.selectJobData[0]?.ExperienceLevel}</div>
                </Col>
                <Col xs={12} md={2} className="borderr">
                <div>Job Type</div>
                <div>{props?.selectJobData[0]?.Department}</div>
                </Col>
                <Col xs={12} md={2}>
                <div>Closing Date</div>
                <div>{props?.selectJobData[0]?.ClosingDate?.split("T")[0]}</div>
                </Col>
            </Row>
            <h5><YsecFont className="yf-job jobicon" /> Upload Resume/CV</h5>
            <div className='pt-3 pb-3'>
                <Row>
                    <Col xs={12} md={6}>
                                <p
                onClick={() => inputRef.current.click()}
                onDrop={handleDrop}
                onDragOver={(e) => {
                    e.preventDefault();
                    setOver(true);
                }}
                onDragLeave={(e) => {
                    e.preventDefault();
                    setOver(false);
                }}
                className={`${over ? 'blue_border p-2' : 'normal_border p-2'}`}
            >
                <div><YsecFont className={`yf-upload-cloud pe-1 cloudicon`} /></div>
                Drag & Drop or Click to choose files
            </p>
            <input
                type="file"
                hidden
                ref={inputRef}
                multiple
                onChange={handleFileChange}
            />
                    </Col>
                    <Col xs={12} md={6}>
                    {/* //here i want to display selected file show from uploadf files */}
                  {selectedFileContent && (
                            <div className="file-preview">
                                <div style={{ whiteSpace: "pre-wrap", border: "1px solid #ccc", padding: "10px" }}>
                                    {typeof selectedFileContent === "string" ? selectedFileContent : selectedFileContent}
                                </div>
                            </div>
                        )}
                    </Col>
                    <Col xs={12} md={6} className=''>
                                <div className="filesdata2 bg-white">
                {files.length > 0 && (
                    <>
                        {files.map((file, index) => (
                            <Row key={file.name + index} className="">
                                <Col xs={10} className="mb-1" onClick={() => handleFilePreview(file)} style={{ cursor: "pointer" }}>
                                    {file.name}
                                </Col>
                                <Col xs={1} className="mb-1">
                                    {/* <YsecButton
                                        type="button"
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            handleRemoveFile(index);
                                        }}
                                        className="delete_icon"
                                    > */}
                                        <YsecFont className="yf-delete-bin-2 deletebin"  onClick={(e) => {
                                            e.stopPropagation();
                                            handleRemoveFile(index);
                                        }}/>
                                    {/* </YsecButton> */}
                                </Col>
                            </Row>
                        ))}
                    </>
                )}
            </div>
   <Row  className='pt-2'>
                <Col xs={12} sm={10}>
                <ProgressBar variant="success" now={calculateProgress()}  />
                </Col>
                <Col xs={12} sm={2}>
                {files.length}/{MAX_FILES} UPLOADED
                </Col>
            </Row>
            
           <Row>
            <Col xs={6} sm={2} md={1}>
            <YsecButton>Save</YsecButton>
            </Col>
            <Col xs={6} sm={2} md={1}>
            <YsecButton type={"button"} className="cancel" onClick={props.handleUpload}>Cancel</YsecButton>
            </Col>
           </Row>
                    </Col>
                </Row>

         

           </div>
        </div>
    );
};