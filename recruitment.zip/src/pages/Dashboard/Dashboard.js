import React, { useState } from "react";
import './Dashboard.scss';
const YsecButton = React.lazy(() => import("Layout/YsecButton2"));
const YsecInput = React.lazy(() => import("Layout/YsecInput2"));
const YsecSelect = React.lazy(() => import("Layout/YsecSelect2"));
const YsecDatePicker = React.lazy(() => import("Layout/YsecDatePicker2"));
const YsecRadio = React.lazy(() => import("Layout/YsecRadio2"));
const YsecTextarea = React.lazy(() => import("Layout/YsecTextarea2"));
const YsecFont = React.lazy(() => import("Layout/YsecFont"));
const Dashboard = () => {
   const [searchText, setSearchText] = useState('');
  return (
    <div className="p-1">

      <React.Suspense fallback={<>Loading...</>}>
      <div className='containerr'>
      <div class="d-flex justify-content-center align-items-center p-2 text-align-center">
  <h5>Dashboard</h5>
</div>
<div class="d-flex flex-wrap row m-1 p-2 bg-white">
  
  <div class="col-12 col-sm-10 p-1">
    <YsecInput placeholder="Search" type="search" icon='yf-search' value={searchText} onChange={(event) => {
      setSearchText(event.target.value);
    }} />
  </div>
  <div class="col-12 col-sm-2  p-1">
    <YsecButton className='btnn w-100'>Submit</YsecButton>
  </div>
</div>

      
      </div>
      </React.Suspense>
    </div>
  );
};
export default Dashboard;
