import React, { useEffect }  from "react";
import "./LayoutRecruitment.scss";

import { useNavigate, useParams } from "react-router-dom";
const LayoutRecruitment = () => {
const Layout = React.lazy(() => import("Layout/Layout"));  
let { companyID, productID } = useParams();
const navigate = useNavigate();




 return (
    <React.Suspense fallback={<div>Loading...</div>}>
      <Layout
        productId_={productID}
        companyId_={companyID}
        LayoutType="layoutRecruitment"      
      />
    </React.Suspense>
  );
};
export default LayoutRecruitment;
