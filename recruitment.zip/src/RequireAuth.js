import React from "react";
import { useSelector } from "react-redux";
import { Outlet } from "react-router-dom"; 
const Login = React.lazy(() => import("Layout/Login2"));
const RequireAuth = () => {
  const { user } = useSelector((state) => state.user);
  return ( user ?<Outlet />:<Login/>)
};

export default RequireAuth;
